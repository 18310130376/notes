# maneki

![Maneki Neko](./maneki-neko.png)

- Maneki-neko 是日本 [招财猫](https://en.wikipedia.org/wiki/Maneki-neko)
- 取招财猫, 寓意: `交易所`招财进宝, 日进斗金.

## 0. 代码结构:

- 核心入口: `exchange-server/maneki/apps`, 业务代码都在这里



```bash


├── CONTRIBUTORS.txt
├── LICENSE
├── README.md
├── compose
│   ├── local
│   └── production
├── config
│   ├── __init__.py
│   ├── settings
│   ├── urls.py
│   └── wsgi.py
├── docs
├── gulpfile.js
├── local.yml
├── manage.py
├── maneki
│   ├── __init__.py
	├── apps  / 所有业务单元
	│   ├── __init__.py
	│   ├── api_key       / API-key相关
	│   ├── constants.py
	│   ├── engine        / 与交易引擎通信
	│   ├── market        / 市场相关
	│   ├── transaction   / 交易相关
	│   ├── user_assets   / 用户资产
	│   ├── user_auth     / 用户登录授权
	│   └── user_kyc      / 用户KYC审核
	├── contrib
	│   ├── __init__.py
	│   └── sites
	├── static
	├── taskapp
	│   ├── __init__.py
	│   └── celery.py
	├── templates
	└── users   / 用户基础信息相关
├── maneki-neko.png
├── package.json
├── production.yml
├── pytest.ini
├── requirements
├── requirements.txt
├── setup.cfg
└── utility


```


## 0. 编码规范:

- [PEP8 - Style Guide for Python Code](https://www.python.org/dev/peps/pep-0008/)
- [Pylint](https://www.pylint.org/)
- [auto-pep8](https://github.com/hhatto/autopep8)
- [yapf](https://github.com/pre-commit/mirrors-yapf)
- [pre-commit](https://github.com/pre-commit/pre-commit)


## 1. Init

### 1.1 local run:


```bash
cd /exchange-server
pip install -r ./requirements.txt

# 创建超级用户:
python manage.py createsuperuser

# 数据迁移:
python manage.py makemigrations
python manage.py migrate

# run server:
python manage.py runserver 8800

# amdin: http://127.0.0.1:8800/admin/


# celery work:
cd maneki
celery -A maneki.taskapp worker -l info

# celery flower work Visualized celery task and broker
celery flower -A maneki.taskapp worker -l info

flower inspector
http://127.0.0.1:5555/tasks


```


- API 调试访问:
    - DRF自带API调试页: http://127.0.0.1:8800/api/v1/
    - swagger工具: http://127.0.0.1:8800/api/
    - 两个工具互补

- dev:

```bash

############################################
# 创建 app 目录:
############################################

cd /exchange-server
mkdir -p ./maneki/apps

# 交易:
mkdir -p ./maneki/apps/transaction
# 市场:
mkdir -p ./maneki/apps/market
#
mkdir -p ./maneki/apps/api_key

############################################
# 初始化 app 目录:
############################################

# 用户基础信息: 银行卡/地址/等等:
python manage.py startapp user_basic ./maneki/apps/user_basic
# 用户登录/授权:
python manage.py startapp user_auth ./maneki/apps/user_auth
# API-key:
python manage.py startapp api_key ./maneki/apps/api_key
# 用户基础信息: 银行卡/地址/等等:
python manage.py startapp user_basic ./maneki/apps/user_basic
# 用户KYC审核:
python manage.py startapp user_kyc ./maneki/apps/user_kyc
# 交易: 充值/提现
python manage.py startapp transaction ./maneki/apps/transaction
# 市场: 下单/k-线/
python manage.py startapp market ./maneki/apps/market
# 内部平台间资产转移:
python manage.py startapp assets_transfer ./maneki/apps/assets_transfer
# 与交易引擎通信:
python manage.py startapp engine ./maneki/apps/engine
# 监控报警:
python manage.py startapp alarm ./maneki/apps/alarm
# reconciliation(对账):
python manage.py startapp reconciliation ./maneki/apps/reconciliation

```


### 1.2 Email Server


- [mailhog - github](https://github.com/mailhog/MailHog)


- In development, it is often nice to be able to see emails that are being sent from your application.
- For that reason local SMTP server `MailHog`_ with a web interface is available as docker container.

- Container mailhog will start automatically when you will run all docker containers.
- Please check `cookiecutter-django Docker documentation`_ for more details how to start all containers.
- With MailHog running, to view messages that are sent by your application, open your browser and go to ``http://127.0.0.1:8025``




### 1.3 Sentry

- Sentry is an error logging aggregator service.
- You can sign up for a free account at  https://sentry.io/signup/?code=cookiecutter  or download and host it yourself.
- The system is setup with reasonable defaults, including 404 logging and integration with the WSGI application.
- You must set the DSN url in production.




## 2. Test


### 2.1 Test coverage


- To run the tests, check your test coverage, and generate an HTML coverage report::

```bash

    $ coverage run manage.py test
    $ coverage html
    $ open htmlcov/index.html


```

### 2.2 Running tests with py.test


```bash
  $ py.test

```




## 3. Deployment with Docker

- [deploy: use docker](http://cookiecutter-django.readthedocs.io/en/latest/deployment-with-docker.html)
