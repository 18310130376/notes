from rest_framework.status import *


"""

扩展 django-rest-framework 状态码:
    - rest_framework.status.is_server_error

"""

#########################################################
# 自定义状态码:
#########################################################


# 46X~499: is_client_error
HTTP_460_EMAIL_NOT_REGISTER = 460
#
