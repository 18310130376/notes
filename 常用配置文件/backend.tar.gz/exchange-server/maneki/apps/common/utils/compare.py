# -*- coding: utf-8 -*-
# @CreateDatetime    :2018/3/15:10:33
# @Author            :Helen
# @Product           :exchange-server
# @Description       :tool kits for compare tuple / list / dict


def compare_intersect(a, b):
    return frozenset(a).issubset(b)
