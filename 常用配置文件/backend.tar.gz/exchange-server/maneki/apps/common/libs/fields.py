from django.db import models


class UserRoleField(models.CharField):
    description = 'user role'

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 20
        super(UserRoleField, self).__init__(*args, **kwargs)


class IDField(models.CharField):
    description = 'common id field'

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 50
        super(IDField, self).__init__(*args, **kwargs)


class UIDField(models.CharField):
    description = 'ID of User'

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 50
        super(UIDField, self).__init__(*args, **kwargs)


class LabelCodeField(models.CharField):
    description = 'Label Code'

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 50
        super(LabelCodeField, self).__init__(*args, **kwargs)


class BIDField(models.CharField):
    description = 'ID of QuestionBundle'

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 50
        super(BIDField, self).__init__(*args, **kwargs)


class CityCodeField(models.CharField):
    description = 'Code of City'

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 10
        super(CityCodeField, self).__init__(*args, **kwargs)


class CodeField(models.CharField):
    description = 'Code'

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 50
        super(CodeField, self).__init__(*args, **kwargs)


class ScopeField(models.CharField):
    description = 'Scope'

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 100
        super(ScopeField, self).__init__(*args, **kwargs)


class StaffNameField(models.CharField):
    description = 'staff name'

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 30
        super(StaffNameField, self).__init__(*args, **kwargs)
