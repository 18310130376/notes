# -*- coding: utf-8 -*-
from django.db import models
from django.utils import timezone
from django.utils.translation import ugettext_lazy as _


# 自定义基类型:
class BaseModel(models.Model):
    created_at = models.DateTimeField(verbose_name=_("Created At"), auto_now_add=True)
    updated_at = models.DateTimeField(verbose_name=_("Updated At"), auto_now=True)

    class Meta:
        abstract = True

    @property
    def created_at_s(self):
        return int(self.created_at.timestamp())

    @property
    def updated_at_s(self):
        return int(self.updated_at.timestamp())

    @property
    def pending_duration(self):
        """记录 pending 时间差

        :return:
        """
        return abs(self.updated_at_s - self.created_at_s)

    def update_with_timestamp(self, **kwargs):
        kwargs["updated_at"] = timezone.now()
        return self.objects.update(**kwargs)


# 软删除:
class SoftDeleteModel(BaseModel):
    # soft delete
    is_deleted = models.BooleanField(verbose_name=_("Api Is Deleted"), default=False)
    deleted_at = models.DateTimeField(verbose_name=_("Deleted At"), default=None, blank=True, null=True)

    def soft_delete(self):
        self.is_deleted = True
        self.deleted_at = timezone.now()
        self.save()

    class Meta:
        abstract = True


# user 相关:
class UserBaseModel(BaseModel):
    user_id = models.UUIDField(verbose_name=_("User ID"), null=False, blank=False, db_index=True)

    class Meta:
        abstract = True

    @property
    def user_id_hex(self):
        return self.user_id.hex


# user 相关:
class UserSoftDeleteModel(SoftDeleteModel):
    user_id = models.UUIDField(verbose_name=_("User ID"), null=False, blank=False, db_index=True)

    class Meta:
        abstract = True

    @property
    def user_id_hex(self):
        return self.user_id.hex
