from django.test import TestCase
from maneki.apps.user_role.utils.cache import cache_permission_settings


class TestCachePermission(TestCase):

    def test_cache_permission(self):
        cache_permission_settings()

