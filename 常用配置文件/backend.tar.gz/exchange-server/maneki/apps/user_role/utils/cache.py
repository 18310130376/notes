import json
from collections import defaultdict

from maneki.apps.common.utils.redis.r import redis_sessions
from maneki.apps.user_role.models.perms import Permission, RolePermission


def make_key(route_path, permission_code):
    return "{}:{}".format(route_path, permission_code)


def get_role_permissions_dict():
    """
    {
        "permission_id": [role_id1, role_id2, role_id3]
    }
    """
    role_permissions = RolePermission.objects.filter(is_deleted=False).all()
    role_permissions_dict = defaultdict(list)
    for role_permission in role_permissions:
        role_permissions_dict[role_permission.permission_id].append(role_permission.role_id)

    return role_permissions_dict


def cache_permission_settings():
    permissions = Permission.objects.filter(is_deleted=False).all()
    role_permissions_dict = get_role_permissions_dict()
    for permission in permissions:
        key = make_key(permission.route_path, permission.permission_code)
        data = role_permissions_dict[permission.id]
        redis_sessions['Permission'].hset('permission_settings', key, json.dumps(data))


def get_permission_cache(key):
    data = redis_sessions['Permission'].hget('permission_settings', key)
    if not data:
        data = []

    data = json.loads(data)

    return data
