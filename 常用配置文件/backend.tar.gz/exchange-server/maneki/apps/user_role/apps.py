from django.apps import AppConfig


class UserRoleConfig(AppConfig):
    name = 'maneki.apps.user_role'
