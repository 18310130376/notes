import logging

from maneki.apps.user_role.models.role import RoleType

logger = logging.getLogger(__name__)


class RoleTypeService(object):

    def __init__(self):
        self.model = RoleType

    def get_role_code(self, role_id):
        role = self.model.objects.filter(id=role_id).first()
        if not role:
            return -1
        return role.role_code
