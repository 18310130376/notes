# -*- coding: utf-8 -*-
import django_filters
from maneki.apps.user_role.models.perms import RolePermission


class RolePermissionFilter(django_filters.FilterSet):
    role_id = django_filters.BaseInFilter(field_name="role_id")

    class Meta:
        model = RolePermission
        fields = ['role_id']
