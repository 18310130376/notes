# coding: utf-8
from collections import defaultdict
from rest_framework.viewsets import GenericViewSet
from rest_framework import permissions

from maneki.apps.common.mixins.rest.mixins import BetterListModelMixin, BetterCreateModelMixin
from maneki.apps.common.permissions.rest.permission_manage import StrictPermissionCheck
from maneki.apps.user_auth.utils.decode_device_str import decode_device_str
from maneki.apps.user_role.models.perms import Permission, RolePermission
from maneki.apps.user_role.models.role import RoleType
from .serializers.permission import ApiPermissionSerializer, RolePermissionSerializer
from .filters.role_permission import RolePermissionFilter
from maneki.apps.constants import ApiPermissionType
from maneki.apps.user.services import get_user_info_from_cache
from maneki.apps.constants import ApiPermissionTypeFront


class PermissionViewSet(BetterCreateModelMixin, BetterListModelMixin, GenericViewSet):
    serializer_class = ApiPermissionSerializer
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]
    pagination_class = None

    def get_queryset(self):
        return Permission.objects

    # 创建权限
    def do_create(self, request, serializer, instance, *args, **kwargs):
        result = self.response_result
        route_path = serializer.validated_data.get('route_path')
        permission_code = serializer.validated_data.get('permission_code')
        permission_name = serializer.validated_data.get('permission_name')

        is_exist = Permission.objects.filter(
            route_path=route_path,
            permission_code=permission_code
        ).first()

        if is_exist:
            result.update(
                code=450,
                detail="route path and code is exist"
            )
            return result

        obj = Permission.objects.create(
            route_path=route_path,
            permission_code=permission_code,
            permission_name="{}:{}".format(permission_name, ApiPermissionType.get_choice(permission_code).label)
        )

        return result

    # 查询权限列表
    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        result.update(data=serializer.data)
        return result


class RolePermissionViewSet(BetterCreateModelMixin, BetterListModelMixin, GenericViewSet):
    """给角色分配权限
    """
    serializer_class = RolePermissionSerializer
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]
    pagination_class = None

    def get_queryset(self):
        return RolePermission.objects

    def do_create(self, request, serializer, instance, *args, **kwargs):
        result = self.response_result
        role_id = serializer.data.get("role_id")
        permission_id = serializer.data.get("permission_id")

        role = RoleType.objects.filter(id=role_id).first()
        if not role:
            result.update(
                code=450,
                detail='role do not exist'
            )
            return result
        permission = Permission.objects.filter(id=permission_id).first()

        if not permission:
            result.update(
                code=450,
                detail='permission do not exist'
            )
            return result
        RolePermission.objects.get_or_create(
            role_id=role.id,
            permission_id=permission.id,
        )

        return result

    # Todo: 添加service
    def do_list(self, request, serializer, *args, **kwargs):
        """
        查看角色所具有的权限
        :param request:
        :param serializer:
        :param args:
        :param kwargs:
        :return:
        """
        result = self.response_result
        user = request.user
        # todo 获取设备信息
        # os@@version@@device_id 例如: ios@@1.0@@FCGTP1MXHFM3
        device_b64str = request.META.get('HTTP_X_AUTH_DEVICE', None)
        device_b64str = decode_device_str(device_b64str)
        user_info = get_user_info_from_cache(user, device_b64str)
        role_id = user_info.get('role_id', -1)
        role_permissions = RolePermission.objects.filter(role_id=role_id).all()
        permission_ids = {r.permission_id for r in role_permissions}
        permissions = Permission.objects.filter(id__in=permission_ids)

        permission_dict = defaultdict()
        for p in permissions:
            permission_dict[p.id] = p

        data = list()
        for role_perms in role_permissions:
            p = permission_dict.get(role_perms.permission_id)
            permission = dict(
                id=p.id,
                path=p.route_path,
                method=ApiPermissionTypeFront.get_choice(p.permission_code).label)
            data.append(permission)

        result.update(data=data)
        return result
