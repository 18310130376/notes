from rest_framework import serializers

from maneki.apps.user_role.models.perms import Permission, RolePermission
from maneki.apps.constants import ApiPermissionType


class ApiPermissionSerializer(serializers.ModelSerializer):
    route_path = serializers.CharField(required=True)
    permission_code = serializers.ChoiceField(ApiPermissionType.choices)
    permission_name = serializers.CharField()

    class Meta:
        model = Permission
        fields = ["id", "permission_name", "route_path", "permission_code"]


class RolePermissionSerializer(serializers.ModelSerializer):
    role_id = serializers.IntegerField()
    permission_id = serializers.IntegerField()

    class Meta:
        model = RolePermission
        fields = ["role_id", 'permission_id']

