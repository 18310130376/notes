from rest_framework import serializers

from maneki.apps.user_role.models.role import RoleType


class RoleSerializer(serializers.ModelSerializer):

    class Meta:
        model = RoleType
        fields = ["id", "role_code", "role_desc_cn", "role_desc_en", "group_code"]


class UserRoleSerializer(serializers.ModelSerializer):
    uid = serializers.UUIDField()
    role_id = serializers.IntegerField()

    class Meta:
        model = RoleType
        fields = ["role_id", "uid"]
