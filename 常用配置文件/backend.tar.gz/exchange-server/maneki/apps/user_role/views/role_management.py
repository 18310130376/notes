from rest_framework.viewsets import GenericViewSet
from rest_framework import permissions

from maneki.apps.user.services import UserService, UserProfileService
from maneki.apps.user_auth.utils.decode_device_str import decode_device_str
from maneki.apps.user_role.models.role import RoleType
from maneki.apps.common.mixins.rest.mixins import BetterListModelMixin, BetterCreateModelMixin
from .serializers.role import RoleSerializer, UserRoleSerializer
from maneki.apps.user.models import UserProfile
from maneki.apps.user.services import refresh_user_info
from maneki.apps.common.permissions.rest.permission_manage import StrictPermissionCheck


class RoleViewSet(BetterCreateModelMixin, BetterListModelMixin, GenericViewSet):
    """ 角色管理

    note:
         创建角色 查看所有角色

    """
    serializer_class = RoleSerializer
    pagination_class = None
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]

    def get_queryset(self):
        return RoleType.objects

    # 创建角色
    def do_create(self, request, serializer, instance, *args, **kwargs):
        result = self.response_result
        role_code = serializer.data.get('role_code')
        role_desc_cn = serializer.data.get('role_desc_cn')
        role_desc_en = serializer.data.get('role_desc_en')
        group_code = serializer.data.get('group_code')
        RoleType.objects.get_or_create(
            role_code=role_code,
            role_desc_cn=role_desc_cn,
            role_desc_en=role_desc_en,
            belongs_group=group_code
        )
        return result

    # 查询角色列表
    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        result.update(data=serializer.data)
        return result


class UserRoleViewSet(BetterCreateModelMixin, GenericViewSet):
    """给用户分配角色
    """
    serializer_class = UserRoleSerializer
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]
    pagination_class = None

    service = UserService()

    def get_queryset(self):
        return UserProfile.objects

    def do_create(self, request, serializer, instance, *args, **kwargs):
        result = self.response_result

        user_id = serializer.data.get("uid")

        user = self.service.filter_record(user_id=user_id)
        if not user:
            result.update(
                code=450,
                detail='user not find',
            )
            return result

        role_id = serializer.data.get("role_id")
        role = RoleType.objects.filter(id=role_id).first()
        if not role:
            result.update(
                code=451,
                detail='role not exist',
            )
            return result

        profile_service = UserProfileService()
        user_profile = profile_service.filter_record(user_id=user_id)
        if not user_profile:
            result.update(
                code=452,
                detail='user_profile not exist',
            )
            return result

        #
        profile_service.update_role(user_profile, role_id)
        #
        device_b64str = request.META.get('HTTP_X_AUTH_DEVICE', None)
        device_b64str = decode_device_str(device_b64str)
        refresh_user_info(user_profile.user_id.hex, device_b64str=device_b64str)
        return result
