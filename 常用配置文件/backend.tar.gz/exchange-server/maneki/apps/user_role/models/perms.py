from django.db import models
from django.utils.translation import ugettext_lazy as _

from maneki.apps.common.libs.models import SoftDeleteModel
from maneki.apps.constants import MODEL_PREFIX, ApiPermissionType

PREFIX_DB_VERBOSE = "UserRolePermission"
PREFIX_DB_TABLE = MODEL_PREFIX + "user_role_"


class Permission(SoftDeleteModel):
    route_path = models.CharField(help_text='api路由地址', max_length=128)
    permission_name = models.CharField(max_length=128)
    permission_code = models.SmallIntegerField(help_text='create or list permission', choices=ApiPermissionType.choices)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + "api permission list")
        db_table = PREFIX_DB_TABLE + "permission"


class RolePermission(SoftDeleteModel):
    permission_id = models.IntegerField()
    role_id = models.IntegerField()

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + "Role Grant Permission list")
        db_table = PREFIX_DB_TABLE + "role_permission"


class GroupPermission(SoftDeleteModel):
    permission_id = models.IntegerField()
    group_id = models.IntegerField(help_text='Group ID')

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + "Group Grant Permission list")
        db_table = PREFIX_DB_TABLE + "group_permission"
