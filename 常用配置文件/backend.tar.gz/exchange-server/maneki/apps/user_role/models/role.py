from django.db import models

from maneki.apps.common.libs.models import SoftDeleteModel
from maneki.apps.constants import MODEL_PREFIX
from django.utils.translation import ugettext_lazy as _

PREFIX_DB_VERBOSE = "UserRole"
PREFIX_DB_TABLE = MODEL_PREFIX + "user_role_"


class RoleGroup(SoftDeleteModel):
    group_code = models.IntegerField(unique=True)
    group_desc_cn = models.CharField(max_length=128)
    group_desc_en = models.CharField(max_length=128)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + "Permission Group")
        db_table = PREFIX_DB_TABLE + "role_group"


class RoleType(SoftDeleteModel):
    role_code = models.IntegerField(unique=True)
    role_desc_cn = models.CharField(max_length=128)
    role_desc_en = models.CharField(max_length=128)
    group_code = models.IntegerField(verbose_name=_("user group"))

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + "Permission Role")
        db_table = PREFIX_DB_TABLE + "role_type"
