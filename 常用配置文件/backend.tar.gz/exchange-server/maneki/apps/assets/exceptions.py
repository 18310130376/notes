# -*- coding: utf-8 -*-
from django.utils.translation import ugettext_lazy as _
from rest_framework.exceptions import APIException
from rest_framework import status


class UnAuthorizationError(APIException):
    status_code = 400
    default_detail = _("账户认证失败")


# 查询用户余额失败
class UserAssetsResponseError(APIException):
    status_code = 400
    default_detail = _("get account info error")


class UserFiatAccountDuplicated(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = 'This account exists.'


class UserFiatAccountNotFound(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = 'This account not found!'


class SwiftCodeError(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = 'swift code error.'


class ViaSwiftCodeError(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = 'via bank swift code error.'
