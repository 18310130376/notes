import simplejson as json
from django.test import TestCase

from .utils import normalize_user_assets_response


# Create your tests here.
def test_normalize_user_assets_response():
    fixture = json.loads(
        """
            {
              "AccountInfo": {
                "RP": "Speculation",
                "G": "dt",
                "BL": [
                  { "CR": "BTC", "SOD": 0, "C": 9926.885 },
                  { "CR": "USD", "SOD": 0, "C": 746975.16151 }
                ],
                "CDL": [
                  {
                    "S": "BTCUSD",
                    "TSS": 1.827,
                    "TBS": 0,
                    "OS": 0,
                    "AP": 0,
                    "P": 0,
                    "MV": 0,
                    "IMF": 1,
                    "LP": 0,
                    "BIMR": 1.827,
                    "QIMR": 0,
                    "LKP": 0
                  }
                ],
                "IsLocked": false,
                "Account": "btcc-574205",
                "MsgType": "AccountInfo"
              },
              "RC": 0,
              "CRID": "0ee5ca68-ffcb-4591-adf3-d41b8a56e37a",
              "MsgType": "GetAccountInfoResponse"
            }
        """
    )
    result = json.loads(
        """
        {
          "account_id": "btcc-574205",
          "assets": [
            {
              "coin": "BTC",
              "total": "9926.885",
              "frozen": "0",
              "available": "9926.885"
            },
            {
              "coin": "USD",
              "total": "746975.16151",
              "frozen": "1.827",
              "available": "746973.33451"
            }
          ]
        }
        """
    )
    assert normalize_user_assets_response(fixture) == result
