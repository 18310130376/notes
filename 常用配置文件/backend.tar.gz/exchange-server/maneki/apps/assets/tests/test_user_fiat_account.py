# -*- coding: utf-8 -*-
import json
import logging
from django.test import TestCase
from rest_framework.authtoken.models import Token
from rest_framework.exceptions import APIException
from rest_framework.test import APIRequestFactory, force_authenticate

from maneki.apps.assets.services.user_fiat_account import UserFiatAccountService
from maneki.apps.assets.views.serializers.user_fiat_account import UserFiatAccountSerializer
from maneki.apps.constants import FiatType
from maneki.apps.transaction.tests.test_fiat_withdraw import mock_data
from maneki.apps.user.models.user import User
from maneki.apps.assets.views.user_fiat_account import UserFiatAccountViewSet
from maneki.apps.assets.views.user_fiat_account import UserFiatAccountDetailView

logger = logging.getLogger(__name__)


class TestUserFiatAccount(TestCase):

    def setUp(self):
        self.user, self.token = mock_data()
        self.service = UserFiatAccountService()
        self.factory = APIRequestFactory()

    def test_user_fiat_account_service(self):
        from maneki.apps.constants import FiatType
        # add
        account, is_new = self.service.add_account(user_id=self.user.user_id, fiat_type=FiatType.CNY, account_type=1,
                                                   bank_id=1, bank_name='ccmc', bank_account='100932598032235')
        # filter
        obj = self.service.filter_record(id=account.id)
        # list
        objects = self.service.list_account(user_id=self.user.user_id)
        if is_new:
            logger.info('ok')
        if obj:
            logger.info(obj.bank_account)
        if objects:
            logger.info(objects)
        # delete
        self.service.remove_account(id=account.id)
        obj = self.service.filter_record(id=account.id)
        logger.info(obj.is_deleted)

    def test_user_fiat_account_view(self):
        # create
        payload = {
            "fiat_type": FiatType.CNY,
            "bank_swift_code": "",
            "bank_name": "wqhe",
            "bank_address": "",
            "beneficiary_name": "nihi",
            "bank_account": "1878145212315465",
            "beneficiary_address": "",
            "via_bank_name": "",
            "via_bank_address": "",
            "via_bank_swift_code": ""
        }
        account_create = UserFiatAccountViewSet.as_view({'post': 'create'})
        request = self.factory.post('api/v1/assets/fiat/accounts', data=json.dumps(payload), content_type='application/json',
                                    headers={"Authorization": "token " + self.token.key})
        force_authenticate(request, user=self.user, token=self.token.key)
        response = account_create(request)
        logger.info(response.data)
        # get
        account, is_new = self.service.get_or_create_account(user_id=self.user.user_id, fiat_type=1, bank_name="wqhe",
                                                             bank_account="1878145212315465",
                                                             beneficiary_name="nihi", account_type=-1,
                                                             bank_swift_code="", bank_address="",
                                                             beneficiary_address="", via_bank_name="",
                                                             via_bank_address="", via_bank_swift_code="")
        logger.info('account:{}'.format(account.id))
        account_detail = UserFiatAccountDetailView.as_view({'get': 'retrieve'})
        url = 'api/v1/assets/fiat/account/{}/'.format(str(account.id))
        logger.info('get url:{}'.format(url))
        request = self.factory.get(url, headers={"Authorization": "token " + self.token.key})
        force_authenticate(request, user=self.user, token=self.token.key)
        response = account_detail(request)
        logger.info("get:{}".format(response.data))

        # list
        account_list = UserFiatAccountViewSet.as_view({'get': 'list'})
        request = self.factory.get('api/v1/assets/fiat/accounts?fiat_type={}'.format('1'),
                                   headers={"Authorization": "token " + self.token.key})
        force_authenticate(request, user=self.user, token=self.token.key)
        response = account_list(request)
        logger.info(response.data)
        # delete
        account_delete = UserFiatAccountDetailView.as_view({'delete': 'destroy'})
        request = self.factory.delete('api/v1/assets/fiat/account?id={}'.format(str(account.id)),
                                      headers={"Authorization": "token " + self.token.key})
        force_authenticate(request, user=self.user, token=self.token.key)
        response = account_delete(request)
        logger.info(response.data)

    def test_user_account_serializer(self):
        payload = {
            "fiat_type": 0,
            "bank_swift_code": "",
            "bank_name": "wqhe",
            "bank_address": "",
            "beneficiary_name": "nihi",
            "bank_account": "1878145212315465",
            "beneficiary_address": "",
            "via_bank_name": "",
            "via_bank_address": "",
            "via_bank_swift_code": ""
        }
        serializer = UserFiatAccountSerializer(data=payload)
        try:
            serializer.is_valid(raise_exception=True)
        except APIException as e:
            logger.error('error:{}'.format(e.default_detail))
        logger.info('serializer data:{}'.format(serializer.data))
