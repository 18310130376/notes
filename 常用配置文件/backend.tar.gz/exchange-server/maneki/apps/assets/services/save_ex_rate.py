# -*- coding: utf-8 -*-
import logging
from django_redis import get_redis_connection
import requests

from config.settings.env import FOREX_KEY, OPEN_KEY, CURRENCY_KEY, FIXER_KEY

LOGGER = logging.getLogger(__name__)


class SaveExchangeRate(object):
    """从网上更新redis中的汇率"""

    @staticmethod
    def get_for_ex():
        api_url = "https://forex.1forge.com/1.0.3/quotes?api_key={}".format(FOREX_KEY)
        response = requests.get(api_url)
        data = response.json()

        if response.status_code != 200:
            LOGGER.warning("Get ForEx Fail, status_code: {}, info: {}".format(response.status_code, data))
            return False

        if "error" in data:
            LOGGER.warning(
                "Get ForEx Fail, status_code: {}, info: {}".format(response.status_code, data.get("message")))
            return False

        final_dict = {i.get('symbol'): i.get('price') for i in data}
        con = get_redis_connection("default")
        con.hmset("fiat_exchange", final_dict)
        LOGGER.info("Get ForEx Api success, data example: {}".format(data[0]))
        return True

    @staticmethod
    def get_open_exchange():
        api_url = "https://openexchangerates.org/api/latest.json?app_id={}".format(OPEN_KEY)
        response = requests.get(api_url)
        data = response.json()

        if response.status_code != 200:
            LOGGER.warning("Get OpenExchange Fail, status_code: {}, info: {}".format(response.status_code, data))
            return False

        error = data.get("error")
        if error:
            LOGGER.warning("Get OpenExchange Fail, status_code: {}, info: {}".format(data.get("status"),
                                                                                     data.get("description")))
            return False
        final_dict = {data.get("base") + k: v for k, v in data.get("rates").items()}
        final_dict.update({"TIMESTAMP": data.get("timestamp")})
        con = get_redis_connection("default")
        con.hmset("fiat_exchange", final_dict)
        LOGGER.info("Get OpenExchange Api success, data example(USD_CNH): {}".format(data.get("rates").get("CNH")))
        return True

    @staticmethod
    def get_currency_layer():
        api_url = "http://www.apilayer.net/api/live?access_key={}".format(CURRENCY_KEY)
        response = requests.get(api_url)
        data = response.json()

        if response.status_code != 200:
            LOGGER.warning("Get CurrencyLayer Fail, status_code: {}, info: {}".format(response.status_code, data))
            return False

        success = data.get("success")
        if not success:
            LOGGER.warning("Get CurrencyLayer Fail, status_code: {}, info: {}".format(data.get("error").get("code"),
                                                                                      data.get("error").get("info")))
            return False

        final_dict = data.get("quotes")
        con = get_redis_connection("default")
        con.hmset("fiat_exchange", final_dict)
        LOGGER.info("Get CurrencyLayer Api success, data example(USD_CNY): {}".format(data.get("quotes").get("USDCNY")))

    @staticmethod
    def get_fixer():
        api_url = "http://data.fixer.io/api/latest?access_key={}".format(FIXER_KEY)
        response = requests.get(api_url)
        data = response.json()

        if response.status_code != 200:
            LOGGER.warning("Get Fixer Fail, status_code: {}, info: {}".format(response.status_code, data))
            return False

        success = data.get("success")
        if not success:
            LOGGER.warning("Get Fixer Fail, status_code: {}, info: {}".format(data.get("error").get("code"),
                                                                              data.get("error").get("info")))
            return False
        usd = data.get("rates").get("USD")
        final_dict = {"USD" + k: round(v / usd, 6) for k, v in data.get("rates").items()}
        con = get_redis_connection("default")
        con.hmset("fiat_exchange", final_dict)
        LOGGER.info("Get Fixer Api success, data example(USD_CNY): {}".format(final_dict.get("USDCNY")))
        return True

    def save_rate(self):
        # 保存法币汇率
        self.get_for_ex()
        result = self.get_open_exchange()
        if not result:
            result = self.get_currency_layer()
            if not result:
                result = self.get_fixer()
                if not result:
                    LOGGER.error("Get Fiat Exchange Rate Error")
                    return False
        LOGGER.info("Save Fiat Exchange Rate Success")
        # 保存数字货币汇率
        result = self.get_shape_shift()
        if not result:
            LOGGER.error("Save Crypto Exchange Rate Error")
            return False
        LOGGER.info("Save Crypto Exchange Rate Success")
        return True

    @staticmethod
    def get_shape_shift():
        api_url = "https://shapeshift.io/rate"
        response = requests.get(api_url)
        data = response.json()

        if response.status_code != 200:
            LOGGER.warning("Get Fixer Fail, status_code: {}, info: {}".format(response.status_code, data))
            return False

        if "error" in data:
            LOGGER.warning("Get ShapeShift Error: {}".format(data.get("error")))
            return False

        final_dict = {i.get("pair"): i.get("rate") for i in data}
        con = get_redis_connection("default")
        con.hmset("crypto_exchange", final_dict)
        LOGGER.info("Get ShapeShift Api success, data example: {}".format(data[0]))
        return True


class GetExchangeRate(object):
    """从redis中获取汇率"""

    @staticmethod
    def get_fiat_rate(rate: str):
        """
        获取法币汇率
        :param rate: 货币符号, USDCNY
        :return: 汇率
        """
        temp_rate = rate.upper()
        con = get_redis_connection("default")
        result = con.hget("fiat_exchange", temp_rate)
        if result:
            result = float(result)
        return result

    @staticmethod
    def get_fiat_all():
        con = get_redis_connection("default")
        temp_result = con.hgetall("fiat_exchange")
        result = {k.decode(): float(v.decode()) for k, v in temp_result.items()}
        return result

    @staticmethod
    def get_crypto_rate(rate: str):
        """
        获取数字货币汇率
        :param rate: 货币符号, btc_eth
        :return: 汇率
        """
        temp_rate = rate.lower()
        con = get_redis_connection("default")
        result = con.hget("crypto_exchange", temp_rate)
        if result:
            result = float(result)
        return result


if __name__ == '__main__':
    # a = GetExchangeRate()
    b = SaveExchangeRate()
    b.save_rate()
    # c = a.get_fiat_all()
    # print(a.get_fiat_rate("USDCNy"))
