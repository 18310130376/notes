# -*- coding: utf-8 -*-
import logging
import requests
import json

from django.db.models import Sum

from django.conf import settings
from maneki.apps.common.utils.timestamp import get_current_date
from maneki.apps.constants import WITHDRAW_DAILY_LIMIT
from maneki.apps.constants import WithdrawStatus
from maneki.apps.constants import CoinType

from maneki.apps.user_kyc.models import KYCIndividual
from maneki.apps.transaction.models import CryptoWithdrawRecordLastThreeMonths
from maneki.apps.transaction.models import FiatCurrencyWithdrawRecordLastThreeMonths

logger = logging.getLogger(__name__)


class EngineProxyService:
    service_address = settings.USER_TRADE_INFO_PROXY

    def user_balance(self, user_id, account):
        url = self.service_address + '/user-balance'
        try:
            response = requests.get(url=url, params={'account': account})
        except Exception as e:
            logger.error("connect to engine proxy error: {}".format(e))
            return False, "connect to engine proxy error"
        if response.status_code != 200:
            return False, response.json()
        content = json.loads(response.content)
        data = dict(balance=content['data'] if isinstance(content['data'], dict) else {})
        withdraw_limit_setting = self._withdraw_limit(user_id=user_id)
        data.update(withdraw_limit=withdraw_limit_setting)
        return True, data

    def user_balance_logs(self, user_id, account, limit, offset):
        url = self.service_address + '/user-balancechangelogs'

        params = {
            "account": account
        }

        if limit:
            params.update(
                limit=limit
            )
        if offset:
            params.update(
                offset=offset
            )
        try:
            response = requests.get(url=url, params=params)
        except Exception as e:
            logger.error("connect to engine proxy error: {}".format(e))
            return False, "connect to engine proxy error"
        if response.status_code != 200:
            return False, []
        content = json.loads(response.content)
        return True, content

    def user_trades(self, account, email, limit, offset, symbol, start_date, end_date):
        url = self.service_address + '/user-trades'
        params = {
            'account': account,
            'start': start_date,
            'end': end_date,
        }
        if email:
            params.update(
                email=email,

            )
        if symbol:
            params.update(
                symbol=symbol
            )
        if limit:
            params.update(
                limit=limit
            )
        if offset:
            params.update(
                offset=offset
            )
        response = requests.get(url=url, params=params)
        if response.status_code != 200:
            return {}
        content = json.loads(response.content)
        data = content['data']
        count = content['count']
        return count, data

    def _withdraw_limit(self, user_id):
        user_kyc_info = KYCIndividual.objects.filter(user_id=user_id).first()
        kyc_level = user_kyc_info.current_level if user_kyc_info else 1

        result = CryptoWithdrawRecordLastThreeMonths.objects.filter(is_deleted=False,
                                                                    created_at__day=get_current_date(),
                                                                    status=WithdrawStatus.COMPLETED,
                                                                    user_id=user_id
                                                                    ).values('coin_type').annotate(withdraw_amt=Sum('tx_amount'))
        # raw_sql = result.query
        # print(raw_sql)

        withdraw_limit = WITHDRAW_DAILY_LIMIT.get(str(kyc_level))
        for record in result:
            coin_type = CoinType.get_choice(record['coin_type']).label
            amt = record['withdraw_amt']
            daily_limit_amt = withdraw_limit.get(coin_type)
            remain_amt = daily_limit_amt - amt
            withdraw_limit.update(
                {
                    coin_type: remain_amt
                }
            )
        return withdraw_limit

    def statistics(self, type, date, start, end, currency):
        url = self.service_address + '/statistics'
        params = {
            "type": type,

        }

        if date:
            params.update(
                date=date,

            )
        if start:
            params.update(
                start=start
            )
        if end:
            params.update(
                end=end
            )

        if currency:
            params.update(
                currency=currency
            )

        response = requests.get(url=url, params=params)
        return response


if __name__ == '__main__':
    e = EngineProxyService()
    # data = e.user_balance('btcc-574205')
    # data = e.user_trades('testbot73', '2018-05-01', '2018-06-30')
    # print(data)
    e._withdraw_limit('1')
