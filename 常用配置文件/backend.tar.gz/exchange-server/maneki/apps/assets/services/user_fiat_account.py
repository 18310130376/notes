# -*- coding: utf-8 -*-
import logging

from maneki.apps.assets.models.fiat_accounts import UserFiatAccount

logger = logging.getLogger(__name__)


class UserFiatAccountService(object):

    def __init__(self):
        self.model = UserFiatAccount

    def filter_qs(self, user_id):
        """查询记录集

        :param user_id:
        :return:
        """
        return self.model.objects.filter(user_id=user_id, is_deleted=False)

    def filter_record(self, user_id, bank_account, fiat_type):
        """查询单条记录

        :param user_id: 用户ID
        :param bank_account:
        :param fiat_type:
        :return:
        """
        qs = self.filter_qs(user_id=user_id)
        return qs.filter(bank_account=bank_account, fiat_type=fiat_type).first()

    def get_or_create_account(self, user_id, fiat_type, bank_name, bank_account, beneficiary_name,
                              account_type=None, bank_swift_code=None, bank_address=None,
                              beneficiary_address=None, via_bank_name=None,
                              via_bank_address=None, via_bank_swift_code=None):
        """添加银行卡

        :param user_id: 用户uid
        :param fiat_type: 提现币种类型
        :param account_type: 账号类型
        :param bank_swift_code: swift code
        :param bank_name: 银行名称
        :param bank_address: 银行地址
        :param beneficiary_name: 受益人
        :param bank_account: 银行账号
        :param beneficiary_address: 受益人地址
        :param via_bank_name: 中介行名称
        :param via_bank_address: 中介行地址
        :param via_bank_swift_code: 中介行swift code
        :return:
        """
        obj, is_new = self.model.objects.get_or_create(
            user_id=user_id,
            bank_account=bank_account,
            fiat_type=fiat_type,
            account_type=account_type,
            beneficiary_name=beneficiary_name,
            bank_name=bank_name,
            bank_swift_code=bank_swift_code,
            bank_address=bank_address,
            beneficiary_address=beneficiary_address,
            via_bank_name=via_bank_name,
            via_bank_address=via_bank_address,
            via_bank_swift_code=via_bank_swift_code
        )
        return obj, is_new

    def remove_account(self, user_id, bank_account, fiat_type):
        """删除银行卡

        :param user_id:
        :param bank_account:
        :param fiat_type:
        :return:
        """
        obj = self.filter_record(user_id=user_id, bank_account=bank_account, fiat_type=fiat_type)
        if not obj:
            return False
        obj.soft_delete()
        return True

    def list_account(self, user_id, fiat_type=None):
        queryset = self.model.objects.filter(user_id=user_id, is_deleted=False)
        if fiat_type or fiat_type == 0:
            return queryset.filter(fiat_type=fiat_type)
        return queryset

    def create_account(self, user_id, fiat_type, bank_name, bank_account, beneficiary_name,
                       bank_swift_code="", bank_address="",
                       beneficiary_address="", via_bank_name="",
                       via_bank_address="", via_bank_swift_code=""):

        obj = self.model.objects.create(
            user_id=user_id,
            bank_account=bank_account,
            fiat_type=fiat_type,
            beneficiary_name=beneficiary_name,
            bank_name=bank_name,
            bank_swift_code=bank_swift_code,
            bank_address=bank_address,
            beneficiary_address=beneficiary_address,
            via_bank_name=via_bank_name,
            via_bank_address=via_bank_address,
            via_bank_swift_code=via_bank_swift_code
        )
        return obj
