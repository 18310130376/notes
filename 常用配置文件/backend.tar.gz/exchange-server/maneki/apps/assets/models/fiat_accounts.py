# -*- coding: utf-8 -*-
import uuid

from django.db.models import DecimalField
from django.db.models import IntegerField
from django.db import models
from django.utils.translation import ugettext_lazy as _

from maneki.apps.common.libs.models import UserSoftDeleteModel
from maneki.apps.constants import FiatType, AccountType
from maneki.apps.constants import MODEL_PREFIX

# 前缀:
PREFIX_DB_VERBOSE = "User"
PREFIX_DB_TABLE = MODEL_PREFIX + "user_assets_"


####################################################
#     法币(fiat) 账号: 充值/提现
####################################################


# 用户银行卡账号:
class UserFiatAccount(UserSoftDeleteModel):
    # 法币类型: CNY, USD, JPY, HKD
    fiat_type = IntegerField(verbose_name=_("Fiat Type"), default=FiatType.UNDEFINED, choices=FiatType.choices)
    # 账号类型: 充值/提现 deposit/withdraw
    account_type = IntegerField(verbose_name=_("Fiat Type"), default=AccountType.UNDEFINED, choices=AccountType.choices)
    # 银行信息
    bank_id = models.IntegerField(verbose_name=_("Bank ID"), default=0)
    bank_swift_code = models.CharField(verbose_name=_("Bank Swift Code"), default="", max_length=255)
    bank_name = models.CharField(verbose_name=_("Bank Name"), default="", max_length=255)
    bank_address = models.CharField(verbose_name=_("Bank Address"), default="", max_length=255)

    #
    beneficiary_name = models.CharField(verbose_name=_("Beneficiary Name"), default="", max_length=255)
    bank_account = models.CharField(verbose_name=_("Bank Account"), default="", max_length=255)
    beneficiary_address = models.CharField(verbose_name=_("Beneficiary Address"), default="", max_length=255)
    # 中介行
    via_bank_id = ""
    via_bank_name = models.CharField(verbose_name=_("Via Bank Name"), default="", max_length=255)
    via_bank_address = models.CharField(verbose_name=_("Via Bank Address"), default="", max_length=255)
    via_bank_swift_code = models.CharField(verbose_name=_("Via Bank Swift Code"), default="", max_length=255)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": Fiat Bank Account")
        db_table = PREFIX_DB_TABLE + "fiat_bank_account"
