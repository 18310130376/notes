# -*- coding: utf-8 -*-
from django.db.models import DecimalField
from django.db.models import IntegerField
from django.utils.translation import ugettext_lazy as _

from maneki.apps.common.libs.models import BaseModel, UserSoftDeleteModel
from maneki.apps.constants import FiatType
from maneki.apps.constants import MODEL_PREFIX

# 前缀:
PREFIX_DB_VERBOSE = "User Assets"
PREFIX_DB_TABLE = MODEL_PREFIX + "user_assets_"


####################################################
#     法币(fiat) 交易: 充值
####################################################

# 用户资产: 法币
class UserFiatAssets(UserSoftDeleteModel):
    fiat_type = IntegerField(verbose_name=_("Fiat Type"), default=FiatType.UNDEFINED, choices=FiatType.choices)
    #
    balance = DecimalField(verbose_name=_("balance"), default=0, max_digits=40, decimal_places=20)  # 小数点后位数
    frozen_balance = DecimalField(verbose_name=_("frozen balance"), default=0, max_digits=40, decimal_places=20)  # 小数点后位数

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": Fiat")
        db_table = PREFIX_DB_TABLE + "fiat_balance"
