# -*- coding: utf-8 -*-
from django.db.models import CharField
from django.db.models import DecimalField
from django.db.models import IntegerField
from django.utils.translation import ugettext_lazy as _

from maneki.apps.common.libs.models import BaseModel
from maneki.apps.constants import CoinType
from maneki.apps.constants import MODEL_PREFIX

# 前缀:
PREFIX_DB_VERBOSE = "Bank"
PREFIX_DB_TABLE = MODEL_PREFIX + "bank_"


# 人民币开户行:
class BankCNY(BaseModel):
    name = CharField(verbose_name=_("Bank Name"), default="", max_length=255)
    code = IntegerField(verbose_name=_("Bank Code"), default="", )
    country_code = IntegerField(verbose_name=_("Country Code"), )

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": CNY")
        db_table = PREFIX_DB_TABLE + "cny"


# 美元开户行:
class BankUSD(BaseModel):
    name = CharField(verbose_name=_("Bank Name"), default="", max_length=255)
    code = IntegerField(verbose_name=_("Bank Code"), default="", )
    country_code = IntegerField(verbose_name=_("Country Code"), )

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": USD")
        db_table = PREFIX_DB_TABLE + "usd"
