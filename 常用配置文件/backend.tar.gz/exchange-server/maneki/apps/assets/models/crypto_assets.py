# -*- coding: utf-8 -*-
from django.db.models import DecimalField
from django.db.models import IntegerField
from django.utils.translation import ugettext_lazy as _

from maneki.apps.common.libs.models import BaseModel, UserSoftDeleteModel
from maneki.apps.constants import CoinType
from maneki.apps.constants import MODEL_PREFIX

# 前缀:
PREFIX_DB_VERBOSE = "User Assets"
PREFIX_DB_TABLE = MODEL_PREFIX + "user_assets_"


####################################################
#     数字代币(coin) 交易: 充值
####################################################

# 用户资产: 数字代币
class UserCryptoAssets(UserSoftDeleteModel):
    coin_type = IntegerField(verbose_name=_("Coin Type"), default=CoinType.UNDEFINED, choices=CoinType.choices)
    #
    balance = DecimalField(verbose_name=_("balance"), default=0, max_digits=40, decimal_places=20)  # 小数点后位数
    frozen_balance = DecimalField(verbose_name=_("frozen balance"), default=0, max_digits=40, decimal_places=20)  # 小数点后位数

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": Crypto")
        db_table = PREFIX_DB_TABLE + "crypto"
