import logging

from rest_framework import viewsets, permissions
from rest_framework.response import Response
from rest_framework import status

from maneki.apps.user.services import UserService
from .filters.user_crypt_account import UserFilter
from ..services.engine_proxy_service import EngineProxyService

logger = logging.getLogger(__name__)


class UserBalanceAssetAdminViewSet(viewsets.GenericViewSet):
    pagination_class = None
    service = EngineProxyService()
    user_service = UserService()
    filter_class = UserFilter
    permission_classes = [permissions.IsAuthenticated]

    def list(self, request):
        logger.info("admin_op:{} view:{} param:{}".format(request.user.email, self.__class__, request))
        result = {
            "code": status.HTTP_200_OK,
            "detail": "ok",
            "data": {},
        }

        user_id = request.query_params.get('user_id')
        if not user_id:
            result.update(
                code=450,
                detail='user_id invalid'
            )
            return Response(result, status=200)
        account_id = self.user_service.user_engine_account_id(user_id=user_id)
        is_ok, data = self.service.user_balance(user_id, account_id)
        if not is_ok:
            result.update(detail=data,
                          code=451)
        else:
            if isinstance(data, str):
                result.update(detail=data,
                              code=450)
            else:
                result.update(data=data)
        return Response(result, status=200)


class UserBalanceLogAssetAdminViewSet(viewsets.GenericViewSet):
    pagination_class = None
    service = EngineProxyService()
    user_service = UserService()
    filter_class = UserFilter
    permission_classes = [permissions.IsAuthenticated]

    def list(self, request):
        logger.info("admin_op:{} view:{} param:{}".format(request.user.email, self.__class__, request))
        result = {
            "code": status.HTTP_200_OK,
            "detail": "ok",
            "data": {},
        }

        user_id = request.query_params.get('user_id')
        if not user_id:
            result.update(
                code=450,
                detail='user_id invalid'
            )
            return Response(result, status=200)
        limit = request.query_params.get('limit')
        offset = request.query_params.get('offset')

        account_id = self.user_service.user_engine_account_id(user_id=user_id)
        is_ok, data = self.service.user_balance_logs(user_id, account_id, limit, offset)
        if not is_ok:
            result.update(detail=data,
                          code=451)
        else:
            if isinstance(data, str):
                result.update(detail=data,
                              code=450)
            else:
                result.update(data=data.get('data'))
        return Response(result, status=200)


class PlatformStatistics(viewsets.GenericViewSet):
    pagination_class = None
    service = EngineProxyService()
    filter_class = UserFilter
    permission_classes = [permissions.IsAuthenticated]

    def list(self, request):
        logger.info("admin_op:{} view:{} param:{}".format(request.user.email, self.__class__, request))
        result = {
            "code": status.HTTP_200_OK,
            "detail": "ok",
            "data": {},
        }
        type = request.query_params.get('type')
        if type not in ("sumbalanceofadaystart", "botbalanceofadaystart", "bottradingsummaryduring",
                        "bottransfersummaryduring", "sumaccounttransferduring", "sumtradefeeduring",
                        "sumdiviendsduring", "tradefeedailyduring", "diviendsdailyduring",
                        'innerwithdrawduring', 'noninnerwithdrawduring',
                        'innerdepositduring', 'noninnerdepositduring'):
            result.update(detail="Invalid statistics type",
                          code=450)
            return Response(result, status=200)

        date = request.query_params.get('date')
        start = request.query_params.get('start')
        end = request.query_params.get('end')
        currency = request.query_params.get('currency')

        data = self.service.statistics(type, date, start, end, currency)
        result.update(data=data.json().get('data'))
        return Response(result, status=200)
