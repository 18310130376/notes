# -*- coding:utf-8 -*-
import logging

from rest_framework import viewsets
from rest_framework.response import Response

from maneki.apps.assets.exceptions import UnAuthorizationError
from maneki.apps.assets.utils import get_user_token
from maneki.apps.assets.utils import normalize_user_assets_response
from maneki.apps.assets.models import UserCryptoAssets
from maneki.apps.assets.models import UserFiatAssets
from maneki.apps.assets.serializers import UserCryptoAssetsSerializer
from maneki.apps.assets.serializers import UserFiatAssetsSerializer
from maneki.apps.engine.services.engine import EngineService
from maneki.apps.transaction.utils.mixin import ViewSetUserFilterMixin

logger = logging.getLogger(__name__)

engine_rpc = EngineService()


####################################################
#     用户资产
####################################################

# 用户资产: 数字代币
class UserCryptoAssetsViewSet(ViewSetUserFilterMixin, viewsets.ModelViewSet):
    queryset = UserCryptoAssets.objects.all().order_by("-updated_at")
    serializer_class = UserCryptoAssetsSerializer


# 用户资产: 法币
class UserFiatAssetsViewSet(ViewSetUserFilterMixin, viewsets.ModelViewSet):
    queryset = UserFiatAssets.objects.all().order_by("-updated_at")
    serializer_class = UserFiatAssetsSerializer


# 用户资产: from engine
class UserAssetsViewSet(viewsets.GenericViewSet):
    # permission_classes = [IsAuthenticated]
    def list(self, request):
        if not request.user.is_authenticated():
            raise UnAuthorizationError
        _user = request.user
        resp = engine_rpc.get_user_account_info(_user.id, get_user_token(_user))
        _response = normalize_user_assets_response(resp)
        return Response(_response)
