# -*- coding: utf-8 -*-
import logging
from rest_framework import permissions

from .serializers.user_fiat_account import UserFiatAccountSerializer
from .filters.user_fiat_account import FiatAccountFilter
from maneki.apps.assets.models.fiat_accounts import UserFiatAccount
from maneki.apps.assets.services.user_fiat_account import UserFiatAccountService
from maneki.apps.common.mixins.rest import BetterReadWriteDeleteViewSet

logger = logging.getLogger(__name__)


class UserFiatAccountViewSet(BetterReadWriteDeleteViewSet):
    """POST: 添加银行卡 GET: 银行卡列表
        user fiat deposit or withdraw account
    """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = UserFiatAccountSerializer
    filter_class = FiatAccountFilter
    #
    lookup_url_kwarg = "bank_account"
    #
    service = UserFiatAccountService()

    def get_queryset(self):
        return UserFiatAccount.objects.filter(
            user_id=self.request.user.user_id,
            is_deleted=False
        )

    def do_create(self, request, serializer, instance, *args, **kwargs):
        result = self.response_result
        self.service.create_account(user_id=serializer.validated_data.get('user_id'),
                                    fiat_type=serializer.validated_data.get('fiat_type'),
                                    bank_name=serializer.validated_data.get('bank_name'),
                                    bank_account=serializer.validated_data.get('bank_account'),
                                    beneficiary_name=serializer.validated_data.get('beneficiary_name'),
                                    bank_swift_code=serializer.validated_data.get('bank_swift_code', ""),
                                    bank_address=serializer.validated_data.get('bank_address', ""),
                                    beneficiary_address=serializer.validated_data.get('beneficiary_address', ""),
                                    via_bank_name=serializer.validated_data.get('via_bank_name', ""),
                                    via_bank_address=serializer.validated_data.get('via_bank_address', ""),
                                    via_bank_swift_code=serializer.validated_data.get('via_bank_swift_code', ""))
        result.update(data=serializer.data)
        return result

    def do_destroy(self, request, *args, **kwargs):
        result = self.response_result
        user = request.user
        bank_account = request.parser_context.get("kwargs").get("bank_account", None)
        fiat_type = self.request.query_params.get('fiat_type', None)

        if not all([bank_account, fiat_type]):
            result.update(
                code=451,
                detail="bank_account and fiat_type are required.",
            )
            return result

        logger.info("request params: {}".format(request.__dict__))
        logger.info("request filter params: {}".format(fiat_type))

        is_ok = self.service.remove_account(user_id=user.user_id, bank_account=bank_account, fiat_type=fiat_type)
        if not is_ok:
            result.update(
                code=452,
                detail="invalid params, account not found.",
            )
            return result
        return result
