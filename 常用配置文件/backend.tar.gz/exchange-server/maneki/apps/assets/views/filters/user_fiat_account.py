# -*- coding: utf-8 -*-
import django_filters

from maneki.apps.constants import FiatType
from maneki.apps.assets.models.fiat_accounts import UserFiatAccount


class FiatAccountFilter(django_filters.FilterSet):
    fiat_type = django_filters.ChoiceFilter(field_name="fiat_type", label="0: CNY, 1: USD", choices=FiatType.choices)

    class Meta:
        model = UserFiatAccount
        fields = ["fiat_type", "bank_account"]
