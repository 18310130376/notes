import django_filters


class UserFilter(django_filters.FilterSet):
    user_id = django_filters.UUIDFilter()


class UserTradesFilter(django_filters.FilterSet):
    user_id = django_filters.UUIDFilter()
    email = django_filters.CharFilter()
    limit = django_filters.BaseInFilter()
    offset = django_filters.BaseInFilter()
    symbol = django_filters.CharFilter()
    start_date = django_filters.DateFilter()
    end_date = django_filters.DateFilter()
