# -*- coding: utf-8 -*-
from rest_framework import serializers
from rest_framework.exceptions import APIException

from maneki.apps.common.mixins.rest import ValidationError450, ValidationError451
from maneki.apps.constants import FiatType
from maneki.apps.assets.models.fiat_accounts import UserFiatAccount
from maneki.apps.assets.exceptions import UserFiatAccountDuplicated
from maneki.apps.assets.exceptions import SwiftCodeError
from maneki.apps.assets.exceptions import ViaSwiftCodeError
from schwifty import BIC
import logging

logger = logging.getLogger(__name__)


class UserFiatAccountSerializer(serializers.ModelSerializer):
    fiat_type = serializers.IntegerField(required=True)
    bank_swift_code = serializers.CharField(max_length=255, min_length=0, required=False)
    bank_name = serializers.CharField(max_length=255, required=True)
    bank_address = serializers.CharField(max_length=255, required=False)
    # 受益人
    beneficiary_name = serializers.CharField(max_length=255, required=True)
    bank_account = serializers.CharField(max_length=255, required=True)
    beneficiary_address = serializers.CharField(max_length=255, required=False)
    # 中介行
    via_bank_name = serializers.CharField(max_length=255, required=False)
    via_bank_address = serializers.CharField(max_length=255, required=False)
    via_bank_swift_code = serializers.CharField(max_length=255, required=False)

    def validate(self, attrs: dict):
        user = self.context['request'].user
        logger.info('attr data:{}'.format(attrs))

        # 处理验证字段
        # swift code
        if "bank_swift_code" in attrs.keys() and attrs["bank_swift_code"]:
            try:
                BIC(str(attrs["bank_swift_code"]).strip().upper())
            except ValueError:
                raise ValidationError451(
                    detail={"bank_swift_code": "invalid bank swift code."}
                )
            attrs["bank_swift_code"] = str(attrs["bank_swift_code"]).strip().upper()

        # bank name
        attrs.update(bank_name=str(attrs["bank_name"]).strip())

        # via bank name
        if "via_bank_name" in attrs.keys():
            attrs.update(via_bank_name=str(attrs["via_bank_name"]).strip())

        # via bank swift code
        if "via_bank_swift_code" in attrs.keys() and attrs["via_bank_swift_code"] != "":
            try:
                BIC(str(attrs["via_bank_swift_code"]).strip().upper())
            except Exception:
                raise ValidationError451(
                    detail={"via_bank_swift_code": "invalid via bank swift code."}
                )
            attrs["via_bank_swift_code"] = str(attrs["via_bank_swift_code"]).strip().upper()

        exists = UserFiatAccount.objects.filter(
            user_id=user.user_id,
            fiat_type=attrs['fiat_type'],
            bank_account=attrs['bank_account'],
            is_deleted=False
        )
        if exists:
            raise UserFiatAccountDuplicated

        attrs.update(user_id=user.user_id)
        return attrs

    class Meta:
        model = UserFiatAccount
        fields = ('fiat_type', 'bank_swift_code', 'bank_name', 'bank_address',
                  'beneficiary_name', 'bank_account', 'beneficiary_address', 'via_bank_name',
                  'via_bank_address', 'via_bank_swift_code', 'id')

