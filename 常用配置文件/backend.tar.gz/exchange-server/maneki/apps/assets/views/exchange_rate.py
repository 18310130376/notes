# -*- coding: utf-8 -*-
from rest_framework import viewsets
from maneki.apps.common.mixins.rest import BetterListModelMixin, RateNotFound
from maneki.apps.assets.services.save_ex_rate import GetExchangeRate, SaveExchangeRate
from rest_framework.response import Response


class FiatExchangeRateViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    """获取法币汇率"""
    serializer_class = None
    pagination_class = None
    # permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return None

    def list(self, request, *args, **kwargs):
        """获取法币汇率, 需带上参数"pairs", 默认返回CNY与HKD

            Request: /?pairs=USDCNY
        """
        pairs = request.query_params.get('pairs')
        a = GetExchangeRate()
        result = self.response_result
        # 当没有输入参数时, 查询默认
        if not pairs:
            cny = a.get_fiat_rate('USDCNY')
            if not cny:
                cny = a.get_fiat_rate('USDCNH')
                if not cny:
                    # 当取不到数据时,刷新数据
                    save = SaveExchangeRate()
                    save.save_rate()
                    cny = a.get_fiat_rate('USDCNY')
            hkd = a.get_fiat_rate('USDHKD')
            result.get('data').update({
                "CNY": cny,
                "HKD": hkd
            })
        else:
            rate = a.get_fiat_rate(pairs)
            if not rate:
                raise RateNotFound
            result.get("data").update({pairs: rate})
        return Response(result)
