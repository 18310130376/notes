import validators

from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework import status

from .filters.user_crypt_account import UserTradesFilter
from ..services.engine_proxy_service import EngineProxyService


class UserTradesAdminViewSet(viewsets.GenericViewSet):
    pagination_class = None
    service = EngineProxyService()
    filter_class = UserTradesFilter

    def list(self, request):
        result = {
            "code": status.HTTP_200_OK,
            "detail": "ok",
            "data": {},
        }

        account = request.query_params.get('user_id', None)
        email = request.query_params.get('email', None)
        if not account and not email:
            result.update(
                code=450,
                detail='user_id or email must pass at least one'
            )
            return Response(result, status=200)

        # if account and not validators.uuid(account):
        #     result.update(
        #         code=451,
        #         detail='user_id invalid'
        #     )
        #     return Response(result, status=200)

        symbol = request.query_params.get('symbol', None)

        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')
        limit = request.query_params.get('limit', None)
        offset = request.query_params.get('offset', None)
        cnt, data = self.service.user_trades(account, email, limit, offset, symbol, start_date, end_date)

        if isinstance(data, str):
            result.update(detail=data,
                          code=452)
        else:
            data = {
                'count': cnt,
                'results': data
            }
            result.update(data=data)
        return Response(result, status=200)
