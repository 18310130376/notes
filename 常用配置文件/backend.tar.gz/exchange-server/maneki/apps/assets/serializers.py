# -*- coding:utf-8 -*-
from rest_framework import serializers

from maneki.apps.assets.models import UserCryptoAssets
from maneki.apps.assets.models import UserFiatAssets
from maneki.apps.constants import CoinType
from maneki.apps.constants import FiatType


####################################################
#     用户资产:
####################################################

# 用户资产: 数字代币
class UserCryptoAssetsSerializer(serializers.ModelSerializer):
    coin_type = serializers.ChoiceField(CoinType.choices)
    balance = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)
    frozen_balance = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)

    class Meta:
        model = UserCryptoAssets
        fields = (
            "user_id", "coin_type", "balance", "frozen_balance",
        )


# 用户资产: 法币
class UserFiatAssetsSerializer(serializers.ModelSerializer):
    fiat_type = serializers.ChoiceField(FiatType.choices)
    balance = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)
    frozen_balance = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)

    class Meta:
        model = UserFiatAssets
        fields = (
            "user_id", "fiat_type", "balance", "frozen_balance",
        )
