# -*- coding: utf-8 -*-
from celery.utils.log import get_task_logger
from celery.schedules import crontab
from celery.task import periodic_task
from maneki.apps.assets.services.save_ex_rate import SaveExchangeRate

logger = get_task_logger(__name__)


def save_exchange_rate_to_redis():
    save_rate = SaveExchangeRate()
    result = save_rate.save_rate()
    if not result:
        return logger.error("save exchange rate error")
    return logger.info("save exchange rate success")


@periodic_task(run_every=crontab(minute=0, hour='*/6'))
def save_exchange():
    save_exchange_rate_to_redis()
