from django.apps import AppConfig


class AssetsConfig(AppConfig):
    name = 'maneki.apps.assets'
    verbose_name = "UserAssets"
