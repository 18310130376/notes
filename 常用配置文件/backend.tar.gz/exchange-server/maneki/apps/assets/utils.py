# -*- coding:utf-8 -*-
from decimal import Decimal

from rest_framework.authtoken.models import Token

from maneki.apps.assets.exceptions import UserAssetsResponseError


# 计算 frozen
def _sum_frozen(contract_detail=[], coin="BTC"):
    def _start_with(s):
        return s.startswith(coin)

    def _ends_with(s):
        return s.endswith(coin)
    _filter_func = _start_with if coin == "BTC" else _ends_with
    _filtered = [cd for cd in contract_detail if _filter_func(cd["S"])]
    _sum = Decimal("0")
    for cdl in _filtered:
        _sum += Decimal(str(cdl["QIMR"]) if coin == "BTC" else str(cdl["BIMR"]))
    return str(_sum)


# 计算 available
def _cac_available(total, frozen):
    return str(Decimal(total) - Decimal(frozen))


# normalize_user_assets
def normalize_user_assets_response(response):
    if response["RC"] != 0 and response["MsgType"] == "GetAccountInfoResponse":
        raise UserAssetsResponseError

    _info = response["AccountInfo"]
    _balance_list = _info["BL"]
    _contract_detail = _info["CDL"]
    _assets = []

    for bl in _balance_list:
        _frozen = _sum_frozen(_contract_detail, bl["CR"])
        asset = {
            "coin": bl["CR"],
            "total": str(bl["C"]),
            "frozen": _frozen,
            "available": _cac_available(str(bl["C"]), _frozen),
        }
        _assets.append(asset)

    return {
        "account_id": _info["Account"],
        "assets": _assets,
    }


# 获取用户 token
def get_user_token(user):
    return Token.objects.get_or_create(user=user)
