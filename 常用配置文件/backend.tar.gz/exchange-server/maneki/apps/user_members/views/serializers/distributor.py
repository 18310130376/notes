# -*- coding: utf-8 -*-
from rest_framework import serializers

from maneki.apps.user.models import User


class FriendlyUserListSerializer(serializers.ModelSerializer):
    email = serializers.CharField(max_length=255)
    created_at = serializers.DateTimeField()

    class Meta:
        fields = ['email', 'created_at']
        model = User
