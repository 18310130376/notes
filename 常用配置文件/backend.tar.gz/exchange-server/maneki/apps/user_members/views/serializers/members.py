# -*- coding: utf-8 -*-
from rest_framework import serializers

from maneki.apps.user_members.models import UserMembers, UserMembersPointsLogs


class UserMemberSigninSerializer(serializers.ModelSerializer):
    # member_points = serializers.IntegerField()

    class Meta:
        model = UserMembers
        fields = []


class UserMemberPointsSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserMembers
        fields = ["member_points"]


class UserMemberPointsLogSerializer(serializers.ModelSerializer):
    point = serializers.IntegerField(source='value')
    email = serializers.CharField(source='extra_1')

    class Meta:
        model = UserMembersPointsLogs
        fields = ["email", "point", "updated_at"]
