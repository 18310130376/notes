# -*- coding: utf-8 -*-
from django_filters import rest_framework

from maneki.apps.user.models import User


class DistributorFilter(rest_framework.FilterSet):
    user_id = rest_framework.UUIDFilter()

    class Meta:

        model = User
        fields = ['user_id']
