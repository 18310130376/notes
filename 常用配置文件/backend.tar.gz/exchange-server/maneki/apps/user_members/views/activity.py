# -*- coding: utf-8 -*-
import logging
from random import choice

from rest_framework import viewsets
from rest_framework import permissions
from rest_framework.response import Response

from maneki.apps.constants import UserMembersPointsSource
from maneki.apps.user_members.services.members import UserActivityService, MemberPointsLogService
from maneki.apps.user_members.services.distributor import UserDistributorService
from maneki.apps.common.mixins.rest import BetterCreateModelMixin, BetterListModelMixin
from .throttles.members import SigninThrottle

logger = logging.getLogger(__name__)


class UserActivityStatusViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    serializer_class = None
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = None
    service = UserActivityService()

    def get_queryset(self):
        return None

    def list(self, request, *args, **kwargs):
        result = self.response_result
        user = request.user
        activity_list = [UserMembersPointsSource.PASS_KYC,
                         UserMembersPointsSource.FIRST_DEPOSIT,
                         UserMembersPointsSource.FIRST_INVITE]
        data = dict()
        for activity in activity_list:
            source = UserMembersPointsSource.get_choice(activity)
            is_finished = self.service.is_activity_finished(user.user_id, source.value)
            data.update({
                source.label: is_finished}
            )

        result.update(
            data=data
        )
        return Response(result)


class UserInviteCodeViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    serializer_class = None
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = None
    service = UserDistributorService()

    def get_queryset(self):
        return None

    def list(self, request, *args, **kwargs):
        result = self.response_result
        user = request.user
        invite_code = self.service.invite_code(user.user_id)
        data = {
            'invite_code': invite_code,
            'invite_link': "https://m.btcc.com/help/activity/?invitationCode={}".format(invite_code),
        }

        result.update(
            data=data
        )
        return Response(result)
