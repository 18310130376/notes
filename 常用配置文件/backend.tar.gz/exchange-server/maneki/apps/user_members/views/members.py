# -*- coding: utf-8 -*-
import logging
from datetime import datetime

from rest_framework import viewsets
from rest_framework import permissions

from maneki.apps.user_members.models.members import UserMembers
from maneki.apps.user_members.services.members import MemberService, MemberPointsLogService
from maneki.apps.common.mixins.rest import BetterCreateModelMixin, BetterListModelMixin
from maneki.apps.constants import UserMembersPointsSource
from .throttles.members import SigninThrottle

from .serializers import UserMemberSigninSerializer, UserMemberPointsSerializer

logger = logging.getLogger(__name__)


class UserMembersSigninViewSet(BetterCreateModelMixin, viewsets.GenericViewSet):
    serializer_class = UserMemberSigninSerializer
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = None
    service = MemberService()
    log_service = MemberPointsLogService()

    # throttle_classes = [SigninThrottle, ]

    def get_queryset(self):
        return UserMembers.objects

    def do_create(self, request, serializer, instance, *args, **kwargs):
        user = request.user
        result = self.response_result

        member_user_points = self.service.get_user_member_points(user_id=user.user_id)
        if not member_user_points:
            logger.info("user {} don't have a member account".format(user.user_id))
            result.update(
                code=453,
                detail="User haven't a member account."
            )
            return result

        last_signin = self.log_service.get_points_run_logs(
            user_id=user.user_id,
            point_source=UserMembersPointsSource.USERLOGIN)
        today = datetime.now()
        if last_signin\
            and last_signin.created_at.day == today.day \
            and last_signin.created_at.month == today.month \
            and last_signin.created_at.year == today.year:
            result.update(
                code=454,
                data={
                    "member_points": self.service.get_user_member_points(user_id=user.user_id)
                },
                detail="You have signin today, please try again tomorrow."
            )
            return result

        member_points, msg = self.service.add_user_member_points(
            user_id=user.user_id,
            point=50,
            point_source=UserMembersPointsSource.USERLOGIN,
            remark='Sign in at {}'.format(datetime.now()))
        result.update(
            code=200,
            data={
                "member_points": member_points,
            },
            detail=msg,

        )
        return result


class UserMembersPointsViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    serializer_class = UserMemberPointsSerializer
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = None
    service = MemberService()

    def get_queryset(self):
        return UserMembers.objects

    def do_list(self, request, serializer, *args, **kwargs):
        user = request.user
        result = self.response_result
        member_points = self.service.get_user_member_points(user_id=user.user_id)
        result.update(
            code=200,
            data={
                "member_points": member_points or 0,
            }
        )
        return result
