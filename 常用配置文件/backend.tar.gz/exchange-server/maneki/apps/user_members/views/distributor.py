# -*- coding: utf-8 -*-
import logging

from rest_framework import permissions
from rest_framework.response import Response
from maneki.apps.common.mixins.rest import BetterListModelMixin, viewsets
from maneki.apps.user.models import User
from maneki.apps.user_members.services import UserDistributorService
from maneki.apps.user_members.views.filters.distributor import DistributorFilter
from maneki.apps.user_members.views.serializers import FriendlyUserListSerializer

logger = logging.getLogger(__name__)


class DistributorsViewSet(BetterListModelMixin, viewsets.GenericViewSet):

    serializer_class = FriendlyUserListSerializer
    permission_classes = [permissions.IsAuthenticated]
    service = UserDistributorService()

    def get_queryset(self):
        return User.objects.filter(is_deleted=0)

    def list(self, request, *args, **kwargs):
        """用户好友列表

        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        result = self.response_result
        attrs = self.service.validate(self.request)
        user_id = self.request.user.user_id_hex
        code = attrs.get('code')
        detail = attrs.get('detail')
        if code != 200:
            result.update(code=code,
                          detail=detail)
            return result

        friends, counts = self.service.get_friends(user_id=user_id, limit=attrs.get('limit'), offset=attrs.get('offset'))

        result.update(data={"user_friends": list(friends),
                            "count": counts})
        return Response(result)
