from rest_framework.throttling import UserRateThrottle


class SigninThrottle(UserRateThrottle):
    # 每天可发5条
    scope = 'day_slow'
