# -*- coding: utf-8 -*-
from rest_framework import permissions
from rest_framework.response import Response

from maneki.apps.common.mixins.rest import BetterListModelMixin, viewsets
from maneki.apps.user_members.services import MemberPointsLogService
from maneki.apps.user_members.views.serializers import UserMemberPointsLogSerializer


class UserInviteeRebateLog(BetterListModelMixin, viewsets.GenericViewSet):
    serializer_class = UserMemberPointsLogSerializer
    permission_classes = [permissions.IsAuthenticated]
    service = MemberPointsLogService()

    def list(self, request, *args, **kwargs):
        result = self.response_result

        attrs = self.service.validate(self.request)
        code = attrs.get("code")
        detail = attrs.get("detail")
        if code != 200:
            result.update(code=code,
                          detail=detail)
            return Response(result)

        limit = attrs.get("limit")
        offset = attrs.get("offset")
        rebate_points, count, records = self.service.fetch_invitee_rebate(user_id=request.user.user_id,
                                                                          limit=limit,
                                                                          offset=offset)
        result.update(data={"total_points": rebate_points.get("rebate_points", 0),
                            "rebates": self.serializer_class(records, many=True).data,
                            "count": count})
        return Response(result)
