# -*- coding: utf-8 -*-
from django.db import models
from django.utils.translation import ugettext_lazy as _

from maneki.apps.constants import MODEL_PREFIX
from maneki.apps.common.libs.models import UserSoftDeleteModel
from maneki.apps.constants import UserDistributorType

PREFIX_DB_VERBOSE = "Distributor"
PREFIX_DB_TABLE = MODEL_PREFIX + "user_distributor"


class UserDistributor(UserSoftDeleteModel):
    name = models.CharField(verbose_name=_("user name info"), max_length=256, default="", null=False)
    user_type = models.SmallIntegerField(verbose_name=_("user type"), default=UserDistributorType.UNDEFINED, choices=UserDistributorType.choices)
    parent_id = models.CharField(verbose_name=_("inviter uuid"), default="", null=False, max_length=32)
    root_id = models.CharField(verbose_name=_("root uuid"), default="", max_length=32, null=False)
    invite_code = models.CharField(verbose_name=_("invite_code"), default="", max_length=32, unique=True)
    node_id = models.CharField(verbose_name=_("node"), default="", max_length=32)
    super_node_id = models.CharField(verbose_name=_("super node"), default="", max_length=32)

    # 预留字段:
    extra_1 = models.CharField(default="", max_length=255)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": User Distributor Info")
        verbose_name_plural = _(PREFIX_DB_VERBOSE + ": User Distributor Log")
        db_table = PREFIX_DB_TABLE + ""
