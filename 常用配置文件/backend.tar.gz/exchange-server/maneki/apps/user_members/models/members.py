# -*- coding: utf-8 -*-
from django.db import models
from django.utils.translation import ugettext_lazy as _

from maneki.apps.constants import MODEL_PREFIX
from maneki.apps.common.libs.models import UserSoftDeleteModel
from maneki.apps.constants import UserMembersPointsSource

PREFIX_DB_VERBOSE = "Members"
PREFIX_DB_TABLE = MODEL_PREFIX + "user_members_"


class UserMembers(UserSoftDeleteModel):
    member_points = models.IntegerField(verbose_name=_("member points"), default=0, null=False)
    member_levels = models.IntegerField(verbose_name=_("member levels"), default=1, null=False)

    # 预留字段:
    extra_1 = models.CharField(default="", max_length=255)
    extra_2 = models.CharField(default="", max_length=255)
    extra_3 = models.CharField(default="", max_length=255)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": User Members Points Info")
        verbose_name_plural = _(PREFIX_DB_VERBOSE + ": User Members Points Info")
        db_table = PREFIX_DB_TABLE + "points"


class UserMembersPointsLogs(UserSoftDeleteModel):
    value = models.PositiveIntegerField(verbose_name=_("point value"), null=False)
    points_source = models.PositiveIntegerField(verbose_name=_("points source code"), null=False, choices=UserMembersPointsSource.choices)
    remark = models.CharField(verbose_name=_("remark"), max_length=256, default="", null=False)

    # 预留字段:
    extra_1 = models.CharField(default="", max_length=255)
    extra_2 = models.CharField(default="", max_length=255)
    extra_3 = models.CharField(default="", max_length=255)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": User Members Points Log")
        verbose_name_plural = _(PREFIX_DB_VERBOSE + ": User Members Points Log")
        db_table = PREFIX_DB_TABLE + "points_logs"

