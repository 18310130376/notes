from django.apps import AppConfig


class UserMembersConfig(AppConfig):
    name = 'maneki.apps.user_members'
