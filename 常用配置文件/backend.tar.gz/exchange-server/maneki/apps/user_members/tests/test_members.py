# -*- coding: utf-8 -*-
import logging

from maneki.apps.user.models.user import User
from rest_framework.test import APIClient
from rest_framework.test import APITestCase
from rest_framework import status

logger = logging.getLogger(__name__)


class TestMembersPointsView(APITestCase):

    def test_deposit_address_list(self):
        client = APIClient()
        is_login = client.login(username='test2@test.com', password='asdfghjkl')
        print(is_login)
        user = User.objects.get(username='test2@test.com')
        client.force_authenticate(user=user)
        response = client.get('/api/v1/marketing/member_points')
        data = {
            "data": {
                "member_points": 1010
            }
        }
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data, data)

    def test_sign_in(self):
        client = APIClient()
        is_login = client.login(username='test2@test.com', password='asdfghjkl')
        print(is_login)
        user = User.objects.get(username='test2@test.com')
        client.force_authenticate(user=user)
        response = client.post('/api/v1/marketing/signin/')
        data = {
            "data": {
                "member_points": 1020
            }
        }
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data, data)
