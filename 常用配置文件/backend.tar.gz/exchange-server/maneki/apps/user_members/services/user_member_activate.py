# -*- coding: utf-8 -*-
import logging
from django.conf import settings

from django.db import transaction
from maneki.apps.common.utils.mq.pika import BaseConsumer
from maneki.apps.common.utils.mq.pika import BaseProducer
from maneki.apps.constants import UserDistributorType
from maneki.apps.user_members.services import MemberService, UserDistributorService
from maneki.apps.common.utils.decorator.db import verify_db_connections


logger = logging.getLogger(__name__)

USER_MEMBER_CREATE = settings.RABBITMQ_CONFIG_GROUP["user_members"]["user_members_creation"]
USER_MEMBER_ADD_POINTS = settings.RABBITMQ_CONFIG_GROUP["user_members"]["user_add_members_points"]


# 用户会员账号:
class UserMemberCreateProducer(BaseProducer):
    MQ_CONFIG_GROUPS = USER_MEMBER_CREATE


# 同步创建用户会员账号 + 第一次激活加上奖励积分
class UserMemberCreateConsumer(BaseConsumer):
    MQ_CONFIG_GROUPS = USER_MEMBER_CREATE

    @verify_db_connections
    # @transaction.atomic
    def do_task(self, payload: dict):
        logger.info("activate user member account: {}".format(payload))

        ms = MemberService()
        create_member_result = ms.create_members(
            user_id=payload["user_id"]
        )

        activate_result = ms.add_user_member_points(
            user_id=payload["user_id"],
            point=int(payload["point"]),
            point_source=int(payload["point_source"]),
            remark=payload["remark"]
        )

        uds = UserDistributorService()
        # 验证通过，查看是否被邀请记录，修改delete状态
        if uds.filter_by_user(user_id=payload.get('user_id')):
            logger.info(f'modify invite user:{payload["user_id"]}')
            uds.update_status(user_id=payload["user_id"])
        else:
            logger.info(f'create invite user:{payload["user_id"]}')
            uds.create_distributor(
                user_id=payload["user_id"],
                user_type=UserDistributorType.USER
            )


# 向指定账户添加积分
class UserMemberAddPointsProducer(BaseProducer):
    MQ_CONFIG_GROUPS = USER_MEMBER_ADD_POINTS


class UserMemberAddPointsConsumer(BaseConsumer):
    MQ_CONFIG_GROUPS = USER_MEMBER_ADD_POINTS

    @verify_db_connections
    # @transaction.atomic
    def do_task(self, payload: dict):
        logger.info("add user member points: {}".format(payload))

        ms = MemberService()
        add_point_result = ms.add_user_member_points(
            user_id=payload["user_id"],
            point=int(payload["point"]),
            point_source=int(payload["point_source"]),
            remark=payload["remark"]
        )
