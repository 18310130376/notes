# -*- coding: utf-8 -*-
import logging

from maneki.apps.constants import UserMembersPointsSource
from maneki.apps.constants import FiatType, CoinType
from maneki.apps.constants import DEPOSIT_LOWER_BOUND
from maneki.apps.constants import DepositStatus
from maneki.apps.constants import UserActivityPoint
from maneki.apps.transaction.models import FiatCurrencyDepositRecordLastThreeMonths
from maneki.apps.transaction.models import CryptoDepositRecordLastThreeMonths
from maneki.apps.user_kyc.models import KYCIndividual
from ..models import UserMembers, UserMembersPointsLogs, UserDistributor
from django.db.models import Sum

logger = logging.getLogger(__name__)


class MemberService(object):
    def __init__(self):
        self.model = UserMembers
        self.log_service = MemberPointsLogService

    def create_members(self, user_id):
        logger.info('user {} create a member account.'.format(user_id))
        return self.model.objects.create(
            user_id=user_id
        )

    def get_user_member_points(self, user_id):
        user_member = self.model.objects.filter(
            user_id=user_id
        ).first()
        if not user_member:
            user_member = self.create_members(user_id=user_id)
        return user_member.member_points

    def add_user_member_points(self, user_id, point, point_source, remark='', extra_1='', real_point=None):
        user_member = self.model.objects.filter(
            user_id=user_id
        ).first()
        if not user_member:
            user_member = self.create_members(user_id=user_id)
        if real_point is None or real_point != 0:
            user_member.member_points += point if real_point is None else real_point
            user_member.save()
        log_service = self.log_service()
        logger.info(f'user_id:{user_id}, point:{point}, point source:{point_source}')
        print(f'user_id:{user_id}, point:{point}, point source:{point_source}')
        log_service.add_points_log(user_id, point, point_source, remark, extra_1)
        return user_member.member_points, "Success."

    def reduce_user_member_points(self, user_id, point, point_source, remark=''):
        user_member = self.model.objects.filter(
            user_id=user_id
        ).first()
        if not user_member:
            return None, None
        if user_member.member_points < point:
            return user_member.member_points, "User {} don't have enough points to consumer{}.".format(user_id, point)
        user_member.member_points -= point
        user_member.save()
        log_service = self.log_service()
        log_service.add_points_log(user_id, point, point_source, remark)
        return user_member.member_points, "Success."


class MemberPointsLogService(object):
    def __init__(self):
        self.model = UserMembersPointsLogs

    def add_points_log(self, user_id, point_value, point_source, remark='', extra_1=''):
        return self.model.objects.create(
            user_id=user_id,
            value=point_value,
            points_source=point_source,
            remark=remark,
            extra_1=extra_1
        )

    def get_points_run_logs(self, user_id, point_source, lastest=True):
        if lastest:
            return self.model.objects.filter(
                user_id=user_id,
                points_source=point_source
            ).order_by("-created_at").first()
        else:
            return self.model.objects.filter(
                user_id=user_id,
                points_source=point_source
            ).order_by("created_at").first()

    @staticmethod
    def validate(request):
        attrs = dict()
        limit = request.query_params.get('limit', 10)
        offset = request.query_params.get('offset', 0)
        if isinstance(limit, str) and limit.isdigit():
            attrs.update(limit=int(limit),
                         code=200)
        elif not isinstance(limit, int):
            attrs.update(code=451,
                         detail='invalid param limit')
        else:
            attrs.update(limit=limit,
                         code=200)

        if isinstance(offset, str) and offset.isdigit():
            attrs.update(offset=int(offset),
                         code=200)
        elif not isinstance(offset, int):
            attrs.update(code=452,
                         detail='invalid param offset')
        else:
            attrs.update(code=200,
                         offset=offset)

        return attrs

    def fetch_invitee_rebate(self, user_id, limit: int, offset: int):
        records = self.model.objects.filter(user_id=user_id,
                                            points_source=UserMembersPointsSource.INVITEE_TRADE_REBATE).\
            order_by("-updated_at")
        rebate_points = records.aggregate(rebate_points=Sum('value'))
        print(rebate_points, records)
        return rebate_points, len(records), records[offset:limit+offset]


class UserActivityService(object):

    def __init__(self):
        self.model = UserMembersPointsLogs
        self.activity_check_func = {
            UserMembersPointsSource.FIRST_DEPOSIT:
            self.is_satisfy_first_deposit_activity,
            UserMembersPointsSource.PASS_KYC:
            self.is_pass_kyc,
            UserMembersPointsSource.FIRST_INVITE:
            self.is_satisfy_first_invite,
        }
        self.member_service = MemberService()
        self.member_point_log_service = MemberPointsLogService()

    def is_activity_finished(self, user_id, activity_type):
        record = self.model.objects.filter(
            user_id=user_id,
            points_source=activity_type
        ).first()

        if record:
            return 1
        else:
            self.check_activity_finish_status(user_id, activity_type)
            return 0

    def check_activity_finish_status(self, user_id: str, activity_type: int):

        func = self.activity_check_func.get(activity_type)
        if not func:
            return
        result = func(user_id)
        if result:
            have_record = self.member_point_log_service.get_points_run_logs(user_id, activity_type)
            if have_record:
                logger.info('user activity completed:{}, activity:{}'.format(user_id, activity_type))
                return True
            else:
                self.member_service.add_user_member_points(user_id, UserActivityPoint.get(activity_type), activity_type)
                logger.info('add user points:{}, activity:{}'.format(user_id, activity_type))
                return True
        return result

    @staticmethod
    def is_satisfy_first_deposit_activity(user_id: str):
        fiat_record = FiatCurrencyDepositRecordLastThreeMonths.objects.filter(
            user_id=user_id,
            fiat_type=FiatType.USD,
            amount__gte=DEPOSIT_LOWER_BOUND.get('USD'),
            status=DepositStatus.COMPLETED
        ).first()

        if fiat_record:
            return True

        crypto_records = CryptoDepositRecordLastThreeMonths.objects.filter(
            user_id=user_id,
            status=DepositStatus.COMPLETED
        )

        for record in crypto_records:
            coin = CoinType.get_choice(record.coin_type).label
            deposit_bound = DEPOSIT_LOWER_BOUND.get(coin)
            logger.info('coin:{},deposit_bound:{},amount:{}'.format(coin, deposit_bound, record.tx_amount))
            if record.tx_amount >= deposit_bound:
                logger.info('user_id:{},coin:{},deposit_bound:{},amount:{}'.format(record.user_id, coin, deposit_bound, record.tx_amount))
                return True
        return False

    @staticmethod
    def is_satisfy_first_trade_activity(user_id):
        pass

    @staticmethod
    def is_pass_kyc(user_id: str):
        kyc_pass = KYCIndividual.objects.filter(user_id=user_id,
                                                current_level__gte=3
                                                ).first()
        return kyc_pass

    def is_satisfy_first_invite(self, user_id):
        # todo check 被邀请人是否过kyc3
        invite_users = UserDistributor.objects.filter(parent_id=user_id.hex, is_deleted=False).values_list('user_id')
        is_invite = KYCIndividual.objects.filter(user_id__in=invite_users, current_level__gte=3).first()
        logger.info(f'user_id:{user_id},invitee:{is_invite}')
        if not is_invite:
            return False
        return True
