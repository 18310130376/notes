# -*- coding: utf-8 -*-
import logging

from maneki.apps.constants import UserDistributorType
from maneki.apps.user.models import User
from ..models import UserDistributor
from maneki.apps.common.utils import generate_nonce_8bit_digits
from maneki.apps.common.utils.decorator.decorators import retry
from django.db.models import Case, IntegerField, Value, When, Q
import uuid

logger = logging.getLogger(__name__)

# BASE_NUM = 14776800


class UserDistributorService(object):
    def __init__(self):
        self.model = UserDistributor
        self.user_model = User

    @retry(times=10, failed_wait=0, raise_exec=True)
    def create_distributor(self, user_id, user_type, parent_id="", root_id="", node_id="", super_node_id="",
                           is_deleted=True, parent_user_type=UserDistributorType.USER):

        invite_code = generate_nonce_8bit_digits(8, 'ABCDEFGHIGKLMNPQRSTUVWXYZ123456789')
        if parent_user_type == UserDistributorType.AGENT:
            node_id = parent_id
            parent_id = ''
        elif parent_user_type == UserDistributorType.SUPER_AGENT:
            super_node_id = parent_id
            node_id = ''
            parent_id = ''
        return self.model.objects.create(
            user_id=user_id,
            user_type=user_type,
            invite_code=invite_code,
            parent_id=parent_id,
            root_id=root_id,
            node_id=node_id,
            super_node_id=super_node_id,
            is_deleted=is_deleted
        )

    def invite_code(self, user_id):
        invite_code = self.model.objects.filter(user_id=user_id, is_deleted=False).first()
        if invite_code:
            return invite_code.invite_code

        invite_code = self.model.objects.filter(user_id=user_id, is_deleted=True).first()
        if invite_code:
            invite_code.is_deleted = False
            invite_code.save()
            return invite_code.invite_code

        invite_code = self.create_distributor(user_id=user_id, user_type=UserDistributorType.USER, is_deleted=False)
        return invite_code.invite_code

    def get_friends(self, user_id, limit: int, offset: int):
        print('params：{},{},{},{},{}'.format(user_id, limit, type(limit), offset, type(offset)))
        logger.info('params：{},{},{},{},{}'.format(user_id, limit, type(limit), offset, type(offset)))
        first_friends = self.model.objects.filter(parent_id=user_id, is_deleted=False).values_list('user_id')
        print('first friends:{}'.format(first_friends))
        logger.info('first friends:{}'.format(first_friends))
        second_friends = self.model.objects.filter(root_id=user_id, is_deleted=False).values_list('user_id')
        print('second friends:{}'.format(second_friends))
        logger.info('second friends:{}'.format(second_friends))
        friends_user = self.user_model.objects.\
            annotate(friends_type=Case(When(user_id__in=first_friends, then=Value(1)),
                                       When(user_id__in=second_friends, then=Value(2)),
                                       default=0,
                                       output_field=IntegerField())).\
            filter(Q(user_id__in=first_friends) | Q(user_id__in=second_friends)).\
            values('email', 'created_at', 'friends_type')

        return friends_user[offset: offset + limit], len(friends_user)

    @staticmethod
    def validate(request):
        attrs = dict()
        limit = request.query_params.get('limit', 10)
        offset = request.query_params.get('offset', 0)
        if isinstance(limit, str) and limit.isdigit():
            attrs.update(limit=int(limit),
                         code=200)
        elif not isinstance(limit, int):
            attrs.update(code=451,
                         detail='invalid param limit')
        else:
            attrs.update(limit=limit,
                         code=200)

        if isinstance(offset, str) and offset.isdigit():
            attrs.update(offset=int(offset),
                         code=200)
        elif not isinstance(offset, int):
            attrs.update(code=452,
                         detail='invalid param offset')
        else:
            attrs.update(code=200,
                         offset=offset)

        return attrs

    def filter_one(self, invite_code: str):
        return self.model.objects.filter(invite_code=invite_code).first()

    def filter_by_user(self, user_id: str):
        return self.model.objects.filter(user_id=user_id).first()

    def update_status(self, user_id: str):
        if isinstance(user_id, uuid.UUID):
            user_id = user_id.hex
        self.model.objects.filter(user_id=user_id).update(is_deleted=False)
