# -*- coding: utf-8 -*-
from .announcement import *
