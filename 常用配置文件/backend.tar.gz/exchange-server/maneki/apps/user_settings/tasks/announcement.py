# -*- coding: utf-8 -*-
import requests
from celery.schedules import crontab
from celery.task import periodic_task
from celery.utils.log import get_task_logger
from django_redis import get_redis_connection

logger = get_task_logger(__name__)


@periodic_task(run_every=crontab(hour="*", minute="*/10"))
def get_announcement():
    an_list = ("1054052", "1054053")
    for i in an_list:
        response = requests.get('https://btcc.kf5.com/apiv2/forums/{}/posts.json'.format(i),
                                auth=('marvin.gong@btcc.com/token', '3db2e474abd439fb151aebcce08018'), timeout=3)
        if response.status_code != 200:
            logger.error("get announcement error: status_code={}, content={}".format(response.status_code, response.json()))
            return None
        re_json = response.content
        conn = get_redis_connection("user_info")
        conn.set("csr:announcement:{}".format(an_list.index(i)), re_json)
