from rest_framework.throttling import UserRateThrottle


class SendSmsCodeThrottle(UserRateThrottle):
    # 每天可发5条
    scope = 'day_slow'


class SendSmsCodeThrottleMinute(UserRateThrottle):
    scope = 'minute_slow'


class CommonThrottle(UserRateThrottle):
    scope = 'day_fast'
