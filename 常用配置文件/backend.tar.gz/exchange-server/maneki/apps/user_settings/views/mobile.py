from rest_framework import permissions
from rest_framework import viewsets

from .filters import MobilePhoneFilter, MobilePhoneVerifyFilter
from .serializers import MobilePhoneSerializer, MobilePhoneVerifySerializer, AuthValidateMixin
from .throttles import SendSmsCodeThrottle, SendSmsCodeThrottleMinute
from maneki.apps.common.mixins.rest import BetterListModelMixin, BetterCreateModelMixin
from maneki.apps.user.services import UserService
from maneki.apps.user.utils.mobile import validate_mobile_phone_number
from maneki.apps.user.models import User
from maneki.taskapp.messagequeue import tasks


class MobilePhoneViewSet(BetterCreateModelMixin, viewsets.GenericViewSet):
    """绑定手机号:

        发送验证码, (重复调用, 会重发验证码)

    API 限速:

        5次/单日/单用户

    """
    queryset = User.objects
    serializer_class = MobilePhoneSerializer
    filter_class = MobilePhoneFilter
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = None

    # throttle_classes = [SendSmsCodeThrottle, SendSmsCodeThrottleMinute]  # API限速 SendSmsCodeThrottle

    def do_create(self, request, serializer, instance, *args, **kwargs):
        result = self.response_result
        user = request.user
        mobile = serializer.validated_data.get("mobile")
        mobile_country_code = serializer.validated_data.get("mobile_country_code")
        #
        tasks.bind_mobile_phone(user, mobile, mobile_country_code=mobile_country_code)

        result.update(
            code=200,
            detail="sms verify code send ok.",
        )
        return result


class MobilePhoneVerifyViewSet(AuthValidateMixin, BetterListModelMixin, viewsets.GenericViewSet):
    """手机号绑定验证:

        手机号 + 手机号国家区位码 + 短信验证码

    :rtype mobile: 手机号 (+)
    :rtype country_code: 手机号国家码
    :rtype verify_code: 短信验证码

    """
    queryset = User.objects
    serializer_class = MobilePhoneVerifySerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_class = MobilePhoneVerifyFilter
    # throttle_classes = [SendSmsCodeThrottle]
    pagination_class = None
    #
    service = UserService()

    def do_list(self, request, serializer, *args, **kwargs):
        """

        :param request:
        :param serializer:
        :param args:
        :param kwargs:
        :return:
        """
        result = self.response_result
        user = request.user

        mobile = request.query_params.get("mobile", None)
        country_code = request.query_params.get("country_code", "")
        verify_code = request.query_params.get("verify_code", "")

        mobile, country_code = validate_mobile_phone_number(mobile, country_code)
        if not mobile:
            result.update(
                code=401,
                detail="invalid mobile phone number.",
            )
            return result

        # check user mobile:
        if user.mobile and user.mobile_verified:
            result.update(
                code=402,
                detail="the user has already bound a mobile phone number.",
            )
            return result

        # check mobile:
        check = self.check_mobile(self.service, mobile)
        if check["is_active"]:
            result.update(
                code=403,
                detail="this mobile phone has been activated.",
            )
            return result

        if check["is_exist"]:
            result.update(
                code=404,
                detail="this mobile phone has been registered, but not activated.",
            )
            return result

        is_verified = self.service.validate_mobile_phone_number(user, mobile, country_code)
        if not is_verified:
            result.update(
                code=405,
                detail="mobile phone number is not correct.",
            )
            return result

        # check verify code
        is_verified = self.service.validate_sms_verify_code(user, verify_code)
        if not is_verified:
            result.update(
                code=406,
                detail="invalid sms verify code",
            )
            return result

        # ok:
        self.service.enable_mobile_phone(user, mobile, country_code)
        result.update(
            detail="mobile phone  activate succeed.",
        )
        return result
