# -*- coding: utf-8 -*-
import json
import logging

from django.utils import timezone
from rest_framework import permissions
from rest_framework import viewsets
from rest_framework.response import Response

from maneki.apps.user_settings.views.serializers import APPVersionSerializer
from .serializers import SettingsManagerSerializer
from .throttles import CommonThrottle
from maneki.apps.user_settings.services import SettingsManagerService, APPVersionService
from maneki.apps.user_settings.models import CryptoConfirmLimit, WithdrawLimit
from maneki.apps.common.mixins.rest import BetterListModelMixin, BetterReadWriteViewSet

logger = logging.getLogger(__name__)


class CryptoConfirmViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    queryset = CryptoConfirmLimit.objects
    serializer_class = SettingsManagerSerializer
    permission_classes = [permissions.IsAuthenticated]
    # throttle_classes = [CommonThrottle]
    pagination_class = None
    #
    service = SettingsManagerService()

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        service = SettingsManagerService()
        crypto_confirm_cache = service.get_confirm_config()

        for c in crypto_confirm_cache:
            c['coin_type'] = int(c['coin_type'])
            c['min_confirm_num'] = int(c['min_confirm_num'])
            c['max_confirm_num'] = int(c['max_confirm_num'])

        result.update(
            code=200,
            data=crypto_confirm_cache,
        )

        return result


class CryptoWithdrawViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    queryset = WithdrawLimit.objects
    serializer_class = SettingsManagerSerializer
    permission_classes = [permissions.IsAuthenticated]
    # throttle_classes = [CommonThrottle]
    pagination_class = None
    #
    service = SettingsManagerService()

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        service = SettingsManagerService()
        crypto_withdraw_cache = service.get_crypto_withdraw_config()

        for c in crypto_withdraw_cache:
            c['coin_type'] = int(c['coin_type'])

        result.update(
            code=200,
            data=crypto_withdraw_cache,
        )

        return result


class FiatWithdrawViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    queryset = WithdrawLimit.objects
    serializer_class = SettingsManagerSerializer
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = None
    # throttle_classes = [CommonThrottle]
    #
    service = SettingsManagerService()

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        service = SettingsManagerService()
        fiat_withdraw_cache = service.get_fiat_withdraw_config()

        for c in fiat_withdraw_cache:
            c['fiat_type'] = int(c['fiat_type'])

        result.update(
            code=200,
            data=fiat_withdraw_cache,
        )

        return result


class APPVersionViewSet(BetterReadWriteViewSet):
    queryset = WithdrawLimit.objects
    serializer_class = APPVersionSerializer
    pagination_class = None
    service = APPVersionService()

    def list(self, request, *args, **kwargs):
        """获取版本号

            Request params:

                Param           | detail
                ---------------------------
                app_type        | app类型

            Response:

                {
                    "code": 201,
                    "detail": "ok",
                    "data": ""
                }

            Response Code:

                Http Code | detail
                201       | ok
                451       | app_type输入错误

        """
        result = self.response_result
        app_type = self.request.query_params.get('app_type')
        if app_type not in ("ios", "android"):
            result.update(code=451, detail="wrong params")
            return Response(result)
        version_data = self.service.get_version(app_type)
        data = json.loads(version_data)
        result.update(data=data)
        return Response(result)

    def do_create(self, request, serializer, instance, *args, **kwargs):
        result = self.response_result
        result.update(code=201)
        app_type = serializer.validated_data.get("app_type")
        if app_type not in ("ios", "android"):
            result.update(code=451, detail="wrong params")
            return Response(result)
        current_version = serializer.validated_data.get("current_version")
        updated_at = serializer.validated_data.get("updated_at")
        if not updated_at:
            updated_at = timezone.now().strftime('%Y-%m-%d')
        else:
            updated_at = updated_at.strftime('%Y-%m-%d')
        data = {"current_version": current_version,
                "update_at": updated_at}
        self.service.cache_version(json.dumps(data), app_type)
        return result

    def create(self, request, *args, **kwargs):
        """存储app版本号

        Request(JSON) Params:

             Param           | detail     |  example     |    是否必须    |  描述
             ------------------------------------------------------------------------
             updated_at      | 升级时间    |  2018-07-24  |   True        | 可以为空，默认当前日期
             current_version | 当前版本号  |  1.0         |   True        |
             app_type        | 应用类型    |  ios         |   True        | ios/android

        Request:

            {
              "updated_at": null,
              "current_version": "1.0",
              "app_type": "ios"
            }

        Response:

            {
                "code": 201,
                "detail": "ok",
                "data": ""
            }

        Response Code:

            Http Code | detail
            201       | ok
            451       | app_type输入错误


        """
        return super(APPVersionViewSet, self).create(request, *args, **kwargs)
