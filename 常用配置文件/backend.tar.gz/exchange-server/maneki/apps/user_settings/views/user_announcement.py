import json

import requests
from rest_framework import viewsets
from rest_framework.response import Response
from django_redis import get_redis_connection
from maneki.apps.common.mixins.rest import BetterListModelMixin
from maneki.apps.user_settings.tasks import get_announcement


class MarketAnnouncementViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    pagination_class = None

    def list(self, request, *args, **kwargs):
        """通告

        Params:

             Param           | detail   |  example
             lang            | 语言      |  0(中文)/1(英文)

        """
        result = self.response_result
        status = self.request.query_params.get('lang', 0)
        if status not in (0, '0', 1, '1'):
            result.update({
                "code": 451,
                "detail": 'wrong number'
            })
            return Response(result)
        conn = get_redis_connection("user_info")
        re = conn.get("csr:announcement:{}".format(status))
        if not re:
            get_announcement()
            re = conn.get("csr:announcement:{}".format(status))
        response = re.decode("utf-8")
        result.update(data=json.loads(response))
        return Response(result)
