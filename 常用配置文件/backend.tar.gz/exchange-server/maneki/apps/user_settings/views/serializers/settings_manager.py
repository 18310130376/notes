# -*- coding: utf-8 -*-
from rest_framework import serializers, exceptions

from maneki.apps.constants import CoinType, FiatType
from maneki.apps.user_settings.models import CryptoConfirmLimit

class SettingsManagerSerializer(serializers.ModelSerializer):
    coin_type = serializers.ChoiceField(CoinType.choices)
    fiat_type = serializers.ChoiceField(FiatType.choices)
    min_amount_num = serializers.CharField()
    max_amount_num = serializers.CharField()
    min_confirm_num = serializers.CharField()
    max_confirm_num = serializers.CharField()

    class Meta:
        model = CryptoConfirmLimit
        fields = ["coin_type", "fiat_type", "min_amount_num", "max_amount_num", "min_confirm_num", "max_confirm_amount"]


class APPVersionSerializer(serializers.ModelSerializer):
    current_version = serializers.CharField()
    updated_at = serializers.DateField(required=False, allow_null=True)
    app_type = serializers.CharField()

    class Meta:
        model = CryptoConfirmLimit
        fields = ["current_version", "updated_at", "app_type"]
