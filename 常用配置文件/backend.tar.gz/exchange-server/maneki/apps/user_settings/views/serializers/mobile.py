# -*- coding: utf-8 -*-
import phonenumbers
from django.utils.translation import ugettext_lazy as _
from rest_framework import serializers, exceptions

from maneki.apps.user.models import User
from maneki.apps.user.services import UserService
from maneki.apps.user_auth.views.mixins import AuthValidateMixin
from maneki.apps.user.utils import validate_mobile_phone_number


class MobilePhoneSerializer(AuthValidateMixin, serializers.ModelSerializer):
    mobile = serializers.CharField(required=True)  # fix: WTF
    country_code = serializers.CharField(source="mobile_country_code", required=True)

    class Meta:
        model = User
        fields = ["mobile", "country_code"]

        service = UserService()

    def validate(self, attrs):
        mobile = attrs.get("mobile")
        country_code = attrs.get("mobile_country_code")  # bugfix: WTF

        mobile, country_code = validate_mobile_phone_number(mobile, country_code)
        if not mobile:
            raise serializers.ValidationError(
                detail={"mobile": "invalid mobile phone number."},
                code=400,
            )

        # mobile check:
        result = self.check_mobile(self.Meta.service, mobile)
        if result.get("is_active") or result.get("is_exist"):
            raise exceptions.ValidationError(
                code=result.get("code"),
                detail={"mobile": result.get("detail")},
            )

        # ok:
        attrs.update(
            mobile=mobile,
            mobile_country_code=country_code,  # fix: WTF
        )
        return attrs


class MobilePhoneVerifySerializer(serializers.ModelSerializer):
    mobile = serializers.CharField(required=True)  # fix: WTF
    country_code = serializers.CharField(source="mobile_country_code", required=True)
    verify_code = serializers.CharField(required=True)

    class Meta:
        model = User
        fields = ["mobile", "country_code", "verify_code"]
