from rest_framework import permissions
from rest_framework import viewsets

from .serializers import UserProfileSerializer
from .throttles import CommonThrottle
from maneki.apps.common.mixins.rest import BetterListModelMixin
from maneki.apps.user_kyc.models import KYCIndividual
from maneki.apps.user.services import UserProfileService


class UserProfileViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    serializer_class = UserProfileSerializer
    permission_classes = [permissions.IsAuthenticated]
    # throttle_classes = [CommonThrottle]
    pagination_class = None

    def get_queryset(self):
        return None

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        user = request.user

        kyc_record = KYCIndividual.objects.filter(user_id=user.user_id).first()
        #
        profile_service = UserProfileService()
        profile_record = profile_service.profile_info(user_id=user.user_id)
        profile_record.update(
            {
                "username": user.username,
                "account_status": user.status,
                #
                "email": user.email,
                "mobile": user.mobile_str,
                "mobile_country_code": user.mobile_country_code,
                #
                "mobile_verified": user.mobile_verified,
                "email_verified": user.email_verified,
                "totp_device_verified": user.totp_device_verified,
                # kyc:
                "kyc_level": kyc_record.current_level if kyc_record else -1,
                "kyc_level_status": kyc_record.current_level_status if kyc_record else -1,
            }
        )

        result["data"] = profile_record
        return result
