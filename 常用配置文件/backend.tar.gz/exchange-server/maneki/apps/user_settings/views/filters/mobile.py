# -*- coding: utf-8 -*-
import django_filters
from phonenumber_field.modelfields import PhoneNumberField

from maneki.apps.user.utils import PhoneNumberFilter
from maneki.apps.user.models import User


class MobilePhoneFilter(django_filters.FilterSet):
    class Meta:
        model = User
        fields = ["mobile", ]
        filter_overrides = {
            PhoneNumberField: {
                "filter_class": PhoneNumberFilter,
            },
        }


class MobilePhoneVerifyFilter(django_filters.FilterSet):
    country_code = django_filters.CharFilter(field_name="mobile_country_code")

    class Meta:
        model = User
        fields = ["mobile", "verify_code", "country_code"]
        filter_overrides = {
            PhoneNumberField: {
                "filter_class": PhoneNumberFilter,
            },
        }
