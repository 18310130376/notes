# -*- coding: utf-8 -*-
from django.db import models
from django.utils.translation import ugettext_lazy as _

from maneki.apps.common.libs.models import SoftDeleteModel
from maneki.apps.constants import MODEL_PREFIX, CurrencyType

# 前缀
PREFIX_DB_VERBOSE = "Config"
PREFIX_DB_TABLE = MODEL_PREFIX + "config_"

class WithdrawLimit(SoftDeleteModel):
    """
    电子货币提现限制配置
    """
    currency_type = models.IntegerField(verbose_name=_("Currency Type"), default=CurrencyType.UNDEFINED, choices=CurrencyType.choices, )
    currency_type_value = models.IntegerField(verbose_name=_("Currency Type value"), default=-1, )
    min_amount_num = models.DecimalField(verbose_name=_("Min Amount Num"), default=0, max_digits=40, decimal_places=20)
    max_amount_num = models.DecimalField(verbose_name=_("Max Amount Num"), default=100, max_digits=40, decimal_places=20)

    class Meta:
        # verbose_name = _(PREFIX_DB_VERBOSE + ": 电子货币提现限制配置")
        # verbose_name_plural = _(PREFIX_DB_VERBOSE + ": 电子货币提现限制配置")
        db_table = PREFIX_DB_TABLE + "crypto_withdraw_limit"


