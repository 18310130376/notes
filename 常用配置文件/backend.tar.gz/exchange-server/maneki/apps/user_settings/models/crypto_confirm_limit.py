# -*- coding: utf-8 -*-
from django.db import models
from django.utils.translation import ugettext_lazy as _


from maneki.apps.common.libs.models import SoftDeleteModel
from maneki.apps.constants import MODEL_PREFIX

# 前缀
PREFIX_DB_VERBOSE = "Config"
PREFIX_DB_TABLE = MODEL_PREFIX + "config_"

class CryptoConfirmLimit(SoftDeleteModel):
    """
    电子货币交易确认数配置
    """
    coin_type = models.IntegerField(verbose_name=_("Coin Type"), default=-1, )
    min_confirm_num = models.PositiveSmallIntegerField(verbose_name=_("Min Confirm Num"), default=0)
    max_confirm_num = models.PositiveIntegerField(verbose_name=_("Max Confirm Num"), default=32)


    class Meta:
        # verbose_name = _(PREFIX_DB_VERBOSE + ": 电子货币交易确认数配置")
        # verbose_name_plural = _(PREFIX_DB_VERBOSE + ": 电子货币交易确认数配置")
        db_table = PREFIX_DB_TABLE + "crypto_confirm_limit"


