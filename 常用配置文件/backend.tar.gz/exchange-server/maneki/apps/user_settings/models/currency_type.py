# -*- coding: utf-8 -*-
from django.db import models
from django.utils.translation import ugettext_lazy as _


from maneki.apps.common.libs.models import SoftDeleteModel
from maneki.apps.constants import MODEL_PREFIX, CurrencyType

# 前缀
PREFIX_DB_VERBOSE = "Config"
PREFIX_DB_TABLE = MODEL_PREFIX + "config_"

class CurrencyTypeConfig(SoftDeleteModel):
    """
    货币类型配置表，包含数字货币和法币
    """
    currency_type_value = models.IntegerField(verbose_name=_("Currency Type value"), default=-1, )
    currency_type_name = models.CharField(verbose_name=_("Currency Type name"), default="Undefined", max_length=128)
    currency_type = models.IntegerField(verbose_name=_("Currency Type"), default=CurrencyType.UNDEFINED, choices=CurrencyType.choices, )

    class Meta:
        # verbose_name = _(PREFIX_DB_VERBOSE + ": 货币类型相关配置")
        # verbose_name_plural = _(PREFIX_DB_VERBOSE + ": 货币类型配置信息")
        db_table = PREFIX_DB_TABLE + "currency_type"

