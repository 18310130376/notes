# -*- coding: utf-8 -*-
from django.db import models
from django.utils.translation import ugettext_lazy as _

from maneki.apps.common.libs.models import SoftDeleteModel
from maneki.apps.constants import MODEL_PREFIX, MarketFeeType, CoinType

# 前缀:
PREFIX_DB_VERBOSE = "Config"
PREFIX_DB_TABLE = MODEL_PREFIX + "config_"


class MarketTradeFeeRate(SoftDeleteModel):
    """市场交易(买单/卖单) 手续费-费率

    """
    level = models.IntegerField(verbose_name=_("fee level"), default=0)
    fee_type = models.IntegerField(verbose_name=_("market fee type"), default=-1, choices=MarketFeeType.choices)
    fee_rate = models.DecimalField(verbose_name=_("market fee rate"), default=1, max_digits=40, decimal_places=20)

    class Meta:
        # verbose_name = _(PREFIX_DB_VERBOSE + ": 市场交易费率")
        # verbose_name_plural = _(PREFIX_DB_VERBOSE + ": 市场交易费率")
        db_table = PREFIX_DB_TABLE + "market_trade_fee_rate"


class WithdrawFeeRate(SoftDeleteModel):
    """数字货币-提现手续费-费率

    """
    coin_type = models.IntegerField(verbose_name=_("Coin Type"), default=CoinType.UNDEFINED, choices=CoinType.choices)
    fee_rate = models.DecimalField(verbose_name=_("crypto withdraw fee rate"), default=1, max_digits=40, decimal_places=20)

    class Meta:
        # verbose_name = _(PREFIX_DB_VERBOSE + ": 数字货币提现手续费率")
        # verbose_name_plural = _(PREFIX_DB_VERBOSE + ": 数字货币提现手续费率")
        db_table = PREFIX_DB_TABLE + "crypto_withdraw_fee_rate"
