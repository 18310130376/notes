# -*- coding: utf-8 -*-
import logging
from decimal import Decimal
from django.core.cache import caches as DjangoCaches

from maneki.apps.common.base import BaseService
from ..models import CryptoConfirmLimit, WithdrawLimit
from maneki.apps.constants import CurrencyType

logger = logging.getLogger(__name__)

class SettingsManagerService(object):
    def __init__(self):
        self.confirm_model = CryptoConfirmLimit
        self.withdraw_model = WithdrawLimit
        self.config_cache = DjangoCaches["config_manager"]

    def load_config_cache(self):
        crypto_confirm_config = self.confirm_model.objects.filter(
            is_deleted=False
        )
        confirm_result = {}
        for ccc in crypto_confirm_config:
            confirm_result[ccc.coin_type] = str((ccc.min_confirm_num, ccc.max_confirm_num))
        self.config_cache.set('crypto_confirm_config', confirm_result, timeout=None)

        withdraw_config = self.withdraw_model.objects.filter(
            is_deleted=False,
        )
        crypto_result, fiat_result = {}, {}
        for wc in withdraw_config:
            if wc.currency_type == CurrencyType.COIN_TYPE:
                crypto_result[wc.currency_type_value] = str((wc.min_amount_num, wc.max_amount_num))
            elif wc.currency_type == CurrencyType.FIAT_TYPE:
                fiat_result[wc.currency_type_value] = str((wc.min_amount_num, wc.max_amount_num))
        self.config_cache.set('crypto_withdraw_config', crypto_result, timeout=None)
        self.config_cache.set('fiat_withdraw_config', fiat_result, timeout=None)

    def get_confirm_config(self):
        crypto_confirm_cache = self.config_cache.get('crypto_confirm_config', {})
        result = []
        for k,v in crypto_confirm_cache.items():
            temp = {}
            temp['coin_type'] = k
            temp['min_confirm_num'], temp['max_confirm_num'] = eval(v)
            result.append(temp)
        return result

    def get_crypto_withdraw_config(self):
        crypto_withdraw_cache = self.config_cache.get('crypto_withdraw_config', {})
        result = []
        for k,v in crypto_withdraw_cache.items():
            temp = {}
            temp['coin_type'] = k
            temp['min_amount_num'], temp['max_amount_num'] = eval(v)
            result.append(temp)
        return result

    def get_fiat_withdraw_config(self):
        fiat_withdraw_cache = self.config_cache.get('fiat_withdraw_config', {})
        result = []
        for k,v in fiat_withdraw_cache.items():
            temp = {}
            temp['fiat_type'] = k
            temp['min_amount_num'], temp['max_amount_num'] = eval(v)
            result.append(temp)
        return result


class APPVersionService(BaseService):

    def __init__(self):
        super(APPVersionService, self).__init__(
            model=CryptoConfirmLimit,
            cache=DjangoCaches["user_info"]
        )

    def cache_version(self, version_data, app_type, expire=60 * 60 * 24 * 30):
        key = app_type
        key_prefix = ["app", "version"]
        self.cache_set(key, key_prefix, version_data, expire)
        return version_data

    def get_version(self, app_type):
        key = app_type
        key_prefix = ["app", "version"]
        return self.cache_get(key, key_prefix)
