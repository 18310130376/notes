from django.apps import AppConfig


class UserSettingsConfig(AppConfig):
    name = 'user_settings'
