import requests
from django.test import TestCase

from maneki.apps.constants import UPLOAD_IMAGE_TYPE, INDIVIDUAL_APP_1
# Create your tests here.
from maneki.apps.user_kyc.service import KYCAuthLogService
from maneki.apps.user_kyc.utils import get_file_extension, generate_file_name, check_file


def test_generate_file_name():
    file_list = ["E:/BaiduNetdiskDownload/ WinRAR.5.50.Final.exe", "E:/BaiduNetdiskDownload/AAR90.rar",
                 "E:/BaiduNetdiskDownload/ABBYY FineReader 12 Professional 安装版.exe",
                 "E:/BaiduNetdiskDownload/acdsee-ultimate-10-64bit.rar",
                 "E:/BaiduNetdiskDownload/ACDSee.Photo.Studio.Ultimate.2018.11.0.Build.1198.DC.rar",
                 "E:/BaiduNetdiskDownload/AcroRdrDC1800920044_zh_CN.exe", "E:/BaiduNetdiskDownload/Adobe破解补丁.rar",
                 "E:/BaiduNetdiskDownload/AIDA64.5.95.4531.Beta.rar",
                 "E:/BaiduNetdiskDownload/Anaconda3-5.0.1-Linux-x86_64.sh",
                 "E:/BaiduNetdiskDownload/Anaconda3-5.0.1-Windows-x86_64.exe",
                 "E:/BaiduNetdiskDownload/AS SSD Benchmark.zip", "E:/BaiduNetdiskDownload/bd118665.rar",
                 "E:/BaiduNetdiskDownload/besttrace.exe", "E:/BaiduNetdiskDownload/ChipGenius.rar",
                 "E:/BaiduNetdiskDownload/cn_windows_vista_with_sp2_x86_dvd_x15-36285.iso",
                 "E:/BaiduNetdiskDownload/crystaldiskmark.zip",
                 "E:/BaiduNetdiskDownload/e76ac583d14b8c4691ab1b970d083b0c.mp3",
                 "E:/BaiduNetdiskDownload/eos-750d-im4-zh.pdf", "E:/BaiduNetdiskDownload/Firefox-full-latest-win64.exe",
                 "E:/BaiduNetdiskDownload/Firefox-latest(1).exe", "E:/BaiduNetdiskDownload/Firefox-latest.exe",
                 "E:/BaiduNetdiskDownload/FlashGenius(www.greenxf.com).zip",
                 "E:/BaiduNetdiskDownload/Git-2.8.1-64-bit.exe", "E:/BaiduNetdiskDownload/glacier.mp3",
                 "E:/BaiduNetdiskDownload/heizhishi 1~107.7z",
                 "E:/BaiduNetdiskDownload/Herbert.von.Karajan.-.[Beethoven.Symphonien.No.9.Choral].专辑.(APE).rar",
                 "E:/BaiduNetdiskDownload/HiFiChoiceIssue429November2017.rar",
                 "E:/BaiduNetdiskDownload/idman629build1.rar", "E:/BaiduNetdiskDownload/inst.exe",
                 "E:/BaiduNetdiskDownload/KEYGEN-FFF.zip", "E:/BaiduNetdiskDownload/maintheme.mp3.egt",
                 "E:/BaiduNetdiskDownload/MemTest_Pro.zip",
                 "E:/BaiduNetdiskDownload/MouseKeyboardCenter_64bit_CHS_3.2.116.exe",
                 "E:/BaiduNetdiskDownload/nebelburg.mp3",
                 "E:/BaiduNetdiskDownload/New arrival - Black &amp; shiny over the knee boots.mp4",
                 "E:/BaiduNetdiskDownload/onekeyghostv13.9.rar",
                 "E:/BaiduNetdiskDownload/pack.zip", "E:/BaiduNetdiskDownload/PAInstall.zip",
                 "E:/BaiduNetdiskDownload/Photoshop_16_LS20_win64.7z",
                 "E:/BaiduNetdiskDownload/Postman-win64-6.0.10-Setup.exe",
                 "E:/BaiduNetdiskDownload/PowerDesigner16.5汉化文件.zip", "E:/BaiduNetdiskDownload/PowerDesigner165(1).zip",
                 "E:/BaiduNetdiskDownload/PowerDesigner165_破解文件.zip",
                 "E:/BaiduNetdiskDownload/pycharm-professional-2017.3.1.exe",
                 "E:/BaiduNetdiskDownload/Q5QEAFjfUQKAXHKtADr_2FX6oJ4864.mp3",
                 "E:/BaiduNetdiskDownload/Release_Notes_Premium_FW_v103(1).pdf",
                 "E:/BaiduNetdiskDownload/Release_Notes_Premium_FW_v103(2).pdf",
                 "E:/BaiduNetdiskDownload/Release_Notes_Premium_FW_v103(3).pdf",
                 "E:/BaiduNetdiskDownload/Release_Notes_Premium_FW_v103.pdf", "E:/BaiduNetdiskDownload/Restore3.07.zip",
                 "E:/BaiduNetdiskDownload/setup_11.4.0.2002l.exe",
                 "E:/BaiduNetdiskDownload/shadowsocks--universal-4.5.1.apk",
                 "E:/BaiduNetdiskDownload/SW_DVD5_Office_Professional_Plus_2013_64Bit_ChnSimp_MLF_X18-55285.ISO",
                 "E:/BaiduNetdiskDownload/SW_DVD5_Office_Professional_Plus_2013_W32_ChnSimp_MLF_X18-55126.rar",
                 "E:/BaiduNetdiskDownload/SW_DVD5_Office_Professional_Plus_2016_64Bit_ChnSimp_MLF_X20-42426.ISO",
                 "E:/BaiduNetdiskDownload/SZQEAFk2RWGAXVvMAEIlBhfq7C0546.mp3",
                 "E:/BaiduNetdiskDownload/The.Crown.S02E01.720p.FIX字幕侠.mp4",
                 "E:/BaiduNetdiskDownload/The.Crown.S02E02.720p.FIX字幕侠.mp4",
                 "E:/BaiduNetdiskDownload/The.Crown.S02E03.720p.FIX字幕侠.mp4",
                 "E:/BaiduNetdiskDownload/The.Crown.S02E04.720p.FIX字幕侠.mp4",
                 "E:/BaiduNetdiskDownload/The.Crown.S02E05.720p.FIX字幕侠.mp4",
                 "E:/BaiduNetdiskDownload/The.Crown.S02E06.720p.FIX字幕侠.mp4",
                 "E:/BaiduNetdiskDownload/The.Crown.S02E07.720p.FIX字幕侠.mp4",
                 "E:/BaiduNetdiskDownload/The.Crown.S02E08.720p.FIX字幕侠.mp4",
                 "E:/BaiduNetdiskDownload/The.Crown.S02E09.720p.FIX字幕侠.mp4",
                 "E:/BaiduNetdiskDownload/The.Crown.S02E10.720p.FIX字幕侠.mp4",
                 "E:/BaiduNetdiskDownload/typora-setup-x64.exe",
                 "E:/BaiduNetdiskDownload/ubuntu-16.04.3-desktop-amd64.iso.torrent",
                 "E:/BaiduNetdiskDownload/ubuntukylin-16.04-desktop-amd64.iso",
                 "E:/BaiduNetdiskDownload/vimcdoc-2.1.0.tar.gzip", "E:/BaiduNetdiskDownload/VMFusionPRO.8.5.2.zip",
                 "E:/BaiduNetdiskDownload/W0826001.zip", "E:/BaiduNetdiskDownload/watch.html",
                 "E:/BaiduNetdiskDownload/winrar-x64-550.exe",
                 "E:/BaiduNetdiskDownload/WinRAR.v3.90.beta.3_KEYGEN-FFF.rar", "E:/BaiduNetdiskDownload/WOTBox.zip",
                 "E:/BaiduNetdiskDownload/wrar550.exe", "E:/BaiduNetdiskDownload/YYetsShare.exe.egt",
                 "E:/BaiduNetdiskDownload/ZeroBundle-win.zip", "E:/BaiduNetdiskDownload/ZeroNet-win-dist.zip",
                 "E:/BaiduNetdiskDownload/【批量下载】异世界狂想曲 11等.zip", "E:/BaiduNetdiskDownload/区块链技术指南.pdf",
                 "E:/BaiduNetdiskDownload/开关程序3.1.rar", "E:/BaiduNetdiskDownload/异世界狂想曲 09.epub",
                 "E:/BaiduNetdiskDownload/异世界狂想曲 10.epub", "E:/BaiduNetdiskDownload/异世界狂想曲 11.epub",
                 "E:/BaiduNetdiskDownload/异世界狂想曲+Web.epub",
                 "E:/BaiduNetdiskDownload/手嶌葵(Aoi.Teshima).-.[Christmas.Songs].专辑.(FLAC)(ED2000.COM).rar",
                 "E:/BaiduNetdiskDownload/深入理解计算机系统（原书第三版）.pdf", "E:/BaiduNetdiskDownload/简体中文版.zip",
                 "E:/BaiduNetdiskDownload/繁体中文版.zip"]

    for file in file_list:
        print(generate_file_name(file))


def test_get_file_extension():
    file_dict = {
        "1.jpg": True,
        "hasdf": False,
        "2.": False,
        "3.ogg": False,
        "4.Png": True,
        ".mp3": False
    }
    for k, v in file_dict.items():
        assert (get_file_extension(k) in UPLOAD_IMAGE_TYPE) == v


def test_check_file():
    file_dict_p = {
        "1.jpg": True,
        "1.Jpg": True,
        "2.doc": False,
        "1": False,
        "1.Doc": False,
        "": False,
    }
    file_dict_f = {
        "2.jpg": False,
        "1.doc": True,
        "1": False,
        "1.Doc": True,
        "": False,
    }
    for k, v in file_dict_p.items():
        assert check_file("license_pic01", k)[0] is v
    for k, v in file_dict_f.items():
        assert check_file("auth_cert", k)[0] is v


class TestUtils(TestCase):

    # def test_docx_updata(self):
    #     from maneki.apps.user_kyc.service import DocUpload
    #     user_list = ((2, 'peter', 'water', 'user_sign2'),
    #                  (3, 'zhao', 'government', 'user_sign3'))
    #     for u in user_list:
    #         f = DocUpload(*u)
            # f.upload(INDIVIDUAL_APP_1)

    def test_rename(self):
        name_list = ("3417c0aea92f4cd4b60765eef66b3acb-2.jpeg",
                     "f28bd9bfef8148f286e10924169838d4-7.jpeg",
                     "083a859cfb9ca43a9b7bee3ee64f807c9.jpeg",
                     "cab69d70d979476580e54d8f08fbd0c5-1.jpeg",
                     "91444721d5044977ad35b4478ca73df6-1.jpeg",
                     "05a2c00491f848f181a3d82f1ce0f58b.jpeg",
                     "fa037a006841488988a420585edc6b80-3.jpeg",
                     "1648a60585a34dfeb2bc8734014911cb-2.jpeg",
                     "aad11e5582c740fc816fa0ffaf39f76b-0.jpeg")
        ser = KYCAuthLogService()
        for i in name_list:
            re = ser.re_name(i)
            print(re)
