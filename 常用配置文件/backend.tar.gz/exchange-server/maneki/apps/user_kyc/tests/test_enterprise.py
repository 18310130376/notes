# -*- coding: utf-8 -*-
import json
import uuid
from rest_framework.authtoken.models import Token
from maneki.apps.user.models.user import User
from rest_framework.test import APIRequestFactory, force_authenticate, APITestCase
from maneki.apps.user_kyc.models import KYCEnterprise
from maneki.apps.user_kyc.views import KYCEnterpriseViewSet, KYCEnterpriseAuthCSRViewSet, \
    KYCEnterUserListViewSet


def make_user(num):
    i = 0
    user_list = []
    while i < num:
        user_dict = {
            "username": "{}@qq.com".format(i),
            "email": "{}@qq.com".format(i),
            "password": "123456",
            "is_superuser": 0,
            "is_staff": 0,
            "user_id": uuid.uuid4(),
            "engine_token": uuid.uuid4(),
            "is_active": 1,
            "status": 1
        }
        user_list.append(user_dict)
        i += 1
    return user_list


class TestEnterpriseView(APITestCase):

    def setUp(self):
        self.factory = APIRequestFactory()
        self.user = User.objects.create(username='hhstore@qq.com',
                                        email='hhstore@qq.com', password='123456',
                                        is_superuser=1, is_staff=0,
                                        user_id=uuid.uuid4(),
                                        engine_token=uuid.uuid4(),
                                        is_active=1, status=1)
        self.csr = User.objects.create(username='director@123.com',
                                       email='123@123.com', password='123456',
                                       is_superuser=1, is_staff=1,
                                       user_id=uuid.uuid4(),
                                       engine_token=uuid.uuid4(),
                                       is_active=1, status=1)

        self.auth = Token.objects.create(key=uuid.uuid4().hex,
                                         user_id=self.user.id)
        self.auth_csr = Token.objects.create(key=uuid.uuid4().hex,
                                             user_id=self.csr.id)
        self.kyc = KYCEnterprise.objects.create(user_id=self.user.user_id,
                                                license_pic01='{}.jpg'.format(uuid.uuid4().hex),
                                                license_pic02='{}.jpg'.format(uuid.uuid4().hex),
                                                license_pic03='{}.jpg'.format(uuid.uuid4().hex),
                                                org_cert='{}.jpg'.format(uuid.uuid4().hex),
                                                auth_cert='{}.jpg'.format(uuid.uuid4().hex),
                                                business_license='{}.jpg'.format(uuid.uuid4().hex))

    def test_create(self):
        view = KYCEnterpriseViewSet.as_view({'post': 'create', 'get': 'list'})
        view_auth = KYCEnterpriseAuthCSRViewSet.as_view({'post': 'create', 'get': 'list'})
        data1 = {
            "company_name": "asdfas",
            "register_num": "asdfs",
            "tax_num": "asfaf",
            "local_country": "asdfas",
            "local_city": "string",
            "local_region": "string",
            "local_address": "string",
            "local_postcode": "string",
            "phone_num": "1241234123",
            "set_up_date": "2018-01-01",
            "register_country": "string"
        }
        data2 = {
            "msg": "ok"
        }
        data3 = {
            "license_country": "asdf",
            "license_type": "paper",
            "last_name": "asdf",
            "first_name": "asdfa",
            "license_number": "adsfa",
            "industry": "fdgsfd"
        }
        data_list = [data1, data2, data3]
        # 客户提交审核
        for i in data_list:
            request = self.factory.post(path='/api/v1/settings/kyc/enterprise',
                                        data=json.dumps(i),
                                        content_type='application/json',
                                        headers={'Authorization': 'Token ' + self.auth.key})
            force_authenticate(request, user=self.user, token=self.auth.key)
            response = view(request)
            print(response.data)
            request2 = self.factory.get(path='/api/v1/settings/kyc/enterprise',
                                        headers={'Authorization': 'Token ' + self.auth.key})
            force_authenticate(request2, user=self.user, token=self.auth.key)
            response2 = view(request2)
            self.assertEqual(response2.data.get("data").get("local_step"), data_list.index(i) + 2)
            print(response2.data)
        # 审核通过
        data_auth = {
            "status": "0"
        }
        request3 = self.factory.post(path='/api/v1/admin/kyc/enterprise/auth/csr/?uid={}'.format(self.user.user_id),
                                     data=json.dumps(data_auth),
                                     content_type='application/json',
                                     headers={'Authorization': 'Token ' + self.auth_csr.key})
        force_authenticate(request3, user=self.user, token=self.auth.key)
        response3 = view_auth(request3)
        print(response3.data)
        request4 = self.factory.get(path='/api/v1/settings/kyc/enterprise',
                                    headers={'Authorization': 'Token ' + self.auth.key})
        force_authenticate(request4, user=self.user, token=self.auth.key)
        response4 = view(request4)
        print(response4.data)
        self.assertEqual(response4.data.get("data").get("local_level"), 2)

    def test_user_list(self):
        view = KYCEnterUserListViewSet.as_view({"get": "list"})
        view_create = KYCEnterpriseViewSet.as_view({"get": "list"})
        user_list = make_user(20)
        for i in user_list:
            user = User.objects.create(**i)
            token = uuid.uuid4().hex
            auth = Token.objects.create(key=token,
                                        user_id=user_list.index(i) + 3)
            request = self.factory.get(path='/api/vi/settings/kyc/enterprise',
                                       headers={'Authorization': 'Token ' + auth.key})
            force_authenticate(request, user=user, token=auth.key)
            response = view_create(request)
            print(response.data)
        request = self.factory.get(path='/api/vi/admin/kyc/enterprise/auth/csr/?limit=10&offset=0',
                                   headers={'Authorization': 'Token ' + self.auth_csr.key})
        force_authenticate(request, user=self.user, token=self.auth.key)
        response = view(request)
        print(response.data)
