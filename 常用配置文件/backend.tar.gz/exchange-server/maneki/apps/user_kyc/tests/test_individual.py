# -*- coding: utf-8 -*-
import json
import time
import uuid
from django.test import TestCase
from rest_framework.authtoken.models import Token

from maneki.apps.user.models.user import User
from rest_framework.test import APIRequestFactory, force_authenticate
from rest_framework.test import APITestCase
from rest_framework import status

from maneki.apps.user_kyc.models import KYCIndividual
from maneki.apps.user_kyc.service import KYCAuthLogService
from maneki.apps.user_kyc.views import KYCIndividualViewSet, KYCIndividualAuthCSRLevel1ViewSet, \
    KYCIndividualAuthCSRLevel2ViewSet, KYCIndividualAuthCSRLevel3ViewSet, KYCIndividualAuthLevel3ViewSet, \
    KYCUserListViewSet


def make_user(num):
    i = 0
    user_list = []
    while i < num:
        user_dict = {
            "username": "{}@qq.com".format(i),
            "email": "{}@qq.com".format(i),
            "password": "123456",
            "is_superuser": 0,
            "is_staff": 0,
            "user_id": uuid.uuid4(),
            "engine_token": uuid.uuid4(),
            "is_active": 1,
            "status": 1
        }
        user_list.append(user_dict)
        i += 1
    return user_list


class TestIndividualView(APITestCase):

    def setUp(self):
        self.factory = APIRequestFactory()
        self.user = User.objects.create(username='hhstore@qq.com',
                                        email='604496499@qq.com', password='123456',
                                        is_superuser=1, is_staff=0,
                                        user_id=uuid.uuid4(),
                                        engine_token=uuid.uuid4(),
                                        is_active=1, status=1)
        self.csr = User.objects.create(username='csr@123.com',
                                       email='peter.zhao@btcc.com', password='123456',
                                       is_superuser=1, is_staff=1,
                                       user_id=uuid.uuid4(),
                                       engine_token=uuid.uuid4(),
                                       is_active=1, status=1)
        self.dir = User.objects.create(username='director@123.com',
                                       email='alex.hk@btcc.com', password='123456',
                                       is_superuser=1, is_staff=1,
                                       user_id=uuid.uuid4(),
                                       engine_token=uuid.uuid4(),
                                       is_active=1, status=1)
        self.auth = Token.objects.create(key=uuid.uuid4().hex,
                                         user_id=self.user.id)
        self.auth_csr = Token.objects.create(key=uuid.uuid4().hex,
                                             user_id=self.csr.id)
        self.auth_dir = Token.objects.create(key=uuid.uuid4().hex,
                                             user_id=self.dir.id)
        self.kyc = KYCIndividual.objects.create(user_id=self.user.user_id,
                                                first_name='peter',
                                                last_name='zhao',
                                                license_pic01='{}.jpg'.format(uuid.uuid4().hex),
                                                license_pic02='{}.jpg'.format(uuid.uuid4().hex),
                                                license_pic03='{}.jpg'.format(uuid.uuid4().hex),
                                                address_cert='{}.jpg'.format(uuid.uuid4().hex))

    def test_create(self):
        view = KYCIndividualViewSet.as_view({'post': 'create', 'get': 'list'})
        # level 1
        data1 = {
            "license_country": "asdf",
            "license_type1": "paper",
            "last_name": "asdf",
            "first_name": "asdfa",
            "license_number": "adsfa",
            "industry": "fdgsfd",
        }
        # level 2
        data2 = {
            "license_type": "passport"
        }
        # level 3
        data3 = {
            "local_country": "123",
            "local_city": "123",
            "local_region": "123",
            "local_address": "123",
            "local_postcode": "123"
        }

        data_list = (data1, data2, data3)
        for i in data_list:
            if i != data1:
                KYCIndividual.objects.filter(user_id=self.user.user_id).update(current_level=data_list.index(i) + 1,
                                                                          current_level_status='not_started')
            request = self.factory.post(path='/api/v1/settings/kyc/individual/',
                                        data=json.dumps(i), content_type='application/json',
                                        headers={'Authorization': 'Token ' + self.auth.key})
            force_authenticate(request, user=self.user, token=self.auth.key)
            response = view(request)
            print(response.data)
            self.assertEqual(response.status_code, status.HTTP_201_CREATED)

            request2 = self.factory.get(path='/api/v1/settings/kyc/individual/',
                                        headers={'Authorization': 'Token ' + self.auth.key})
            force_authenticate(request2, user=self.user, token=self.auth.key)
            response2 = view(request2)
            print(response2.data)
            self.assertEqual(response2.status_code, status.HTTP_200_OK)

    def test_list(self):
        # 测试审核失败的返回值
        view = KYCIndividualViewSet.as_view({'get': 'list'})
        # temp = {
        #     1: {"current_level": 2}
        # }
        i = 0
        while i < 4:
            # KYCIndividual.objects.filter(user_id=self.user.id).update(current_level=i+1,
            request = self.factory.get(path='/api/v1/settings/kyc/individual/',
                                       headers={'Authorization': 'Token ' + self.auth.key})
            force_authenticate(request, user=self.user, token=self.auth.key)
            response = view(request)
            print(response.data)
            self.assertEqual(response.status_code, status.HTTP_200_OK)
            KYCIndividual.objects.filter(user_id=self.user.user_id).update(current_level=i + 1,
                                                                      current_level_status='manual_rejected')
            i += 1

    def test_auth_csr(self):
        # 客服查询用户信息
        view_dict = {
            1: KYCIndividualAuthCSRLevel1ViewSet.as_view({'get': 'list', 'post': 'create'}),
            2: KYCIndividualAuthCSRLevel2ViewSet.as_view({'get': 'list', 'post': 'create'}),
            3: KYCIndividualAuthCSRLevel3ViewSet.as_view({'get': 'list', 'post': 'create'})
        }
        data_list = []
        csr_data = {1: {"status": 0},
                    2: {"status": 2,
                        "data": "license_type"},
                    3: {"status": 1,
                        "data": {"license_type": {"before_change": "",
                                                  "after_change": "paper",
                                                  "common": ""},
                                 "last_name": {"before_change": "",
                                               "after_change": "",
                                               "common": ""}}}
                    }
        i = 1
        while i < 4:
            # 客服获取用户的信息,开始审核
            request = self.factory.get(path='/api/v1/admin/kyc/individual/auth/level_{}/csr/?uid={}'
                                       .format(i, self.user.user_id),
                                       headers={'Authorization': 'Token ' + self.auth.key})
            force_authenticate(request, user=self.user, token=self.auth.key)
            response = view_dict.get(i)(request)
            print('获取用户的信息, level{}'.format(i))
            print(response.data)
            data_list.append(response.data.get('data'))
            # 客服审核提交
            self.assertEqual(response.status_code, status.HTTP_200_OK)
            request2 = self.factory.post(path='/api/v1/admin/kyc/individual/auth/level_{}/csr/?uid={}'
                                         .format(i, self.user.user_id),
                                         data=json.dumps(csr_data.get(i)), content_type='application/json',
                                         headers={'Authorization': 'Token ' + self.auth.key})
            force_authenticate(request2, user=self.user, token=self.auth.key)
            response2 = view_dict.get(i)(request2)
            print('客服提交审核结果, level{}'.format(i))
            print(response2.data)
            if i == 2:
                # 客服拒绝后, 用户重新提交
                view3 = KYCIndividualViewSet.as_view({'post': 'create'})
                data_client = {
                    "license_type": "paper"
                }
                request3 = self.factory.post(path='/api/v1/settings/kyc/individual/',
                                             data=json.dumps(data_client), content_type='application/json',
                                             headers={'Authorization': 'Token ' + self.auth.key})
                force_authenticate(request3, user=self.user, token=self.auth.key)
                response3 = view3(request3)
                print('用户再次提交数据')
                print(response3.data)
                # 客服再次审核
                data_csr = {"status": 0}
                request = self.factory.get(path='/api/v1/admin/kyc/individual/auth/level_{}/csr/?uid={}'
                                           .format(i, self.user.user_id),
                                           headers={'Authorization': 'Token ' + self.auth.key})
                force_authenticate(request, user=self.user, token=self.auth.key)
                response = view_dict.get(i)(request)
                print('用户再次提交审核')
                print(response.data)
                data_list.append(response.data.get('data'))
                # 客服再次审核提交
                self.assertEqual(response.status_code, status.HTTP_200_OK)
                request2 = self.factory.post(path='/api/v1/admin/kyc/individual/auth/level_{}/csr/?uid={}'
                                             .format(i, self.user.user_id),
                                             data=json.dumps(data_csr), content_type='application/json',
                                             headers={'Authorization': 'Token ' + self.auth.key})
                force_authenticate(request2, user=self.user, token=self.auth.key)
                response2 = view_dict.get(i)(request2)
                print('客服再次提交审核结果')
                print(response2.data)
            if i == 3:
                # 主管审核
                view_auth = KYCIndividualAuthLevel3ViewSet.as_view({"get": "list",
                                                                    "post": "create"})
                data_auth = {
                    "msg": "1",
                    "license_type": "passport",
                    "last_name": "dell"
                }
                request4 = self.factory.get(path='/api/v1/admin/kyc/individual/auth/level_{}/?uid={}'
                                            .format(i, self.user.user_id),
                                            headers={'Authorization': 'Token ' + self.auth.key})
                force_authenticate(request4, user=self.user, token=self.auth.key)
                response4 = view_auth(request4)
                print('主管查看审核信息')
                print(response4.data)
                # data_auth.update(data_auth)
                # 主管同意修改
                request5 = self.factory.post(path='/api/v1/admin/kyc/individual/auth/level_{}/?uid={}'
                                             .format(i, self.user.user_id),
                                             data=json.dumps(data_auth), content_type='application/json',
                                             headers={'Authorization': 'Token ' + self.auth.key})
                force_authenticate(request5, user=self.user, token=self.auth.key)
                response5 = view_auth(request5)
                print('主管提交审核结果')
                print(response5.data)
            i += 1

    def test_user_list(self):
        view = KYCUserListViewSet.as_view({"get": "list"})
        view_create = KYCIndividualViewSet.as_view({"get": "list"})
        user_list = make_user(20)
        for i in user_list:
            user = User.objects.create(**i)
            token = uuid.uuid4().hex
            auth = Token.objects.create(key=token,
                                        user_id=user.id)
            request = self.factory.get(path='/api/vi/settings/kyc/individual',
                                       headers={'Authorization': 'Token ' + auth.key})
            force_authenticate(request, user=user, token=auth.key)
            response = view_create(request)
            print(response.data)
        time.sleep(1)
        request = self.factory.get(path='/api/vi/admin/kyc/individual/auth/user/?limit=10&offset=0',
                                   headers={'Authorization': 'Token ' + self.auth_csr.key})
        force_authenticate(request, user=self.csr, token=self.auth_csr.key)
        response = view(request)
        print(response.data)


class TestServiceSimple(TestCase):

    def test_individual_auth_service(self):
        base_url = """https://stackoverflow.com/questions/
                   49194719/{}authentication-plugin-caching-
                   sha2-password-cannot-be-loaded"""
        name = uuid.uuid4().hex + ".jpg"
        url = base_url.format(name)
        service = KYCAuthLogService()
        new_name = service.re_name(url)
        print(new_name)
