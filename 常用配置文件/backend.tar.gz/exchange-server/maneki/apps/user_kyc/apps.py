from django.apps import AppConfig


class UserKycConfig(AppConfig):
    name = 'maneki.apps.user_kyc'
    verbose_name = "User KYC"
