# -*- coding: utf-8 -*-
from django_filters import rest_framework as filters

from maneki.apps.user_kyc.models import KYCLog, KYCIndividual, KYCEnterprise


class BaseFilter(filters.FilterSet):
    timestamp_start = filters.CharFilter(help_text='开始时间戳')
    timestamp_end = filters.CharFilter(help_text='结束时间戳')
    # uid = django_filters.CharFilter(name='uid')
    # email = django_filters.CharFilter(name='')
    # status = django_filters.ChoiceFilter(name='application_status', help_text="主管审核状态")


class UserKYCFilter(BaseFilter):
    # date_min = filters.DateFilter(name='created_at', help_text='最远日期', lookup_expr='gte')
    # date_max = filters.DateFilter(name='created_at', help_text='最近日期', lookup_expr='lte')
    status = filters.CharFilter(help_text='用户的审核状态')
    app = filters.CharFilter(help_text='客服提交主管的审核状态')
    email = filters.CharFilter(help_text='用户Email')
    nationality = filters.CharFilter(help_test='用户国籍')

    class Meta:
        model = KYCIndividual
        fields = ['timestamp_start', 'timestamp_end', 'nationality', 'status', 'app', 'email']


class EnterpriseFilter(BaseFilter):
    status = filters.CharFilter(help_text='用户的审核状态')

    class Meta:
        model = KYCEnterprise
        fields = ['timestamp_start', 'timestamp_end', 'status']


class CSRKYCFilter(BaseFilter):
    uid = filters.CharFilter()
    csr = filters.CharFilter(help_text='客服ID')
    status = filters.CharFilter(help_text='客服申请的审核状态')
    email = filters.CharFilter(help_text='用户email')

    class Meta:
        model = KYCLog
        fields = ['timestamp_start', 'timestamp_end', 'uid', 'csr', 'status', 'email']


class CSRKYCLogFilter(BaseFilter):
    client_id = filters.UUIDFilter()
    csr_id = filters.UUIDFilter()
    kyc_level = filters.CharFilter()
    kyc_type = filters.CharFilter()

    class Meta:
        model = KYCLog
        fields = ['timestamp_start', 'timestamp_end', 'client_id', 'csr_id', 'kyc_level', 'kyc_type']
