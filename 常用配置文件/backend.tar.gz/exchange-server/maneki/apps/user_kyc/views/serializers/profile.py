# -*- coding:utf-8 -*-
from rest_framework import serializers
from maneki.apps.user_kyc.models import KYCEnterprise, KYCCSRComment
from maneki.apps.user_kyc.models import KYCIndividual, KYCLog


####################################################
#     企业用户KYC:
####################################################


class EnterpriseKYCSerializer(serializers.Serializer):
    """用戶KYC審核"""

    def create(self, validated_data):
        return KYCEnterprise.objects.update_or_create(**validated_data)


class EnterpriseKYCStep1Serializer(serializers.Serializer):
    """序列化第一步"""
    company_name = serializers.CharField(max_length=100)
    register_num = serializers.CharField(max_length=100)
    tax_num = serializers.CharField(max_length=100)
    local_country = serializers.CharField(max_length=10)
    local_city = serializers.CharField(max_length=30)
    local_region = serializers.CharField(max_length=40)
    local_address = serializers.CharField(max_length=150)
    local_postcode = serializers.CharField(max_length=10)
    phone_num = serializers.CharField(max_length=15)
    set_up_date = serializers.DateField()
    register_country = serializers.CharField()

    def update(self, instance, validated_data):
        return KYCEnterprise.objects.filter(user_id=instance).update(**validated_data)


class EnterpriseKYCStep3Serializer(serializers.Serializer):
    """序列化第三步"""
    license_type = serializers.ChoiceField(choices=['passport', 'paper', 'driver_license'])
    last_name = serializers.CharField(max_length=100)
    first_name = serializers.CharField(max_length=100)
    middle_name = serializers.CharField(max_length=100, required=False)
    license_number = serializers.CharField(max_length=100)

    def update(self, instance, validated_data):
        return KYCEnterprise.objects.filter(user_id=instance).update(**validated_data)


class EnterpriseKYCAuthSerializer(serializers.ModelSerializer):
    company_name = serializers.CharField(max_length=100, required=False)
    register_num = serializers.CharField(max_length=100, required=False)
    tax_num = serializers.CharField(max_length=100, required=False)
    local_country = serializers.CharField(max_length=10, required=False)
    local_city = serializers.CharField(max_length=30, required=False)
    local_region = serializers.CharField(max_length=40, required=False)
    local_address = serializers.CharField(max_length=150, required=False)
    local_postcode = serializers.CharField(max_length=10, required=False)
    phone_num = serializers.CharField(max_length=15, required=False)
    set_up_date = serializers.DateField(required=False)
    register_country = serializers.CharField(required=False)
    license_type = serializers.ChoiceField(choices=['passport', 'paper', 'driver_license'], required=False)
    last_name = serializers.CharField(max_length=100, required=False)
    first_name = serializers.CharField(max_length=100, required=False)
    middle_name = serializers.CharField(max_length=100, required=False)
    license_number = serializers.CharField(max_length=100, required=False)

    # def update(self, instance, validated_data):
    #     return KYCEnterprise.objects.filter(user_id=instance).update(**validated_data)
    def validate(self, attrs):
        user = self.context['request'].query_params.get('uid')
        if user:
            attrs.update(user_id=user)
        return attrs

    class Meta:
        model = KYCEnterprise
        # fields = "__all__"
        fields = (
            "company_name", "register_num", "tax_num",
            "local_country", "local_city", "local_region",
            "local_address", "local_postcode", "user_sign", "phone_num",
            "set_up_date", "register_country", "business_license",
            "org_cert", "auth_cert", "license_type", "last_name",
            "first_name", "middle_name", "license_number", "license_pic01",
            "license_pic02", "license_pic03", "industry")


####################################################
#     个人用户KYC:
####################################################
class IndividualKYCStep2Serializer(serializers.ModelSerializer):
    license_country = serializers.CharField(required=True, max_length=30)
    license_type1 = serializers.ChoiceField(choices=['passport', 'paper', 'driver_license'])
    last_name = serializers.CharField(required=True, max_length=256)
    first_name = serializers.CharField(required=True, max_length=256)
    middle_name = serializers.CharField(required=False, default='', max_length=256, allow_blank=True)
    license_number = serializers.CharField(required=True, max_length=100)
    industry = serializers.CharField(required=True, max_length=70)

    # user_sign2 = serializers.CharField(required=True)

    class Meta:
        model = KYCIndividual
        fields = (
            "license_country", "license_type1", "last_name", "first_name",
            "middle_name", "license_number", "industry"
        )

    # def update(self, instance, validated_data):
    #     return KYCIndividual.objects.filter(user_id=instance).update(**validated_data)


class IndividualKYCListSerializer(serializers.ModelSerializer):
    class Meta:
        model = KYCIndividual
        fields = (
            "current_level", "current_level_status",
            "change_list"
        )


class IndividualKYCUserNameSerializer(serializers.ModelSerializer):
    class Meta:
        model = KYCIndividual
        fields = (
            "user_id", "first_name", "last_name", "middle_name"
        )


class IndividualKYCAuthSerializer(serializers.ModelSerializer):

    def update(self, instance, validated_data):
        return KYCIndividual.objects.filter(user_id=instance).update(**validated_data)

    class Meta:
        model = KYCIndividual
        fields = "__all__"


class IndividualKYCStep3Serializer(serializers.ModelSerializer):
    license_type = serializers.ChoiceField(choices=['passport', 'paper', 'driver_license'])
    license_pic01 = serializers.FileField(required=False)
    license_pic02 = serializers.FileField(required=False)
    license_pic03 = serializers.FileField(required=False)

    # def validate(self, attrs):
    #     user = self.context['request'].user
    #     attrs.update(user_id=user.id)
    #     print(self.context)
    #     return attrs

    # def update(self, instance, validated_data):
    #     return KYCIndividual.objects.filter(user_id=instance).update(**validated_data)
    class Meta:
        model = KYCIndividual
        fields = (
            "license_type", "license_pic01", "license_pic02", "license_pic03"
        )


class IndividualKYCStep4Serializer(serializers.ModelSerializer):
    local_address = serializers.CharField(max_length=256)
    local_city = serializers.CharField(max_length=30)
    local_region = serializers.CharField(max_length=40)
    local_postcode = serializers.CharField(max_length=256)
    local_country = serializers.CharField(max_length=30)
    address_cert = serializers.FileField(required=False)

    # def update(self, instance, validated_data):
    #     return KYCIndividual.objects.filter(user_id=instance).update(**validated_data)
    class Meta:
        model = KYCIndividual
        fields = (
            "local_address", "local_city", "local_region", "local_postcode",
            "local_country", "address_cert"
        )


class IndividualKYCAuthStep2Serializer(IndividualKYCStep2Serializer):
    license_country = serializers.CharField(required=False, max_length=30)
    license_type1 = serializers.ChoiceField(choices=['passport', 'paper', 'driver_license'], required=False)
    last_name = serializers.CharField(required=False, max_length=100)
    first_name = serializers.CharField(required=False, max_length=100)
    middle_name = serializers.CharField(required=False, default='', max_length=100, allow_blank=True)
    license_number = serializers.CharField(required=False, max_length=100)
    industry = serializers.CharField(required=False, max_length=30)

    def validate(self, attrs):
        user = self.context['request'].query_params.get('uid')
        # csr = self.context['request'].user.uid
        attrs.update(uid=user)
        return attrs

    class Meta:
        model = KYCIndividual
        fields = (
            "license_country", "license_type1", "last_name", "first_name",
            "middle_name", "license_number", "industry",
        )
        # fields += ()


class IndividualKYCAuthStep3Serializer(serializers.ModelSerializer):
    license_country = serializers.CharField(required=False, max_length=30)
    license_type1 = serializers.ChoiceField(choices=['passport', 'paper', 'driver_license'], required=False)
    last_name = serializers.CharField(required=False, max_length=100)
    first_name = serializers.CharField(required=False, max_length=100)
    middle_name = serializers.CharField(required=False, default='', max_length=100, allow_blank=True)
    license_number = serializers.CharField(required=False, max_length=100)
    industry = serializers.CharField(required=False, max_length=30)
    license_type = serializers.ChoiceField(choices=['passport', 'paper', 'driver_license'], required=False)
    license_pic01 = serializers.FileField(required=False)
    license_pic02 = serializers.FileField(required=False)
    license_pic03 = serializers.FileField(required=False)

    def validate(self, attrs):
        user = self.context['request'].query_params.get('uid')
        # csr = self.context['request'].user.uid
        attrs.update(user_id=user)
        return attrs

    class Meta:
        model = KYCIndividual
        fields = (
            "license_country", "license_type1", "last_name", "first_name",
            "middle_name", "license_number", "industry", "change_list",
            "license_type", "license_pic01", "license_pic02", "license_pic03",
        )


class IndividualKYCAuthStep4Serializer(serializers.ModelSerializer):
    license_country = serializers.CharField(required=False, max_length=30)
    license_type1 = serializers.ChoiceField(choices=['passport', 'paper', 'driver_license'], required=False)
    last_name = serializers.CharField(required=False, max_length=100)
    first_name = serializers.CharField(required=False, max_length=100)
    middle_name = serializers.CharField(required=False, default='', max_length=100, allow_blank=True)
    license_number = serializers.CharField(required=False, max_length=100)
    industry = serializers.CharField(required=False, max_length=30)
    license_type = serializers.ChoiceField(choices=['passport', 'paper', 'driver_license'], required=False)
    license_pic01 = serializers.FileField(required=False)
    license_pic02 = serializers.FileField(required=False)
    license_pic03 = serializers.FileField(required=False)
    local_address = serializers.CharField(max_length=150, required=False)
    local_city = serializers.CharField(max_length=30, required=False)
    local_region = serializers.CharField(max_length=40, required=False)
    local_postcode = serializers.CharField(max_length=10, required=False)
    local_country = serializers.CharField(max_length=30, required=False)
    address_cert = serializers.FileField(required=False)

    def validate(self, attrs):
        user = self.context['request'].query_params.get('uid')
        attrs.update(user_id=user)
        return attrs

    class Meta:
        model = KYCIndividual
        fields = (
            "license_country", "license_type1", "last_name", "first_name",
            "middle_name", "license_number", "industry", "change_list",
            "license_type", "license_pic01", "license_pic02", "license_pic03",
            "local_address", "local_city", "local_region", "local_postcode",
            "local_country", "address_cert",
        )


class KYCLogSerializer(serializers.ModelSerializer):
    csr_name = serializers.SerializerMethodField('name')
    client_email = serializers.SerializerMethodField('email')
    client_id = serializers.SerializerMethodField('client_uuid')
    csr_id = serializers.SerializerMethodField('csr_uuid')

    class Meta:
        model = KYCLog
        fields = (
            'csr_name', 'client_email', 'kyc_level', 'csr_type',
            'client_id', 'csr_id', 'created_at_s', 'csr_data',
            'updated_at_s', 'application_status', 'id'
        )

    @staticmethod
    def name(obj):
        return obj.csr_name

    @staticmethod
    def email(obj):
        return obj.client_email

    @staticmethod
    def client_uuid(obj):
        return obj.client_uuid

    @staticmethod
    def csr_uuid(obj):
        return obj.csr_uuid


class KYCUserSerializer(serializers.ModelSerializer):
    user_id = serializers.SerializerMethodField('user_uuid')
    local_country = serializers.SerializerMethodField('country')

    class Meta:
        model = KYCIndividual
        fields = (
            "user_id", "created_at_s", "updated_at_s", "current_level", "current_level_status",
            "application_status", "name", "local_country"
        )

    @staticmethod
    def user_uuid(obj):
        return obj.user_id_hex

    @staticmethod
    def country(obj):
        return obj.license_country


class KYCEnterUserSerializer(serializers.ModelSerializer):
    user_id = serializers.SerializerMethodField('user_uuid')

    class Meta:
        model = KYCEnterprise
        fields = (
            "user_id", "created_at_s", "updated_at_s", "current_level", "current_level_status",
        )

    @staticmethod
    def user_uuid(obj):
        return obj.user_id_hex


class KYCCSRCommentSerializer(serializers.ModelSerializer):
    comment = serializers.CharField(max_length=5000)

    class Meta:
        model = KYCCSRComment
        fields = (
            "id", "key", "comment"
        )


class KYCLogSumSerializer(serializers.ModelSerializer):
    csr_name = serializers.SerializerMethodField('name')
    client_email = serializers.SerializerMethodField('email')
    client_id = serializers.SerializerMethodField('client_uuid')
    csr_id = serializers.SerializerMethodField('csr_uuid')

    class Meta:
        model = KYCLog
        fields = (
            'csr_name', 'client_email', 'kyc_level', 'csr_type', 'client_id', 'csr_id', 'created_at', 'csr_data'
        )

    @staticmethod
    def name(obj):
        return obj.csr_name

    @staticmethod
    def email(obj):
        return obj.client_email

    @staticmethod
    def client_uuid(obj):
        return obj.client_uuid

    @staticmethod
    def csr_uuid(obj):
        return obj.csr_uuid
