# -*- coding:utf-8 -*-
import datetime
import json
import logging

from rest_framework import viewsets, permissions
from rest_framework import status
from rest_framework import mixins
from rest_framework.response import Response
from maneki.apps.common.mixins.rest import BetterCreateModelMixin, BetterListModelMixin, BetterDestroyMixin
from maneki.apps.common.permissions.rest.permission_manage import StrictPermissionCheck
from maneki.apps.user_kyc.exceptions import NoneDataError, \
    ParamsError, UserKYCCompleted, LevelRefused, StatusRefused
from maneki.apps.user_kyc.libs.db.choices import CSRLogType
from maneki.apps.user_kyc.models import KYCIndividual, KYCEnterprise, KYCLog, LevelStatus, KYCCSRComment, User
from maneki.apps.user_kyc.utils import format_time_duration
from maneki.apps.user_kyc.views.filters import CSRKYCFilter, UserKYCFilter, EnterpriseFilter, CSRKYCLogFilter
from maneki.apps.user_kyc.views.serializers.profile import EnterpriseKYCAuthSerializer, IndividualKYCAuthSerializer, \
    IndividualKYCAuthStep2Serializer, IndividualKYCAuthStep3Serializer, IndividualKYCAuthStep4Serializer, \
    KYCLogSerializer, IndividualKYCListSerializer, KYCUserSerializer, KYCEnterUserSerializer, \
    IndividualKYCStep2Serializer, KYCCSRCommentSerializer, IndividualKYCUserNameSerializer, KYCLogSumSerializer
from maneki.apps.user_kyc.service import get_kyc_models_object, \
    IndividualUserService, EnterpriseUserService, IndividualListService, \
    KYCAuthLogService, AuthImageUpload, KYCEnterpriseAuthService
from maneki.apps.user_kyc.views.serializers.profile import EnterpriseKYCSerializer

logger = logging.getLogger(__name__)


class KYCEnterpriseViewSet(mixins.CreateModelMixin, mixins.ListModelMixin, viewsets.GenericViewSet):
    serializer_class = EnterpriseKYCSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return KYCEnterprise.objects.all()

    def create(self, request, *args, **kwargs):
        """上传 企业用户 输入的证件信息, 要求headers中携带用户token

        参数示例:

            第一步:

            POST Json:

                {
                  "company_name": "string",   //企业名称
                  "register_num": "string",   //企业登记号
                  "tax_num": "string",        //税号
                  "local_address": "string",  //公司地址
                  "local_city": "string",     //城市
                  "local_region": "string",   //州,省份,地区
                  "local_postcode": "string", //邮编
                  "local_country": "string",  //国家
                  "phone_num": "1241234123",  //公司电话
                  "set_up_date": "2018-01-01",   //公司注册日期
                  "register_country": "string",  //公司注册国家
                  "industry": "manufacturing"  //行业信息
                }

            第二步:

            Form-data

                {
                    "business_license",  //营业执照
                    "org_cert",  //组织机构代码证
                }

            JSON

                {
                    "msg": "ok"  // 图片上传完毕后上传
                }

            第三步:

            JSON

                {
                  "license_type": "passport/paper/driver_license",  //证件类型
                  "last_name": "string",       //姓
                  "first_name": "string",      //名
                  "middle_name": "string",     //中间名
                  "license_number": "string",  //证件号
                }

            Form-data

                {
                    "auth_cert"  //企业授权书
                    "license_pic01",  //驾照/身份证/护照正面照
                    "license_pic02",  //身份证照反面
                    "license_pic03",  //驾照/身份证/护照手持证件照
                }

        Response:

            success: 201
                {
                    "url": "http://demo.com/1.jpg"
                }
            failed: 400

                {
                    "detail": "用户信息上传结束, 请勿重复上传"
                }
                {
                    "detail": {"file_name": ("license_pic01", "license_pic03")}  //当用户未将全部的文件上传,返回用户缺少的文件名
                }
                {
                    "first_name": ["This field is required."]  //发送的json数据缺少字段时返回
                }
        """
        # 防止未认证的用户访问
        user_id = request.user.user_id
        user_obj = get_kyc_models_object(user_id)
        user_step = user_obj.current_step
        user_status = user_obj.current_level_status
        if user_status == LevelStatus.submitted.name:
            raise UserKYCCompleted
        # data = request.data
        # result, status_info = handle_enterprise_user_info(user_id, user_step, data)
        enterprise = EnterpriseUserService(request, user_step)
        result, status_info = enterprise.run()
        return Response(result, status=status_info)

    def list(self, request, *args, **kwargs):
        """获取 企业用户 的注册步骤与审核状态, 要求headers中携带用户token

        Response:

            success: 200
                {
                    "local_step": 1,  //用户当前处于的步骤
                    "user_verify_status": "not_started",  //用户当前的状态
                    "local_level": 1  //用户当前的等级
                    "auth_comment": ""  //客服拒绝的字段列表
                }
        """
        user_id = request.user.user_id
        # 根据用户ID获取数据库对象
        u = get_kyc_models_object(user_id)
        user_step = u.current_step
        user_status = u.current_level_status
        user_level = u.current_level
        auth_comment = u.change_list
        result = {
            "code": status.HTTP_200_OK,
            "detail": "ok",
            "data": {},
        }
        result.get('data').update({'local_step': user_step,
                                   'user_verify_status': user_status,
                                   'local_level': user_level,
                                   'auth_comment': auth_comment})
        if user_status == LevelStatus.manual_rejected.name:
            user_obj = KYCEnterprise.objects.filter(uid=request.user.user_id).first()
            # ser = EnterpriseKYCAuthSerializer(instance=u)
            # response_dict.get("params_dict").update(ser.data)
            change_list = user_obj.change_list
            result.get('data').update(change_list=change_list)

        return Response(result,
                        status=status.HTTP_200_OK)


class KYCIndividualViewSet(mixins.ListModelMixin, mixins.CreateModelMixin, viewsets.GenericViewSet):
    serializer_class = IndividualKYCAuthSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return KYCIndividual.objects.all()

    def list(self, request, *args, **kwargs):
        """获取 个人用户 的注册步骤与审核状态, 要求headers中携带用户token

        Response:

            success: 200
                {
                    "user_verify_status": "not_started      /未开始
                                           submitted        /审核中
                                           auto_approved    /自动审核通过
                                           manual_approved  /人工审核通过
                                           manual_rejected  /人工审核拒绝",  //用户当前的状态
                    "local_level": 1,  //用户当前的等级
                    "auth_comment": {
                                        "change_list": "",
                                        "reject_reason": ""
                                    },  //客服审核拒绝的字段列表
                    "params_dict": {}  //当状态为客服拒绝时, 返回当前level的用户填写信息; 其他状态为空
                }
        """
        user_id = request.user.user_id
        ser_obj = IndividualListService(user_id)
        msg = ser_obj.get_message()
        return Response(msg, status=status.HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        """上传 个人用户 输入的证件信息或图片, 要求headers中携带用户token

        参数示例:
            POST Json:

                {
                  // 第一步
                  "license_country": "string",
                  "license_type1": "passport/paper/driver_license",  //用户level2认证时填写的证件类型
                  "last_name": "string",
                  "first_name": "string",
                  "middle_name": "string",
                  "license_number": "string",
                  "industry": "-1",  //行业信息
                  // 第二步
                  "license_type": "passport/paper/driver_license",  //用户level3认证时填写的证件类型
                  // 第三步
                  "local_country": "string",
                  "local_city": "string",
                  "local_region": "string",
                  "local_address": "string",
                  "local_postcode": "string",
                }
                {
                  "user_sign3": "0/1"  //
                  "license_type": "paper"  //当level3图片上传完毕时,发送,返回200与用户缺少的数据
                }
            or Form-data
                {
                    "license_pic01",  //驾照/身份证/护照正面照
                    "license_pic02",  //身份证照反面
                    "license_pic03",  //驾照/身份证/护照手持证件照
                    "address_cert"  //当地地址文件证明
                }

        Response:

            success:
            201
                {
                    "msg": "OK"  //信息上传成功, 返回
                }
            200
                {
                    "license_pic01": "http://aws/1.jpg"  //图片上传成功, 返回图片的url
                }

            failed: 400

                {
                    "detail": "用户信息上传结束, 请勿重复上传"  //用户处于审核状态时返回
                }
                {
                    "detail": {"file_name": ("license_pic01", "license_pic03")}  //当用户未将全部的文件上传,返回用户缺少的文件名
                }
                {
                    "first_name": ["This field is required."]  //发送的json数据缺少字段时返回
                }
        """
        # 防止未认证的用户访问
        user_id = request.user.user_id
        # 当用户审核状态为未开始或驳回时,才可进行下一步
        # if not check_user_level_status(user_id, 'individual'):
        #     raise UserKYCCompleted
        # current_level = get_individual_user_current_level(user_id)
        # result, status_info = handle_individual_user_info(request, current_level)
        user_obj = get_kyc_models_object(user_id, 'individual')
        current_level, current_status = user_obj.current_level, user_obj.current_level_status
        if current_status == LevelStatus.submitted.name:
            raise UserKYCCompleted
        handle_user = IndividualUserService(request, current_level, user_id)
        result, status_info = handle_user.run()
        return Response(result, status=status_info)


class KYCIndividualAuthLevel1ViewSet(BetterListModelMixin, BetterCreateModelMixin, viewsets.GenericViewSet):
    """个人用户审核第一步

    """
    serializer_class = IndividualKYCAuthStep2Serializer
    pagination_class = None
    create_save_required = False
    client_current_level = 1
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]

    def get_queryset(self):
        return KYCIndividual.objects.all()

    def do_create(self, request, serializer, instance, *args, **kwargs):
        msg = request.data.get('msg')
        if msg not in ('1', '0', 1, 0):
            raise ParamsError
        result = self.response_result
        client_id = request.query_params.get('uid')
        current_level = self.client_current_level
        logger.info("individual auth, msg: {}, client_id: {}, client_kyc_level: {}".format(msg,
                                                                                           client_id,
                                                                                           current_level + 1))
        ser = KYCAuthLogService()
        ser.super_user_create(client_id, current_level + 1, str(msg))
        # if result_info:
        #     serializer.is_valid(raise_exception=True)
        #     serializer.save()
        # result.update(result_temp)
        result.update(code=status.HTTP_201_CREATED)
        return result

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        log_service = KYCAuthLogService()
        # 获取kyc表中的信息
        user_obj = KYCIndividual.objects.filter(user_id=request.query_params.get("uid")).first()
        ser = self.get_serializer(instance=user_obj)
        # result.get('data').update(serializer.data[0])
        result.get('data').update(ser.data)
        # 主管获取客服的修改记录
        log_date = log_service.get_log(request.query_params.get('uid'), self.client_current_level + 1)
        if log_date:
            result.get('data').update({"csr_data": log_date})
        return result

    def create(self, request, *args, **kwargs):
        """主管审核个人用户客服申请, 请求url中需带上uid
        只有主管可以访问接口

            super_user:

                {
                    "msg": "1/0",  // OK/Rejected
                }

        """
        # if not self.request.user.is_superuser():
        #     raise NotStaffError
        user_id = self.request.query_params.get('uid')
        # 判断url中是否传递了uid
        if not user_id:
            raise ParamsError
        return super(KYCIndividualAuthLevel1ViewSet, self).create(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """主管审核个人用户客服申请
        获得用户的id与当前level后,调用,请求url中需带上uid
        """
        user_id = self.request.query_params.get('uid')
        # 判断url中是否传递了uid
        if not user_id:
            raise ParamsError
        return super(KYCIndividualAuthLevel1ViewSet, self).list(request, *args, **kwargs)


class KYCIndividualAuthLevel2ViewSet(KYCIndividualAuthLevel1ViewSet):
    serializer_class = IndividualKYCAuthStep3Serializer
    client_current_level = 2


class KYCIndividualAuthLevel3ViewSet(KYCIndividualAuthLevel1ViewSet):
    serializer_class = IndividualKYCAuthStep4Serializer
    client_current_level = 3


class KYCIndividualAuthCSRLevel1ViewSet(BetterListModelMixin, BetterCreateModelMixin, viewsets.GenericViewSet):
    """"""
    serializer_class = IndividualKYCAuthStep2Serializer
    pagination_class = None
    level_int = 1
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]

    def get_queryset(self):
        return KYCIndividual.objects.all()

    def do_list(self, request, serializer, *args, **kwargs):
        uid = request.query_params.get('uid')
        result = self.response_result
        user_obj = KYCIndividual.objects.filter(user_id=uid).first()
        ser = self.get_serializer(instance=user_obj)
        data = ser.data
        service = KYCAuthLogService()
        check_result = 0
        if self.level_int == 1:
            check_result = service.check_info(data)
        result.get('data').update({
            "data": data,
            "error": check_result
        })
        return result

    def do_create(self, request, serializer, instance, *args, **kwargs):
        result = self.response_result
        client_id = request.query_params.get('uid')
        current_level = self.level_int
        if not client_id:
            raise NoneDataError
        csr_id = request.user.user_id
        key = current_level + 1
        service = KYCAuthLogService()
        csr_status = str(request.data.get('status'))
        csr_data = request.data.get("data")
        logger.info("individual csr auth, data: {}, client_id: {}, current_level: {}, csr_id: {}".format(request.data,
                                                                                                         client_id,
                                                                                                         current_level,
                                                                                                         csr_id))
        # 判断审核状态
        if csr_status == '0':
            service.individual_auth_pass(client_id, self.level_int)
            service.create_csr_log(client_id=client_id, csr_id=csr_id, kyc_level=key, csr_type=CSRLogType.PASSED)
        elif csr_status == '1':
            service.auth_changed(client_id, csr_id, key, csr_data)
        elif csr_status == '2':
            service.auth_rejected(client_id, csr_data)
            service.create_csr_log(client_id=client_id, csr_id=csr_id, kyc_level=key, csr_type=CSRLogType.REJECTED, value=json.dumps(csr_data))
        else:
            raise NoneDataError
        result.update(code=status.HTTP_201_CREATED)
        return result

    def create(self, request, *args, **kwargs):
        """客服提交审核结果, 请求时需带上uid参数(用户id)
        如果客服审核全部通过,则在fields_pass中传'1'; 如果审核不通过,将字段传入fields_rejected,
        如果客服需要修改字段,则将修改的字段传入fields_changed
        POST:

            {
                "status": 0/1/2,  // 通过,修改,拒绝
                "data": {
                        "change_list": "first_name,last_name",
                        "reason": 13
                        }  // 状态为拒绝时
                "data": {
                        "license_type":{
                            "before_change":"",
                            "after_change":"",
                            "common":""
                        },
                        "last_name":{
                            "before_change":"",
                            "after_change":"",
                            "common":""
                        }  // 状态为修改时
                }
            }

        """
        user_id = self.request.query_params.get('uid')
        # 判断url中是否传递了uid
        if not user_id:
            raise ParamsError
        return super(KYCIndividualAuthCSRLevel1ViewSet, self).create(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """客服获取用户的提交的信息, 需在url中带上uid参数

            Request: auth/level1/csr/?uid=1
        """
        user_id = self.request.query_params.get('uid')
        # 判断url中是否传递了uid
        if not user_id:
            raise ParamsError
        return super(KYCIndividualAuthCSRLevel1ViewSet, self).list(request, *args, **kwargs)


class KYCIndividualAuthCSRLevel2ViewSet(KYCIndividualAuthCSRLevel1ViewSet):
    """"""
    serializer_class = IndividualKYCAuthStep3Serializer
    level = "level_2"
    level_int = 2


class KYCIndividualAuthCSRLevel3ViewSet(KYCIndividualAuthCSRLevel1ViewSet):
    serializer_class = IndividualKYCAuthStep4Serializer
    level = "level_3"
    level_int = 3


class KYCAuthImageViewSet(BetterCreateModelMixin, viewsets.GenericViewSet):
    """

    """
    serializer_class = IndividualKYCListSerializer
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]

    def get_queryset(self):
        return KYCIndividual.objects.all()

    def do_create(self, request, serializer, instance, *args, **kwargs):
        result = self.response_result
        image_key, *others = request.FILES
        logger.info("auth image, image_key: {}, file: {}".format(image_key, request.FILES.get(image_key).name))
        service = AuthImageUpload()
        url = service.image_upload(request.FILES.get(image_key), image_key)
        result.update(data=url, code=201, detail='created')
        return result

    def create(self, request, *args, **kwargs):
        """
        客服上传图片, 使用form_data上传, 直接将获取到的URL保存
        """
        if not request.FILES:
            raise NoneDataError
        # return self.do_create()
        return super(KYCAuthImageViewSet, self).create(request, *args, **kwargs)


class KYCAuthUserListViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    serializer_class = KYCLogSerializer
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]
    filter_class = CSRKYCFilter
    create_save_required = False

    def get_queryset(self):
        return KYCLog.objects

    def filter_queryset(self, queryset):
        timestamp_start = self.request.query_params.get('timestamp_start', None)
        timestamp_end = self.request.query_params.get('timestamp_end', None)
        start_at, end_at = format_time_duration(timestamp_start, timestamp_end)
        uid = self.request.query_params.get('uid', -1)
        csr = self.request.query_params.get('csr', -1)
        application_status_temp = self.request.query_params.get('status', -1)
        user_email = self.request.query_params.get('email')
        kyc_type = self.request.query_params.get('kyc_type')
        ser = IndividualListService
        filter_dict = {
            "updated_at__gte": start_at,
            "updated_at__lte": end_at,
            "csr_type": CSRLogType.MODIFICATION,
        }
        if uid != -1:
            filter_dict.update(
                client_id=uid
            )
        if csr != -1:
            filter_dict.update(
                csr_id=csr
            )
        application_status = ser.handle_app(application_status_temp)
        if application_status != -1:
            filter_dict.update(
                application_status=application_status
            )
        if user_email:
            uid = ser.get_uid_from_email(user_email)
            if uid:
                filter_dict.update(
                    client_id=uid
                )
        if kyc_type:
            filter_dict.update(
                csr_type=kyc_type
            )
        qs = self.get_queryset().filter(**filter_dict).order_by("-created_at")
        return qs

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        data = serializer.data
        if data:
            result.update(data=data)
        return result

    def list(self, request, *args, **kwargs):
        """主管获取客服申请的列表

        GET /?page=4&?key=user&?value=peter

            status: {
                0  // 审核未开始
                1  // 审核已提交
                2  // 审核拒绝
                3  // 审核通过
            }

        Response:

            {
                "user_verify_status": "not_started"     /未开始
                                       submitted        /审核中
                                       auto_approved    /自动审核通过
                                       manual_approved  /人工审核通过
                                       manual_rejected  /人工审核拒绝",  //用户当前的状态
                "application_status":-1, 'Undefined'
                                      0, 'Not Started'  // 未开始
                                      1, 'Submitted'  // 已提交
                                      2, 'Rejected'  // 拒绝
                                      3, 'Approved'  // 通过
            }

        """
        return super(KYCAuthUserListViewSet, self).list(request, *args, **kwargs)


class KYCUserListViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    """客服查询个人客户列表"""
    serializer_class = KYCUserSerializer
    filter_class = UserKYCFilter
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]

    def get_queryset(self):
        return KYCIndividual.objects.all().order_by("-updated_at")

    def filter_queryset(self, queryset):
        timestamp_start = self.request.query_params.get('timestamp_start', None)
        timestamp_end = self.request.query_params.get('timestamp_end', None)
        start_at, end_at = format_time_duration(timestamp_start, timestamp_end)
        current_status_temp = self.request.query_params.get('status', -1)
        application_status_temp = self.request.query_params.get('app', -1)
        user_email = self.request.query_params.get('email', None)
        user_nationality = self.request.query_params.get('nationality')
        logger.info('timestamp_end: {}, timestamp_start: {}, current_status_temp: {}, application_status_temp: {}, user_email: {}'.format(
            timestamp_end, timestamp_start, current_status_temp, application_status_temp, user_email
        ))
        ser = IndividualListService
        filter_dict = {
            "updated_at__gte": start_at,
            "updated_at__lte": end_at,
        }
        current_status = ser.handle_status(current_status_temp)
        if current_status != -1:
            filter_dict.update(
                current_level_status=current_status,
            )
        application_status = ser.handle_app(application_status_temp)
        if application_status != -1:
            filter_dict.update(
                application_status=application_status
            )
        if user_email:
            uid = ser.get_uid_from_email(user_email)
            if uid:
                filter_dict = {
                    "user_id": uid
                }
        if user_nationality == "Others":
            country_list = ['AD', 'AE', 'AF', 'AG', 'AI', 'AL', 'AM', 'AO', 'AR', 'AT', 'AU', 'AZ', 'BB', 'BD', 'BE',
                            'BF', 'BG', 'BH', 'BI', 'BJ', 'BL', 'BM', 'BN', 'BO', 'BR', 'BS', 'BW', 'BY', 'BZ', 'CA',
                            'CF', 'CG', 'CH', 'CK', 'CL', 'CM', 'CO', 'CR', 'CS', 'CU', 'CY', 'CZ', 'DE', 'DJ', 'DK',
                            'DO', 'DZ', 'EC', 'EE', 'EG', 'ES', 'ET', 'FI', 'FJ', 'FR', 'GA', 'GB', 'GD', 'GE', 'GF',
                            'GH', 'GI', 'GM', 'GN', 'GR', 'GT', 'GU', 'GY', 'HK', 'HN', 'HT', 'HU', 'ID', 'IE', 'IL',
                            'IN', 'IQ', 'IR', 'IS', 'IT', 'JM', 'JO', 'JP', 'KE', 'KG', 'KH', 'KP', 'KR', 'KT', 'KW',
                            'KZ', 'LA', 'LB', 'LC', 'LI', 'LK', 'LR', 'LS', 'LT', 'LU', 'LV', 'LY', 'MA', 'MC', 'MD',
                            'MG', 'ML', 'MM', 'MN', 'MO', 'MS', 'MT', 'MU', 'MV', 'MW', 'MX', 'MY', 'MZ', 'NA', 'NE',
                            'NG', 'NI', 'NL', 'NO', 'NP', 'NR', 'NZ', 'OM', 'PA', 'PE', 'PF', 'PG', 'PH', 'PK', 'PL',
                            'PR', 'PT', 'PY', 'QA', 'RO', 'RU', 'SA', 'SB', 'SC', 'SD', 'SE', 'SG', 'SI', 'SK', 'SL',
                            'SM', 'SN', 'SO', 'SR', 'ST', 'SV', 'SY', 'SZ', 'TD', 'TG', 'TH', 'TJ', 'TM', 'TN', 'TO',
                            'TR', 'TT', 'TW', 'TZ', 'UA', 'UG', 'US', 'UY', 'UZ', 'VC', 'VE', 'VN', 'YE', 'YU', 'ZA',
                            'ZM', 'ZR', 'ZW']
            filter_dict.update(
                # ~Q(local_country="CN")
                license_country__in=country_list
            )
        elif user_nationality == "CN":
            filter_dict.update(
                license_country="CN"
            )
        qs = self.get_queryset().filter(**filter_dict)
        return qs

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        data = serializer.data
        if data:
            result.update(data=data)
        return result

    def list(self, request, *args, **kwargs):
        """
        客服查询个人客户列表

            status: {
                0  // 审核通过
                1  // 等待审核
                2  // 审核不通过
            }

            app: {
                0  // 审核未开始
                1  // 审核已提交
                2  // 审核拒绝
                3  // 审核通过
            }

        Response:

            {
                "user_verify_status": "not_started"      /未开始
                                       submitted        /审核中
                                       auto_approved    /自动审核通过
                                       manual_approved  /人工审核通过
                                       manual_rejected  /人工审核拒绝",  //用户当前的状态
                "application_status":-1, 'Undefined'
                                      0, 'Not Started'  // 未开始
                                      1, 'Submitted'  // 已提交
                                      2, 'Rejected'  // 拒绝
                                      3, 'Approved'  // 通过
            }

        """
        return super(KYCUserListViewSet, self).list(request, *args, **kwargs)


class KYCEnterUserListViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    """客服查询企业用户列表"""
    serializer_class = KYCEnterUserSerializer
    filter_class = EnterpriseFilter
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]

    def get_queryset(self):
        return KYCEnterprise.objects.all()

    def filter_queryset(self, queryset):
        timestamp_start = self.request.query_params.get('timestamp_start', None)
        timestamp_end = self.request.query_params.get('timestamp_end', None)
        start_at, end_at = format_time_duration(timestamp_start, timestamp_end)
        current_status_temp = self.request.query_params.get('status', -1)
        logger.info('timestamp_start: {}, timestamp_end: {}, current_status_temp: {}'.format(
            timestamp_start, timestamp_end, current_status_temp
        ))
        ser = IndividualListService
        filter_dict = {
            "updated_at__gte": start_at,
            "updated_at__lte": end_at,
        }
        current_status = ser.handle_status(current_status_temp)
        if current_status != -1:
            filter_dict.update(
                current_level_status=current_status
            )
        qs = self.get_queryset().filter(**filter_dict)
        return qs

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        data = serializer.data
        if data:
            result.update(data=data)
        return result

    def list(self, request, *args, **kwargs):
        """
        客服查询企业用户列表
        """
        return super(KYCEnterUserListViewSet, self).list(request, *args, **kwargs)


class KYCEnterpriseAuthCSRViewSet(BetterListModelMixin, BetterCreateModelMixin, viewsets.GenericViewSet):
    queryset = KYCEnterprise.objects.all()
    serializer_class = EnterpriseKYCAuthSerializer
    pagination_class = None
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        user_id = self.request.query_params.get('uid')
        if not user_id:
            raise ParamsError
        queryset = KYCEnterprise.objects.filter(user_id=user_id)
        serializer = self.get_serializer(queryset, many=True)
        result.get("data").update(serializer.data[0])
        return result

    def do_create(self, request, serializer, instance, *args, **kwargs):
        result = self.response_result
        user_id = self.request.query_params.get('uid')
        if not user_id:
            raise ParamsError
        csr_status = request.data.get("status")
        if csr_status not in (0, 1, '0', '1'):
            raise ParamsError
        csr_status = str(csr_status)
        fields_rejected = request.data.get("data")
        service = KYCEnterpriseAuthService()
        if csr_status == '1':
            service.auth_rejected(user_id, fields_rejected)
        else:
            # 审核通过
            service.auth_pass(user_id, 1)
        result.update(code=status.HTTP_201_CREATED)
        return result

    def create(self, request, *args, **kwargs):
        """客服提交审核结果, 需带上uid参数

            Request: /?uid=fasdrewdf

                {
                    "status": 0/1,  //通过/拒绝
                    "data": "",  //将拒绝的字段传入
                }

        """
        return super(KYCEnterpriseAuthCSRViewSet, self).create(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        """客服获取用户的所有信息, 需带上uid参数

        Request: /?uid=fasdrewdf

        """
        return super(KYCEnterpriseAuthCSRViewSet, self).list(request, *args, **kwargs)


class KYCEnterpriseAuthViewSet(BetterCreateModelMixin, viewsets.GenericViewSet):
    """主管修改企业用户的注册信息

    """
    queryset = KYCEnterprise.objects.all()
    serializer_class = EnterpriseKYCAuthSerializer
    pagination_class = None
    create_save_required = False
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]

    def do_create(self, request, serializer, instance, *args, **kwargs):
        user_id = self.request.query_params.get('uid')
        if not user_id:
            raise ParamsError
        result = self.response_result
        service = KYCEnterpriseAuthService()
        service.director_save(request.data, user_id)
        result.update(code=status.HTTP_201_CREATED)
        return result

    def create(self, request, *args, **kwargs):
        """主管修改企业用户的注册信息
        POST:  /?uid=asdfas

            {
                "last_name": "fasdf",  //将修改的的字段放在后面即可
                ......
            }

        """
        return super(KYCEnterpriseAuthViewSet, self).create(request, *args, **kwargs)


class KYCIndividualLevel1ViewSet(BetterCreateModelMixin, BetterListModelMixin, viewsets.GenericViewSet):
    """个人用户KYC第一步"""
    serializer_class = IndividualKYCStep2Serializer
    queryset = KYCIndividual.objects.all()
    pagination_class = None
    create_save_required = False
    current_level = 1

    def do_create(self, request, serializer, instance, *args, **kwargs):
        pass

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        user_obj = self.get_queryset().filter(user_id=request.user.user_id).first()
        if user_obj.current_level != self.current_level:
            raise LevelRefused
        if user_obj.current_level_status != LevelStatus.manual_rejected.name:
            raise StatusRefused
        data = self.get_serializer(user_obj)
        result.update(data=data)

    def list(self, request, *args, **kwargs):
        """当审核拒绝时, 返回用户填写的正确信息

        """
        super(KYCIndividualLevel1ViewSet, self).list(request, *args, **kwargs)

    def create(self, request, *args, **kwargs):
        """个人用户KYC审核, 提交信息
            POST Json:

                {
                  // 第一步
                  "license_country": "string",  //用户国籍
                  "license_type1": "passport/paper/driver_license",  //证件类型
                  "last_name": "string",
                  "first_name": "string",
                  "middle_name": "string",
                  "license_number": "string",  //证件号码
                  "industry": "-1",  //行业信息
                }

        """
        super(KYCIndividualLevel1ViewSet, self).create(request, *args, **kwargs)


class InformationCheckViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    permission_classes = [permissions.IsAuthenticated,]
    pagination_class = None
    serializer_class = None

    def get_queryset(self):
        return KYCIndividual.objects

    def list(self, request, *args, **kwargs):
        """
        检查身份信息是否已经存在
        GET
        """
        result = self.response_result
        user_get_in = request.query_params.get('license')
        if not user_get_in:
           raise ParamsError
        license_num = self.get_queryset().filter(license_number=user_get_in,
                                                 current_level__in=('3', '4')).first()
        # 当用户填入的证件号码已经存在时, 返回错误
        if license_num:
            result.update(
                code=464,
                detail='this license number has been activated.'
            )
            return Response(result)
        return Response(result)


class KYCChangeUserNameViewSet(BetterCreateModelMixin, viewsets.GenericViewSet):
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]
    pagination_class = None
    serializer_class = IndividualKYCUserNameSerializer

    def get_queryset(self):
        return KYCIndividual.objects

    def create(self, request, *args, **kwargs):
        """修改用户姓名
        Params:

             Param        | detail
             user_id      | 用户ID
             email        | 用户email
             first_name   | 名
             middle_name  | 中间名
             last_name    | 姓

        Response:

            {
                "code": 200,
                "detail": "ok",
                "data": ""
            }

        Response Code:

             Http Code | detail
             201       | ok
             450       | need user_id
             451       | need user name
             452       | User not exist
             500       | server error

        """
        result = self.response_result
        user_id = self.request.data.get("user_id")
        user_email = self.request.data.get("email")
        first_name = self.request.data.get("first_name")
        middle_name = self.request.data.get("middle_name")
        last_name = self.request.data.get("last_name")
        if not user_id:
            if not user_email:
                result.update({
                    "code": 450,
                    "detail": "need user id"
                })
                return Response(result)
            user_id = User.objects.filter(email=user_email).first().user_id
        qs = {}
        if first_name:
            qs.update(first_name=first_name)
        if middle_name:
            qs.update(middle_name=middle_name)
        if last_name:
            qs.update(last_name=last_name)
        if not qs:
            result.update({
                "code": 451,
                "detail": "need user name"
            })
            return Response(result)
        user_obj = self.get_queryset().filter(user_id=user_id)
        if not user_obj:
            result = {
                "code": 452,
                "detail": "User not exist",
                "data": ""
            }
            return Response(result)
        user_obj.update(**qs)
        result.update(code=201)
        return Response(result)


class KYCCSRCommentViewSet(BetterListModelMixin, BetterCreateModelMixin, BetterDestroyMixin, viewsets.GenericViewSet):
    """客服拒绝理由"""
    permission_classes = [permissions.IsAuthenticated,]
    pagination_class = None
    serializer_class = KYCCSRCommentSerializer

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        data = serializer.data
        if data:
            result.update(data=data)
        return result

    def do_create(self, request, serializer, instance, *args, **kwargs):
        result = self.response_result
        comment = request.data.get('comment')
        if not comment:
            result.update(
                code=464,
                detail='None data has received'
            )
            return result
        comment_obj = KYCCSRComment.objects.filter(comment=comment).first()
        if comment_obj:
            result.update(
                code=465,
                detail='This comment has already exist'
            )
            return result
        # KYCCSRComment.objects.create(comment=comment)
        return result

    def do_destroy(self, request, *args, **kwargs):
        result = self.response_result
        return result

    def list(self, request, *args, **kwargs):
        """
        Response:

            {
                "paper": [{
                           "EN": "Example",
                           "CN": "理由"
                           },
                          {
                          "EN": "Example",
                          "CN": "理由"
                          }
                ],
                "passport": [{
                              "EN": "Example",
                              "CN": "理由"
                              },
                              {
                              "EN": "Example",
                              "CN": "理由"
                              }
                ],
                "driver_license": [{
                                   "EN": "Example",
                                   "CN": "理由"
                                   },
                                  {
                                  "EN": "Example",
                                  "CN": "理由"
                                  }
                ],
                "address_cert": [{
                                   "EN": "Example",
                                   "CN": "理由"
                                   },
                                  {
                                  "EN": "Example",
                                  "CN": "理由"
                                  }
                ],
                "others": [{
                           "EN": "Example",
                           "CN": "理由"
                           },
                          {
                          "EN": "Example",
                          "CN": "理由"
                          }
                ],
            }
        """
        super(KYCCSRCommentViewSet, self).list(request, *args, **kwargs)

    def create(self, request, *args, **kwargs):
        """
        """
        super(KYCCSRCommentViewSet, self).create(request, *args, **kwargs)


class KYCCsrLogCountViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    """用户请求数据分析"""
    serializer_class = KYCLogSumSerializer
    filter_class = CSRKYCLogFilter
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = None

    def get_queryset(self):
        return KYCLog.objects

    def filter_queryset(self, queryset=None):
        timestamp_start = self.request.query_params.get('timestamp_start')
        timestamp_end = self.request.query_params.get('timestamp_end')
        start_at, end_at = format_time_duration(timestamp_start, timestamp_end)
        client_id = self.request.query_params.get('client_id')
        csr_id = self.request.query_params.get('csr_id')
        filter_dict = {
            "created_at__gte": start_at,
            "created_at__lte": end_at,
        }
        if client_id:
            filter_dict.update(
                client_id=client_id
            )
        if csr_id:
            filter_dict.update(
                csr_id=csr_id
            )
        qs = self.get_queryset().filter(**filter_dict)
        return qs

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        result.update(data={
            "total_count": self.filter_queryset().count(),
            "level_3_count": self.filter_queryset().filter(kyc_level=3).count(),
            "level_4_count": self.filter_queryset().filter(kyc_level=4).count(),
            "pass_count": self.filter_queryset().filter(csr_type=CSRLogType.PASSED).count(),
            "reject_count": self.filter_queryset().filter(csr_type=CSRLogType.REJECTED).count(),
            "change_count": self.filter_queryset().filter(csr_type=CSRLogType.MODIFICATION).count(),
        })
        return result

    def list(self, request, *args, **kwargs):
        """客服请求统计

        Params:

             Param           | detail
             timestamp_start | 开始时间戳
             timestamp_end   | 结束时间戳
             client_id       | 用户ID
             csr_id          | 客服ID

        Response:

            {
                "code": 200,
                "detail": "ok",
                "data": {
                            "total_count": 4,    //处理总数
                            "level_3_count": 4,  //l3处理数量
                            "level_4_count": 0,  //l4处理数量
                            "pass_count": 1,     //请求通过数量
                            "reject_count": 1,   //请求拒绝数量
                            "change_count": 2    //请求修改数量
                          }
            }

        Response Code:

             Http Code | detail
             200       | ok
             500       | server error

        """
        return super(KYCCsrLogCountViewSet, self).list(request, *args, **kwargs)


class KYCIndividualBirthViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = None

    def list(self, request, *args, **kwargs):
        result = self.response_result
        user_id = self.request.user.user_id
        birth = KYCIndividual.objects.filter(user_id=user_id).first().birth
        if birth == datetime.date(2037, 7, 7):
            birth = ""
        result.update(data={"birth": birth})
        return Response(result)
