from django.utils import timezone
import json
import logging
import os
import re
import sys
import time
import docx
from django.core.files.uploadedfile import InMemoryUploadedFile
from rest_framework import status

from config.settings.base import APPS_DIR
from maneki.apps.constants import UPLOAD_FILE_SIZE, UPLOAD_IMAGE_HEIGHT, INDIVIDUAL_APP_1, INDIVIDUAL_APP_2, \
    IS_UPLOAD_DOCX, ENTERPRISE_APP_1, UPLOAD_FILE_TYPE, UPLOAD_IMAGE_TYPE
from maneki.apps.user.models import User
from maneki.apps.user_kyc.exceptions import FileTypeError, FileSizeError, FileLostError, \
    NeedMoreFileError, UserKYCCompleted, FileUploadFail, NoneDataError, UserKYCSuccess, RepetitionError, NeedReason
from maneki.apps.user_kyc.libs.db.choices import LevelStatus, UserCurrentStep, CSRApplicationStatus, CSRLogType
from PIL import Image
import io
from maneki.apps.user_kyc.libs.s3_storage_backend import PrivateMediaStorage
from maneki.apps.user_kyc.models import KYCEnterprise, KYCIndividual, KYCLog
from maneki.apps.user_kyc.utils import generate_file_name, check_file, get_file_extension, is_cn_id_valid

MSG_OK = {'detail': 'ok',
          'code': status.HTTP_200_OK,
          'data': {}}
# MSG_OK = {
#     "msg": "OK"
# }
LOGGER = logging.getLogger(__name__)


def get_kyc_models_object(user, key='enterprise'):
    # 查询用户的KYC信息，当用户首次注册时，新建用户对象
    if key == 'enterprise':
        obj, result = KYCEnterprise.objects.get_or_create(user_id=user)
        return obj
    else:
        obj, result = KYCIndividual.objects.get_or_create(user_id=user)
        return obj


class BaseStorage(object):

    @staticmethod
    def _image_resize(file, new_file_name, file_key):
        # old_file = self.request.FILES.get(self.file_key)
        LOGGER.info(
            "BaseStorage, resize, new_file_name: {}, file_key: {}, old_file_name".format(new_file_name, file_key))
        img = Image.open(file)
        # saving it to memory
        thumb_io = io.BytesIO()
        w, h = img.size
        if h > UPLOAD_IMAGE_HEIGHT:
            h2 = UPLOAD_IMAGE_HEIGHT
            w2 = int(h2 * w / h)
        else:
            h2, w2 = h, w
        img.resize((w2, h2)).save(thumb_io, file.content_type.split('/')[-1].upper())
        # generating name for the new file
        new_file_name = new_file_name
        # creating new InMemoryUploadedFile() based on the modified file
        file_temp = InMemoryUploadedFile(thumb_io,
                                         file_key,  # important to specify field name here
                                         new_file_name,
                                         file.content_type,
                                         sys.getsizeof(thumb_io),
                                         None)
        return file_temp

    def upload_to_s3(self, file_name, file, file_type, file_key):
        LOGGER.info('BaseStorage, upload, file_name: {}, file_type: {}, file_key: {}'.format(file_name,
                                                                                             file_type,
                                                                                             file_key))
        f = PrivateMediaStorage()
        if file_type == 'image':
            try:
                new_file = self._image_resize(file, file_name, file_key)
            except Exception as e:
                LOGGER.error("image resize error: {}".format(e))
                raise FileTypeError
        else:
            new_file = file
        try:
            f.save(file_name, new_file)
        except Exception as e:
            LOGGER.error("file upload to s3 error: {}".format(e))
            raise FileUploadFail
        file_url = f.url(file_name)
        LOGGER.info('BaseStorage, upload, file_url: {}'.format(file_url))
        return file_url


class FileStorage(BaseStorage):
    """
    保存用户上传的图片与文件
    """

    def __init__(self, request):
        self.request = request
        self.logger = LOGGER
        self.user_obj = KYCEnterprise.objects.filter(user_id=request.user.user_id)
        self.file_key, *ignore = self.request.FILES
        self.file_type = None

    def file_storage_v2(self):
        file = self.request.FILES.get(self.file_key)
        file_check_result, self.file_type = self._check_user_file(file)
        if not file_check_result:
            raise FileTypeError
        if file.size > UPLOAD_FILE_SIZE:
            raise FileSizeError
        result, file_url, file_name = self._handle_upload_file(file)
        self.logger.info("""FileStorage.file_storage_v2, 
                            file_check_result: {}, file_type: {}, 
                            new_file_name: {}, user_id: {}""".format(file_check_result,
                                                                     self.file_type,
                                                                     file_name,
                                                                     self.request.user.user_id))
        if not result:
            return {"file_url": file_url}, status.HTTP_201_CREATED
        else:
            raise FileLostError

    def _handle_upload_file(self, f):
        """
        保存用户上传的文件
        :param f: 文件
        :return:
        """
        file_name = generate_file_name(f.name)
        file_url = self.upload_to_s3(file_name, f, self.file_type, self.file_key)
        # 保存文件名到数据库
        db_result = self._save_to_database(file_name)
        return db_result, file_url, file_name

    def _check_user_file(self, file):
        # 判断用户上传的文件格式是否正确
        self.logger.info('FileStorage._check_user_file, file_key: {}, file_name: {}'.format(self.file_key, file.name))
        return check_file(self.file_key, file.name)

    def _save_to_database(self, file_name):
        file_dict = {self.file_key: file_name}
        try:
            self.user_obj.update(**file_dict)
        except Exception as e:
            self.logger.error('user: {} storage file {} error: {}'.format(self.request.user.id, self.file_key, e))
            raise FileUploadFail


# class AuthFileStorage(FileStorage):
#     """
#     客服保存图片
#     """
#
#     def __init__(self, request):
#         super(AuthFileStorage, self).__init__(request)
#         self.id = request.query_params.get('uid')


class IndividualImageStore(FileStorage):
    """用于个人用户上传图片"""

    def __init__(self, request):
        super(IndividualImageStore, self).__init__(request)
        self.user_obj = KYCIndividual.objects.filter(user_id=request.user.user_id)


class EnterpriseUserService(object):
    """
    处理企业用户的kyc注册
    """

    def __init__(self, request, step):
        self.request = request
        self.step = step
        self.logger = LOGGER

    def run(self):
        user_obj = KYCEnterprise.objects.filter(user_id=self.request.user.user_id).first()
        current_level = user_obj.current_level
        current_level_status = user_obj.current_level_status
        self.logger.info("""EnterpriseUserService.run, user_id: {}, 
                            user_step: {}, user_status: {}, request_data: {}, 
                            request_file: {}""".format(self.request.user.user_id,
                                                       current_level, current_level_status, self.request.data,
                                                       self.request.FILES))
        if current_level == 2:
            raise UserKYCSuccess
        # 当用户审核状态为未开始或驳回时,才可进行注册
        if current_level_status == LevelStatus.not_started.name:
            return self._kyc_start()
        elif current_level_status == LevelStatus.submitted.name:
            raise UserKYCCompleted
        elif current_level_status == LevelStatus.manual_rejected.name:
            return self._reject()
        else:
            raise UserKYCCompleted

    def _kyc_start(self):
        if self.step == UserCurrentStep.STEP_1:
            return self._user_step1()
        if self.step in (UserCurrentStep.STEP_2, UserCurrentStep.STEP_3):
            return self._user_step2_or_3()
        else:
            raise NeedMoreFileError

    def _user_step1(self):
        # TODO: 循环引用, 清理代码
        from maneki.apps.user_kyc.views.serializers.profile import EnterpriseKYCStep1Serializer, \
            EnterpriseKYCStep3Serializer, \
            IndividualKYCStep2Serializer, IndividualKYCStep3Serializer, IndividualKYCStep4Serializer

        serializer1 = EnterpriseKYCStep1Serializer(
            instance=self.request.user.user_id, data=self.request.data)
        serializer1.is_valid(raise_exception=True)
        serializer1.save()
        self._change_user_step_level(self.request.user.user_id, UserCurrentStep.STEP_2)
        return MSG_OK, status.HTTP_201_CREATED

    def _user_step2_or_3(self):
        if self.request.FILES:
            return self._file_storage()
        elif self.request.data:
            return self._data_storage()
        else:
            raise NoneDataError

    def _file_storage(self):
        image_storage = FileStorage(self.request)
        return image_storage.file_storage_v2()

    def _data_storage(self):
        if self.step == UserCurrentStep.STEP_2:
            return self._data_storage2()
        elif self.step == UserCurrentStep.STEP_3:
            return self._data_storage3()
        else:
            raise NoneDataError

    def _check_msg(self):
        return self.request.data.get('msg')

    def _data_storage2(self):
        result, msg = self._check_file_in_db2()
        if result:
            self._change_user_step_level(self.request.user.user_id, UserCurrentStep.STEP_3)
            # 生成合同文件
            self._generate_docx('user_sign', ENTERPRISE_APP_1)
            return MSG_OK, status.HTTP_200_OK
        else:
            return msg, status.HTTP_400_BAD_REQUEST

    def _generate_docx(self, sign, app_url):
        if not IS_UPLOAD_DOCX:
            return
        from maneki.taskapp.messagequeue import tasks
        user_name, industry = self.get_attr()
        uid = self.request.user.user_id
        start_time = time.time()
        tasks.generate_agreement.delay([uid, user_name, industry, sign, app_url])
        # self._upload_docx(uid, user_name, industry, sign, app_url)
        end_time = time.time()
        LOGGER.info("update_doc time: {}".format(end_time - start_time))

    def get_attr(self):
        user_obj = get_kyc_models_object(self.request.user.user_id)
        user_name = user_obj.first_name + user_obj.middle_name + user_obj.last_name
        industry = user_obj.industry
        return user_name, industry

    @staticmethod
    def _change_user_step_level(user_id, step=None, level=None):
        # 修改用户的注册步骤与当前level
        u = KYCEnterprise.objects.filter(user_id=user_id)
        if step:
            u.update(current_step=step)
            if step == UserCurrentStep.STEP_4:
                # 当第三步注册完成时，修改用户状态为'已提交'
                u.update(current_level_status=LevelStatus.submitted.name)
        if level:
            u.update(current_level=level)

    def _check_file_in_db2(self):
        user_obj = KYCEnterprise.objects.filter(user_id=self.request.user.user_id)
        bl = user_obj.first().business_license.name
        oc = user_obj.first().org_cert.name
        if all([bl, oc]):
            user_obj.update(current_step=UserCurrentStep.STEP_3)
            return True, None
        else:
            file_list = list()
            if not bl:
                file_list.append('business_license')
            if not oc:
                file_list.append('org_cert')
            return False, {'detail': {'file_needed': file_list}}

    def _data_storage3(self):

        from maneki.apps.user_kyc.views.serializers.profile import EnterpriseKYCStep1Serializer, \
            EnterpriseKYCStep3Serializer

        serializer3 = EnterpriseKYCStep3Serializer(instance=self.request.user.user_id, data=self.request.data)
        serializer3.is_valid(raise_exception=True)
        serializer3.save()
        result, msg = self._check_file_in_db3()
        if result:
            self._change_user_step_level(self.request.user.user_id, UserCurrentStep.STEP_4)
            return MSG_OK, status.HTTP_201_CREATED
        else:
            return msg, status.HTTP_400_BAD_REQUEST

    def _check_file_in_db3(self):
        # 用户KYC审核第二步结束时, 判断用户的信息是否完整
        user_obj = KYCEnterprise.objects.filter(user_id=self.request.user.user_id).first()
        cert_type = user_obj.license_type
        if cert_type in ('passport', 'driver_license'):
            p1 = user_obj.license_pic01.name
            if p1 == " ":
                p1 = None
            p3 = user_obj.license_pic03.name
            if p3 == " ":
                p3 = None
            ac = user_obj.auth_cert.name
            if ac == " ":
                ac = None
            if all([p1, p3, ac]):
                return True, None
            else:
                file_list = list()
                if not p1:
                    file_list.append('license_pic01')
                if not p3:
                    file_list.append('license_pic03')
                if not ac:
                    file_list.append('auth_cert')
                return False, {'detail': {'file_needed': file_list}}
        elif cert_type == 'paper':
            p1 = user_obj.license_pic01.name
            if p1 == " ":
                p1 = None
            p2 = user_obj.license_pic02.name
            if p2 == " ":
                p2 = None
            p3 = user_obj.license_pic03.name
            if p3 == " ":
                p3 = None
            ac = user_obj.auth_cert.name
            if ac == " ":
                ac = None
            if all([p1, p2, p3, ac]):
                return True, None
            else:
                file_list = list()
                if not p1:
                    file_list.append('license_pic01')
                if not p2:
                    file_list.append('license_pic02')
                if not p3:
                    file_list.append('license_pic03')
                if not ac:
                    file_list.append('auth_cert')
                return False, {'detail': {'file_needed': file_list}}
        else:
            return False, {'detail': 'license_type error'}

    @staticmethod
    def _reject():
        return MSG_OK.update(detail='csr reject your registration'), status.HTTP_200_OK


def change_individual_user(user_id, data):
    """
    改变个人客户的审核状态
    :param user_id:
    :param data:
    :return:
    """
    try:
        data.update({"updated_at": timezone.now()})
        KYCIndividual.objects.filter(user_id=user_id).update(**data)
    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.error("'change_individual_user' error: {}".format(e))
        raise FileUploadFail


def change_enterprise_uid(user_id, data):
    """
    改变企业客户的审核状态
    """
    try:
        data.update({"updated_at": timezone.now()})
        KYCEnterprise.objects.filter(user_id=user_id).update(**data)
    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.error("'change_enterprise_uid' error: {}".format(e))
        raise FileUploadFail


class IndividualUserService(object):
    """
    处理用户上传信息与图片, 返回错误信息与http状态
    """

    def __init__(self, request, current_step, user_id):
        self.request = request
        self.current_step = current_step
        self.logger = LOGGER
        self.user_id = user_id

    def run(self):
        if self.current_step == 1:
            return self._step1()
        elif self.current_step in (2, 3):
            return self._step2_or_3()
        else:
            raise UserKYCSuccess

    def _step1(self):

        from maneki.apps.user_kyc.views.serializers.profile import EnterpriseKYCStep1Serializer, \
            EnterpriseKYCStep3Serializer, \
            IndividualKYCStep2Serializer, IndividualKYCStep3Serializer, IndividualKYCStep4Serializer

        user_obj = get_kyc_models_object(self.user_id, 'individual')
        serializer2 = IndividualKYCStep2Serializer(instance=user_obj, data=self.request.data)
        serializer2.is_valid(raise_exception=True)
        # 检查中国身份证号合法性
        if self.request.data.get('license_country') == 'CN' and self.request.data.get('license_type1') == 'paper':
            if not is_cn_id_valid(self.request.data.get('license_number')):
                return {"code": 461, "detail": "invalid CN id", "data": {}}, status.HTTP_200_OK
        # 检查证件号是否重复
        r = self.check_id(self.request.data.get('license_number'))
        if not r:
            return {"code": 451, "detail": "invalid id", "data": {}}, status.HTTP_200_OK
        serializer2.save()
        self.generate_docx('user_sign2', serializer2, INDIVIDUAL_APP_1)
        # 将用户状态修改为通过
        change_individual_user(user_id=self.user_id,
                               data={'current_level_status': LevelStatus.not_started.name,
                                     'current_level': 2})
        return MSG_OK, status.HTTP_201_CREATED

    def _step2_or_3(self):
        if self.request.FILES:
            return self._file_storage()
        elif self.request.data:
            return self._data_storage()
        else:
            raise NoneDataError

    def generate_docx(self, sign, serializer, app_url):
        if not IS_UPLOAD_DOCX:
            return
        from maneki.taskapp.messagequeue import tasks
        first_name = serializer.validated_data.get('first_name', "")
        middle_name = serializer.validated_data.get('middle_name', "")
        last_name = serializer.validated_data.get('last_name', "")
        user_name = first_name + " " + middle_name + " " + last_name
        industry = serializer.validated_data.get('industry', "")
        if not (user_name or industry):
            user_name, industry = self.get_attr()
        uid = self.user_id.hex
        start_time = time.time()
        tasks.generate_agreement((uid, user_name, industry, sign, app_url))
        # self._upload_docx(uid, user_name, industry, sign, app_url)
        end_time = time.time()
        LOGGER.info("update_doc time: {}".format(end_time - start_time))

    @staticmethod
    def _upload_docx(uid, user_name, industry, sign, app_url):
        f = DocUpload(uid, user_name, industry, sign)
        f.upload(app_url)

    def _file_storage(self):
        image_storage = IndividualImageStore(self.request)
        return image_storage.file_storage_v2()

    def _data_storage(self):
        if self.current_step == 2:
            return self._data_storage_2()
        else:
            return self._data_storage_3()

    def _data_storage_2(self):

        from maneki.apps.user_kyc.views.serializers.profile import EnterpriseKYCStep1Serializer, \
            EnterpriseKYCStep3Serializer, \
            IndividualKYCStep2Serializer, IndividualKYCStep3Serializer, IndividualKYCStep4Serializer

        user_obj = get_kyc_models_object(self.user_id, 'individual')
        serializer3 = IndividualKYCStep3Serializer(instance=user_obj, data=self.request.data)
        # 前端发送传送完毕信息(msg=OK), 判断表中的数据是否完整
        serializer3.is_valid(raise_exception=True)
        self._serializer_save(serializer3)
        # try:
        self.generate_docx('user_sign3', serializer3, INDIVIDUAL_APP_2)
        # except Exception as e:
        #     self.logger.error("upload docx sign3 error: {}".format(e))
        # raise FileUploadFail
        # 查表判断信息是否完整
        result, msg = self._check_step2()
        # if result:
        #     change_individual_user(user_id=self.user_id, data={'current_level': UserCurrentStep.STEP_2})
        return self._handle_check_result(result, msg)

    def _data_storage_3(self):

        from maneki.apps.user_kyc.views.serializers.profile import EnterpriseKYCStep1Serializer, \
            EnterpriseKYCStep3Serializer, \
            IndividualKYCStep2Serializer, IndividualKYCStep3Serializer, IndividualKYCStep4Serializer

        user_obj = get_kyc_models_object(self.user_id, 'individual')
        serializer4 = IndividualKYCStep4Serializer(instance=user_obj, data=self.request.data)
        serializer4.is_valid(raise_exception=True)
        serializer4.save()
        # 判断表中的数据是否完整
        result, msg = self._check_step3()
        # if result:
        #     change_individual_user(user_id=self.user_id, data={'current_level': UserCurrentStep.STEP_3})
        return self._handle_check_result(result, msg)

    @staticmethod
    def _serializer_save(serializer):
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return MSG_OK, status.HTTP_201_CREATED

    def _handle_check_result(self, result, msg):
        if result:
            change_individual_user(user_id=self.user_id,
                                   data={'current_level_status': LevelStatus.submitted.name,
                                         'change_list': ' '})
            return MSG_OK, status.HTTP_201_CREATED
        else:
            return msg, status.HTTP_400_BAD_REQUEST

    def _check_step2(self):
        # 用户KYC审核第二步结束时, 判断用户的信息是否完整
        user_obj = KYCIndividual.objects.filter(user_id=self.user_id).first()
        cert_type = user_obj.license_type
        if cert_type in ('passport', 'driver_license'):
            p1 = user_obj.license_pic01.name
            if p1 == " ":
                p1 = None
            p3 = user_obj.license_pic03.name
            if p3 == " ":
                p3 = None
            if p1 and p3:
                return True, None
            else:
                file_list = list()
                if not p1:
                    file_list.append('license_pic01')
                if not p3:
                    file_list.append('license_pic03')
                return False, {'detail': {'file_needed': file_list}}
        elif cert_type == 'paper':
            p1 = user_obj.license_pic01.name
            if p1 == " ":
                p1 = None
            p2 = user_obj.license_pic02.name
            if p2 == " ":
                p2 = None
            p3 = user_obj.license_pic03.name
            if p3 == " ":
                p3 = None
            if all([p1, p2, p3]):
                return True, None
            else:
                file_list = list()
                if not p1:
                    file_list.append('license_pic01')
                if not p2:
                    file_list.append('license_pic02')
                if not p3:
                    file_list.append('license_pic03')
                return False, {'detail': {'file_needed': file_list}}
        else:
            return False, {'detail': 'license_type error'}

    def _check_step3(self):
        # 用户kyc验证第三步结束时, 检查用户的信息是否完整
        user_obj = KYCIndividual.objects.filter(user_id=self.user_id).first()
        p1 = user_obj.address_cert.name
        if p1 == " ":
            p1 = None
        t1 = user_obj.local_city
        if t1 == " ":
            t1 = None
        if all([p1, t1]):
            return True, None
        else:
            return False, {'detail': {'file_needed': ('address_cert',)}}

    def get_attr(self):
        user_obj = get_kyc_models_object(self.user_id, 'individual')
        user_name = user_obj.first_name + user_obj.middle_name + user_obj.last_name
        industry = user_obj.industry
        return user_name, industry

    @staticmethod
    def check_id(id_num):
        if KYCIndividual.objects.filter(license_number=id_num).count():
            return False
        return True


class DocUpload(object):

    def __init__(self, uid, user_name, industry, sign):
        self.user_name = user_name
        self.industry = industry
        self.date_cn = time.strftime("%Y{} %m{} %d{}", time.gmtime()).format('年', '月', '日')
        self.date_en = time.strftime("%d %b %Y", time.gmtime())
        self.replace_data = dict()
        self.user_id = uid
        self.sign = sign
        self.logger = LOGGER

    def replace(self, app_url):
        self.replace_data.update({'#name#': self.user_name,
                                  'datecn': self.date_cn,
                                  'dateen': self.date_en,
                                  '#industry#': self.industry})
        document = docx.Document(str(os.path.join(str(APPS_DIR), app_url)))
        for k, v in self.replace_data.items():
            self._replace_text(document, k, v)
        return document

    def upload(self, app_url):
        file = self.replace(app_url)
        thumb_io = io.BytesIO()
        file.save(thumb_io)
        file_name = generate_file_name('.docx')
        file_temp = InMemoryUploadedFile(thumb_io,
                                         'docx_file',  # important to specify field name here
                                         file_name,
                                         'docx',
                                         sys.getsizeof(thumb_io),
                                         None)
        try:
            f = PrivateMediaStorage()
            f.save(file_name, file_temp)
        except Exception as e:
            self.logger.error("doc upload error: {}".format(e))
            raise FileUploadFail
        self._save_to_database(file_name)
        return f.url(file_name)

    @staticmethod
    def _replace_text(doc, old_text, new_text):
        for p in doc.paragraphs:
            if old_text in p.text:
                inline = p.runs
                for i in inline:
                    if old_text in i.text:
                        text = i.text.replace(old_text, str(new_text))
                        i.text = text

    def _save_to_database(self, file_name):
        change_individual_user(self.user_id, {self.sign: file_name})


class IndividualListService(object):

    def __init__(self, user_id):

        from maneki.apps.user_kyc.views.serializers.profile import EnterpriseKYCStep1Serializer, \
            EnterpriseKYCStep3Serializer, \
            IndividualKYCStep2Serializer, IndividualKYCStep3Serializer, IndividualKYCStep4Serializer

        self.serializer_dict = {
            1: IndividualKYCStep2Serializer,
            2: IndividualKYCStep3Serializer,
            3: IndividualKYCStep4Serializer
        }
        self.user_id = user_id
        self.queryset = KYCIndividual.objects.filter(user_id=self.user_id)

    def get_message(self):
        # get_kyc_models_object(self.user_id, 'individual')
        # msg = {
        #     "code": status.HTTP_200_OK,
        #     "detail": "ok",
        #     "data": {},
        # }
        msg = {"params_dict": {}}
        u = get_kyc_models_object(self.user_id, 'individual')
        user_status = u.current_level_status
        user_level = u.current_level
        msg.update({'user_verify_status': user_status,
                    'local_level': user_level,
                    'auth_comment': ""})
        if user_status == 'manual_rejected':
            params_dict = self._handle(user_level)
            msg["params_dict"].update(params_dict)
            msg.update(auth_comment=u.change_list,
                       reject_reason=u.reject_reason)
        return msg

    def _handle(self, level):
        serializer = self.serializer_dict.get(int(level))(self.queryset, many=True)
        return serializer.data[0]

    @staticmethod
    def handle_status(user_status):
        status_dict = {
            0: 'not_started',
            1: 'submitted',
            2: 'manual_rejected'
        }
        if user_status not in ('1', '2', '3', '4', '0', 0, 1, 2, 3, 4):
            return -1
        status_temp = int(user_status)
        return status_dict.get(status_temp)

    @staticmethod
    def handle_app(app):
        if app not in ('0', '1', '2', '3', 0, 1, 2, 3):
            return -1
        return int(app)

    @staticmethod
    def get_uid_from_email(email):
        user_obj = User.objects.filter(email=email).first()
        if not user_obj:
            return None
        return user_obj.user_id


class KYCAuthLogService(object):

    @staticmethod
    def queryset_obj(uid, data):
        change_individual_user(uid, data)

    def get_log(self, user_id, current_step: int):
        queryset = KYCLog.objects.filter(client_id=user_id, kyc_level=current_step, csr_type=CSRLogType.MODIFICATION).last()
        if not queryset:
            return None
        user_obj = User.objects.filter(user_id=queryset.csr_id).first()
        result = {}
        # 为所有的文件生成url
        value = self.dict_handler(json.loads(queryset.value), 'get')
        result.update({
            'fields_data': value,
            'csr': user_obj.username,  # TODO 客服的真实姓名
        })
        return result

    @staticmethod
    def re_name(str_name):
        format_list = UPLOAD_FILE_TYPE + UPLOAD_IMAGE_TYPE
        format_str = "|".join(format_list)
        re_temp = "(?:{})".format(format_str)
        temp = re.search(r"\w{32}\." + re_temp, str_name)
        # temp = re.search(r"\w{32}\.(?:jpg|png|gif|jpeg|docx|doc|pdf)", str_name)
        if temp:
            return temp.group()
        return temp

    # @staticmethod
    # def upload_image(f, name):
    #
    #     try:
    #         up = PrivateMediaStorage()
    #         up.save(name, f)
    #     except Exception as e:
    #         LOGGER.error("auth image upload error: {}".format(e))
    #         raise FileUploadFail
    #     return up.url(name), name

    @staticmethod
    def check_info(data):
        license_number = data.get('license_number')
        auth_obj = KYCIndividual.objects.filter(license_number=license_number).count()
        if auth_obj == 1:
            return 0
        print(auth_obj)
        return 1

    @staticmethod
    def get_file_url(file_name, obj):
        return obj.url(file_name)

    def dict_handler(self, data, option):
        """
        {
            "license_pic01": {
                                "before_change": "",
                                "after_change": "",
                                "common": ""
                            },
            "last_name": {
                                "before_change": "",
                                "after_change": "",
                                "common": ""
                          },
            ... ...
        }
        :param data: 形式如上的字典
        :param option: 'get' 或 其他
        :return: 修改后的字典
        """
        if option == 'get':
            obj = PrivateMediaStorage()
        else:
            obj = None
        for k1, v1 in data.items():
            if k1 in ('license_pic01', 'license_pic02',
                      'license_pic03', 'business_license',
                      'org_cert', 'address_cert', 'auth_cert'):
                for k2, v2 in v1.items():
                    if k2 in ('before_change', 'after_change'):
                        if not v2:
                            continue
                        v1.update({k2: self._get_value(v2, option, obj)})
        return data

    def _get_value(self, v, option, obj):
        if option == 'get':
            value = self.get_file_url(self.re_name(v), obj)
        else:
            value = self.re_name(v)
        return value

    def auth_pass(self, user_id, level: int):
        level_temp = {"current_level_status": LevelStatus.not_started.name, "current_level": level + 1}
        self.queryset_obj(user_id, level_temp)

    def individual_auth_pass(self, user_id, level: int):
        self.auth_pass(user_id, level)
        self.service_email(user_id, "Passed")

    @staticmethod
    def delete_csr_log(client_id, level):
        obj_list = KYCLog.objects.filter(client_id=client_id, kyc_level=level, csr_type=CSRLogType.MODIFICATION)
        for i in obj_list:
            i.is_deleted = True
            i.save()

    @staticmethod
    def change_log_status(client_id, level, status):
        obj_list = KYCLog.objects.filter(client_id=client_id, kyc_level=level, csr_type=CSRLogType.MODIFICATION)
        for i in obj_list:
            i.application_status = status
            i.save()

    def auth_rejected(self, user_id, change_dict: dict):
        data_dict = {"current_level_status": LevelStatus.manual_rejected.name,
                     "change_list": change_dict.get('change_list')}
        reason = change_dict.get('reason')
        if not reason:
            raise NeedReason
        data_dict.update(reject_reason=reason)
        self.queryset_obj(user_id, data_dict)
        self.service_email(user_id, "Rejected")

    @staticmethod
    def create_csr_log(client_id, csr_id, kyc_level, csr_type, application_status=CSRApplicationStatus.UNDEFINED, value=""):
        KYCLog.objects.create(
            client_id=client_id,
            csr_id=csr_id,
            application_status=application_status,
            kyc_level=kyc_level,
            value=value,
            csr_type=csr_type
        )

    def service_email(self, user_id, status):
        """
        发送用户提醒
        :param user_id:
        :param status: "Rejected"/"Passed"
        :return:
        """
        from maneki.taskapp.messagequeue.tasks import send_email
        user_name, user_email, user_mobile, kyc_status, kyc_level, country_code = self._get_user_info(user_id, status)
        if kyc_status == 'Rejected':
            temp_id = 'no'
        else:
            temp_id = 'l{}'.format(kyc_level)
        send_email.delay(user_name, user_email, kyc_status, "BTCC Identity Authentication Result",
                   "no_reply@btcc.com", "kyc_{}".format(temp_id))

    @staticmethod
    def _get_user_info(user_id, status):
        user_obj = User.objects.filter(user_id=user_id).first()
        kyc_obj = KYCIndividual.objects.filter(user_id=user_id).first()
        user_email = user_obj.email
        user_mobile = user_obj.mobile
        mobile_country_code = user_obj.mobile_country_code
        kyc_status = status
        kyc_level = kyc_obj.current_level
        n1 = kyc_obj.first_name
        n2 = kyc_obj.last_name
        user_name = n1 + " " + n2
        return user_name, user_email, user_mobile, kyc_status, kyc_level, mobile_country_code

    @staticmethod
    def handel_change_list(change_str):
        change_list = change_str.split(",")
        change_dict = {}
        for i in change_list:
            change_dict.update({i: ""})
        return change_dict

    def auth_changed(self, client_id, csr_id, current_level, data: dict):
        self.check_log_exist(client_id, current_level)
        temp = self.dict_handler(data, 'delete')
        LOGGER.info("auth_changed, client_id: {}, csr_id: {}, current_level: {}, data: {}, temp: {}".format(
            client_id, csr_id, current_level, data, temp
        ))
        temp = json.dumps(temp)
        KYCLog.objects.create(
            client_id=client_id,
            csr_id=csr_id,
            kyc_level=current_level,
            value=temp,
            application_status=CSRApplicationStatus.SUBMITTED
        )
        self.queryset_obj(client_id, {"application_status": CSRApplicationStatus.SUBMITTED})

    @staticmethod
    def check_log_exist(client_id, current_level):
        log = KYCLog.objects.filter(client_id=client_id, kyc_level=current_level,
                                    application_status=CSRApplicationStatus.SUBMITTED, csr_type=CSRLogType.MODIFICATION)
        if log:
            raise RepetitionError

    def super_user_create(self, client_id, current_level, msg):
        LOGGER.info('super_user_create, client_id: {}, current_level: {}, msg: {}'.format(
            client_id, current_level, msg
        ))
        # 主管拒绝
        if msg == '0':
            self.change_log_status(client_id, current_level, CSRApplicationStatus.REJECTED)
            self.queryset_obj(client_id, {"application_status": CSRApplicationStatus.REJECTED})
            return None, False
        # 主管同意
        else:
            log_obj = KYCLog.objects.filter(client_id=client_id,
                                            kyc_level=current_level, csr_type=CSRLogType.MODIFICATION)
            csr_log = log_obj.last().value
            csr_dict = json.loads(csr_log)
            log_obj.update(application_status=CSRApplicationStatus.APPROVED)
            data_dict = {k: v.get("after_change") for k, v in csr_dict.items()}
            user_dict = {}
            user_dict.update({"current_level_status": LevelStatus.not_started.name,
                              "application_status": CSRApplicationStatus.NOT_STARTED,
                              "current_level": current_level})
            data_temp = self.handel_director_dict(data_dict)
            user_dict.update(data_temp)
            self.queryset_obj(client_id, user_dict)
            self.delete_csr_log(client_id, current_level)
            self.service_email(client_id, "Passed")
            return None, True

    def get_comment(self, payload):
        data = json.loads(payload)
        reason = data.get('reject_reason')
        return reason

    def handel_director_dict(self, data: dict):
        # 当传入包含url的文件名时,用正则处理后存入数据库
        for k, v in data.items():
            if k in ('license_pic01', 'license_pic02',
                     'license_pic03', 'business_license',
                     'org_cert', 'address_cert', 'auth_cert'):
                data.update({k: self.re_name(v)})
        return data


class AuthImageUpload(BaseStorage):
    """

    """

    def image_upload(self, data, file_key):
        LOGGER.info("auth image upload, file: {}, key: {}".format(data.name, file_key))
        file_name = generate_file_name(data.name)
        file_type = self._check_file(file_name)
        return self.upload_to_s3(file_name, data, file_type, file_key)

    @staticmethod
    def _check_file(file_name):
        LOGGER.info("auth check file, file_name: {}".format(file_name))
        file_ext = get_file_extension(file_name)
        if file_ext in UPLOAD_FILE_TYPE:
            return 'doc'
        elif file_ext in UPLOAD_IMAGE_TYPE:
            return 'image'
        else:
            raise FileTypeError


class KYCEnterpriseAuthService(KYCAuthLogService):
    @staticmethod
    def queryset_obj(uid, data):
        change_enterprise_uid(uid, data)

    def director_save(self, data: dict, uid):
        data_temp = self.handel_director_dict(data)
        self.queryset_obj(uid, data_temp)


class KYCIndividualBirthService(object):

    def __init__(self):
        self.queryset = KYCIndividual.objects

    def update_birth(self, user_id, birth):
        self.queryset.filter(user_id=user_id).update(birth=birth)

    def get_birth(self, user_id):
        kyc_obj = self.queryset.filter(user_id=user_id, current_level=4).first()
        if kyc_obj:
            return True, kyc_obj.birth
        else:
            return False, None
