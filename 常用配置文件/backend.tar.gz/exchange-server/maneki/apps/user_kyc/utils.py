import os
import re
import uuid

from maneki.apps.common.utils import date
from maneki.apps.constants import UPLOAD_FILE_TYPE, UPLOAD_IMAGE_TYPE


def generate_file_path(file_name):
    """
    生成文件名与路径
    :param file_name: 文件名
    :return: 文件路径
    """
    # 保存路径
    path = os.path.join(os.path.expanduser("~"), 'exchange_server/')
    # 当路径不存在时创建路径
    if not os.path.exists(path):
        os.mkdir(path)
    file_path = os.path.join(path, file_name)
    return file_path


def generate_file_name(f):
    """
    生成文件名
    :param f: 原文件名
    :return:
    """
    # file_name = hashlib.sha1((str(user_id)+file_key).encode()).hexdigest() + time.strftime(
    #     "-%Y-%m-%d-%H:%M:%S", time.localtime())
    file_name = uuid.uuid4().hex
    return '{}.{}'.format(file_name, get_file_extension(f))


def get_file_extension(f):
    return f.split(".")[-1].lower()


def check_file(file_key, file_name):
    if file_key == 'auth_cert':
        file_ext = get_file_extension(file_name)
        if file_ext in UPLOAD_FILE_TYPE:
            return True, 'file'
        else:
            return False, 'file'
    elif file_key in ('license_pic01', 'license_pic02',
                      'license_pic03', 'business_license',
                      'org_cert', 'address_cert'):
        file_ext = get_file_extension(file_name)
        if file_ext in UPLOAD_IMAGE_TYPE:
            return True, 'image'
        else:
            return False, 'image'
    else:
        return False, None


def format_time_duration(timestamp_start, timestamp_end):
    if timestamp_start and timestamp_end:
        timestamp_start = date.unix_to_datetime(int(timestamp_start[0:10]), "%Y-%m-%d %H:%M:%S")
        timestamp_end = date.unix_to_datetime(int(timestamp_end[0:10]), "%Y-%m-%d %H:%M:%S")
    else:
        timestamp_start = date.utc_now_str(timedelta_day=30)
        timestamp_end = date.utc_now_str()

    return timestamp_start, timestamp_end

pattern = re.compile('^[1-9]\\d{5}(18|19|([23]\\d))\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$')
RATIO = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2]
CHECK_CODE_LIST = ['1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2']


def is_cn_id_valid(id):
    if id and len(id) == 18 and pattern.match(id):
        chars = list(id)
        verify_code = chars.pop(17)
        id_sum = 0
        index = 0
        for i in chars:
            id_sum += int(i) * RATIO[index]
            index += 1
        id_sum %= 11
        return verify_code.upper() == CHECK_CODE_LIST[id_sum]
    return False
