from enum import Enum
from djchoices import DjangoChoices, ChoiceItem


class LicenseType(Enum):
    passport = 1
    paper = 2
    driver_license = 3


LicenseType_CHOICES = (
    (LicenseType.passport.name, '护照'),
    (LicenseType.paper.name, '证件'),
    (LicenseType.driver_license.name, '驾照'),
)

LicenseType_Map = {k: v for k, v in LicenseType_CHOICES}


class UserLicenseType(DjangoChoices):
    UNDEFINED = ChoiceItem(-1, 'Undefined')
    PASSPORT = ChoiceItem(0, 'passport')
    PAPER = ChoiceItem(1, 'paper')
    DRIVER_LICENSE = ChoiceItem(2, 'driver_license')


class UserLevelStatus(DjangoChoices):
    NOT_STARTED = ChoiceItem(0, 'not_started')  # 未开始
    SUBMITTED = ChoiceItem(1, 'submitted')  # 已提交
    AUTO_APPROVED = ChoiceItem(2, 'auto_approved')  # 自动审核通过
    MANUAL_APPROVED = ChoiceItem(3, 'manual_approved')  # 人工审核通过
    MANUAL_REJECTED = ChoiceItem(4, 'manual_rejected')  # 人工审核未通过


class ErrorMessage(DjangoChoices):
    OK = ChoiceItem(0, 'OK')
    FILE_NOT_ALLOWED = ChoiceItem(1, 'file type not allowed')  # 不允许的文件格式
    USER_STEP_ERROR = ChoiceItem(2, 'user step error')  # 用户的当前步骤数有误
    UPLOAD_ERROR = ChoiceItem(3, 'file upload error')  # 文件上传错误


class UserCurrentStep(DjangoChoices):
    STEP_1 = ChoiceItem(1, 'step_1')
    STEP_2 = ChoiceItem(2, 'step_2')
    STEP_3 = ChoiceItem(3, 'step_3')
    STEP_4 = ChoiceItem(4, 'step_4')


class CSRApplicationStatus(DjangoChoices):
    UNDEFINED = ChoiceItem(-1, 'Undefined')
    NOT_STARTED = ChoiceItem(0, 'Not Started')  # 未开始
    SUBMITTED = ChoiceItem(1, 'Submitted')  # 已提交
    REJECTED = ChoiceItem(2, 'Rejected')  # 拒绝
    APPROVED = ChoiceItem(3, 'Approved')  # 通过


class CSRLogType(DjangoChoices):
    UNDEFINED = ChoiceItem(-1, 'Undefined')
    MODIFICATION = ChoiceItem(0, 'modification')  # 修改
    REJECTED = ChoiceItem(1, 'rejected')          # 拒绝
    PASSED = ChoiceItem(2, 'passed')              # 通过


class LevelStatus(Enum):
    not_started = 1
    submitted = 2
    auto_approved = 3
    manual_approved = 4
    manual_rejected = 5


LevelStatus_CHOICES = (
    (LevelStatus.not_started.name, '未开始'),
    (LevelStatus.submitted.name, '已提交'),
    (LevelStatus.auto_approved.name, '自动审核通过'),
    (LevelStatus.manual_approved.name, '手工审核通过'),
    (LevelStatus.manual_rejected.name, '手工审核未通过'),
)

LevelStatus_Map = {k: v for k, v in LevelStatus_CHOICES}
