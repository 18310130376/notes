# -*- coding: utf-8 -*-
from django.db import models


class LicenseTypeField(models.CharField):
    description = 'user type'

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 20
        super(LicenseTypeField, self).__init__(*args, **kwargs)


class AuthenticationStateField(models.CharField):
    description = ' '

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 20
        super(AuthenticationStateField, self).__init__(*args, **kwargs)


class IDField(models.CharField):
    description = 'common id field'

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 50
        super(IDField, self).__init__(*args, **kwargs)


class UIDField(models.CharField):
    description = 'ID of User'

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 50
        super(UIDField, self).__init__(*args, **kwargs)


class S3IDField(models.FileField):
    description = 'S3 Object ID'

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 50
        super(S3IDField, self).__init__(*args, **kwargs)


class CountryCodeField(models.CharField):
    description = 'Code of Country'

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 30
        super(CountryCodeField, self).__init__(*args, **kwargs)


class StateCodeField(models.CharField):
    description = 'Code of State'

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 20
        super(StateCodeField, self).__init__(*args, **kwargs)


class CityCodeField(models.CharField):
    description = 'Code of City'

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 30
        super(CityCodeField, self).__init__(*args, **kwargs)


class RegionCodeField(models.CharField):
    description = 'Code of Regsion'

    def __init__(self, *args, **kwargs):
        kwargs['max_length'] = 40
        super(RegionCodeField, self).__init__(*args, **kwargs)
