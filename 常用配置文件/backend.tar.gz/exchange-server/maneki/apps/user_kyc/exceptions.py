# -*- coding: utf-8 -*-
from rest_framework.exceptions import APIException


class ParamsError(APIException):
    status_code = 200
    default_detail = {
        'code': 451,
        'detail': 'Need params'}


class NoneDataError(APIException):
    status_code = 200
    default_detail = {
        'code': 452,
        'detail': "None data has received"}


class FileTypeError(APIException):
    status_code = 200
    default_detail = {
        'code': 453,
        'detail': 'Invalid file type'}


class FileSizeError(APIException):
    status_code = 200
    default_detail = {
        'code': 454,
        'detail': 'file size out of limit'
    }


class FileLostError(APIException):
    status_code = 200
    default_detail = {
        'code': 455,
        'detail': 'file that needed not found'
    }


class NeedMoreFileError(APIException):
    status_code = 200
    default_detail = {
        'code': 456,
        'detail': 'need more file to complete the registration'
    }


class UserKYCCompleted(APIException):
    status_code = 200
    default_detail = {
        'code': 457,
        'detail': 'user kyc has already completed'
    }


class UserKYCSuccess(APIException):
    status_code = 200
    default_detail = {
        'code': 458,
        'detail': 'user kyc success'
    }


class FileUploadFail(APIException):
    status_code = 200
    default_detail = {
        "code": 459,
        "detail": "file upload fail"
    }


class RepetitionError(APIException):
    status_code = 200
    default_detail = {
        "code": 460,
        "detail": "do not update repetitively"
    }


class InvalidEmail(APIException):
    status_code = 200
    default_detail = {
        "code": 461,
        "detail": "invalid email"
    }


class LevelRefused(APIException):
    status_code = 200
    default_detail = {
        "code": 462,
        "detail": "user level error"
    }


class StatusRefused(APIException):
    status_code = 200
    default_detail = {
        "code": 463,
        "detail": "user status error"
    }


class NeedReason(APIException):
    status_code = 200
    default_detail = {
        "code": 464,
        "detail": "need reject reason"
    }

