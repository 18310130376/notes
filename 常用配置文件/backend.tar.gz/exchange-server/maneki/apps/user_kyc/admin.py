# -*- coding: utf-8 -*-
from django.contrib import admin

from maneki.apps.user_kyc.models import KYCIndividual, KYCEnterprise, KYCLog


class CountryAdmin(admin.ModelAdmin):
    pass


# class StateAdmin(admin.ModelAdmin):
#     pass
#
#
# class CityAdmin(admin.ModelAdmin):
#     pass
#
#
# class RegionAdmin(admin.ModelAdmin):
#     pass


class KYCIndividualAdmin(admin.ModelAdmin):
    pass


class KYCIndividualLogAdmin(admin.ModelAdmin):
    pass


class KYCEnterpriseAdmin(admin.ModelAdmin):
    pass


class KYCLogAdmin(admin.ModelAdmin):
    pass


admin.site.register(KYCIndividual, KYCIndividualAdmin)
admin.site.register(KYCEnterprise, KYCEnterpriseAdmin)
admin.site.register(KYCLog, KYCLogAdmin)
