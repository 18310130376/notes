# -*- coding: utf-8 -*-
import json
from datetime import datetime

from django.db import models
from django.utils.translation import ugettext_lazy as _

from maneki.apps.constants import MODEL_PREFIX
from maneki.apps.user.models import User
from maneki.apps.user_kyc.libs.db.choices import LicenseType_CHOICES, LevelStatus_CHOICES, LicenseType, LevelStatus, \
    UserCurrentStep, CSRApplicationStatus, CSRLogType
from maneki.apps.common.libs.models import SoftDeleteModel, UserSoftDeleteModel
from maneki.apps.user_kyc.libs.db.fields import \
    S3IDField, CityCodeField, CountryCodeField, RegionCodeField, LicenseTypeField, \
    AuthenticationStateField

# 前缀:
PREFIX_DB_VERBOSE = "KYC"
PREFIX_DB_TABLE = MODEL_PREFIX + "user_kyc_"


class KYCIndividual(UserSoftDeleteModel):
    # unique:
    user_id = models.UUIDField(verbose_name=_("User ID"), unique=True, null=False, blank=False, db_index=True)
    #
    license_country = CountryCodeField(verbose_name=_("License Country"), null=False, default="")
    license_type1 = LicenseTypeField(verbose_name=_("License Type 1"), null=False, choices=LicenseType_CHOICES, default=LicenseType.passport.name)

    last_name = models.CharField(verbose_name=_("Last Name"), max_length=256, null=False, default="")
    first_name = models.CharField(verbose_name=_("First Name"), max_length=256, null=False, default="")
    middle_name = models.CharField(verbose_name=_("Middle Name"), max_length=256, null=False, default="")
    industry = models.CharField(verbose_name=_("Industry"), max_length=256, null=False, default='')
    user_sign2 = S3IDField(verbose_name=_("User Agreement Step No.2"), null=False, default=' ')
    user_sign3 = S3IDField(verbose_name=_("User Agreement Step No.3"), null=False, default=' ')

    license_type = LicenseTypeField(
        verbose_name=_("License Type"), null=False, choices=LicenseType_CHOICES,
        default=LicenseType.passport.name)
    license_number = models.CharField(verbose_name=_("License Number"), max_length=256,
                                      null=False, default="")

    license_pic01 = S3IDField(verbose_name=_("License Picture 001"),
                              null=False, default=" ")
    license_pic02 = S3IDField(verbose_name=_("License Picture 002"), null=False,
                              default=" ")
    license_pic03 = S3IDField(verbose_name=_("License Picture 003"), null=False,
                              default=" ")

    address_cert = S3IDField(verbose_name=_("Address Certificate"), null=False,
                             default=" ")
    local_country = CountryCodeField(verbose_name=_("Local Country"), null=False, default="")
    local_city = CityCodeField(verbose_name=_("Local City"), null=False, default="")
    local_region = RegionCodeField(verbose_name=_("Local Region"), null=False, default="")
    local_address = models.CharField(verbose_name=_("Local Address"), max_length=256, null=False,
                                     default="")
    local_postcode = models.CharField(verbose_name=_("Local Postcode"), max_length=256, null=False,
                                      default="")
    birth = models.DateField(verbose_name=_("user birth"), default=datetime.strptime("2037-07-07", "%Y-%m-%d"))
    current_level = models.IntegerField(verbose_name=_("Current Level"), default=1)
    current_level_status = AuthenticationStateField(verbose_name=_("Current Level Status"),
                                                    choices=LevelStatus_CHOICES, default=LevelStatus.not_started.name)
    change_list = models.TextField(verbose_name=_("Current Level Change List"), max_length=1000,
                                   null=False, default="")
    application_status = models.IntegerField(verbose_name=_("Application Status"), null=False,
                                             choices=CSRApplicationStatus.choices,
                                             default=CSRApplicationStatus.NOT_STARTED)
    reject_reason = models.TextField(verbose_name=_(""), max_length=1000, null=False, default='')
    extra_image = models.CharField(default="", max_length=255)
    # 预留字段:
    extra_2 = models.CharField(default="", max_length=255)
    extra_3 = models.CharField(default="", max_length=255)
    extra_4 = models.CharField(default="", max_length=255)
    extra_5 = models.CharField(default="", max_length=255)
    extra_6 = models.CharField(default="", max_length=255)

    def name(self):
        return self.first_name + " " + self.last_name

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ': individual')
        verbose_name_plural = _(PREFIX_DB_VERBOSE + ': individual')
        db_table = PREFIX_DB_TABLE + "individual"


class KYCEnterprise(UserSoftDeleteModel):
    """
    企业用户
    """
    # unique:
    user_id = models.UUIDField(verbose_name=_("User ID"), unique=True, null=False, blank=False, db_index=True)
    #
    company_name = models.CharField(verbose_name=_("Company Name"), null=False, default='', max_length=256)
    register_num = models.CharField(verbose_name=_("Register Number"), null=False, default='', max_length=256)
    tax_num = models.CharField(verbose_name=_("Tax Number"), null=False, default='', max_length=256)
    local_country = CountryCodeField(verbose_name=_("Local Country"), null=False, default='')
    local_city = CityCodeField(verbose_name=_("Local City"), null=False, default='')
    local_region = RegionCodeField(verbose_name=_("Local Region"), null=False, default='')
    local_address = models.CharField(verbose_name=_("Local Address"), max_length=256, null=False,
                                     default='')
    local_postcode = models.CharField(verbose_name=_("Local Postcode"), max_length=256, null=False,
                                      default='')
    user_sign = S3IDField(verbose_name=_("User Agreement"), null=False, default='')
    phone_num = models.CharField(verbose_name=_("Phone Number"), max_length=256, null=False, default='')
    set_up_date = models.DateField(verbose_name=_("Company Set-up Date"), null=False, default="2018-3-17")
    register_country = CountryCodeField(verbose_name=_("Register Country"), null=False, default='')

    business_license = S3IDField(verbose_name=_("Business License"), null=False, default="")
    org_cert = S3IDField(verbose_name=_("Organization Code Certificate"), null=False, default="")

    auth_cert = S3IDField(verbose_name=_("Power Of Attorney"), null=False, default="")
    license_type = LicenseTypeField(
        verbose_name=_("License Type"), null=False, choices=LicenseType_CHOICES,
        default=LicenseType.passport.name)
    last_name = models.CharField(verbose_name=_("Last Name"), max_length=256, null=False, default='')
    first_name = models.CharField(verbose_name=_("First Name"), max_length=256, null=False, default='')
    middle_name = models.CharField(verbose_name=_("Middle Name"), max_length=256, null=False, default='')
    license_number = models.CharField(verbose_name=_("License Number"), max_length=256, null=False,
                                      default='')
    license_pic01 = S3IDField(verbose_name=_("License Picture 001"), null=False, default="")
    license_pic02 = S3IDField(verbose_name=_("License Picture 002"), null=False, default="")
    license_pic03 = S3IDField(verbose_name=_("License Picture 003"), null=False, default="")
    current_level = models.IntegerField(verbose_name=_("Current Level"), null=False, default=1)
    current_step = models.IntegerField(verbose_name=_("Current User Step"), null=False,
                                       choices=UserCurrentStep.choices, default=UserCurrentStep.STEP_1)
    current_level_status = AuthenticationStateField(
        verbose_name=_("Current Level Status"), null=False, choices=LevelStatus_CHOICES,
        default=LevelStatus.not_started.name)
    change_list = models.TextField(verbose_name=_("Current Level Change List"), max_length=1000, null=False,
                                   default='')
    industry = models.CharField(verbose_name=_("Industry"), max_length=256, null=False, default='')
    reject_reason = models.CharField(verbose_name=_(""), max_length=256, null=False, default='')
    # 预留字段:
    extra_1 = models.CharField(default="", max_length=255)
    extra_2 = models.CharField(default="", max_length=255)
    extra_3 = models.CharField(default="", max_length=255)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ': enterprise')
        verbose_name_plural = _(PREFIX_DB_VERBOSE + ': enterprise')
        db_table = PREFIX_DB_TABLE + "enterprise"


class KYCLog(SoftDeleteModel):
    # 客服修改变动记录日志
    client_id = models.UUIDField(max_length=30, verbose_name=_("Client ID"), null=True)
    csr_id = models.UUIDField(max_length=30, verbose_name=_("CSR ID"), null=True)
    application_status = models.IntegerField(verbose_name=_("Application Status"), null=False,
                                             choices=CSRApplicationStatus.choices,
                                             default=CSRApplicationStatus.NOT_STARTED)
    kyc_level = models.IntegerField(null=False, default=-1)
    value = models.TextField(null=False, default='', max_length=5000)
    csr_type = models.IntegerField(verbose_name=_('csr type'), null=False, default=CSRLogType.MODIFICATION, choices=CSRLogType.choices)

    # 预留字段:
    extra_1 = models.CharField(default="", max_length=255)
    extra_2 = models.CharField(default="", max_length=255)
    extra_3 = models.CharField(default="", max_length=255)
    extra_4 = models.TextField(default="", max_length=1000)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ': csr log')
        verbose_name_plural = _(PREFIX_DB_VERBOSE + ': csr log')
        db_table = PREFIX_DB_TABLE + "log"

    @property
    def client_email(self):
        obj = User.objects.filter(user_id=self.client_id).first()
        if obj:
            return obj.email

    @property
    def csr_name(self):
        obj = KYCIndividual.objects.filter(user_id=self.csr_id).first()
        if obj:
            return obj.name()

    @property
    def client_uuid(self):
        return self.client_id.hex

    @property
    def csr_uuid(self):
        return self.csr_id.hex

    @property
    def csr_data(self):
        if self.value:
            return json.loads(self.value)


class KYCCSRComment(SoftDeleteModel):
    # 客服评论记录
    key = models.CharField(null=False, default='', max_length=250)
    comment = models.TextField(null=False, default='', max_length=5000)

    class Meta:
        db_table = PREFIX_DB_TABLE + "comment"


class UserExtraImage(UserSoftDeleteModel):
    value = models.TextField(null=False, default='', max_length=5000)

    class Meta:
        db_table = PREFIX_DB_TABLE + "extra_image"
