from django.apps import AppConfig


class AuditConfig(AppConfig):
    name = 'maneki.apps.audit'
    verbose_name = "Audit"
