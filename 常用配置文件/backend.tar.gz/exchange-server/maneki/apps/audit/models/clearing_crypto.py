from django.db import models

from maneki.apps.common.libs.models import BaseModel
from maneki.apps.constants import TransactionType
from maneki.apps.constants import TransactionStatus
from maneki.apps.constants import CoinType
from maneki.apps.constants import MODEL_PREFIX
from django.utils.translation import ugettext_lazy as _

# 前缀:
PREFIX_DB_VERBOSE = "Audit Record"
PREFIX_DB_TABLE = MODEL_PREFIX + "audit_clearing_crypto_"

"""
清算表:
    - 日结
    - 月结
    
"""


class CryptoDailyClearingRecord(BaseModel):
    """数字货币 单日清算表

        - tb_name: maneki_audit_clearing_crypto_daily
        - fields:
            coin_type,
            pending_fee_total, pending_tx_count,
            completed_fee_total, completed_tx_count,
            day_at:


    """

    # TODO: [ coin_type, pending_fee_total, completed_fee_total,
    coin_type = models.IntegerField(verbose_name=_("Coin Type"), default=CoinType.UNDEFINED, choices=CoinType.choices)
    pending_fee_total = models.IntegerField(verbose_name=_("Pending Fee Total"), default=0, )
    pending_tx_count = models.IntegerField(verbose_name=_("Pending TX Count"), default=0)
    completed_fee_total = models.DecimalField(verbose_name=_("Completed Fee Total"), default=0, max_digits=40,
                                              decimal_places=20)
    completed_tx_count = models.IntegerField(verbose_name=_("Completed_fee_count"), default=0)
    day_at = models.DateField(verbose_name=_("Day at"), auto_now_add=True)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": Crypto Daily Clearing")
        db_table = PREFIX_DB_TABLE + "daily"


class CryptoMonthlyClearingRecord(BaseModel):
    """数字货币 单月清算表


    TODO:
        - tb_name: maneki_audit_clearing_crypto_monthly
        - fields:
            coin_type,
            pending_fee_total, pending_tx_count,
            completed_fee_total, completed_tx_count,
            month_at:



    """
    xxx_fee = models.DecimalField(verbose_name=_("xxx fee"), default=0, max_digits=40, decimal_places=20)  # 小数点后位数

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": Crypto Monthly Clearing")
        db_table = PREFIX_DB_TABLE + "monthly"
