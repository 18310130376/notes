# -*- coding: utf-8 -*-
import uuid
from django.db import models
from django.utils.translation import ugettext_lazy as _
from maneki.apps.common.libs.models import UserSoftDeleteModel
from maneki.apps.constants import MODEL_PREFIX, TransactionType, CoinType

PREFIX_DB_TABLE = MODEL_PREFIX + "tx_record_"


# class ExceptionRecordUpdateLog(UserSoftDeleteModel):
#
#     username = models.EmailField(verbose_name=_('email address'), null=True, blank=True, default="", db_index=True)
#     tx_type = models.IntegerField(verbose_name=_("Tx Op Type"), default=TransactionType.UNDEFINED,
#                                   choices=TransactionType.choices, )
#     remark = models.TextField(verbose_name=_("modify remark"), null=False)
#     coin_type = models.CharField(verbose_name=_('coin type'), default=CoinType.UNDEFINED.label, null=False)
#     engine_sn = models.UUIDField(verbose_name=_("Engine SN Number"), null=False)
#     pre_status = models.IntegerField(verbose_name=_("before update status"), null=False)
#     after_status = models.IntegerField(verbose_name=_("after update status"), null=False)

