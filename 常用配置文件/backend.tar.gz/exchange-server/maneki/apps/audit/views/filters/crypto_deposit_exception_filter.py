# -*- coding: utf-8 -*-
import django_filters
import logging
import validators

from maneki.apps.common.utils.format_timestamp import format_timestamp
from maneki.apps.constants import CoinType, DepositStatus
from maneki.apps.transaction.models import CryptoDepositRecordLastThreeMonths
from maneki.apps.common.mixins.rest import BetterListModelMixin, BetterCreateModelMixin, ValidationError450, \
    ValidationError451, ValidationError452, ValidationError453, ValidationError454

logger = logging.getLogger(__name__)


class CryptoDepositExceptionFilter(django_filters.FilterSet):
    timestamp_start = django_filters.CharFilter(field_name="updated_at")
    timestamp_end = django_filters.CharFilter(field_name="timestamp_end")
    coin_type = django_filters.ChoiceFilter(field_name='coin_type',
                                            label='0: BTC, 1: ETC, 2: ETH, 3: BCH, 4: ICO, 5: REP, '
                                                  '6: LTC, 7: DASH, 8: MONA',
                                            choices=CoinType.choices)
    status = django_filters.NumberFilter(field_name='status',
                                         label='-3: 引擎失败, -2: 失败, -1: 未定义, 0:最终完成, 1: 链上pending, 2:链上完成, 3: 引擎pending, 4：引擎完成,'
                                         )
    user_id = django_filters.UUIDFilter()

    class Meta:
        model = CryptoDepositRecordLastThreeMonths
        fields = ['timestamp_start', 'timestamp_end', 'coin_type', 'status', 'user_id']

    @property
    def qs(self):
        params = self.params_check()

        condition = dict()

        condition.update(user_id=params['user_id'],
                         coin_type=params['coin_type'],
                         updated_at__gte=params['start_date'],
                         updated_at__lte=params['end_date']
                         )
        condition = {k: v for k, v in condition.items() if v is not None}

        return self.queryset.filter(**condition)

    def params_check(self):
        user_id = self.data.get('user_id', None)
        timestamp_start = self.data.get('timestamp_start', None)
        timestamp_end = self.data.get('timestamp_end', None)
        coin_type = self.data.get('coin_type', None)

        if user_id and not validators.uuid(user_id):
            raise ValidationError450(detail='filter params invalid:[{}]'.format('user_id'))
        if timestamp_start and not str(timestamp_start).isdigit():
            raise ValidationError452(detail='filter params invalid:[{}]'.format('timestamp_end'))
        if timestamp_end and not str(timestamp_end).isdigit():
            raise ValidationError452(detail='filter params invalid:[{}]'.format('timestamp_end'))
        if coin_type and not str(coin_type).isdigit():
                raise ValidationError453(detail='filter params invalid:[{}]'.format('coin_type'))

        params = {
            'user_id': user_id,
            'start_date': format_timestamp(timestamp_start),
            'end_date': format_timestamp(timestamp_end, timedelta_day=0),
            'coin_type': coin_type
        }

        return params
