# -*- coding: utf-8 -*-
import logging

import django_filters
from maneki.apps.constants import CoinType, WithdrawStatus
from maneki.apps.transaction.models import CryptoWithdrawRecordLastThreeMonths

logger = logging.getLogger(__name__)


class CryptoWithdrawExceptionFilter(django_filters.FilterSet):
    timestamp_start = django_filters.CharFilter(field_name="timestamp_start")
    timestamp_end = django_filters.CharFilter(field_name="timestamp_end")
    coin_type = django_filters.ChoiceFilter(field_name='coin_type',
                                            label='0: BTC, 1: ETC, 2: ETH, 3: BCH, 4: ICO, 5: REP, 6: LTC, 7: DASH, 8: MONA',
                                            choices=CoinType.choices)
    status = django_filters.NumberFilter(field_name='status',
                                         label="-7:区块连通知失败, -6: 交易引擎通知失败, -5: 人工审核失败, -4: 用户审核失败, "
                                               "-3: 用户撤单, -2: 失败, -1: 未定义, 0: 最终完成状态, 1: 用户审核Pending,"
                                               "2: 用户审核Completed, 3: 客服人工审核Pending, 4: 客服人工审核Completed,"
                                               "5: 交易引擎Pending, 6: 交易引擎Completed, 7: 链上Pending,8: 链上: 完成,"
                                         )
    user_id = django_filters.UUIDFilter()

    class Meta:
        model = CryptoWithdrawRecordLastThreeMonths
        fields = ['timestamp_start', 'timestamp_end', 'coin_type', 'status', "user_id"]
