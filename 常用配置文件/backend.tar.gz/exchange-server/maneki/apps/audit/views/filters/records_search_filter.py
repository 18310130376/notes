# -*- coding: utf-8 -*-
import django_filters


class RecordsSearchFilter(django_filters.FilterSet):
    tx_type = django_filters.NumberFilter(field_name='tx_type', label='0: deposit， 1：withdraw')
    currency_type = django_filters.NumberFilter(field_name='currency_type', label='0: 数字货币， 1：法币')
    address = django_filters.CharFilter(field_name='address')
    tx_id = django_filters.CharFilter(field_name='tx_id')
    user_id = django_filters.UUIDFilter(field_name='user_id')
    email = django_filters.CharFilter(field_name='email')

    class Meta:
        model = None
        fields = []


class ServiceChargeFilter(django_filters.FilterSet):
    date_start = django_filters.CharFilter(field_name='date start', help_text='开始时间')
    date_end = django_filters.CharFilter(field_name='date end', help_text='结束时间')

    class Meta:
        model = None
        fields = []
