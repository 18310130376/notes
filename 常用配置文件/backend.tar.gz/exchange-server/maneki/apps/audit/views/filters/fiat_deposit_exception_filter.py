# -*- coding: utf-8 -*-
import django_filters

from maneki.apps.transaction.models import FiatCurrencyDepositRecordLastThreeMonths


class FiatDepositExceptionFilter(django_filters.FilterSet):
    timestamp_start = django_filters.CharFilter(field_name="timestamp_start",)
    timestamp_end = django_filters.CharFilter(field_name="timestamp_end")
    fiat_type = django_filters.ChoiceFilter(field_name='fiat_type',
                                            label='-1: Undefined, 0: CNY, 1: USD, 2: EU, 3: HKD, 4: JPY',)
    status = django_filters.NumberFilter(field_name='status',
                                         label='-3: 引擎失败, -2: 失败, -1: 未定义, 0:最终完成, 1: 链上pending, 2:链上完成, 3: 引擎pending, 4：引擎完成,'
                                         )
    user_id = django_filters.UUIDFilter(field_name='user_id')

    class Meta:
        model = FiatCurrencyDepositRecordLastThreeMonths
        fields = ['timestamp_start', 'timestamp_end', 'fiat_type', 'status', 'user_id']
