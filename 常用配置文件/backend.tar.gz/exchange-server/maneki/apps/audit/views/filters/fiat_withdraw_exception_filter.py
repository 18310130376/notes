# -*- coding: utf-8 -*-
import django_filters

from maneki.apps.constants import FiatType
from maneki.apps.transaction.models import FiatCurrencyWithdrawRecordLastThreeMonths


class FiatWithdrawExceptionFilter(django_filters.FilterSet):
    timestamp_start = django_filters.CharFilter(field_name="timestamp_start")
    timestamp_end = django_filters.CharFilter(field_name="timestamp_end")
    fiat_type = django_filters.ChoiceFilter(field_name='fiat_type',
                                            label='-1: Undefined, 0: CNY, 1: USD, 2: EU, 3: HKD, 4: JPY',
                                            choices=FiatType.choices)
    status = django_filters.NumberFilter(field_name='status',
                                         label="-7:区块连通知失败, -6: 交易引擎通知失败, -5: 人工审核失败, -4: 用户审核失败, "
                                               "-3: 用户撤单, -2: 失败, -1: 未定义, 0: 最终完成状态, 1: 用户审核Pending,"
                                               "2: 用户审核Completed, 3: 客服人工审核Pending, 4: 客服人工审核Completed,"
                                               "5: 交易引擎Pending, 6: 交易引擎Completed, 7: 链上Pending,8: 链上: 完成,"
                                               "10000: 除去最终完成的",
                                         )
    user_id = django_filters.UUIDFilter(field_name='user_id')

    class Meta:
        model = FiatCurrencyWithdrawRecordLastThreeMonths
        fields = []
