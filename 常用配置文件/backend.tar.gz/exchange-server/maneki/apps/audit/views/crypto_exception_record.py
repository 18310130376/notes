# -*- coding: utf-8 -*-
import logging

import validators
from rest_framework import permissions
from rest_framework import viewsets

from .throttles import TxRecordAdminThrottleDay
from maneki.apps.audit.views.filters.crypto_deposit_exception_filter import CryptoDepositExceptionFilter
from maneki.apps.audit.views.filters.crypto_withdraw_exception_filter import CryptoWithdrawExceptionFilter
from maneki.apps.audit.views.serializers.crypto_deposit_exception_serializer import CryptoDepositExceptionSerializer
from maneki.apps.audit.views.serializers.crypto_deposit_exception_serializer import CryptoDepositExceptionUpdateSerializer
from maneki.apps.audit.views.serializers.crypto_withdraw_exception_serializer import CryptoWithdrawExceptionSerializer
from maneki.apps.audit.views.serializers.crypto_withdraw_exception_serializer import CryptoWithdrawExceptionUpdateSerializer
from maneki.apps.common.mixins.rest import BetterCreateModelMixin
from maneki.apps.common.mixins.rest import BetterListModelMixin
from maneki.apps.common.mixins.rest import ValidationError450
from maneki.apps.common.mixins.rest import ValidationError451
from maneki.apps.common.mixins.rest import ValidationError452
from maneki.apps.common.mixins.rest import ValidationError453
from maneki.apps.common.mixins.rest import ValidationError454
from maneki.apps.common.utils.format_timestamp import format_timestamp
from maneki.apps.common.utils.validate.params_validators import ParamValidator
from maneki.apps.common.permissions.rest.permission_manage import StrictPermissionCheck
from maneki.apps.constants import DepositStatus
from maneki.apps.constants import WithdrawStatus
from maneki.apps.transaction.models import CryptoDepositRecordLastThreeMonths
from maneki.apps.transaction.models import CryptoWithdrawRecordLastThreeMonths
from maneki.apps.transaction.services.crypto import CryptoWithdrawService
from maneki.apps.transaction.services.crypto.deposit import CryptoDepositService

logger = logging.getLogger(__name__)


class CryptoDepositExceptionRecordView(BetterListModelMixin, BetterCreateModelMixin, viewsets.GenericViewSet):
    """数字货币充值异常记录
        GET：获取异常记录列表
        POST：修改异常信息

    """
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]
    serializer_class_list = CryptoDepositExceptionSerializer
    serializer_class = CryptoDepositExceptionUpdateSerializer
    filter_class = CryptoDepositExceptionFilter
    throttle_classes = [TxRecordAdminThrottleDay]
    create_save_required = False
    service = CryptoDepositService()

    def get_queryset(self):
        return CryptoDepositRecordLastThreeMonths.objects

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        # todo: qs maybe invalid
        result.update(
            data=serializer.data,
        )
        return result

    def do_create(self, request, serializer, instance, *args, **kwargs):
        """修改充值异常信息
        """
        result = self.response_result
        code = serializer.validated_data.get('code')
        detail = serializer.validated_data.get('detail')
        if code != 200:
            result.update(code=code,
                          detail=detail)
            return result

        record = self.service.filter_record(
            engine_sn=serializer.validated_data.get('engine_sn'),
        )
        record = self.service.update_record(
            record=record,
            status=serializer.validated_data.get('status'),
        )
        # todo 加修改日志

        serializer = self.serializer_class(record)
        result.update(data=serializer.data)
        return result


class CryptoWithdrawExceptionRecordView(BetterListModelMixin, BetterCreateModelMixin, viewsets.GenericViewSet):
    """数字货币提现异常记录

    """
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]
    serializer_class_list = CryptoWithdrawExceptionSerializer
    serializer_class = CryptoWithdrawExceptionUpdateSerializer
    queryset = CryptoWithdrawRecordLastThreeMonths.objects.all().order_by("-updated_at")
    filter_class = CryptoWithdrawExceptionFilter
    throttle_classes = [TxRecordAdminThrottleDay]
    service = CryptoWithdrawService()

    def filter_queryset(self, queryset):
        # 过滤 时间段, user_id, sn, status 可以自定义错误码
        user_id = self.request.query_params.get('user_id', None)
        if user_id and ParamValidator().uuid_validator(uuid_param=user_id):
            queryset = queryset.filter(user_id=user_id)
        # 过滤起始时间
        timestamp_start = self.request.query_params.get('timestamp_start', None)
        if timestamp_start and not str(timestamp_start).isdigit():
            raise ValidationError451(detail='filter params invalid:[{}]'.format('timestamp_start'))
        timestamp_start = format_timestamp(timestamp=timestamp_start)
        queryset = queryset.filter(updated_at__gte=timestamp_start)

        # 过滤结束时间
        timestamp_end = self.request.query_params.get('timestamp_end', None)
        if timestamp_end and not str(timestamp_end).isdigit():
            raise ValidationError452(detail='filter params invalid:[{}]'.format('timestamp_end'))
        timestamp_end = format_timestamp(timestamp_end, timedelta_day=0)
        queryset = queryset.filter(updated_at__lte=timestamp_end)
        # 过滤币种类型
        coin_type = self.request.query_params.get('coin_type', None)
        if coin_type:
            if not str(coin_type).isdigit():
                raise ValidationError453(detail='filter params invalid:[{}]'.format('coin_type'))
            queryset = queryset.filter(coin_type=int(coin_type))

        # 过滤状态
        status = self.request.query_params.get('status', None)
        if status:
            if not str(status).isdigit():
                raise ValidationError454(detail='filter params invalid:[{}]'.format('status'))
            queryset = queryset.filter(status=int(status))
        else:
            pass
            # queryset = queryset.exclude(status=WithdrawStatus.COMPLETED)
        queryset = super().filter_queryset(queryset)
        return queryset

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        # todo: qs maybe invalid
        result.update(
            data=serializer.data,
        )
        return result

    def do_create(self, request, serializer, instance, *args, **kwargs):
        """提现异常修改

        :param request:
        :param serializer:
        :param instance:
        :param args:
        :param kwargs:
        :return:
        """
        result = self.response_result
        record = self.service.filter_record(engine_sn=serializer.validated_data.get('engine_sn')).first()
        self.service.update_record_status(record=record, status=serializer.validated_data.get('status'))
        serializer = self.serializer_class(record)
        result.update(data=serializer.data)
        return result
