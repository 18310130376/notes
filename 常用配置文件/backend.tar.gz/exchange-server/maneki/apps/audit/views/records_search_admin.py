# -*- coding: utf-8 -*-
import logging
import re

from django.db.models import Sum
from rest_framework import permissions, viewsets

from maneki.apps.audit.models import FiatDailyClearingRecord, CryptoDailyClearingRecord
from maneki.apps.audit.utils.data import format_time_duration
from maneki.apps.audit.views.filters.records_search_filter import RecordsSearchFilter, ServiceChargeFilter
from maneki.apps.common.mixins.rest import BetterReadWriteViewSet, ValidationError450, ValidationError451, \
    BetterListModelMixin
from maneki.apps.constants import FiatType, CoinType
from maneki.apps.transaction.services.crypto import CryptoDepositService, CryptoWithdrawService
from maneki.apps.transaction.services.fiat.deposit import FiatDepositService
from maneki.apps.transaction.services.fiat.withdraw import FiatWithdrawService
from maneki.apps.transaction.views import CryptoCurrencyDepositSerializer, FiatWithdrawRecordSerializer, \
    FiatCurrencyDepositRecordSerializer, StrictPermissionCheck
from maneki.apps.transaction.views.serializers.withdraw import CryptoCurrencyWithdrawSerializer
from .throttles import TxRecordAdminThrottleDay
from rest_framework.response import Response


class RecordsSearchViewSet(BetterReadWriteViewSet):
    """交易记录search

    """
    permission_classes = [permissions.IsAuthenticated, ]
    serializer_class_list = CryptoCurrencyDepositSerializer
    serializer_class = CryptoCurrencyDepositSerializer
    throttle_classes = [TxRecordAdminThrottleDay]
    filter_class = RecordsSearchFilter
    service = None

    def get_queryset(self):
        return

    def filter_queryset(self, queryset):
        # 充/提 类型 法币/数字货币类型
        tx_type = self.request.query_params.get('tx_type')
        if not tx_type or not str(tx_type).isdigit() or int(tx_type) not in [0, 1]:
            raise ValidationError450(detail='tx_type')
        currency_type = self.request.query_params.get('currency_type')
        if not currency_type or not str(currency_type).isdigit() or int(currency_type) not in [0, 1]:
            raise ValidationError451(detail='currency_type')

        # 过滤条件 address, tx_id, user_id, email
        address = self.request.query_params.get('address')
        tx_id = self.request.query_params.get('tx_id')
        user_id = self.request.query_params.get('user_id')
        email = self.request.query_params.get('email')
        if int(tx_type) == 0 and int(currency_type) == 0:
            # 数字货币充值
            self.serializer_class_list = CryptoCurrencyDepositSerializer
            self.service = CryptoDepositService()

        elif int(tx_type) == 0 and int(currency_type) == 1:
            # 法币充值
            self.serializer_class_list = FiatCurrencyDepositRecordSerializer
            self.service = FiatDepositService()

        elif int(tx_type) == 1 and int(currency_type) == 0:
            # 数字货币提现
            self.serializer_class_list = CryptoCurrencyWithdrawSerializer
            self.service = CryptoWithdrawService()

        else:
            # 法币提现
            self.serializer_class_list = FiatWithdrawRecordSerializer
            self.service = FiatWithdrawService()

        queryset = self.service.search_records(address=address, tx_id=tx_id, user_id=user_id, email=email)

        return queryset


class TradeServiceChargeViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    """交易手续费清算"""
    filter_class = ServiceChargeFilter
    # permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]

    def _fiat_fee(self, fiat_type):
        fiat_dict = {i[1]: i[0] for i in FiatType.choices}
        qs = {
            "day_at__gte": self.request.query_params.get('date_start', None),
            "day_at__lte": self.request.query_params.get('date_end', None),
            "fiat_type": fiat_dict.get(fiat_type)
        }
        temp = FiatDailyClearingRecord.objects.filter(**qs).aggregate(Sum('completed_fee_total')).get(
            'completed_fee_total__sum')
        if not temp:
            temp = 0
        return temp

    def _crypto_fee(self, coin_type):
        coin_dict = {i[1]: i[0] for i in CoinType.choices}
        qs = {
            "day_at__gte": self.request.query_params.get('date_start', None),
            "day_at__lte": self.request.query_params.get('date_end', None),
            "coin_type": coin_dict.get(coin_type)
        }
        temp = CryptoDailyClearingRecord.objects.filter(**qs).aggregate(Sum('completed_fee_total')).get(
            'completed_fee_total__sum')
        if not temp:
            temp = 0
        return temp

    @staticmethod
    def _re_date_time(date):
        return re.match(r'\d*4\-\d{1, 2}\-\d{1, 2}', date)

    def filter_queryset(self, queryset):
        """修复 filter 问题, 必须写此方法

        :param queryset:
        :return:
        """
        return queryset

    def list(self, request, *args, **kwargs):
        """法币手续费清算
        Request:

            param1: date_start,
            param2: date_end,

            example: audit/service_charge/daily/?date_start=2018-6-1&date_end=2018-6-30

        Response:

            {
                code: 200,
                detail: "OK",
                data: {
                    "USD": 100000.0000,
                    "BTC": 12.0000,
                    "ETH": 10.0000
                }
            }

        """
        if not self.request.query_params.get('date_start') and self.request.query_params.get('date_end'):
            result = {
                "code": 450,
                "detail": "",
                "data": ""
            }
            return Response(result)
        result = self.response_result
        result.get('data').update({
            "USD": self._fiat_fee('USD'),
            "BTC": self._crypto_fee("BTC"),
            "BCH": self._crypto_fee("BCH"),
            "ETH": self._crypto_fee("ETH"),
            "LTC": self._crypto_fee("LTC")
        })
        return Response(result)
