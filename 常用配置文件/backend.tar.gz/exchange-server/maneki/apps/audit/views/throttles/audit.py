from rest_framework.throttling import UserRateThrottle


class TxRecordAdminThrottleDay(UserRateThrottle):
    scope = 'tx_record_admin'
