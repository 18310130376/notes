# -*- coding: utf-8 -*-
from rest_framework import serializers

from maneki.apps.common.mixins.rest import ValidationError450, ValidationError451, ValidationError452
from maneki.apps.constants import FiatType, WithdrawStatus
from maneki.apps.transaction.models import FiatCurrencyWithdrawRecordLastThreeMonths


####################################################
#     (Fiat Currency) 交易: 提现
####################################################


# 法币提现:
from maneki.apps.transaction.services.fiat.withdraw import FiatWithdrawService


class FiatWithdrawExceptionSerializer(serializers.ModelSerializer):
    fiat_type = serializers.ChoiceField(FiatType.choices)
    engine_sn = serializers.UUIDField()
    engine_request_no = serializers.UUIDField()
    engine_response_code = serializers.IntegerField()
    amount = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)
    bank_account = serializers.CharField(label=u'银行账号', max_length=100)
    status = serializers.IntegerField(label=u'status', )
    updated_at = serializers.DateTimeField()

    class Meta:
        model = FiatCurrencyWithdrawRecordLastThreeMonths

        fields = (
            "fiat_type", "engine_sn", "engine_request_no", "engine_response_code", "status", "bank_account", "amount",
            "updated_at", "is_deleted"
        )


class FiatWithdrawExceptionUpdateSerializer(serializers.ModelSerializer):
    engine_sn = serializers.UUIDField()
    status = serializers.IntegerField(label=u'status')

    def validate(self, attrs):
        user = self.context['request'].user
        # 记录验证
        engine_sn = attrs.get('engine_sn')
        if not self.Meta.service.filter_record(engine_sn=engine_sn):
            raise ValidationError450(detail='The record not found!')
        # 状态验证
        status = attrs.get('status')
        if status is None:
            raise ValidationError451(detail='status is required!')
        if status not in WithdrawStatus.values.keys():
            raise ValidationError452(detail='invalid status!')
        attrs.update(user_id=user.user_id)
        return attrs

    class Meta:
        model = FiatCurrencyWithdrawRecordLastThreeMonths
        fields = ('fiat_type', 'amount', 'bank_account', 'status', 'updated_at',
                  'engine_sn')
        service = FiatWithdrawService()
