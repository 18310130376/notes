# -*- coding: utf-8 -*-
from rest_framework import serializers

from maneki.apps.common.mixins.rest import ValidationError450, ValidationError451, ValidationError452
from maneki.apps.constants import CoinType, DepositStatus
from maneki.apps.transaction.models import CryptoDepositRecordLastThreeMonths
from maneki.apps.transaction.services.crypto.deposit import CryptoDepositService


####################################################
#     数字代币(Crypto Currency) 交易: 充值
####################################################


# 充值:
class CryptoDepositExceptionSerializer(serializers.ModelSerializer):
    coin_type = serializers.ChoiceField(CoinType.choices)
    tx_amount = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)
    tx_fee = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)
    tx_address = serializers.CharField(label=u'address', max_length=100)
    status = serializers.IntegerField(label=u'status', )
    updated_at = serializers.DateTimeField()
    confirmations = serializers.IntegerField()
    user_id = serializers.UUIDField()

    class Meta:
        model = CryptoDepositRecordLastThreeMonths
        fields = (
            "user_id", "status", "tx_address", "tx_amount", "tx_fee", "coin_type", "updated_at", "confirmations", "engine_sn",
            "is_deleted"
        )


# 充值记录修改
class CryptoDepositExceptionUpdateSerializer(serializers.ModelSerializer):
    status = serializers.IntegerField(label=u'status', required=True)
    engine_sn = serializers.UUIDField(required=True)

    # Todo: limit status
    def validate(self, attrs):
        user = self.context['request'].user
        # 记录验证
        engine_sn = attrs.get('engine_sn')
        if not self.Meta.service.filter_record(user_id=user.user_id, tx_id=0, engine_sn=engine_sn):
            attrs.update(code=450,
                         detail='The record not found!')
        # 状态验证
        status = attrs.get('status')
        if status is None:
            attrs.update(code=451,
                         detail='status is required!')
        if status not in DepositStatus.values.keys():
            attrs.update(code=452,
                         detail='invalid status!')
        attrs.update(user_id=user.user_id,
                     code=200)
        return attrs

    class Meta:
        model = CryptoDepositRecordLastThreeMonths
        fields = ('engine_sn', 'status')
        service = CryptoDepositService()

