# -*- coding: utf-8 -*-

from rest_framework import serializers

from maneki.apps.common.mixins.rest import ValidationError450, ValidationError451, ValidationError452
from maneki.apps.constants import FiatType, DepositStatus
from maneki.apps.transaction.models import FiatCurrencyDepositRecordLastThreeMonths


####################################################
#     (Fiat Currency) 交易: 充值
####################################################


# 法币充值:
from maneki.apps.transaction.services.fiat.withdraw import FiatWithdrawService


class FiatDepositExceptionSerializer(serializers.ModelSerializer):
    fiat_type = serializers.ChoiceField(FiatType.choices)
    engine_sn = serializers.UUIDField()
    engine_request_no = serializers.UUIDField()
    engine_response_code = serializers.IntegerField()
    amount = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)
    bank_account = serializers.CharField(label=u'银行账号', max_length=100)
    status = serializers.IntegerField(label=u'status', )
    updated_at = serializers.DateTimeField()

    class Meta:
        model = FiatCurrencyDepositRecordLastThreeMonths

        fields = (
            "fiat_type", "engine_sn", "engine_request_no", "engine_response_code", "status", "bank_account", "amount",
            "updated_at", "is_deleted"
        )


class FiatDepositExceptionUpdateSerializer(serializers.ModelSerializer):
    engine_sn = serializers.UUIDField()
    status = serializers.IntegerField(label=u'status')

    def validate(self, attrs):
        user = self.context['request'].user
        # 记录验证
        engine_sn = attrs.get('engine_sn')
        if not self.Meta.model.objects.filter(engine_sn=engine_sn, is_deleted=False).first():
            raise ValidationError450(detail='The record not found!')
        # 状态验证
        status = attrs.get('status')
        if status is None:
            raise ValidationError451(detail='status is required!')
        if status not in DepositStatus.values.keys():
            raise ValidationError452(detail='invalid status!')
        attrs.update(user_id=user.user_id)
        return attrs

    class Meta:
        model = FiatCurrencyDepositRecordLastThreeMonths
        fields = ('status', 'engine_sn')

