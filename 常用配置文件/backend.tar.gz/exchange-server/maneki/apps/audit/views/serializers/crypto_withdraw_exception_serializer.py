# -*- coding: utf-8 -*-
from rest_framework import serializers

from maneki.apps.common.mixins.rest import ValidationError450, ValidationError451, ValidationError452
from maneki.apps.constants import CoinType, WithdrawStatus
from maneki.apps.transaction.models import CryptoWithdrawRecordLastThreeMonths


####################################################
#     数字代币(Crypto Currency) 交易: 提现
####################################################


# 提现:
from maneki.apps.transaction.services.crypto import CryptoWithdrawService


class CryptoWithdrawExceptionSerializer(serializers.ModelSerializer):
    coin_type = serializers.ChoiceField(CoinType.choices)
    tx_amount = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)
    tx_fee = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)
    tx_address = serializers.CharField(label=u'tx address', max_length=100)
    status = serializers.IntegerField()
    user_id = serializers.UUIDField()

    class Meta:
        model = CryptoWithdrawRecordLastThreeMonths
        fields = (
            "tx_address", "tx_amount", "tx_fee", "coin_type",
            "engine_sn", "status", "confirmations",
            "updated_at", "user_id",
        )


# 提现异常修改
class CryptoWithdrawExceptionUpdateSerializer(serializers.ModelSerializer):
    status = serializers.IntegerField(label=u'status', required=True)
    engine_sn = serializers.UUIDField(required=True)

    def validate(self, attrs):
        user = self.context['request'].user
        # 记录验证
        engine_sn = attrs.get('engine_sn')
        if not self.Meta.service.filter_record(engine_sn=engine_sn):
            raise ValidationError450(detail='The record not found!')
        # 状态验证
        status = attrs.get('status')
        if status is None:
            raise ValidationError451(detail='status is required!')
        if status not in WithdrawStatus.values.keys():
            raise ValidationError452(detail='invalid status!')
        attrs.update(user_id=user.user_id)
        return attrs

    class Meta:
        model = CryptoWithdrawRecordLastThreeMonths
        fields = ('coin_type', 'tx_amount', 'tx_address', 'status', 'updated_at', 'confirmations',
                  'engine_sn', 'engine_code')
        service = CryptoWithdrawService()
