# -*- coding: utf-8 -*-
import logging

from rest_framework import permissions
from rest_framework import viewsets

from .throttles import TxRecordAdminThrottleDay
from maneki.apps.audit.views.filters.fiat_deposit_exception_filter import FiatDepositExceptionFilter
from maneki.apps.audit.views.filters.fiat_withdraw_exception_filter import FiatWithdrawExceptionFilter
from maneki.apps.audit.views.serializers.fiat_deposit_exception_serializer import FiatDepositExceptionSerializer
from maneki.apps.audit.views.serializers.fiat_deposit_exception_serializer import FiatDepositExceptionUpdateSerializer
from maneki.apps.audit.views.serializers.fiat_withdraw_exception_serializer import FiatWithdrawExceptionSerializer
from maneki.apps.audit.views.serializers.fiat_withdraw_exception_serializer import FiatWithdrawExceptionUpdateSerializer
from maneki.apps.common.mixins.rest import BetterCreateModelMixin
from maneki.apps.common.mixins.rest import BetterListModelMixin
from maneki.apps.common.mixins.rest import ValidationError450
from maneki.apps.common.mixins.rest import ValidationError451
from maneki.apps.common.mixins.rest import ValidationError452
from maneki.apps.common.mixins.rest import ValidationError453
from maneki.apps.common.mixins.rest import ValidationError454
from maneki.apps.common.permissions.rest.permission_manage import StrictPermissionCheck
from maneki.apps.common.utils.format_timestamp import format_timestamp
from maneki.apps.common.utils.validate.params_validators import ParamValidator
from maneki.apps.constants import DepositStatus
from maneki.apps.constants import WithdrawStatus
from maneki.apps.transaction.models import FiatCurrencyDepositRecordLastThreeMonths
from maneki.apps.transaction.models import FiatCurrencyWithdrawRecordLastThreeMonths
from maneki.apps.transaction.services.fiat.deposit import FiatDepositService
from maneki.apps.transaction.services.fiat.withdraw import FiatWithdrawService

logger = logging.getLogger(__name__)


class FiatDepositExceptionRecordView(BetterListModelMixin, BetterCreateModelMixin, viewsets.GenericViewSet):
    """法币充值异常记录

    """
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]
    serializer_class_list = FiatDepositExceptionSerializer
    serializer_class = FiatDepositExceptionUpdateSerializer
    queryset = FiatCurrencyDepositRecordLastThreeMonths.objects.all().order_by("-updated_at")
    filter_class = FiatDepositExceptionFilter
    throttle_classes = [TxRecordAdminThrottleDay]
    service = FiatDepositService()

    def filter_queryset(self, queryset):
        # 过滤 时间段, user_id, sn, status 可以自定义错误码
        user_id = self.request.query_params.get('user_id', None)
        if user_id and ParamValidator().uuid_validator(uuid_param=user_id):
            queryset = queryset.filter(user_id=user_id)
        # 过滤起始时间
        timestamp_start = self.request.query_params.get('timestamp_start', None)
        if timestamp_start and not str(timestamp_start).isdigit():
            raise ValidationError451(detail='filter params invalid:[{}]'.format('timestamp_start'))
        timestamp_start = format_timestamp(timestamp=timestamp_start)

        queryset = queryset.filter(updated_at__gte=timestamp_start)
        # 过滤结束时间
        timestamp_end = self.request.query_params.get('timestamp_end', None)
        if timestamp_end and not str(timestamp_end).isdigit():
            raise ValidationError452(detail='filter params invalid:[{}]'.format('timestamp_end'))
        timestamp_end = format_timestamp(timestamp_end, timedelta_day=0)
        queryset = queryset.filter(updated_at__lte=timestamp_end)

        # 过滤币种类型
        fiat_type = self.request.query_params.get('fiat_type', None)
        if fiat_type:
            if not str(fiat_type).isdigit():
                raise ValidationError453(detail='filter params invalid:[{}]'.format('fiat_type'))
            queryset = queryset.filter(fiat_type=int(fiat_type))

        # 过滤状态
        status = self.request.query_params.get('status', None)
        if status:
            if not str(status).isdigit():
                raise ValidationError454(detail='filter params invalid:[{}]'.format('status'))
            queryset = queryset.filter(status=int(status))
        else:
            queryset = queryset.exclude(status=DepositStatus.COMPLETED)
        queryset = super().filter_queryset(queryset)
        return queryset

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        # todo: qs maybe invalid
        result.update(
            data=serializer.data,
        )
        return result

    def do_create(self, request, serializer, instance, *args, **kwargs):
        """修改异常记录

        :param request:
        :param serializer:
        :param instance:
        :param args:
        :param kwargs:
        :return:
        """
        result = self.response_result
        record = self.service.filter_record(engine_sn=serializer.validated_data.get('engine_sn'))
        self.service.update_record_status(record=record, status=serializer.validated_data.get('status'))
        serializer = self.serializer_class(record)
        result.update(data=serializer.data)
        return result


class FiatWithdrawExceptionRecordView(BetterListModelMixin, BetterCreateModelMixin, viewsets.GenericViewSet):
    """法币提现异常记录

    """
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]
    serializer_class_list = FiatWithdrawExceptionSerializer
    serializer_class = FiatWithdrawExceptionUpdateSerializer
    queryset = FiatCurrencyWithdrawRecordLastThreeMonths.objects.all().order_by("-updated_at")
    filter_class = FiatWithdrawExceptionFilter
    throttle_classes = [TxRecordAdminThrottleDay]
    service = FiatWithdrawService()

    def filter_queryset(self, queryset):
        # 过滤 时间段, user_id, sn, status 可以自定义错误码
        user_id = self.request.query_params.get('user_id', None)
        if user_id and ParamValidator().uuid_validator(uuid_param=user_id):
            queryset = queryset.filter(user_id=user_id)
        # 过滤起始时间
        timestamp_start = self.request.query_params.get('timestamp_start', None)
        if timestamp_start and not str(timestamp_start).isdigit():
            raise ValidationError451(detail='filter params invalid:[{}]'.format('timestamp_start'))
        timestamp_start = format_timestamp(timestamp=timestamp_start)
        queryset = queryset.filter(updated_at__gte=timestamp_start)

        # 过滤结束时间
        timestamp_end = self.request.query_params.get('timestamp_end', None)
        if timestamp_end and not str(timestamp_end).isdigit():
            raise ValidationError452(detail='filter params invalid:[{}]'.format('timestamp_end'))
        timestamp_end = format_timestamp(timestamp_end, timedelta_day=0)
        queryset = queryset.filter(updated_at__lte=timestamp_end)
        # 过滤币种类型
        fiat_type = self.request.query_params.get('fiat_type', None)
        if fiat_type:
            if not str(fiat_type).isdigit():
                raise ValidationError453(detail='filter params invalid:[{}]'.format('fiat_type'))
            queryset = queryset.filter(fiat_type=int(fiat_type))

        # 过滤状态
        status = self.request.query_params.get('status', None)
        if status:
            if not str(status).isdigit():
                raise ValidationError454(detail='filter params invalid:[{}]'.format('status'))
            queryset = queryset.filter(status=int(status))
        else:
            queryset = queryset.exclude(status=WithdrawStatus.COMPLETED)
        queryset = super().filter_queryset(queryset)
        return queryset

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        # todo: qs maybe invalid
        result.update(
            data=serializer.data,
        )
        return result

    def do_create(self, request, serializer, instance, *args, **kwargs):
        """修改异常记录

        :param request:
        :param serializer:
        :param instance:
        :param args:
        :param kwargs:
        :return:
        """
        result = self.response_result
        record = self.service.filter_record(engine_sn=serializer.validated_data.get('engine_sn'))
        self.service.update_record_status(record=record, status=serializer.validated_data.get('status'))
        serializer = self.serializer_class(record)
        result.update(data=serializer.data)
        return result
