# -*- coding: utf-8 -*-
from maneki.apps.audit.models import CryptoDailyClearingRecord, CryptoMonthlyClearingRecord


class CryptoClearingService(object):
    """清算服务层:

    - 日结
    - 月结

    """

    def __init__(self):
        self.model_daily = CryptoDailyClearingRecord
        self.model_monthly = CryptoMonthlyClearingRecord

    def filter_record(self, coin_type, day_at):
        # TODO: 根据条件, 查询 单日 清算记录
        pass

    def clearing_daily(self, day_at, coin_type):
        # TODO: 单日清算动作
        # TODO: 根据 tx 记录, 处理, 计算, 然后写表
        pass

    def clearing_monthly(self, month_at, coin_type):
        # TODO: 单月清算动作
        # TODO: 根据 本表 记录, 处理, 计算, 然后写表
        pass
