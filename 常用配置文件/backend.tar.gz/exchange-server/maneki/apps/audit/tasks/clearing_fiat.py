# -*- coding: utf-8 -*-
from celery.schedules import crontab
from celery.task import periodic_task

from maneki.apps.audit.models import FiatDailyClearingRecord
from maneki.apps.constants import FiatType
from maneki.apps.transaction.models import FiatCurrencyWithdrawRecordLastThreeMonths
from django.db.models import Sum
from django.utils import timezone
from celery.utils.log import get_task_logger

logger = get_task_logger(__name__)


def report_fiat_clearing_daily():
    # todo: 上报到 单独的 财务统计钉钉群组
    pass


def report_fiat_clearing_monthly():
    # todo: 上报到 单独的 财务统计钉钉群组
    pass


def _fiat_clearing_daily(fiat_type):
    date_now = timezone.now().strftime("%Y-%m-%d")
    yesterday = (timezone.now() - timezone.timedelta(days=1)).strftime("%Y-%m-%d")
    record_obj = FiatCurrencyWithdrawRecordLastThreeMonths.objects.filter(updated_at__gte="{} 0:00".format(yesterday),
                                                                          updated_at__lt="{} 0:00".format(date_now),
                                                                          fiat_type=fiat_type)
    complete_fee = record_obj.filter(status=0).aggregate(Sum('service_charge')).get('service_charge__sum', 0)
    if not complete_fee:
        complete_fee = 0
    complete_count = record_obj.filter(status=0).count()
    pending_fee = record_obj.filter(status__gt=0).aggregate(Sum('service_charge')).get('service_charge__sum', 0)
    if not pending_fee:
        pending_fee = 0
    pending_count = record_obj.filter(status__gt=0).count()
    logger.info(
        "complete_fee: {}, complete_count: {}, pending_fee: {}, pending_count: {}".format(complete_fee, complete_count,
                                                                                          pending_fee, pending_count))
    obj = FiatDailyClearingRecord.objects.create(fiat_type=fiat_type, pending_fee_total=pending_fee,
                                                 pending_tx_count=pending_count,
                                                 completed_fee_total=complete_fee,
                                                 completed_tx_count=complete_count, )
    FiatDailyClearingRecord.objects.filter(id=obj.id).update(day_at=yesterday)


@periodic_task(run_every=crontab(hour=8, minute=0))
def get_fiat_clearing_daily():
    for i in FiatType.values:
        if i < 0:
            continue
        _fiat_clearing_daily(i)
