import requests

from maneki.apps.common.utils.sign import generate_sign_sha256
from maneki.apps.common.utils.timestamp import generate_timestamp_13bit
from maneki.apps.common.utils.crypto import generate_nonce_8bit


def test_api_key_auth():
    url = "http://127.0.0.1:8000/api/v1/settings/api_key/"

    public_key = "tjAEJLfyMDz6dudUiDXg4TA9iU5yh-b4wnOWQFUX4QZcd4zJ_m9M7vLPP7aJCz2O"
    secret_key = "GKaPg-HOBJOtrHz6FbO-gT0tsTYQzrIWOH4vNkFCAuSbn90WUlZIzMnvE0RS3dJV"

    sign_params = {
        "nonce": generate_nonce_8bit(),
        "timestamp": generate_timestamp_13bit(),
        "public_key": public_key,
    }

    payload = {}
    payload.update(sign_params)
    print("raw_payload:", payload)
    payload["signature"] = generate_sign_sha256(payload, secret_key)
    print("sign_payload:", payload)

    r = requests.get(url, params=payload)
    print(r.status_code)
    print(r.json())
