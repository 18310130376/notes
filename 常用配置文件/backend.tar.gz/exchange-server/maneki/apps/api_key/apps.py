from django.apps import AppConfig


class ApiKeyConfig(AppConfig):
    name = 'maneki.apps.api_key'
    verbose_name = "UserApiKey"
