# -*- coding: utf-8 -*-
# http header prefix:
HTTP_HEADER_PREFIX = "X-BTCC-"


# 参数域:
class ApiKeyField:
    headers = {
        "public_key": HTTP_HEADER_PREFIX + "KEY",
        "signature": HTTP_HEADER_PREFIX + "SIGN",
        "timestamp": HTTP_HEADER_PREFIX + "TIMESTAMP",
        "nonce": HTTP_HEADER_PREFIX + "NONCE",
    }
