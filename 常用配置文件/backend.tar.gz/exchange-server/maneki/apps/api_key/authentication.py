# -*- coding: utf-8 -*-
import logging
from rest_framework import authentication

from maneki.apps.api_key.services import ApiKeyService

# from django.contrib.auth.models import User

logger = logging.getLogger(__name__)


# API-KEY 鉴权:
class ApiKeyAuthentication(authentication.BaseAuthentication):

    def authenticate(self, request):
        # request.META.get('HTTP_AUTHORIZATION', b'')
        # public_key = request.GET.get("public_key", None)
        payload = self.format_payload(request)

        # logger.warning("request payload: {}".format(payload))

        if not self.validate_sign_fields(payload):
            # raise exceptions.AuthenticationFailed("Not Found: Public Key.")
            # logger.warning("Not Found: Public Key.")
            return None

        s = ApiKeyService()
        is_ok, user, detail = s.authenticate(payload=payload)
        # logger.warning(detail)
        return user, None

    @staticmethod
    def format_payload(request):
        """
        payload: {
            "public_key",
            "signature",
            "nonce",
            "timestamp"
        }

        :param request:
        :return:
        """
        # request.GET, request.POST
        payload = request.query_params or request.data
        return payload

    @staticmethod
    def validate_sign_fields(payload: dict):
        """
        sign_fields = ["public_key", "signature", "nonce", "timestamp"]

        :param payload:
        :return:
        """
        if not payload.get("public_key"):
            return False

        is_ok = bool(payload.get("signature")) and bool(payload.get("nonce")) and bool(payload.get("timestamp"))
        return is_ok


"""
ref:
    - rest_framework.authtoken.serializers.AuthTokenSerializer#validate()
    - 校验格式


"""
