from rest_framework import serializers

from maneki.apps.api_key.models import UserApiKey
from maneki.apps.constants import ApiKeyPermission
from maneki.apps.user.models.user import User

# list:


class UserApiKeyListSerializer(serializers.ModelSerializer):
    # fix for duplicate key_name: (api-key auth)
    public = serializers.CharField(source="public_key")
    secret = serializers.CharField(source="secret_key_mask")

    class Meta:
        model = UserApiKey
        fields = ("public", "secret", "label", "permission", "created_at", "white_list")
        read_only_fields = ("public", "secret")


# create:
class UserApiKeyCreateSerializer(serializers.ModelSerializer):
    label = serializers.CharField(max_length=64)
    permission = serializers.CharField(max_length=255)
    verify_mode = serializers.CharField()
    verify_code = serializers.CharField()
    whitelist = serializers.CharField(max_length=255, required=False, allow_blank=True)

    class Meta:
        model = UserApiKey
        fields = ("label", "permission", "verify_mode", "verify_code", "whitelist")

    def validate(self, attrs):
        permission = attrs.get('permission', '-1')

        if not isinstance(permission, str):
            attrs.update(code=451,
                         detail='param permission must be str')
        print('choice:{}'.format(ApiKeyPermission.values))
        if permission.isdigit() and int(permission) in ApiKeyPermission.values:
            attrs.update(permission=int(permission))
            attrs.update(code=200)
        else:
            attrs.update(code=452,
                         detail='invalid param permission')
        return attrs


