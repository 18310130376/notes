import logging

from rest_framework import permissions
from rest_framework.response import Response

from maneki.apps.api_key.services import ApiKeyService
from maneki.apps.common.mixins.rest import BetterReadWriteDeleteViewSet, BetterListModelMixin, viewsets
from .filters import ApiKeyFilter, ApiKeyVerifyFilter
from .serializers import UserApiKeyCreateSerializer, UserApiKeyListSerializer
from ..models import UserApiKey
# from maneki.apps.user_auth.views.throttles.auth import SmsThrottleMinute, SmsThrottleDay
from maneki.taskapp.messagequeue import tasks
from maneki.apps.constants import VerifyMode
from maneki.apps.user.services import UserService

logger = logging.getLogger(__name__)


class UserApiKeyViewSet(BetterReadWriteDeleteViewSet):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = UserApiKeyCreateSerializer
    serializer_class_list = UserApiKeyListSerializer
    # throttle_classes = [SmsThrottleMinute, SmsThrottleDay]
    filter_class = ApiKeyFilter
    user_service = UserService
    pagination_class = None
    lookup_url_kwarg = "target_key"
    #
    service = ApiKeyService()

    def get_queryset(self):
        user = self.request.user
        return UserApiKey.objects.filter(
            user_id=user.user_id,
            is_deleted=False
        )

    def do_list(self, request, serializer, *args, **kwargs):
        """获取API_KEY 列表, or 根据条件过滤 API_KEY

        :param request:
        :param serializer:
        :param args:
        :param kwargs:
        :return:
        """
        result = self.response_result

        data = [
            {
                "public_key": item.get("public"),
                "secret_key": item.get("secret"),
                "label": item.get("label"),
                "permission": item.get("permission"),
                "created_at": item.get("created_at"),
                "whitelist": item.get("white_list")
            }
            for item in serializer.data
        ]
        result.update(data=data)
        return result

    def do_create(self, request, serializer, instance, *args, **kwargs):
        """生成一对API_KEY

        :param request:
        :param serializer:
        :param instance:
        :param args:
        :param kwargs:
        :return:
        """
        result = self.response_result
        user = request.user

        permission = serializer.validated_data.get("permission")
        label = serializer.validated_data.get("label")

        code = serializer.validated_data.get('code')
        print('validate code:{}'.format(code))

        if code != 200:
            result.update(code=code,
                          detail=serializer.validated_data.get('detail'))
            return result

        # 如果已经存在api，则不允许创建
        is_ok, detail = self.service.validate_user_api_key(user_id=user.user_id_hex)
        if not is_ok:
            result.update(
                code=406,
                detail=detail
            )
            return result

        # 短信验证和谷歌验证
        verify_mode = serializer.validated_data.get("verify_mode")
        verify_code = serializer.validated_data.get("verify_code")
        white_list = serializer.validated_data.get("whitelist")
        white_list = white_list if white_list else ""
        #
        is_ok, result = self.service.validate_mobile_or_otp(verify_mode, result)
        if not is_ok:
            return result
        # 短信验证
        if int(verify_mode) == VerifyMode.MOBILE:
            is_ok = self.service.validate_sms_verify_code(user, verify_code)
            if not is_ok:
                result.update(
                    code=452,
                    detail="invalid verify code"
                )
                return result

        # otp 验证
        if int(verify_mode) == VerifyMode.OTP:
            otp_device, is_exist, is_active = self.user_service.user_2fa_device_status(user)
            otp_device = otp_device if is_active else None
            is_otp_verified = self.user_service.validate_otp_verify_code(otp_device, verify_code) if all(
                [otp_device, verify_code]) else False

            if not is_otp_verified:
                result.update(
                    code=453,
                    detail="invalid otp code"
                )
                return result
        # 验证 ip 白名单
        is_ok, result = self.service.validate_white_list(white_list, result)
        if not is_ok:
            return result
        record = self.service.create_record(
            user_id=user.user_id,
            permission=permission,
            label=label,
            white_list=white_list,
        )
        if not record:
            result.update(code=451, detail="create failed")
            return result
        #
        # cache:
        self.service.cache_api_key_auth_info(user=user, key_record=record)

        data = {
            "public_key": record.public_key,
            "secret_key": record.secret_key,
            "label": record.label,
            "user_id": record.user_id_hex,
            "white_list": white_list
        }
        result.update(data=data)
        return result

    def do_destroy(self, request, *args, **kwargs):
        """ 删除一对 API_KEY, 软删除.
            - API: /api/v1/api_key/1/
            - HTTP: DELETE (DELETE 时, URL必须带1)

        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        result = self.response_result
        public_key = request.data.get("target_key", None) or request.query_params.get("target_key", None)
        user_id = self.request.user.user_id
        #
        is_ok, code, detail = self.service.delete_key(user_id=user_id, public_key=public_key)
        result.update(code=code, detail=detail)
        return result


class UserCreateApiKeyVerifyViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    permission_classes = [permissions.IsAuthenticated]
    # throttle_classes = [SmsThrottleMinute, SmsThrottleDay]
    filter_class = ApiKeyVerifyFilter
    service = ApiKeyService()
    user_service = UserService

    def get_queryset(self):
        user = self.request.user
        return UserApiKey.objects.filter(
            user_id=user.user_id,
            is_deleted=False
        )

    def list(self, request, *args, **kwargs):
        """
        获取验证方式
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        result = self.response_result
        user = self.request.user
        verify_mode = self.request.query_params.get("verify_mode", None)
        # 验证登录方式
        is_ok, result = self.service.validate_mobile_or_otp(verify_mode, result)
        if not is_ok:
            return Response(result)
        # redis缓存验证码 + 发送验证短信
        if int(verify_mode) == VerifyMode.MOBILE:
            mobile = user.mobile
            if not mobile:
                result.update(
                    code=456,
                    detail="phone number do not found"
                )
                return Response(result)
            tasks.send_and_cache_sms_verify_code(user_id=self.request.user.user_id_hex)
            data = {
                "mobile": str(user.mobile)
            }
            result.update(
                detail="sms code has been send, please check your mobile phone.",
                data=data,
            )
            return Response(result)
        result.update(
            detail="otp verify"
        )
        return Response(result)
