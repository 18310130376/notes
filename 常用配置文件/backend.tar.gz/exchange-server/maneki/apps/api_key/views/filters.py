# -*- coding: utf-8 -*-
import django_filters

from maneki.apps.api_key.models import UserApiKey
from maneki.apps.user.models import User
from maneki.apps.constants import VerifyMode


class ApiKeyFilter(django_filters.FilterSet):
    target_key = django_filters.CharFilter(field_name="public_key")
    permission = django_filters.CharFilter(field_name="permission")

    class Meta:
        model = UserApiKey
        fields = ["target_key", "permission"]


class ApiKeyVerifyFilter(django_filters.FilterSet):
    verify_mode = django_filters.ChoiceFilter(VerifyMode)

    class Meta:
        model = User
        fields = ["verify_mode"]
