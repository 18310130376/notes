from django.core.cache import caches as DjangoCaches

from maneki.apps.api_key.models import UserApiKey
from maneki.apps.common.base import BaseService
from maneki.apps.common.utils import generate_key_hash
from maneki.apps.common.utils import validate_sign_sha256 as validate_sign
from maneki.apps.constants import VerifyMode

from maneki.apps.user.models import User


class ApiKeyService(BaseService):

    def __init__(self):
        super(ApiKeyService, self).__init__(
            model=UserApiKey,
            cache=DjangoCaches["engine_proxy"]
        )

        self._model_user = User
        self.cache = DjangoCaches["user_info"]

    def create_record(self, user_id, permission, label, white_list):
        fields = dict(
            user_id=user_id,
            permission=permission,
            label=label,
            white_list=white_list,
        )
        is_ok, one = self.create_one(
            query_fields=fields,
            create_fields=fields
        )
        if one.is_deleted:
            one.is_deleted = False
            one.save()
        return one

    def validate_key_pairs(self, user_id, public_key):
        pass

    def filter_records(self, user_id, permission=None):
        fields = dict(
            user_id=user_id,
            permission=permission,
        )

        is_ok, many = self.filter_many(query_fields=fields)
        return many

    def filter_record(self, public_key=None):
        fields = dict(
            public_key_hash=generate_key_hash(public_key)
        )
        is_ok, one = self.filter_one(query_fields=fields)
        return one

    def is_exist(self, user_id, public_key) -> (bool, UserApiKey):
        fields = dict(
            user_id=user_id,
            public_key=public_key,
            is_deleted=False
        )
        return self.filter_one(query_fields=fields)

    def delete_key(self, user_id, public_key):
        if not public_key:
            return False, 451, "public_key is required."

        is_exist, record = self.is_exist(user_id=user_id, public_key=public_key)
        if not is_exist:
            return False, 452, "Not Found."
        #
        record.soft_delete()
        return True, 200, "OK."

    @staticmethod
    def validate_signature(payload: dict, secret_key: str, input_sign: str):
        return validate_sign(payload, secret_key, input_sign)

    def authenticate(self, payload: dict):
        """API用户登录鉴权

        :param payload:
        :return:
        """
        public_key = payload.get("public_key")
        input_sign = payload.get("signature")
        record = self.filter_record(public_key=public_key)
        if not record:
            return False, None, "Invalid: Public Key."

        is_ok = self.validate_signature(
            payload=payload,
            secret_key=record.secret_key,
            input_sign=input_sign
        )

        if not is_ok:
            return False, None, "Invalid: Signature"

        user = User.objects.filter(user_id=record.user_id).first()
        return bool(user), user, "ok"

    def cache_api_key_auth_info(self, user: User, key_record: UserApiKey):
        """cache for engine proxy

        :param user:
        :param key_record:
        :return:
        """
        v = user.auth_fields
        v.update(
            permission=key_record.permission_label,
            label=key_record.label,
            secret_key=key_record.secret_key,
            status=key_record.status,
            white_list=key_record.white_list,
        )
        return self.cache_set(
            key=key_record.public_key,
            key_prefix_fields=["api_key", ],
            value=v,
        )

    @staticmethod
    def validate_verify_mode(verify_mode, result: dict):
        if not verify_mode:
            result.update(
                code=411,
                detail="verify mode needed!"
            )
            return False,
        if not verify_mode in VerifyMode:
            result.update(
                code=412,
                detail="invalid verify mode"
            )
            return False, result
        return True, result

    @staticmethod
    def validate_mobile_or_otp(verify_mode, result: dict):
        if not verify_mode:
            result.update(
                code=454,
                detail="verify_mode needed!"
            )
            return False, result
        if not str(verify_mode).isdigit() or int(verify_mode) not in [VerifyMode.MOBILE, VerifyMode.OTP]:
            result.update(
                code=455,
                detail="invalid verify_mode"
            )
            return False, result
        return True, result

    @staticmethod
    def validate_verify_code(verify_code, result: dict):
        if not verify_code:
            detail = "verify_code needed"
            result.update(
                code=404,
                detail=detail)
            return False, result
        return True, result

    def validate_sms_verify_code(self, user: User, verify_code):
        """短信验证码校验

        :param user:
        :param verify_code:
        :return:
        """
        key = "verify:sms:" + user.user_id_hex
        return self._validate_cache_verify_code(key, verify_code)

    def _validate_cache_verify_code(self, key, verify_code):
        """校验验证码是否正确

        :param key:
        :param verify_code: 输入验证码
        :return:
        """
        cache_code = self.cache.get(key, None)
        return verify_code == cache_code

    @staticmethod
    def validate_user_api_key(user_id=None):
        """
        校验用户是否已存在 api-key,存在则不允许创建
        :param user_id:
        :return:
        """
        api_key = UserApiKey.objects.filter(user_id=user_id, is_deleted=False).first()
        if api_key:
            return False, "api-key has already exist!"
        return True, "ok"

    def obtain_verify_code(self, user: User):
        key = "verify:sms:" + user.user_id_hex
        return self.cache.get(key, None)

    @staticmethod
    def validate_white_list(white_list, result: dict):
        """
        校验 ip 白名单
        :param white_list:
        :param result:
        :return:
        """
        # 判断一共几条 ip
        if not white_list:
            return True, result
        count = white_list.count(",")
        if count > 4:
            result.update(
                code=457,
                detail="too many ip whitelists"
            )
            return False, result

        # 判断 ip 总长度
        if len(white_list) > 79:
            result.update(
                code=458,
                detail="whitelist is too long"
            )
            return False, result
        return True, result
