# -*- coding: utf-8 -*-
from django.db.models import UUIDField
from django.db.models import CharField
from django.db.models import IntegerField
from django.utils.translation import ugettext_lazy as _

from maneki.apps.common.libs.models import UserSoftDeleteModel
from maneki.apps.common.utils import generate_key_hash
from maneki.apps.common.utils import generate_secret_key_32bit
from maneki.apps.common.utils import generate_secret_key_64bit
from maneki.apps.constants import ApiKeyPermission
from maneki.apps.constants import ApiKeyStatus
from maneki.apps.constants import MODEL_PREFIX

"""
sentry.models.apikey.ApiKey()
"""


class UserApiKey(UserSoftDeleteModel):
    # fix: 无索引: 允许多个
    user_id = UUIDField(verbose_name=_("User ID"), null=False, blank=False, db_index=False)

    # used as redis-key:
    public_key_hash = CharField(verbose_name=_("Api Public Key MD5"), default="", max_length=64, unique=True)
    public_key = CharField(verbose_name=_("Api Public Key"), default=generate_secret_key_64bit, max_length=64, unique=True)
    secret_key = CharField(verbose_name=_("Api Secret Key"), default=generate_secret_key_64bit, max_length=255, unique=True)

    label = CharField(max_length=255, default="", verbose_name=_("Api Key Description"))
    status = IntegerField(verbose_name=_("Api Status"), default=ApiKeyStatus.UNDEFINED, choices=ApiKeyStatus.choices)
    # TODO: 权限设计
    # roles = CharField()
    permission = IntegerField(verbose_name=_("Api Permission"), default=ApiKeyPermission.UNDEFINED, choices=ApiKeyPermission.choices)
    #
    # rate_limit_count = IntegerField()
    # rate_limit_window = IntegerField()
    # allowed_ip = GenericIPAddressField(verbose_name=_("Api Allowed Ip"), default="", )
    version = IntegerField(verbose_name=_("Key Version"), default=0)
    # whitelist: ip白名单
    white_list = CharField(max_length=255, default="", verbose_name=_("Api Key White list"))
    # support legacy tx keys in API
    scopes = (
        'transaction:read', 'transaction:write', 'transaction:admin',
    )

    class Meta:
        verbose_name = _("User Api Key")
        db_table = MODEL_PREFIX + "user_api_key"

    def save(
        self, force_insert=False, force_update=False, using=None,
        update_fields=None,
    ):
        if self.public_key and not self.public_key_hash:
            self.public_key_hash = generate_key_hash(self.public_key)

        super(UserApiKey, self).save()

    @property
    def permission_label(self):
        return ApiKeyPermission.get_choice(self.permission).label

    @property
    def secret_key_mask(self):
        """对 secret_key 作掩码处理

            - d41f4d147f2ff82f8b33ce2b0f46c9b52c73c24bcc313cd2a7b8d14388917de7
            - d41f4d**********************************************************

        :return:
        """
        key_mask = self.secret_key
        length = len(key_mask)
        key_mask = key_mask[:6] + "*" * (length - 6)
        return key_mask

    @classmethod
    def generate_key_and_hash(cls, hash_required=False):
        """生成 key 和 hash 值

        :param hash_required: 是否生成 hash 值
        :return:
        """
        key = generate_secret_key_64bit()
        key_hash = generate_key_hash(key) if hash_required else None
        return key, key_hash

    @property
    def is_active(self):
        return self.status == ApiKeyStatus.ACTIVE


# 内部服务专用签名key:
class UserInternalApiKey(UserSoftDeleteModel):
    # for Internal Service Sign:
    internal_key = CharField(verbose_name=_("Api Internal Key"), default=generate_secret_key_32bit, max_length=64, unique=True)

    status = IntegerField(verbose_name=_("Api Status"), default=ApiKeyStatus.UNDEFINED, choices=ApiKeyStatus.choices)
    label = CharField(max_length=255, default="", verbose_name=_("Internal Key Description"))
    version = IntegerField(verbose_name=_("Key Version"), default=0)

    class Meta:
        verbose_name = _("User Internal Key")
        db_table = MODEL_PREFIX + "user_api_key_internal"

    @property
    def is_active(self):
        return self.status == ApiKeyStatus.ACTIVE
