# -*- coding: utf-8 -*-


class ErrorsCommon:
    limit_error = (10000, "param limit error")
    offset_error = (10001, "param offset error")
    time_start_error = (10002, "param timestamp_start error")
    time_end_error = (10003, "param timestamp_end error")
    status_error = (10004, "param status error")
    user_id_error = (10005, "param user_id error")
    email_error = (10006, "param email error")


class Errors1:
    coin_type_error = (11000, "param coin type error")
    verify_type_error = (11001, "param verify type error")

