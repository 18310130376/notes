import json

from rest_framework import viewsets, permissions
from rest_framework.response import Response

from maneki.apps.user.models.user import User
from maneki.apps.user.models.user_profile import UserProfile
from maneki.apps.user_kyc.libs.s3_storage_backend import PrivateMediaStorage
from maneki.apps.user_role.models.role import RoleType

from maneki.apps.assets.models.fiat_accounts import UserFiatAccount
from maneki.apps.user_kyc.models.kyc import KYCIndividual, UserExtraImage
from maneki.apps.user.views.filters.user_filter import UserFilter


class SearchUserViewSet(viewsets.GenericViewSet):
    filter_class = UserFilter
    pagination_class = None
    permission_classes = [permissions.IsAuthenticated]

    def list(self, request, *args, **kwargs):
        code, detail, data = 200, 'ok', {}

        email = request.query_params.get('email', None)
        mobile = request.query_params.get('mobile', None)
        user_id = request.query_params.get('user_id', None)
        if not any([email, mobile, user_id]):
            code = 451
            detail = 'must have one filter'

            return Response({'code': code, 'detail': detail, 'data': data}, status=200)
        condition = {k: v for k, v in dict(
            user_id=user_id,
            mobile=mobile,
            email=email
        ).items() if v is not None}

        user = User.objects.filter(**condition).first()
        if not user:
            code = 450
            detail = 'user not find'

            return Response({'code': code, 'detail': detail, 'data': data}, status=200)

        user_info = {
            'uid': user.user_id_hex,
            'email': user.email,
            'mobile': user.mobile_str if user.mobile else "",
            '2fa_verified': user.totp_device_verified,
            'mobile_verified': user.mobile_verified,
        }

        profile = UserProfile.objects.filter(user_id=user.user_id).first()

        if profile:
            user_info.update({
                'level': profile.level,
                'is_double_check': profile.is_double_check,
                'deposit_code': profile.deposit_code,
                'nickname': profile.nickname,
            })

        kyc = KYCIndividual.objects.filter(user_id=user.user_id).first()

        if kyc:
            image_obj = PrivateMediaStorage()
            kyc_info = {
                'first_name': kyc.first_name,
                'middle_name': kyc.middle_name,
                'last_name': kyc.last_name,
                'license_country': kyc.license_country,
                'current_level': kyc.current_level,
                'license_type1': kyc.license_type1,
                'license_number': kyc.license_number,
                'industry': kyc.industry,
                'license_type': kyc.license_type,
                'license_pic01': image_obj.url(kyc.license_pic01.name),
                'license_pic03': image_obj.url(kyc.license_pic03.name),
                'address_cert': image_obj.url(kyc.address_cert.name),
                "local_country": kyc.local_country,
                'local_city': kyc.local_city,
                'local_region': kyc.local_region,
                'local_address': kyc.local_address,
                'local_postcode': kyc.local_postcode,
            }
            if kyc.license_type == 'paper':
                kyc_info.update({
                    "license_pic02": image_obj.url(kyc.license_pic02.name)
                })
            extra_image = kyc.extra_image
            if extra_image == 'False':
                others = UserExtraImage.objects.filter(user_id=user.user_id).first().value
            else:
                others = extra_image
            if others:
                others = eval(others)
                others = {k: image_obj.url(v) for k, v in others.items()}
            kyc_info.update(others=others)
            user_info.update(
                kyc=kyc_info
            )

        fiat_accounts = UserFiatAccount.objects.filter(user_id=user_id, is_deleted=False).all()

        if fiat_accounts:
            accounts = []
            for account in fiat_accounts:
                account_info = {
                    'fiat_type': account.fiat_type,
                    'account_type': account.account_type,
                    'bank_id': account.bank_id,
                    'bank_swift_code': account.bank_swift_code,
                    'bank_address': account.bank_address,
                    'bank_account': account.bank_account,
                    'beneficiary_name': account.beneficiary_name,
                    'beneficiary_address': account.beneficiary_address,
                    'via_bank_name': account.via_bank_name,
                    'via_bank_address': account.via_bank_address,
                    'via_bank_swift_code': account.via_bank_swift_code

                }
                accounts.append(account_info)
            user_info.update(
                accounts=accounts
            )
        data = user_info
        return Response({'code': code, 'detail': detail, 'data': data}, status=200)
