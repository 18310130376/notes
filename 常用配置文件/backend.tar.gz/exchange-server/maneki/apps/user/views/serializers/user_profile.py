# -*- coding: utf-8 -*-
from rest_framework import serializers

from ...models import UserProfile


# Deposit Code
class FiatDepositCodeSerializer(serializers.ModelSerializer):
    deposit_code = serializers.CharField(label='deposit code', help_text='deposit code ', min_length=8)

    class Meta:
        model = UserProfile
        fields = ["deposit_code"]
