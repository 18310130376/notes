import django_filters

from maneki.apps.user.models.user import User


class UserFilter(django_filters.FilterSet):
    user_id = django_filters.UUIDFilter()
    email = django_filters.CharFilter()
    mobile = django_filters.CharFilter()

    class Meta:
        model = User
        fields = ['user_id', 'email', 'mobile']
