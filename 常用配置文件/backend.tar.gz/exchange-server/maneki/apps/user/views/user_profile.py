from rest_framework import viewsets
from rest_framework import mixins
from rest_framework import permissions
from rest_framework.response import Response
from rest_framework import status

from ..models import UserProfile
from .serializers import FiatDepositCodeSerializer


class UserFiatDepositCodeViewSet(viewsets.GenericViewSet):
    serializer_class = FiatDepositCodeSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return UserProfile.objects.filter(
            user_id=self.request.user.user_id,
            is_deleted=False,
        )

    def list(self, request, *args, **kwargs):
        instance = self.get_queryset().filter(user_id=request.user.user_id).first()
        serializer = self.get_serializer(instance)
        deposit_code = serializer.data.get('deposit_code')
        result = {
            "message": "ok",
            "data": {
                'deposit_code': deposit_code
            },
        }
        return Response(
            result,
            status=status.HTTP_200_OK,
        )
