import bcrypt


def set_trade_password(user, raw_value):
    user.trade_password = bcrypt.hashpw(raw_value.encode('utf-8'), bcrypt.gensalt())
    user.save()
    return True


def check_trade_password(user, raw_value):
    return bcrypt.checkpw(raw_value.encode("utf-8"), user.trade_password.encode("utf-8"))
