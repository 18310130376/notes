from django_filters.filters import Filter
from phonenumber_field import formfields


class PhoneNumberFilter(Filter):
    """
    ref:
        - https://github.com/stefanfoulis/django-phonenumber-field
        - http://django-filter.readthedocs.io/en/latest/ref/filterset.html#customise-filter-generation-with-filter-overrides

    """
    field_class = formfields.PhoneNumberField
