import phonenumbers
import logging

logger = logging.getLogger(__name__)


def validate_mobile_phone_number(mobile: str, country_code: str):
    """格式化和校验手机号

    :param mobile: [+49 176 1234 5678, ]
    :param country_code: [+86 ]
    :return:
    """
    if not mobile or not country_code:
        return None, None

    country_code = "+" + country_code if not country_code.startswith("+") else country_code
    mobile = country_code + mobile if not mobile.startswith(country_code) else mobile

    logger.info("mobile phone: mobile={}, country_code={}".format(mobile, country_code))

    mobile, mobile_obj = format_and_parse_mobile_phone_number(mobile)
    # 格式校验:
    if not phonenumbers.is_valid_number(mobile_obj):
        return None, None
    return mobile, country_code


def format_and_parse_mobile_phone_number(raw_mobile: str, fmt=phonenumbers.PhoneNumberFormat.E164):
    """格式化手机号, 去空格

    :param raw_mobile:
    :param fmt: [phonenumbers.PhoneNumberFormat.E164, ]
    :return: [已格式化手机号, 手机号对象]
    """
    logger.info("format mobile phone: raw={}".format(raw_mobile))
    if not isinstance(raw_mobile, phonenumbers.phonenumber.PhoneNumber):
        mobile_obj = phonenumbers.parse(raw_mobile)
    else:
        mobile_obj = raw_mobile

    mobile_str = phonenumbers.format_number(mobile_obj, fmt)
    logger.info("format mobile phone result: str={}, obj=[{}]".format(mobile_str, mobile_obj))
    return mobile_str, mobile_obj
