from __future__ import absolute_import
from __future__ import unicode_literals

from celery.utils.log import get_task_logger
from django.core.cache import caches as DjangoCaches
from rest_framework.permissions import BasePermission


logger = get_task_logger(__name__)


def is_in_blacklist(user_uid):
    client = DjangoCaches['user_black_list']
    user_black_list = client.get('black_list_uid', [])

    return user_uid in user_black_list


def get_user_in_black_list():
    client = DjangoCaches['user_black_list']
    user_black_list = client.get('black_list_uid', [])

    return user_black_list


def add_user_into_black_list(user_uid):
    client = DjangoCaches['user_black_list']
    user_black_list = client.get('black_list_uid', [])

    user_black_list.append(user_uid)
    user_black_list = list(set(user_black_list))
    return client.set('black_list_uid', user_black_list, timeout=None)


def remove_user_from_black_list(user_uid):
    if not is_in_blacklist(user_uid):
        return False

    client = DjangoCaches['user_black_list']
    user_black_list = client.get('black_list_uid', [])

    user_black_list.remove(user_uid)
    return client.set('black_list_uid', user_black_list, timeout=None)


class IsInBlacklist(BasePermission):
    # add into permissions_classes list to block user which in black list
    def has_permission(self, request, view):
        return not is_in_blacklist(request.user.user_id_hex)


def is_in_server_maintenance_list(url):
    '''
    url: for example: '/api/v1/auth/set/tradecode/'
    '''
    client = DjangoCaches['server_maintenance']
    server_maintenance_list = client.get('server_maintenance_list', [])

    return url in server_maintenance_list


def get_url_in_server_maintenance():
    client = DjangoCaches['server_maintenance']
    server_maintenance_list = client.get('server_maintenance_list', [])

    return server_maintenance_list


def add_url_into_server_maintenance(url):
    '''
    url: for example: '/api/v1/auth/set/tradecode/'
    '''
    client = DjangoCaches['server_maintenance']
    server_maintenance_list = client.get('server_maintenance_list', [])

    server_maintenance_list.append(url)
    server_maintenance_list = list(set(server_maintenance_list))
    return client.set('server_maintenance_list', server_maintenance_list, timeout=None)


def remove_user_from_server_maintenance(url):
    '''
    url: for example: '/api/v1/auth/set/tradecode/'
    '''
    if not is_in_server_maintenance_list(url):
        return False

    client = DjangoCaches['server_maintenance']
    server_maintenance_list = client.get('server_maintenance_list', [])

    server_maintenance_list.remove(url)
    return client.set('server_maintenance_list', server_maintenance_list, timeout=None)


class IsInServerMaintence(BasePermission):
    # add url into Server Maintence list to avoid access
    def has_permission(self, request, view):
        url = request._request.get_full_path()
        return not is_in_server_maintenance_list(url)
