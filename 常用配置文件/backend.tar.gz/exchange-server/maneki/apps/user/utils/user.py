import secrets
import string


def generate_username(length=11):
    """ 生成11位随机数: (数字+字母大小写)

        - string.ascii_letters: 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
        - string.punctuation:  '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
        - string.hexdigits: digits + 'abcdef' + 'ABCDEF'
    :return:
    """
    alphabet = string.digits

    key = ''.join(
        secrets.choice(alphabet)
        for _ in range(length)
    )
    return key
