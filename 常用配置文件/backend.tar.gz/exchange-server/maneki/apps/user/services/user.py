import logging
import json
import base64
import requests
from datetime import datetime
from django.conf import settings
from django.contrib.auth import login as django_login
from django.core.cache import caches as DjangoCaches
from faker import Faker

from maneki.apps.common.utils import generate_nonce_8bit_digits, generate_secret_key_v4
from maneki.apps.constants import UserAccountStatus, UserMigrationStatus, UserDistributorType
from maneki.apps.engine.services import EngineService
from maneki.apps.user.services.user_profile import UserProfileService
from maneki.apps.user_auth.services.register_code import RegisterCodeService
from maneki.apps.common.utils.redis.r import redis_sessions, get_token_cache_key
from maneki.apps.user_members.services import MemberService, UserDistributorService
from maneki.apps.user_role.services.role import RoleTypeService
from maneki.apps.constants import UserMembersPointsSource, UserActivityPoint
from maneki.taskapp.messagequeue import tasks

from ..models import User, UserProfile
from .otp import TimeOTPDeviceService
from ..utils.check_field import set_trade_password, check_trade_password

logger = logging.getLogger(__name__)


class UserService(object):
    def __init__(self):
        self.model = User
        self.profile_model = UserProfile
        self.engine_cache = DjangoCaches["engine_proxy"]
        #
        self.cache = DjangoCaches["user_info"]
        self.profile_service = UserProfileService()
        self.role_service = RoleTypeService()
        self.register_code_service = RegisterCodeService()

    def create_user_email(self, email, password, username):
        obj = self.model.objects.create(email=email,
                                        password=password,
                                        username=username)
        return obj

    def create_user_mobile(self, mobile, mobile_country_code, password, username):
        obj = self.model.objects.create(mobile=mobile,
                                        mobile_country_code=mobile_country_code,
                                        password=password,
                                        username=username)
        return obj

    def filter_record(self,
                      email=None,
                      mobile=None,
                      mobile_country_code=None,
                      user_id=None):
        """筛选单条user记录

        :param email:
        :param mobile:
        :param mobile_country_code:
        :param user_id:
        :return:
        """
        if email:
            return self.model.objects.filter(email=email).first()
        if mobile and mobile_country_code:
            mobile, _, _ = self.format_mobile_phone(mobile=mobile, country_code=mobile_country_code)
            return self.model.objects.filter(mobile=mobile).first()
        if user_id:
            return self.model.objects.filter(user_id=user_id).first()

    def user_engine_account_id(self, user_id):
        """ 引擎 account id

        :param user_id:
        :return:
        """
        obj = self.filter_record(user_id=user_id)
        return obj.engine_account_id if obj else 0

    @staticmethod
    def _update_old_account_status(user: User):
        user.old_account_status = UserMigrationStatus.COMPLETED
        user.save()
        return True

    def send_reset_password_verify_code(self,
                                        email=None,
                                        mobile=None,
                                        mobile_country_code=None):

        user = self.filter_record(
            email=email,
            mobile=mobile, mobile_country_code=mobile_country_code)
        if not user:
            return False, 451, "email has not registered."

        # check:
        is_enable, is_old, is_staff, is_admin = user.account_status
        if not is_enable:
            return False, 452, "email has not activated."

        verify_code = self.cache_email_reset_password_verify_code(user=user)

        if email:
            self.async_send_email_verify_code(email=email, verify_code=verify_code)

        return True, 200, "reset email has been resend, please check your email account."

    @staticmethod
    def async_send_email_verify_code(email, verify_code):
        return tasks.send_email.delay(
            user="",
            email=email,
            verify_code=verify_code,
            email_subject="Reset Your BTCC Account",
        )

    def reset_password(self, verify_code,
                       new_password1,
                       new_password2,
                       email=None, mobile=None, mobile_country_code=None):
        """密码重置:

        :param verify_code:
        :param new_password1:
        :param new_password2:
        :param email:
        :param mobile:
        :param mobile_country_code:
        :return:
        """

        user = self.filter_record(email=email, mobile=mobile, mobile_country_code=mobile_country_code)
        if not user:
            return False, 451, "email has not registered."

        # check:
        is_enable, is_old, is_staff, is_admin = user.account_status

        if not is_enable:
            return False, 452, "email has not activated."

        is_ok = self.validate_email_reset_password_verify_code(user=user, verify_code=verify_code)
        if not is_ok:
            return False, 453, "invalid reset password verify code."

        if new_password1 != new_password2:
            return False, 454, "new passwords are not match."

        # change_password:
        self.update_password(user=user, new_password=new_password1)

        # old account:
        if is_old:
            self._update_old_account_status(user=user)

        return True, 200, "update password."

    def cache_email_reset_password_verify_code(self, user: User, expire=30 * 60):
        key = "reset_password:email:" + user.user_id_hex
        return self._cache_verify_code(key=key, expire=expire)

    def cache_email_verify_code(self, user: User, expire=30 * 60):
        """邮件验证码

        :param user:
        :param expire:
        :return:
        """
        key = "verify:email:" + user.user_id_hex
        return self._cache_verify_code(key=key, expire=expire)

    def cache_sms_verify_code(self, user: User, verify_code=None, expire=30 * 60):
        """短信验证码

        :param user:
        :param verify_code:
        :param expire:
        :return:
        """
        key = "verify:sms:" + user.user_id_hex
        return self._cache_verify_code(key=key, value=verify_code, expire=expire)

    def cache_mobile_phone_number(self, user: User, mobile, mobile_country_code, expire=60 * 60 * 24):
        """绑定手机号: 缓存1天

        :param user:
        :param mobile:
        :param mobile_country_code:
        :param expire:
        :return:
        """
        key1 = "verify:mobile:" + user.user_id_hex
        key2 = "verify:mobile_country_code:" + user.user_id_hex
        mobile, mobile_country_code, _ = self.format_mobile_phone(mobile, mobile_country_code)

        self._cache_verify_code(key=key1, value=mobile, expire=expire)
        self._cache_verify_code(key=key2, value=mobile_country_code, expire=expire)

    def validate_mobile_phone_number(self, user: User, mobile, mobile_country_code):
        """校验用户的手机号和国家区位码

        :param user:
        :param mobile:
        :param mobile_country_code: 手机号区位码
        :return:
        """
        key1 = "verify:mobile:" + user.user_id_hex
        key2 = "verify:mobile_country_code:" + user.user_id_hex
        mobile, mobile_country_code, _ = self.format_mobile_phone(mobile, mobile_country_code)

        status1 = self._validate_cache_verify_code(key=key1, verify_code=mobile)
        status2 = self._validate_cache_verify_code(key=key2, verify_code=mobile_country_code)
        return status1 and status2

    def validate_email_verify_code(self, user: User, verify_code):
        """邮件验证码校验

        :param user:
        :param verify_code:
        :return:
        """
        key = "verify:email:" + user.user_id_hex
        return self._validate_cache_verify_code(key, verify_code)

    def validate_email_reset_password_verify_code(self, user: User, verify_code):
        key = "reset_password:email:" + user.user_id_hex
        return self._validate_cache_verify_code(key, verify_code)

    def validate_sms_verify_code(self, user: User, verify_code):
        """短信验证码校验

        :param user:
        :param verify_code:
        :return:
        """
        key = "verify:sms:" + user.user_id_hex
        return self._validate_cache_verify_code(key, verify_code)

    @staticmethod
    def validate_otp_verify_code(device, verify_code):
        """otp device 验证码校验

        :param device:
        :param verify_code:
        :return:
        """
        return device.verify_token(verify_code)

    def _cache_verify_code(self, key, value=None, expire=30 * 60):
        """生成验证码, 写入 redis

        :param key:
        :param expire: 默认存活时间30分钟
        :return: 返回验证码
        """
        value = value or generate_nonce_8bit_digits()
        self.cache.set(key, value, timeout=expire)
        return value

    def _validate_cache_verify_code(self, key, verify_code):
        """校验验证码是否正确

        :param key:
        :param verify_code: 输入验证码
        :return:
        """
        cache_code = self.cache.get(key, None)
        return verify_code == cache_code

    @staticmethod
    def check_password(user: User, password: str):
        return user.check_password(password)

    def logout(self, user: User, device_b64str=None):
        if device_b64str:
            self.delete_cache_for_engine_proxy(user, device_b64str)
            self.delete_auth_token(user, device_b64str)
        else:
            self.delete_cache_for_engine_proxy(user)
            self.delete_auth_token(user)

    def login(self, request: object, user: User, is_mobile=False, device_b64str=None):
        logger.info('django login')
        if getattr(settings, 'REST_SESSION_LOGIN', True):
            if is_mobile:
                django_login(request, user, backend='django.contrib.auth.backends.ModelBackend')
            else:
                django_login(request, user, backend="allauth.account.auth_backends.AuthenticationBackend")
        logger.info('login profile db start')
        profile = self.profile_service.filter_record(user_id=user.user_id)
        if device_b64str:
            token = self.get_or_create_auth_token(user, device_b64str)
        else:
            token = self.get_or_create_auth_token(user)
        logger.info('login profile db end')
        result = {
            "user_id": user.engine_account_id,
            "level": str(profile.level) if profile else "-1",
            "role_id": str(profile.role_id) if profile else "-1",
            "role_code": str(self.role_service.get_role_code(profile.role_id)) if profile else "-1",
            "token": token,
        }
        logger.info("User Login: user_id={}, email={}, mobile={}".format(user.user_id_hex, user.email, user.mobile))
        return result

    def old_account_login(self, email, password):
        old_login_url = "https://api.btcc.com/api.php/account/authenticate"
        headers = {'Authorization': 'Basic ' + base64.b64encode(
            bytes(email, encoding='utf8') +
            b':' + bytes(password, encoding='utf8')).decode(),
                   'Content-Type': 'application/x-www-form-urlencoded'}
        post_data = {'captcha': None, 'twofactorpwd': None, 'keepLogin': False, 'msie10': False}
        req = requests.post(url=old_login_url, data=post_data, headers=headers)
        if req.status_code == 200:
            return True
        else:
            return False

    @staticmethod
    def get_or_create_auth_token(user: User, device_b64str=None):
        #  if found token, use it , else create a new token
        if device_b64str:
            user_info = get_user_info_from_cache(user, device_b64str)
        else:
            user_info = get_user_info_from_cache(user)
        logger.info('user info:{}'.format(user_info))
        if 'token' in user_info:
            old_key = get_token_cache_key(user_info['token'])
            redis_sessions['TokenAuth'].set(old_key, user.user_id_hex, ex=60 * 60 * 24)
            return user_info['token']

        # create new token
        token = generate_secret_key_v4(length=20)
        new_key = get_token_cache_key(token)

        redis_sessions['TokenAuth'].set(new_key, user.user_id_hex, ex=60 * 60 * 24)
        return token

    @staticmethod
    def delete_auth_token(user: User, device_b64str=None):
        if device_b64str:
            user_info = get_user_info_from_cache(user, device_b64str)
        else:
            user_info = get_user_info_from_cache(user)
        if 'token' in user_info:
            old_key = get_token_cache_key(user_info['token'])
            redis_sessions['TokenAuth'].set(old_key, user.user_id_hex, ex=1)
            return True
        return False

    def cache_for_engine_proxy(self, user: User, token):
        result = user.auth_fields
        result.update(token=token)
        self.engine_cache.set(user.engine_account_id, result, timeout=60 * 60 * 24)
        return result

    def delete_cache_for_engine_proxy(self, user: User, device_b64str=None):
        if device_b64str:
            self.engine_cache.set(user.engine_account_id + ":" + device_b64str, 'to_delete', timeout=1)
        else:
            self.engine_cache.set(user.engine_account_id, 'to_delete', timeout=1)
        return True

    def payload_for_user_members(self, user: User):
        result = {
            "user_id": user.user_id_hex,
            "point": UserActivityPoint.get(101, 1000),  # TODO: need refactor.
            "point_source": UserMembersPointsSource.USERACTIVATE,
            "remark": "user activate at {}".format(datetime.now())
        }
        return result

    def user_email_status(self, email: str):
        is_exist, is_active = False, False
        user = self.model.objects.filter(email=email).first()
        if user:
            is_exist = True
            is_active = user.email_verified
        return user, is_exist, is_active

    def user_mobile_status(self, mobile: str):
        is_exist, is_active = False, False
        user = self.model.objects.filter(mobile=mobile).first()
        if user:
            is_exist = True
            is_active = user.mobile_verified
        return user, is_exist, is_active

    @staticmethod
    def user_2fa_device_status(user: User):
        s = TimeOTPDeviceService()
        return s.user_2fa_device_status(user)

    @staticmethod
    def update_password(user: User, new_password: str):
        user.set_password(new_password)
        user.save()

    def enable_account(self, user: User, by_email: bool = False, by_mobile: bool = False):
        """激活账号+同步 user profile 信息

        :param user:
        :param by_email:
        :param by_mobile:
        :return:
        """
        user.is_active = True
        user.status = UserAccountStatus.EXCHANGE_ENABLED
        if not user.engine_token:
            user.engine_token = generate_secret_key_v4(length=20)  # TODO: 小心, 只生成1次
        if by_email:
            user.email_verified = True
        if by_mobile:
            user.mobile_verified = True
        user.save()

        # sync
        self.sync_user_profile(user_id=user.user_id)
        return user

    def sync_user_profile(self, user_id):
        return self.profile_service.create_record(user_id=user_id)

    @staticmethod
    def engine_response_update_status(user: User):
        """引擎创建成功, 更新账号状态

        :param user:
        :return:
        """
        user.status = UserAccountStatus.ENABLED
        user.save()
        return user

    @staticmethod
    def disable_account(user: User):
        pass

    @staticmethod
    def format_mobile_phone(mobile: str, country_code: str):
        """格式化手机号

        :param mobile:
        :param country_code:
        :return:
        """
        mobile, country_code = str(mobile), str(country_code)

        country_code = "+" + country_code if not country_code.startswith("+") else country_code
        mobile = country_code + mobile if not mobile.startswith(country_code) else mobile
        mobile_simple = mobile.lstrip(country_code)
        return mobile, country_code, mobile_simple

    def enable_mobile_phone(self, user: User, mobile: str, country_code: str):
        """激活手机号

        :param user:
        :param mobile:
        :param country_code:
        :return:
        """
        mobile, country_code, _ = self.format_mobile_phone(mobile=mobile, country_code=country_code)

        user.mobile = mobile
        user.mobile_verified = True
        user.mobile_country_code = country_code
        user.save()
        return user

    @staticmethod
    def enable_email(user: User, email: str):
        """激活邮箱

        :param user:
        :param email:
        :return:
        """
        user.email = email
        user.email_verified = True
        user.save()
        return user

    @staticmethod
    def update_2fa_device_status(user_id: str, is_verified: bool):
        user = User.objects.filter(user_id=user_id).first()
        if not user:
            return
        user.totp_device_verified = is_verified
        user.save()

    @staticmethod
    def set_trade_password(user: User, trade_password: str):
        return set_trade_password(user, trade_password)

    @staticmethod
    def trade_password_is_empty(user: User):
        return user.trade_password == ''

    @staticmethod
    def check_trade_password(user: User, trade_password: str):
        return check_trade_password(user, trade_password)

    @staticmethod
    def cache_user_info(user: User, **kwargs):
        cache_user_info(user.user_id, **kwargs)

    def is_valid_register_code(self, register_code, user_identity):
        is_usable = self.register_code_service.validate_code(register_code, user_identity)
        if not is_usable:
            return False
        return True

    def update_register_code_user_id(self, user_identity, user_id):
        self.register_code_service.update_user_id(user_identity, user_id)

    @staticmethod
    def get_device_info(device_b64str):
        # base64解码
        device_str = base64.b64decode(device_b64str).decode()
        # 解析字符串
        device_info_list = str(device_str).split('@@')
        # 获取device info
        device_info = {
            'os': device_info_list[0],
            'version': device_info_list[1],
            'device_id': device_info_list[2]
        }
        return device_info

    def cache_for_engine_proxy_with_device(self, user: User, token, device_b64str, device_info):
        result = {
            "user_id": user.engine_account_id,
            "email": user.email if user.email else "",
            "mobile": user.mobile_str if user.mobile else "",
            "engine_token": user.engine_token,
            "token": token,
            "device_info": device_info,
        }
        key = user.engine_account_id + ':' + device_b64str
        self.engine_cache.set(key, result, timeout=60 * 60 * 24)
        logger.info('cache for engine')
        return result

    @staticmethod
    def cache_user_info_with_device(user: User, token, device_b64str, device_info):
        user_info = get_and_format_user_info(user.user_id)
        user_info.update(token=token)
        user_info.update(device_info=device_info)
        key = user.user_id_hex + ':' + device_b64str
        redis_sessions['UserInfo'].set(key, json.dumps(user_info), ex=60 * 60 * 24)

    @staticmethod
    def sync_engine_user(email, user_id, engine_token):
        es = EngineService()
        result = es.create_account(
            email=email,
            user_id=user_id,
            token=engine_token,
        )
        logger.info("RPC Engine Response: {}".format(result))

        if result['RC'] != 0:
            return False

        # if settings.TEMP_STAGE_USER_ACCOUNT:
        #     # TODO: demo test, init user account
        #     # test create account add currency to account
        #     add_currency(user_id=payload["user_id"])
        # update:
        us = UserService()
        user = us.filter_record(user_id=user_id)
        if not user:
            return False
        us.engine_response_update_status(user=user)
        return True

    @staticmethod
    def create_member_points(user_id, point, point_source, remark):
        """

        :param user_id:
        :param point:
        :param point_source:
        :param remark:
        :return:
        """
        logger.info("activate user member account: {}".format(user_id))

        ms = MemberService()
        create_member_result = ms.create_members(
            user_id=user_id
        )

        activate_result = ms.add_user_member_points(
            user_id=user_id,
            point=int(point),
            point_source=int(point_source),
            remark=remark
        )

        uds = UserDistributorService()
        # 验证通过，查看是否被邀请记录，修改delete状态
        if uds.filter_by_user(user_id=user_id):
            logger.info(f'modify invite user:{user_id}')
            uds.update_status(user_id=user_id)
        else:
            logger.info(f'create invite user:{user_id}')
            uds.create_distributor(
                user_id=user_id,
                user_type=UserDistributorType.USER
            )
        return create_member_result, activate_result


def cache_user_info(uid, **kwargs):
    user_info = get_and_format_user_info(uid)
    if kwargs.get('token', None):
        user_info.update(token=kwargs['token'])
    redis_sessions['UserInfo'].set(uid.hex, json.dumps(user_info), ex=60 * 60 * 24)


def refresh_user_info(uid, device_b64str=None):
    if device_b64str:
        cached_info = redis_sessions['UserInfo'].get(uid + ':' + device_b64str)
    else:
        cached_info = redis_sessions['UserInfo'].get(uid)
    if not cached_info:
        return False
    cached_info = json.loads(cached_info)

    new_user_info = get_and_format_user_info(uid)

    for key, value in cached_info.items():
        new_value = new_user_info.get(key, None)
        if new_value:
            cached_info[key] = new_value
    if device_b64str:
        redis_sessions['UserInfo'].set(uid + ':' + device_b64str, json.dumps(cached_info), ex=60 * 60 * 24)
    else:
        redis_sessions['UserInfo'].set(uid, json.dumps(cached_info), ex=60 * 60 * 24)


def get_and_format_user_info(user_id):
    service = UserService()
    user = service.filter_record(user_id=user_id)

    profile_service = UserProfileService()
    profile = profile_service.filter_record(user_id=user_id)

    user_info = {
        'uid': user.user_id_hex,
        'email': user.email,
    }
    if profile:
        user_info.update({
            'level': profile.level,
            'is_double_check': profile.is_double_check,
            'deposit_code': profile.deposit_code,
            'nickname': profile.nickname,
            'role_id': profile.role_id
        })
    return user_info


def get_user_info_from_cache(user: User, device_b64str=None):
    # 获取用户信息
    if device_b64str:
        user_info = redis_sessions['UserInfo'].get(user.user_id_hex + ':' + device_b64str)
    else:
        user_info = redis_sessions['UserInfo'].get(user.user_id_hex)
    if not user_info:
        return {}
    user_info = json.loads(user_info)
    return user_info


def get_user_token(user: User, device_b64str=None):
    if device_b64str:
        print('device user info')
        user_info = redis_sessions['UserInfo'].get(user.user_id_hex + ':' + device_b64str)
    else:
        user_info = redis_sessions['UserInfo'].get(user.user_id_hex)
    if not user_info:
        return ''
    user_info = json.loads(user_info)
    token = user_info.get('token', '')
    return token


# 仅测试用，添加测试用户Currency
def add_currency(user_id: str):
    import decimal
    coin_type_init = {
        "USD": "10000",
        "BTC": "1",
        "ETH": "10",
        "BCH": "100",
        "LTC": "1000",
    }
    es = EngineService()
    faker = Faker()

    for k, v in coin_type_init.items():
        req_id = faker.uuid4()
        result = es.deposit(
            request_id=req_id,
            coin_type=k,
            amount=decimal.Decimal(v),
            username=user_id,
        )
        logger.info("add currency result:{}".format(result))
