from uuid import UUID

from maneki.apps.user.models import UserProfile, User
from maneki.apps.common.utils import generate_nonce_8bit_digits
from maneki.apps.common.utils.decorator.decorators import retry


class UserProfileService(object):

    def __init__(self):
        self.model = UserProfile
        self.user_model = User

    def filter_record(self, user_id: UUID):
        return self.model.objects.filter(user_id=user_id).first()

    def filter_record_by_bank_code(self, deposit_bank_code: str):
        return self.model.objects.filter(deposit_code=deposit_bank_code).first()

    def create_record(self, user_id: UUID):
        """ 创建 user profile

        :param user_id:
        :return:
        """
        obj = self.model.objects.filter(user_id=user_id).first()
        if not obj:
            obj = self.model.objects.create(user_id=user_id)

        bank_code = self._generate_deposit_bank_code()
        obj.deposit_code = bank_code
        obj.level = 1
        obj.role_id = 0
        obj.save()
        return obj

    @retry(times=10, failed_wait=0, raise_exec=True)
    def _generate_deposit_bank_code(self):
        bank_code = generate_nonce_8bit_digits(8, 'ABCDEFGHIGKLMNPQRSTUVWXYZ123456789')

        obj = self.filter_record_by_bank_code(bank_code)
        if obj:
            raise Exception('deposite code exist')
        return bank_code

    @staticmethod
    def update_role(profile: UserProfile, role_id):
        profile.role_id = role_id
        profile.save()
        return profile

    def profile_info(self, user_id: UUID):
        record = self.filter_record(user_id)
        result = {
            "first_name": record.first_name if record else "",
            "last_name": record.last_name if record else "",
            "role_id": record.role_id if record else "",
            "level": record.level if record else "",
            #
            "bank_deposit_code": record.deposit_code if record else "",
            "trade_double_check_status": record.is_double_check if record else "",
            "kyc_type": record.kyc_type if record else "",
        }
        return result
