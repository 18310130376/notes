from django.db import transaction

from ..models import TimeOTPDevice, TOTPDeviceStatus
from maneki.apps.user.models import User


class TimeOTPDeviceService(object):
    def __init__(self):
        self.model = TimeOTPDevice
        self.user_model = User

    def create_device(self, user: User):
        """创建设备, 先决条件: 检查用户设备不存在

        :param user:
        :return:
        """
        return self.model.objects.create(user_id=user.user_id, confirmed=False)

    def enable_device(self, user: User = None, device: TimeOTPDevice = None):
        """激活设备

        :param user:
        :param device:
        :return:
        """
        return self._update_device_status(user, device, is_confirmed=True)

    def disable_device(self, user: User = None, device: TimeOTPDevice = None):
        """禁用设备

        :param user:
        :param device:
        :return:
        """
        return self._update_device_status(user, device, is_confirmed=False)

    @transaction.atomic
    def _update_device_status(self, user: User = None, device: TimeOTPDevice = None, is_confirmed: bool = False):
        if not device:
            device = self.model.objects.filter(user_id=user.user_id).first()
        if not device:
            return False
        # change status:
        device.status = TOTPDeviceStatus.ACTIVATED if is_confirmed else TOTPDeviceStatus.DELETED
        device.confirmed = is_confirmed
        device.save()

        # sync user profile:
        # 防止循环引用:
        from maneki.apps.user.services import UserService
        user_service = UserService()
        user_service.update_2fa_device_status(device.user_id, is_confirmed)
        return True

    def user_2fa_device_status(self, user: User):
        """用户2FA设备状态

        :param user:
        :return:
        """
        is_exist, is_active = True, True
        device = self.model.objects.filter(user_id=user.user_id).first()
        if not device:
            return None, not is_exist, not is_active

        if not device.confirmed:
            return device, is_exist, not is_active

        return device, is_exist, is_active
