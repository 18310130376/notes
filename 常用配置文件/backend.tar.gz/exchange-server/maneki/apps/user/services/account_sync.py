# -*- coding: utf-8 -*-
import logging
from django.conf import settings
from faker import Faker

from maneki.apps.common.utils.decorator.db import verify_db_connections
from maneki.apps.common.utils.mq.pika import BaseConsumer
from maneki.apps.common.utils.mq.pika import BaseProducer
from maneki.apps.engine.services.engine import EngineService

from ..services.user import UserService, add_currency

logger = logging.getLogger(__name__)

USER_SYNC_ENGINE = settings.RABBITMQ_CONFIG_GROUP["user"]["sync_engine_account"]


# 用户帐号:
class SyncEngineAccountProducer(BaseProducer):
    MQ_CONFIG_GROUPS = USER_SYNC_ENGINE


# 同步创建引擎用户帐号
class SyncEngineAccountConsumer(BaseConsumer):
    MQ_CONFIG_GROUPS = USER_SYNC_ENGINE

    @verify_db_connections
    def do_task(self, payload: dict):
        logger.info("sync engine account task: {}".format(payload))

        es = EngineService()
        result = es.create_account(
            email=payload['email'],
            user_id=payload['user_id'],
            token=payload['engine_token'],
        )
        logger.info("RPC Engine Response: {}".format(result))

        if result['RC'] != 0:
            raise Exception("Engine Sync User Account failed!")

        if settings.TEMP_STAGE_USER_ACCOUNT:
            # TODO: demo test, init user account
            # test create account add currency to account
            add_currency(user_id=payload["user_id"])
        # update:
        us = UserService()
        user = us.filter_record(user_id=payload["user_id"])
        if not user:
            raise Exception("User: {} does not exist.".format(payload["user_id"]))
        us.engine_response_update_status(user=user)
