from __future__ import absolute_import
from __future__ import unicode_literals

from celery.schedules import crontab
from celery.task import periodic_task
from celery.utils.log import get_task_logger
from django.core.cache import caches as DjangoCaches

logger = get_task_logger(__name__)

# TODO :test
def add_user_info_to_engine_proxy():
    user_info_client = DjangoCaches['user_info']
    engine_info_client = DjangoCaches['engine_proxy']

    user_infos = user_info_client.keys("*:*") or set()
    engine_infos = engine_info_client.keys("*:*") or set()

    engine_lack_infos = set(user_infos) - set(engine_infos)
    logger.info("add {} to engine proxy via celery".format(engine_lack_infos))
    for user_uid in engine_lack_infos:
        user_info = user_info_client.get(user_uid)
        result = {
            "user_id": user_info.get('uid', ''),
            "email": user_info.get('email', ''),
            "mobile": user_info.get('mobile', ''),
            "engine_token": user_info.get('engine_token',''),
            "token": user_info.get('auth_token',''),
        }
        engine_info_client.set(user_uid.hex, result, timeout=None)
    return None

# TODO :test
def delete_user_info_from_engine_proxy():
    user_info_client = DjangoCaches['user_info']
    engine_info_client = DjangoCaches['engine_proxy']

    user_infos = user_info_client.keys("*:*") or set()
    engine_infos = engine_info_client.keys("*:*") or set()

    engine_to_delete_infos = set(engine_infos) - set(user_infos)
    logger.info("delete {} from engine proxy via celery".format(engine_to_delete_infos))
    if engine_info_client:
        engine_info_client.delete_many(list(engine_to_delete_infos))
    return None


@periodic_task(run_every=crontab(minute=45, hour='*/12'))
def add_user_info():
    add_user_info_to_engine_proxy()


@periodic_task(run_every=crontab(minute=0, hour='*/12'))
def delete_user_info():
    delete_user_info_from_engine_proxy()
