# cookbook/ingredients/schema.py
import graphene

from graphene_django.types import DjangoObjectType
from graphene_django.converter import convert_django_field, convert_field_to_string
from graphene_django.filter import DjangoFilterConnectionField

from phonenumber_field.modelfields import PhoneNumberField

from maneki.apps.user.models import User


#
# @convert_field_to_string(PhoneNumberField)
# def convert_phonenumberfield(field, registry=None):
#     return graphene.String()
#

class UserType(DjangoObjectType):
    class Meta:
        model = User
        filter_fields = ['user_id', 'email', 'level', 'status']
        exclude_fields = ['mobile']

    # def resolve_mobile(self, info):
    #     return str(self.mobile)


class UserQuery(object):
    users = graphene.List(UserType)

    user = graphene.Field(
        UserType
    )

    # user = graphene.Field(
    #     UserType,
    #     user_id=graphene.UUID(),
    #     email=graphene.String(),
    #     # mobile=graphene.String(),
    # )

    # def resolve_all_categories(self, info, **kwargs):
    #     return User.objects.all()

    # def resolve_all_ingredients(self, info, **kwargs):
    #     # We can easily optimize query count in the resolve method
    #     return UserProfile.objects.all()
    #
    # def resolve_user(self, info, **kwargs):
    #     email = kwargs.get("email")
    #     if email:
    #         return User.objects.filter(email=email).first()
