from graphene import relay
from graphene_django.types import DjangoObjectType
from graphene_django.filter import DjangoFilterConnectionField

from maneki.apps.user.models import UserProfile


class UserProfileType(DjangoObjectType):
    class Meta:
        model = UserProfile
        interfaces = (relay.Node,)
        filter_fields = {
            'user_id': ['exact', 'icontains', 'istartswith'],
            'role_id': ['exact', ],
            'deposit_code': ['exact', ],
            'level': ['exact', ],
        }


class UserProfileQuery(object):
    profiles = DjangoFilterConnectionField(UserProfileType)

    profile = relay.Node.Field(UserProfileType)
