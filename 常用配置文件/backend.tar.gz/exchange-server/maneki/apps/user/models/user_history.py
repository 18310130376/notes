from django.db import models
from django.utils.translation import ugettext_lazy as _

from maneki.apps.common.libs.models import UserBaseModel, UserSoftDeleteModel
from maneki.apps.constants import MODEL_PREFIX

# 前缀:
PREFIX_DB_VERBOSE = "User"
PREFIX_DB_TABLE = MODEL_PREFIX + "user_"


# 登录历史记录:
class UserLoginHistory(UserSoftDeleteModel):
    ip = models.GenericIPAddressField(verbose_name=_("User IP"))
    device = models.CharField(verbose_name=_("User Login Device Info"), default="", max_length=255)

    # 预留字段:
    extra_1 = models.CharField(default="", max_length=255)
    extra_2 = models.CharField(default="", max_length=255)
    extra_3 = models.CharField(default="", max_length=255)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": Login History")
        db_table = PREFIX_DB_TABLE + "history_login"


# 安全修改操作历史记录:
class UserSecurityChangeHistory(UserBaseModel):
    code = models.IntegerField(verbose_name="Security Change Operate code", default=0)
    label = models.CharField(verbose_name=_("Security Change  Operate"), default="", max_length=255)

    # 预留字段:
    extra_1 = models.CharField(default="", max_length=255)
    extra_2 = models.CharField(default="", max_length=255)
    extra_3 = models.CharField(default="", max_length=255)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": Security Change History")
        db_table = PREFIX_DB_TABLE + "history_security_change"
