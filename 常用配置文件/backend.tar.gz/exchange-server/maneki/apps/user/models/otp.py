import uuid
import pyotp
import time

from django.conf import settings
from django.db import models
from django.utils.translation import ugettext_lazy as _
from django.utils.six import string_types
from django_otp.models import Device
from django_otp.oath import TOTP
from urllib import parse as url_parse
from urllib.parse import quote

from maneki.apps.constants import MODEL_PREFIX, TOTPDeviceStatus


def default_key():
    return pyotp.random_base32()


# Time-based One Time Password
class TimeOTPDevice(models.Model):
    # user = None
    # user_id = models.UUIDField(_('user unique id'), default=uuid.uuid4, editable=False, db_index=True)
    #
    key = models.CharField(_('otp key'), max_length=80, default=default_key, unique=True)
    #
    step = models.PositiveSmallIntegerField(default=30, help_text="The time step in seconds.")
    t0 = models.BigIntegerField(default=0, help_text="The Unix time at which to begin counting steps.")
    digits = models.PositiveSmallIntegerField(choices=[(6, 6), (8, 8)], default=6, help_text="The number of digits to expect in a token.")
    tolerance = models.PositiveSmallIntegerField(default=1, help_text="The number of time steps in the past or future to allow.")
    drift = models.SmallIntegerField(default=0, help_text="The number of time steps the prover is known to deviate from our clock.")
    last_t = models.BigIntegerField(default=-1, help_text="The t value of the latest verified token. The next token must be at a higher time step.")
    #
    status = models.IntegerField(_("2fa device verify status"), default=TOTPDeviceStatus.UNDEFINED, choices=TOTPDeviceStatus.choices)

    user_id = models.UUIDField(help_text="The user that this device belongs to.")
    name = models.CharField(max_length=64, help_text="The human-readable name of this device.")
    confirmed = models.BooleanField(default=True, help_text="Is this device ready for use?")

    # 预留字段:
    extra_1 = models.CharField(default="", max_length=255)
    extra_2 = models.CharField(default="", max_length=255)
    extra_3 = models.CharField(default="", max_length=255)

    class Meta(Device.Meta):
        verbose_name = _("Time-based One Time Password device")
        db_table = MODEL_PREFIX + "user_2fa_totp"

    def verify_token(self, token: str):
        OTP_TOTP_SYNC = getattr(settings, 'OTP_TOTP_SYNC', True)

        totp = TOTP(self.key, self.step, self.t0, self.digits, self.drift)
        totp.time = time.time()

        device = pyotp.TOTP(self.key)
        verified = device.verify(token)

        if verified:
            self.last_t = totp.t()
            if OTP_TOTP_SYNC:
                self.drift = totp.drift
            self.save()

        return verified

    @property
    def config_url(self):
        """
        A URL for configuring Google Authenticator or similar.

        See https://github.com/google/google-authenticator/wiki/Key-Uri-Format.
        The issuer is taken from :setting:`OTP_TOTP_ISSUER`, if available.

        """
        label = 'btcc' # self.user.get_username()
        params = {
            'secret': self.key,
            'algorithm': 'SHA1',
            'digits': self.digits,
            'period': self.step,
        }

        issuer = getattr(settings, 'OTP_TOTP_ISSUER', None)
        if isinstance(issuer, string_types) and (issuer != ''):
            issuer = issuer.replace(':', '')
            params['issuer'] = issuer
            label = '{}:{}'.format(issuer, label)

        url = 'otpauth://totp/{}?{}'.format(quote(label), url_parse.urlencode(params))
        return url

