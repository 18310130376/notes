# -*- coding: utf-8 -*-
from django.db import models
from django.utils.translation import ugettext_lazy as _
from django.core.validators import MaxValueValidator, MinValueValidator

from maneki.apps.common.libs.models import UserSoftDeleteModel
from maneki.apps.constants import MODEL_PREFIX, UserKYCType
from maneki.apps.constants import UserVIPLevel

# 前缀:
PREFIX_DB_VERBOSE = "User"
PREFIX_DB_TABLE = MODEL_PREFIX + "user_"


class UserProfile(UserSoftDeleteModel):
    # unique:
    user_id = models.UUIDField(verbose_name=_("User ID"), unique=True, null=False, blank=False, db_index=True)
    #
    nickname = models.CharField(verbose_name=_("Nickname"), max_length=64, default="", null=False, blank=False)
    first_name = models.CharField(verbose_name=_("First Name"), max_length=64, default="", null=False, blank=False)
    last_name = models.CharField(verbose_name=_("Last Name"), max_length=64, default="", null=False, blank=False)
    # role
    role_id = models.IntegerField(verbose_name=_("Role Type"), default=-1, null=True)
    #
    level = models.IntegerField(verbose_name=_("VIP Level"), default=UserVIPLevel.LV0, choices=UserVIPLevel.choices)
    labels = models.CharField(verbose_name=_("User Notes/Labels"), default="", max_length=128, null=True)

    # fiat bank deposit code:
    deposit_code = models.CharField(verbose_name=_("deposit Code"), default="", max_length=15, null=False, unique=True)
    # 交易折扣:
    trade_discount = models.FloatField(verbose_name=_("trade discount: 0.1 ~ 1.0"), validators=[MinValueValidator(0), MaxValueValidator(1.0)], default=1.0)
    # 交易折扣:
    withdraw_discount = models.FloatField(verbose_name=_("withdraw discount: 0.1 ~ 1.0"),
                                          validators=[MinValueValidator(0), MaxValueValidator(1.0)], default=1.0)
    # trade double check:
    is_double_check = models.BooleanField(verbose_name=_("trade double check switch"), default=True)
    # kyc用户类型: 个人/企业
    kyc_type = models.BooleanField(verbose_name=_("User Type (KYC)"), default=UserKYCType.INDIVIDUAL, choices=UserKYCType.choices, null=False, blank=False)

    # 预留字段:
    extra_1 = models.CharField(default="", max_length=255)
    extra_2 = models.CharField(default="", max_length=255)
    extra_3 = models.CharField(default="", max_length=255)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": User Registration Information")
        verbose_name_plural = _(PREFIX_DB_VERBOSE + ": User Registration Information")
        db_table = PREFIX_DB_TABLE + "profile"
