# -*- coding: utf-8 -*-
import uuid
import logging
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils.encoding import python_2_unicode_compatible
from django.utils.translation import ugettext_lazy as _
from phonenumber_field.modelfields import PhoneNumberField

from maneki.apps.common.libs.models import SoftDeleteModel
from maneki.apps.constants import MODEL_PREFIX, UserMigrationStatus
from maneki.apps.constants import UserAccountStatus

logger = logging.getLogger(__name__)

# 前缀:
PREFIX_DB_VERBOSE = "User"
PREFIX_DB_TABLE = MODEL_PREFIX + "user"


@python_2_unicode_compatible
class User(AbstractUser, SoftDeleteModel):
    # First Name and Last Name do not cover name patterns
    # around the globe.
    user_id = models.UUIDField(_('user id'), default=uuid.uuid4, unique=True, editable=False, db_index=True)
    # engine account:
    engine_token = models.CharField(_('engine key'), max_length=64, default="", null=False, blank=False)
    #
    email = models.EmailField(_('email address'), null=True, blank=True, default="", db_index=True)
    mobile = PhoneNumberField(_('mobile phone number'), null=True, blank=True, default="", db_index=True)
    mobile_country_code = models.CharField(_("mobile phone number: country code"), max_length=8, default="")
    # verify attributes
    verify_code = models.CharField(_('verify code'), max_length=512, default="", null=True, blank=True)
    #
    email_verified = models.BooleanField(_("email verify status"), default=False)
    mobile_verified = models.BooleanField(_("mobile phone verify status"), default=False)
    totp_device_verified = models.BooleanField(_("totp(2FA) device status"), default=False)
    # 交易二次确认密码:
    trade_password = models.CharField(_("user trade password"), max_length=128, default="", null=True, blank=True)
    #
    status = models.IntegerField(_("user account status"), default=UserAccountStatus.UNDEFINED, choices=UserAccountStatus.choices)
    is_active = models.BooleanField(_('user active status'), default=False, )
    # 旧leaf迁移用户:
    old_account_id = models.CharField(_("old leaf account"), max_length=64, default="", null=True, blank=True)
    old_account_status = models.IntegerField(_("old migration status"), default=UserMigrationStatus.UNDEFINED, choices=UserMigrationStatus.choices)

    # 预留字段:
    extra_1 = models.CharField(default="", max_length=255)
    extra_2 = models.CharField(default="", max_length=255)
    extra_3 = models.CharField(default="", max_length=255)
    # disable fields:
    first_name = None
    last_name = None

    class Meta(AbstractUser.Meta):
        swappable = 'AUTH_USER_MODEL'
        db_table = PREFIX_DB_TABLE
        app_label = 'user'  # TODO: bugfix: 必须和实际 app folder 名称一致
        ordering = ['date_joined']

    def __str__(self):
        return self.username

    @property
    def account_status(self):
        """账号状态

        :return:
        """
        is_enable = self.is_active
        # 是否是旧 leaf 迁移用户
        is_old = bool(self.old_account_id) and bool(self.old_account_status == UserMigrationStatus.PENDING)
        # 内部员工
        is_staff = self.is_staff
        is_admin = self.is_superuser
        return is_enable, is_old, is_staff, is_admin

    @property
    def user_id_hex(self):
        return self.user_id.hex

    @property
    def engine_account_id(self):
        """与交易引擎通信: account, 兼容旧leaf 迁移用户
        :return:
        """
        engine_account = self.old_account_id if self.old_account_id else self.user_id_hex
        logger.info("engine account id: {}".format(engine_account))
        return engine_account

    @property
    def mobile_str(self):
        return self.mobile.as_e164 if self.mobile else ""

    @property
    def auth_fields(self):
        return {
            "user_id": self.engine_account_id,
            "email": self.email if self.email else "",
            "mobile": self.mobile_str if self.mobile else "",
            "engine_token": self.engine_token,
        }


# 普通用户账号:
class Customer(User):
    class Meta:
        proxy = True
        app_label = 'user'

        verbose_name = _(PREFIX_DB_VERBOSE + ": Customer")
        verbose_name_plural = verbose_name


# 员工账号:
class Staff(User):
    class Meta:
        proxy = True
        app_label = 'user'

        verbose_name = _(PREFIX_DB_VERBOSE + ": Staff")
        verbose_name_plural = verbose_name
