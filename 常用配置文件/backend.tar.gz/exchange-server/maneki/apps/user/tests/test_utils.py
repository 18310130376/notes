import phonenumbers

from ..utils import format_and_parse_mobile_phone_number


def test_m_f():
    mobile_1 = "+49 176 1234 5678"
    mobile_2 = phonenumbers.parse(mobile_1)
    _, m1 = format_and_parse_mobile_phone_number(mobile_1)
    _, m2 = format_and_parse_mobile_phone_number(mobile_2)
    _, m3 = format_and_parse_mobile_phone_number(mobile_1, phonenumbers.PhoneNumberFormat.INTERNATIONAL)
    _, m4 = format_and_parse_mobile_phone_number(mobile_1, phonenumbers.PhoneNumberFormat.RFC3966)

    for item in [m1, m2, m3, m4]:
        print("mobile: {}\t{}".format(type(item), item))

    # phonenumbers.format_number_for_mobile_dialing()
