import pyotp


def test_2fa():
    key = pyotp.random_base32()
    device = pyotp.TOTP(key)
    verify_url = pyotp.totp.TOTP(key).provisioning_uri("a1@qq.com", issuer_name="btcc")

    print(key)
    print(device)
    print(verify_url)
    device.now()

    device.verify(742128)
