# -*- coding: utf-8 -*-
import pytest

from maneki.apps.user.services.account_sync import SyncEngineAccountConsumer, SyncEngineAccountProducer


# engine 创建新用户
# @pytest.mark.django_db
def test_producer_m_usercreate():
    try:
        p = SyncEngineAccountProducer()
        msg = {
            "user_id": '16d1bf6e59da40e2cbe4bec3b02b0acf',
            "token": '69f3dc2192f250cbb9760ad5fb5f1ce90693aa24',
            "account": 'x20',
        }
        p.publish(msg)
    except Exception as e:
        print(e)


# @pytest.mark.timeout(4)
@pytest.mark.django_db
def test_consumer_usercreate():
    c = SyncEngineAccountConsumer()
    c.consume()  # 死循环, 不会退出, 需要外部结束掉测试, 正常验证结果.


# 创建radius需求
def test_producer_usercreate():
    p = SyncEngineAccountConsumer()
    msg = {
        "user_id": 25555,
        "token": "f1d02bce8b9b4e8c5ebe60aa4560c7d4e71bbd90",
        "account": "cv1@123455.com",

    }
    p.publish(msg)
