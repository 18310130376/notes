# -*- coding: utf-8 -*-
import logging
from django.conf import settings

from maneki.apps.common.utils.mq.pika import BaseConsumer
from maneki.apps.common.utils.decorator.db import verify_db_connections
from maneki.apps.constants import CoinSeries
from maneki.apps.constants import ETH_LABEL_GROUP
from maneki.apps.constants import BTC_LABEL_GROUP
from maneki.apps.constants import COIN_SERIES_LABEL

from maneki.apps.transaction.services.crypto.deposit_address import CryptoDepositAddressService

logger = logging.getLogger(__name__)

DEPOSIT_ADDRESS_PREPARE = settings.RABBITMQ_CONFIG_GROUP["deposit_address"]["prepare"]


class CryptoDepositAddressLoader(BaseConsumer):
    MQ_CONFIG_GROUPS = DEPOSIT_ADDRESS_PREPARE

    service = CryptoDepositAddressService()

    @verify_db_connections
    def do_task(self, payload: dict):
        logger.info("Crypto Deposit Address MQ: ".format(payload))

        address_list = payload.get("address", None)
        address_region = payload.get("region", None)
        coin_type = payload.get("coin_type")
        coin_series = CoinSeries.UNDEFINED

        if not address_list or not address_region:
            raise KeyError("Invalid MQ Params: {address, region} not found.")

        if coin_type in ETH_LABEL_GROUP:
            coin_series = CoinSeries.ETH_SERIES
        elif coin_type in BTC_LABEL_GROUP:
            coin_series = COIN_SERIES_LABEL.get(coin_type)

        #
        self.service.load_address(coin_series, address_list, address_region)
