# -*- coding: utf-8 -*-
import logging
from django.conf import settings

from maneki.apps.constants import CoinSeries
from maneki.apps.common.utils.redis.r import redis_client
from maneki.apps.constants import DepositAddressStatus
from maneki.apps.constants import WALLET_HASH_FEILD

from maneki.apps.transaction.models.crypto_currency_address import CryptoDepositAddress, CryptoDepositAddressPool

logger = logging.getLogger(__name__)

# redis url:
REDIS_URL = settings.REDIS_LOCATION_BLOCKCHAIN_PROXY


class CryptoDepositAddressService(object):

    def __init__(self, redis_url=None):
        self.model = CryptoDepositAddress
        self.pool_model = CryptoDepositAddressPool
        #
        self.redis_url = redis_url if redis_url else REDIS_URL
        url, db = self.redis_url.rsplit("/", 1)
        self.cache = redis_client(url, db)

    def load_address(self, coin_series: CoinSeries, address_list: list, address_region: str):
        if not isinstance(address_list, list):
            address_list = list(address_list)

        for address in address_list:
            self.pool_model.objects.create(
                coin_series=coin_series,
                address=address,
                status=DepositAddressStatus.USABLE,
                address_region=address_region,
            )

    def filter_record(self, tx_address: str, status=DepositAddressStatus.ASSIGNED, user_id=None):
        """注意: 充值地址是唯一的.

        :param tx_address: 充值地址全表唯一索引.
        :param status:
        :param user_id:
        :return:
        """
        if user_id:
            return self.model.objects.filter(
                address=tx_address,
                status=status,
                user_id=user_id
            ).first()
        return self.model.objects.filter(
            address=tx_address,
            status=status
        ).first()

    def create_record(self, user_id, tx_address, coin_type):
        obj, _ = self.model.objects.get_or_create(
            user_id=user_id,
            address=tx_address,
            coin_type=coin_type,
            status=DepositAddressStatus.ASSIGNED,

        )
        return obj

    def disable_record(self, user_id: str, address: str):
        """禁用用户个人地址.

        :param user_id:
        :param address:
        :return:
        """
        obj = self.model.objects.filter(
            user_id=user_id,
            address=address,
            is_deleted=False,
        ).first()

        if not obj:
            return False

        obj.status = DepositAddressStatus.DISABLE
        obj.save()
        return True

    def cache_for_blockchain_proxy(self, coin_type, address: str, user_id: str):
        return self.cache.hset(
            coin_type,
            address,
            user_id
        )

    def filter_address(self, user_id, coin_type):
        return self.model.objects.filter(user_id=user_id, coin_type=coin_type,
                                         status=DepositAddressStatus.ASSIGNED).first()

    def get_pool_address(self, coin_series):
        return self.pool_model.objects.filter(coin_series=coin_series,
                                              status=DepositAddressStatus.USABLE).first()

    def set_address_to_redis(self, address: str, coin_type: int, user_id: str):
        self.cache.hset(WALLET_HASH_FEILD.get(coin_type, 'ERROR'), address,
                        '{}'.format(user_id))

    def get_user_address(self, user_id, coin_type: int):
        address = self.model.objects.filter(user_id=user_id, coin_type=coin_type,
                                            status=DepositAddressStatus.ASSIGNED).first()
        # serializer = CoinDepositAddressSerializer(address)

        return address.coin_type, address.address

    def is_user_deposit_address(self, user_id, address):
        return self.model.objects.filter(
            user_id=user_id,
            address=address
        ).exists()
