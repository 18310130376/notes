# -*- coding: utf-8 -*-
import logging

from maneki.apps.transaction.models.crypto_currency import BlockchainTransaction
from maneki.apps.constants import CONFIRM_LIMIT
from maneki.apps.constants import TransactionStatus

logger = logging.getLogger(__name__)


class CryptoTransactionService(object):
    def __init__(self):
        self.model = BlockchainTransaction
        self.limit = CONFIRM_LIMIT
        self.status = TransactionStatus

    def filter_record(self, tx_id: str):
        return self.model.objects.filter(tx_id=tx_id).first()

    def create_record(self, tx_type, tx_id, block_id, coin_type, miner_fee, confirmations=0, status=0):
        obj, _ = self.model.objects.get_or_create(
            tx_id=tx_id,
            block_id=block_id,
            coin_type=coin_type,
            miner_fee=miner_fee,
            confirmations=confirmations,
            status=status,
            tx_type=tx_type,
        )
        return obj

    def update_record(self, tx_record: BlockchainTransaction, confirmations, status):
        logger.info('record:{},{}'.format(tx_record, confirmations))
        tx_record.confirmations = confirmations
        tx_record.status = status
        tx_record.save()

    def create_or_update(self, tx_id, tx_type, block_id, coin_type, miner_fee, confirmations=0):
        """创建 or 更新 block_tx 记录

        :param tx_id:
        :param tx_type:
        :param block_id:
        :param coin_type:
        :param miner_fee:
        :param confirmations:
        :return:
        """
        record = self.filter_record(tx_id)

        if not record:
            record = self.create_record(
                tx_type=tx_type,
                tx_id=tx_id,
                block_id=block_id,
                coin_type=coin_type,
                miner_fee=miner_fee,
                confirmations=confirmations,
                status=self.status.BEFORE_COMPLETED,
            )
            return record
        #
        record.confirmations = confirmations
        if confirmations >= self.limit.get(coin_type):
            record.status = self.status.COMPLETED
        record.save()
        return record
