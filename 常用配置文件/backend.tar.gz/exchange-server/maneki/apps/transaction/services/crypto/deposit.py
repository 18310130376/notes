# -*- coding: utf-8 -*-
import logging
from django.conf import settings
from django.db import transaction

from maneki.apps.common.mixins.rest import ValidationError452
from maneki.apps.constants import DepositStatus, EngineResponseCode
from maneki.apps.engine.services.engine import EngineService
from maneki.apps.transaction.models import CryptoDepositRecordLastThreeMonths as CryptoRecordLTM, BlockchainTransaction
from maneki.apps.transaction.services.crypto.tx import CryptoTransactionService
from maneki.apps.transaction.utils.exceptions import FiatDepositRecordNotFound


logger = logging.getLogger(__name__)
DEPOSIT_WALLET_GROUPS = settings.RABBITMQ_CONFIG_GROUP["deposit"]["wallet"]
DEPOSIT_ENGINE_INBOX = settings.RABBITMQ_CONFIG_GROUP["deposit"]["engine_inbox"]


class CryptoDepositService(object):

    def __init__(self):
        self.model = CryptoRecordLTM
        self.tx_model = BlockchainTransaction
        self.tx_service = CryptoTransactionService()
        self.engine = EngineService()

    def filter_records(self, tx_id):
        qs = self.model.objects.filter(tx_id=tx_id).all()
        return qs

    def filter_record(self, user_id=None, tx_id=None, engine_sn=None):
        if engine_sn:
            return self.model.objects.filter(engine_sn=engine_sn).first()
        return self.model.objects.filter(
            tx_id=tx_id,
            user_id=user_id
        )

    def filter_unfinished_record(self, user_id=None, tx_id=None, engine_sn=None):
        """
        Fix 多个消息到来导致状态更新成功又变为失败的问题
        """
        if engine_sn:
            return self.model.objects.filter(engine_sn=engine_sn).exclude(
                status=0
            ).first()
        return self.model.objects.filter(
            tx_id=tx_id,
            user_id=user_id
        ).exclude(
            status=0
        )

    # @transaction.atomic
    def create_record(self, user_id=None, tx_id=None, coin_type=None, engine_sn=None):
        if engine_sn:
            return self.model.objects.create(user_id=user_id, engine_sn=engine_sn)

        obj, _ = self.model.objects.get_or_create(
            user_id=user_id,
            tx_id=tx_id,
            coin_type=coin_type
        )
        return obj

    @staticmethod
    def update_inner_record(record: CryptoRecordLTM, user_id, tx_id, coin_type, tx_amount, tx_address):
        record.user_id = user_id
        record.tx_id = tx_id
        record.coin_type = coin_type
        record.tx_amount = tx_amount
        record.tx_address = tx_address
        record.save()
        return record

    @staticmethod
    def update_record(record: CryptoRecordLTM, status):
        if record.status == DepositStatus.COMPLETED or record.engine_code == EngineResponseCode.COMPLETED:
            return record
        record.status = status
        record.save()
        return record

    def filter_record_by_date(self, user_id, timestamp_start, timestamp_end):
        return self.model.objects.filter(user_id=user_id,
                                         updated_at__gte=timestamp_start,
                                         updated_at__lte=timestamp_end)

    def update_or_create_record(self, user_id, tx_id, tx_address, coin_type, tx_amount, status, confirmations):
        depositObjs, result = self.model.objects.update_or_create(
            tx_id=tx_id,
            user_id=user_id,
            tx_address=tx_address,
            coin_type=coin_type,
            tx_amount=tx_amount
        )
        depositObjs.status = status
        depositObjs.confirmations = confirmations
        depositObjs.save()
        return depositObjs

    def filter_exception_record(self, timestamp_start, timestamp_end, coin_type=None, status=None):
        queryset = self.model.objects.filter(updated_at__gte=timestamp_start, updated_at__lte=timestamp_end).order_by(
            '-updated_at')
        if coin_type and str(coin_type).isdigit():
            queryset = queryset.filter(coin_type=int(coin_type))
        if status and str(status).isdigit():
            queryset = queryset.filter(status=int(status))
        else:
            queryset = queryset.exclude(status=DepositStatus.COMPLETED)
        return queryset

    def delete_record(self, engine_sn):
        obj = self.model.objects.get(engine_sn=engine_sn)
        if not obj:
            raise FiatDepositRecordNotFound
        obj.soft_delete()

    def search_records(self, address=None, tx_id=None, user_id=None, email=None):
        qs = self.model.objects
        if address:
            qs = qs.filter(tx_address=address)
        if tx_id:
            qs = qs.filter(tx_id=tx_id)
        if user_id:
            qs = qs.filter(user_id=user_id)
        if email:
            from maneki.apps.user.services import UserService
            user_service = UserService()
            user = user_service.filter_record(email=email)
            if user is None:
                raise ValidationError452(detail='this email did not registered.')
            qs = qs.filter(user_id=user.user_id_hex)
        return qs
