# -*- coding: utf-8 -*-
import logging
import json
import uuid

from django.conf import settings
from django.db import transaction

from maneki.apps.common.utils.decorator.db import verify_db_connections
from maneki.apps.common.utils.mq.pika import BaseConsumer
from maneki.apps.common.utils.mq.pika import BaseProducer
from maneki.apps.constants import EngineResponseCode, TransactionType
from maneki.apps.engine.services.engine import EngineService
from maneki.apps.transaction.services.crypto import CryptoWithdrawService, CryptoTransactionService, UserService

logger = logging.getLogger(__name__)
WITHDRAW_ENGINE_INBOX = settings.RABBITMQ_CONFIG_GROUP["withdraw"]["engine_inbox"]
WITHDRAW_WALLET_INBOX = settings.RABBITMQ_CONFIG_GROUP["withdraw"]["wallet_submit"]
WITHDRAW_WALLET_RESPONSE = settings.RABBITMQ_CONFIG_GROUP["withdraw"]["wallet_completed"]


###########################################################################
#                 Producer
###########################################################################


class WithdrawRequestToEngineProducer(BaseProducer):
    """生产者: 创建 task 发给 engine RPC 调用

    """
    MQ_CONFIG_GROUPS = WITHDRAW_ENGINE_INBOX


class WithdrawRequestToBlockchainProxyProducer(BaseProducer):
    """生产者: 创建 task 给 blockchain-proxy 打币出去

    """
    MQ_CONFIG_GROUPS = WITHDRAW_WALLET_INBOX


###########################################################################
#                 Consumer
###########################################################################


class WithdrawResponseFromEngineConsumer(BaseConsumer):
    """消费者: 交易引擎 engine RPC 处理返回结果

    - engine response:
        - ok: update db, publish task to blockchain proxy.
        - error: update db, raise exception.

    """
    MQ_CONFIG_GROUPS = WITHDRAW_ENGINE_INBOX

    @verify_db_connections
    def do_task(self, payload: dict):
        logger.info("Engine RPC Request: {}".format(payload))
        # engine:
        rpc = EngineService()
        service = CryptoWithdrawService()
        request_no = payload.get("request_no")
        user_id = payload.get("username")
        fee = payload.get("fee")

        s = UserService()
        engine_account_id = s.user_engine_account_id(user_id)
        # todo UDST
        if payload.get('coin_type') == 'USDT':
            result = rpc.withdraw_usdt_with_fee(request_id=request_no,
                                                coin_type='USD',
                                                amount=payload.get('amount'),
                                                username=engine_account_id,
                                                fee=fee)
        else:
            result = rpc.withdraw_with_fee(
                request_id=request_no,
                coin_type=payload.get("coin_type"),
                amount=payload.get("amount"),
                username=engine_account_id,
                fee=fee
            )

        code = result.get("RC", -100)

        if code == 2015:
            s = UserService()
            engine_account_id = s.user_engine_account_id(user_id)
            request_no = uuid.uuid4().hex
            # todo USDT
            if payload.get('coin_type') == 'USDT':
                result = rpc.withdraw_usdt_with_fee(request_id=request_no,
                                                    coin_type='USD',
                                                    amount=payload.get('amount'),
                                                    username=engine_account_id,
                                                    fee=fee)
            else:
                result = rpc.withdraw_with_fee(
                    request_id=request_no,
                    coin_type=payload.get("coin_type"),
                    amount=payload.get("amount"),
                    username=engine_account_id,
                    fee=fee
                )
            code = result.get("RC", -100)
        logger.error("Engine RPC Response: {}".format(result))
        if code != 0:

            # update code:
            service.engine_response_update(
                engine_sn=payload.get('sn'),
                engine_code=code,
                status=service.status.ENGINE_FAILED,
            )
            raise Exception("Engine RPC Withdraw Failed.")

        #######################################
        # ok:
        record = service.engine_response_update(
            engine_sn=payload.get('sn'),
            engine_code=code,
            status=service.status.ENGINE_COMPLETED,
        )

        # ok:
        p = WithdrawRequestToBlockchainProxyProducer()
        task = service.withdraw_blockchain_proxy_task(record)
        p.publish(task)


class WithdrawResponseFromBlockchainProxyConsumer(BaseConsumer):
    """消费者: bockchain-proxy 打币异常记录更新

    """
    MQ_CONFIG_GROUPS = WITHDRAW_WALLET_RESPONSE

    @verify_db_connections
    # @transaction.atomic
    def do_task(self, payload: dict):
        logger.info("Blockchain Proxy Report: {}".format(payload))

        service = CryptoWithdrawService()

        records = payload.get("txs", [])
        tx_id = payload.get("tx_id", "")
        block_id = payload.get("block_id", "")
        miner_fee = payload.get("miner_fee", 0)

        confirmations = int(payload.get("confirmations", 0))

        for r in records:
            if not isinstance(r, dict):
                r = json.loads(r)
            service.blockchain_proxy_response_update(
                tx_id=tx_id,
                engine_sn=r.get("sn"),
                address=r.get("address", "") or r.get("target_address", ""),
                confirmations=confirmations,
            )

        ##################################
        # block_tx db:
        # todo: update record
        r = records[0]
        coin_type = r.get("coin_type", -1)
        tx_service = CryptoTransactionService()
        # todo withdraw tx_id: tx_type + ':' + tx_id
        withdraw_tx_id = str(TransactionType.WITHDRAW) + ':' + tx_id
        tx_service.create_or_update(
            tx_id=withdraw_tx_id,
            tx_type=TransactionType.WITHDRAW,
            block_id=block_id,
            coin_type=coin_type,
            miner_fee=miner_fee,
            confirmations=confirmations,
        )
