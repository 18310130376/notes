import logging
from uuid import UUID

from maneki.apps.transaction.models import CryptoWithdrawAddress, WithdrawAddressStatus
from maneki.apps.transaction.services.crypto.deposit_address import CryptoDepositAddressService

logger = logging.getLogger(__name__)


class CryptoWithdrawAddressService(object):

    def __init__(self):
        self.model = CryptoWithdrawAddress
        self.status = WithdrawAddressStatus
        self.deposit_address_service = CryptoDepositAddressService()

    @property
    def default_response_result(self):
        result = {
            "status": True,
            "code": 200,
            "detail": "ok"
        }
        return result

    def address_exist(self, user_id: UUID, coin_type: int, address: str):
        return self.model.objects.filter(
            user_id=user_id,
            coin_type=coin_type,
            address=address,
            status=self.status.NORMAL,
            is_deleted=False
        ).exists()

    def address_status(self, user_id: UUID, coin_type: int, address: str):
        """根据币种, 判断地址状态

        :param user_id:
        :param address:
        :param coin_type:
        :return: [record, user_id, 存在?, 激活?]
        """

        is_exist = False
        is_enable = False
        logger.info("withdraw address filter: user={}, coin={}, address={}".format(user_id, coin_type, address))

        record = self.model.objects.filter(
            user_id=user_id,
            address=address,
            coin_type=coin_type,
        ).first()
        # 不存在:
        if not record:
            return record, is_exist, is_enable

        logger.info("withdraw address status: user={}, coin={}, address={}, status={}".format(
            record.user_id,
            record.coin_type,
            record.address,
            record.status,
        ))

        # 存在:
        is_exist = True
        is_enable = bool(record.status == self.status.NORMAL)
        return record, is_exist, is_enable

    def check_user_deposit_address(self, user_id, address):
        """检查添加地址, 是否是同一用户的充值地址

        :param user_id:
        :param address:
        :return:
        """
        record = self.deposit_address_service.filter_record(
            tx_address=address,
            user_id=user_id
        )
        return record

    def add_address(self, user_id: UUID, address: str, coin_type: int, label: str):
        """用户添加提现地址, 允许同一个地址, 被不同用户添加

        :param user_id:
        :param address:
        :param coin_type:
        :param label:
        :return:
        """
        # TODO: user_id , hex vs str, 小心 相等匹配
        if not isinstance(user_id, UUID):
            user_id = UUID(user_id)

        logger.info("input params: user_id={}, address={}, coin_type={}, label={}".format(
            user_id, address,
            coin_type, label,
        ))

        record, is_exist, is_enable = self.address_status(user_id=user_id, address=address, coin_type=coin_type)

        # 不存在 或 user_id 不相同
        if not is_exist or record.user_id != user_id:
            logger.info("create withdraw address: user={}, is_exist={}, is_enable={}".format(
                user_id,
                is_exist,
                is_enable,
            ))
            record = self.model.objects.create(
                user_id=user_id,
                address=address,
                status=self.status.NORMAL,
                label=label,
                coin_type=coin_type,
            )
            return record

        logger.info("address is exist, update status or do nothing.")

        ###############################
        # 更新状态:
        if record.status != self.status.NORMAL:
            # 存在: 且 user_id 相同:
            record.status = self.status.NORMAL
            record.is_deleted = False
            record.label = label
            record.save()
        return record

    def disable_address(self, user_id: UUID, address: str, coin_type: int):
        """禁用地址

        :param user_id:
        :param address:
        :param coin_type:
        :return:
        """
        result = self.default_response_result
        record, is_exist, is_enable = self.address_status(user_id=user_id, address=address, coin_type=coin_type)

        # 记录不存在
        if not is_exist:
            result.update(
                status=False,
                code=451,
                detail="invalid address."
            )
            return result

        # 用户ID 不匹配
        if record.user_id != user_id:
            result.update(
                status=False,
                code=452,
                detail="user is not address owner."
            )
            return result

        # disable:
        record.status = self.status.DISABLE
        record.save()
        return result

    def check_inner_address_type_match(self, coin_type: int, address: str):

        address_record = self.deposit_address_service.filter_record(tx_address=address)
        if not address_record:
            return False, None, False
        print(f'{coin_type},{address_record.coin_type}')
        return True, address_record, bool(int(address_record.coin_type) == int(coin_type))
