# -*- coding: utf-8 -*-
import logging
import json
from django.conf import settings
from django.db import transaction

from maneki.apps.transaction.services.crypto.deposit import CryptoDepositService
from maneki.apps.transaction.services.crypto.deposit_address import CryptoDepositAddressService
from maneki.apps.transaction.services.crypto.tx import CryptoTransactionService
from maneki.apps.constants import ETH_GROUP
from maneki.apps.constants import CoinType
from maneki.apps.constants import COIN_SERIES
from maneki.apps.constants import DepositAddressStatus
from maneki.apps.constants import CONFIRM_LIMIT
from maneki.apps.constants import TransactionStatus
from maneki.apps.constants import DepositStatus
from maneki.apps.constants import TransactionType
from maneki.apps.transaction.views.serializers import CryptoCurrencyDepositEngineSerializer
from maneki.apps.common.utils.compare import compare_intersect
from maneki.apps.transaction.models import CryptoDepositAddress

logger = logging.getLogger(__name__)
DEPOSIT_WALLET_GROUPS = settings.RABBITMQ_CONFIG_GROUP["deposit"]["wallet"]
DEPOSIT_ENGINE_INBOX = settings.RABBITMQ_CONFIG_GROUP["deposit"]["engine_inbox"]


# TODO: not completed.
class CryptoDepositManager(object):
    """加密货币 充值服务

    """

    def __init__(self):
        self.address_service = CryptoDepositAddressService()
        self.deposit_service = CryptoDepositService()
        self.tx_service = CryptoTransactionService()

    @transaction.atomic
    def distribute_address(self, user_id, coin_type: int):
        """分配coin_type类型的地址

        :param user_id:
        :param coin_type:
        :return:
        """
        # 判断该用户是够否存在该类型地址
        address = self.address_service.filter_address(user_id=user_id, coin_type=coin_type)
        if address:
            return address
        # 不存在分配地址
        if coin_type in ETH_GROUP:
            coin_type = CoinType.ETH
        coin_series = COIN_SERIES.get(coin_type)
        one = self.address_service.get_pool_address(coin_series=coin_series)
        if not one:
            # Todo: warning address for coin_type run out
            logger.warning('address for coin_type {} run out'.format(coin_type))
            return None
        address = self.address_service.create_record(
            user_id=user_id,
            coin_type=coin_series,
            tx_address=one.address
        )
        if not address:
            return None
        one.status = DepositAddressStatus.ASSIGNED
        one.save()
        # 写redis
        self.address_service.set_address_to_redis(
            address=address.address,
            coin_type=coin_series,
            user_id=user_id
        )
        return address
