# -*- coding: utf-8 -*-
import logging
from django.conf import settings

from maneki.apps.common.utils.decorator.db import verify_db_connections
from maneki.apps.common.utils.mq.pika import BaseConsumer
from maneki.apps.constants import TransactionStatus, DepositStatus
from maneki.apps.transaction.services.crypto import CryptoDepositAddressService, CryptoTransactionService
from maneki.apps.transaction.services.crypto.deposit import CryptoDepositService
from maneki.apps.transaction.services.crypto.deposit_engine_handler import DepositEngineRequestProducer
from maneki.apps.transaction.services.crypto.deposit_manager import CryptoDepositManager
from maneki.apps.constants import CONFIRM_LIMIT
from maneki.apps.constants import TransactionType

logger = logging.getLogger(__name__)
DEPOSIT_WALLET_GROUPS = settings.RABBITMQ_CONFIG_GROUP["deposit"]["wallet"]
DEPOSIT_ENGINE_INBOX = settings.RABBITMQ_CONFIG_GROUP["deposit"]["engine_inbox"]


###########################################################################
#                 Consumer
###########################################################################


class DepositReportBlockAnalyzer(BaseConsumer):
    """analyze chain report block:

        - block info: [tx_id, tx_address, tx_fee]

    """
    MQ_CONFIG_GROUPS = DEPOSIT_WALLET_GROUPS

    manager = CryptoDepositManager()

    @verify_db_connections
    def do_task(self, payload: dict):
        # todo: 1. 分析 mq task, btc_block 是一组交易集合. eth_task, 是单条交易.
        # todo: 2. write record: [block_tx_record, deposit_record]
        # todo: 3. update record: [block_tx_record, deposit_record]
        # todo: 4. check deposit status: [ok, produce engine_rpc_task; pending: do nothing]
        logger.info("deposit block report: {}".format(payload))
        service = BlockAnalyzeService()
        service.analyze_block(block=payload)


class BlockAnalyzeService(object):
    """

================
# 充值处理:

b'{

        "coin_type": 2,
        "tx_id": "0xc19f3846d274e4c10de165edffbc681b476d6b1e0afdf0b71903b3796e559686",
        "confirmations": 80,
        "status": 1,
        "update_time": "2018-06-10T15:41:15.000000+0000",
        "block_id": "0xd9d18b641238b15c5e85c1ada4e6c09ea7b16b553d7fc45e95252f165781e09c",
        "txs": [
            {
                "target_address": "0x54d9aaa609b0dc72c3c1e9121fbc6d81d9aaaeb8",
                "coin_value": "0.02",
                "region": "ETH btcc migration 2018-06-08",
                "index": 8
            }
        ],

        "nonce": "IaovyYJ1",
        "timestamp": 1528645275028,
        "sign": "4022300bb13beed04796459c5c1eb2e6713593204a44de515548c714422d04c3"

        }'



================
# 提现处理:


b'{
    "coin_type": 0,
    "tx_id": "2418834450d11dcfcafb0559a74b1170e1294bf8c8e7b787c93912e20c8f8ad1",
    "confirmations": 4,
    "status": 0, "update_time": "2018-06-11 02:31:04",
    "block_id": "00000000000000000034ee971fdcf0d195daabc0c718f89a4d1aeacba25a8b09",
    "tx_fee": "0.0000182",
    "txs": [
        {
        "coin_type": 0,
        "sn": "6008639794314c39abaf1639573d49be",
        "target_address": "3BG7ZtbM4C2ELaCiSMeth6xop1sdsJk6Ay",
        "amount": "0.01000000000000000000"
        }],

    "nonce": "4faDXUhm",
    "timestamp": 1528684264181,
    "sign": "5ec72fa7a93366c7c1b1beef0b99ad4bb9ff6be1c1105c57af4fc4f50cfd33e3"}'



    """

    def __init__(self):
        self.address_service = CryptoDepositAddressService()
        self.tx_service = CryptoTransactionService()
        self.deposit_service = CryptoDepositService()
        self.confirm_limit = CONFIRM_LIMIT
        pass

    @staticmethod
    def check_tx_status(block: dict):
        """tx 交易有可能失败

        :param block:
        :return:
        """
        status = block.get("status", -1)
        is_ok = bool(status != -1)
        return is_ok

    def check_tx_confirmations(self, confirmations: int, coin_type: int):
        """确认数

        :param confirmations:
        :param coin_type:
        :return:
        """
        limit = self.confirm_limit.get(coin_type, None)
        is_completed = bool(confirmations >= limit)
        return is_completed

    def is_block_tx_record_exist(self, tx_id):
        tx_record = self.tx_service.filter_record(tx_id=tx_id)
        return bool(tx_record), tx_record

    def analyze_block(self, block: dict):
        tx_confirmations = block.get("confirmations")
        coin_type = block.get("coin_type")
        txs = block.get("txs", [])

        # ok:
        is_exist, tx_record = self.is_block_tx_record_exist(tx_id=block.get("tx_id"))

        if not is_exist:
            logger.info("create tx_record + deposit_record")

            self.create_deposit_records(block=block)

        is_completed = self.check_tx_confirmations(confirmations=tx_confirmations, coin_type=coin_type)
        is_ok = self.check_tx_status(block=block)

        # update:
        logger.info('update_deposit_status, is_confirm_completed:{} block_tx_is_ok:{}'.format(is_completed, is_ok))
        self.update_deposit_records(block=block, is_completed=is_completed, is_ok=is_ok)
        # ok:
        # todo: update status(tx+deposit)
        # todo: publish tasks: for() call rpc

    def filter_tx_address_record(self, block_tx: dict):
        tx_address = block_tx.get("target_address", None) or block_tx.get("address", None)
        address_record = self.address_service.filter_record(tx_address=tx_address)
        if address_record:
            return address_record, address_record.user_id, tx_address
        return None, None, tx_address

    def create_deposit_records(self, block: dict):
        tx_id = block.get('tx_id')
        coin_type = block.get("coin_type")
        confirmations = block.get('confirmations')

        # tx record:
        self.tx_service.create_record(
            tx_type=TransactionType.DEPOSIT,
            tx_id=tx_id,
            block_id=block.get('block_id'),
            coin_type=coin_type,
            confirmations=confirmations,
            miner_fee=block.get('tx_fee', 0),
            status=TransactionStatus.PENDING,
        )
        # deposit_record:

        txs = block.get("txs", [])
        if not txs:
            logger.error("deposit error: invalid txs".format(block))
            return False

        # deposit records:
        for tx in txs:
            address_record, user_id, tx_address = self.filter_tx_address_record(block_tx=tx)
            if user_id:
                self.deposit_service.update_or_create_record(
                    user_id=user_id,
                    tx_id=tx_id,
                    tx_address=tx_address,
                    coin_type=coin_type,
                    tx_amount=tx.get("coin_value"),
                    status=DepositStatus.CHAIN_PENDING,
                    confirmations=confirmations,
                )
            else:
                logger.error('block_deposit_msg:{} | Not found user of target tx_address:{}'.format(tx, tx_address))
        return True

    def update_deposit_records(self, block: dict, is_completed, is_ok):
        tx_id = block.get('tx_id')
        coin_type = block.get("coin_type")
        confirmations = block.get('confirmations')
        txs = block.get("txs", [])

        tx_status = TransactionStatus.PENDING
        deposit_status = DepositStatus.CHAIN_PENDING

        if is_completed:
            tx_status = TransactionStatus.COMPLETED
            deposit_status = DepositStatus.CHAIN_COMPLETED

        if not is_ok:
            tx_status = TransactionStatus.FAILED
            deposit_status = DepositStatus.FAILED

        # tx_record:
        tx_record = self.tx_service.filter_record(tx_id=tx_id)

        #########################################################
        # TODO: 这段检查要小心! 保证 publish engine_task 只执行一次
        #########################################################
        if not tx_record:
            logger.warning('tx_record_blockchain not fount tx_id:{}'.format(tx_id))
            return False

        if tx_record.status == TransactionStatus.COMPLETED:
            # TODO: 防止 重复 publish engine_task
            # TODO: 潜在bug, 如果有一笔 提现和充值, 混在一个 block里,判断条件有bug.
            logger.warning('the block tx is already finish:{}'.format(tx_record.__dict__))
            return False
        #########################################################
        #   end check
        #########################################################

        self.tx_service.update_record(
            tx_record=tx_record,
            confirmations=confirmations,
            status=tx_status
        )

        # deposit_records:
        for tx in txs:
            address_record, user_id, tx_address = self.filter_tx_address_record(block_tx=tx)
            if user_id:
                self.deposit_service.update_or_create_record(
                    user_id=user_id,
                    tx_id=tx_id,
                    tx_address=tx_address,
                    coin_type=coin_type,
                    tx_amount=tx.get("coin_value"),
                    status=deposit_status,
                    confirmations=confirmations,
                )

        #########################################################
        # TODO: 保证 publish engine_task 只执行一次
        #########################################################

        if tx_record.status == TransactionStatus.COMPLETED:
            # publish
            self.publish_engine_deposit_request(tx_id=tx_id)

        return True

    def publish_engine_deposit_request(self, tx_id):
        """批量广播 engine task

        :param tx_id:
        :return:
        """
        qs = self.deposit_service.filter_records(tx_id=tx_id)
        if not qs:
            logger.warning("invalid deposit tx_id: {}".format(tx_id))
            return False

        # batch publish tasks:
        for obj in qs:
            task = {
                "tx_amount": obj.tx_amount_fmt,
                "engine_sn": obj.engine_sn_id,
                "engine_request_no": obj.engine_request_no_id,
                "user_id": obj.engine_account_id,
                "coin_type": obj.coin_type,
            }
            p = DepositEngineRequestProducer()
            p.publish(task)
            logger.warning("batch engine-deposit-task: {}".format(task))

        return True
