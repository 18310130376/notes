# -*- coding: utf-8 -*-
import logging
import uuid

from django.conf import settings
from django.core.exceptions import ObjectDoesNotExist
from django.db import transaction

from maneki.apps.common.utils.decorator.db import verify_db_connections
from maneki.apps.common.utils.mq.pika import BaseConsumer
from maneki.apps.common.utils.mq.pika import BaseProducer
from maneki.apps.constants import TransactionStatus, CoinType, EngineResponseCode, DepositStatus
from maneki.apps.engine.services.engine import EngineService
from maneki.apps.transaction.services.crypto.deposit import CryptoDepositService
from maneki.apps.common.utils.decorator.db import verify_db_connections


logger = logging.getLogger(__name__)
DEPOSIT_WALLET_GROUPS = settings.RABBITMQ_CONFIG_GROUP["deposit"]["wallet"]
DEPOSIT_ENGINE_INBOX = settings.RABBITMQ_CONFIG_GROUP["deposit"]["engine_inbox"]


###########################################################################
#                 Producer
###########################################################################


class DepositEngineRequestProducer(BaseProducer):
    """crypto deposit - produce engine request task

        - 入队: 单条 充值请求

    """
    MQ_CONFIG_GROUPS = DEPOSIT_ENGINE_INBOX


class DepositEngineRequestConsumer(BaseConsumer):
    """crypto deposit - consume engine request task

        - 消费待充值的 task
    """
    MQ_CONFIG_GROUPS = DEPOSIT_ENGINE_INBOX

    @verify_db_connections
    # @transaction.atomic
    def do_task(self, payload: dict):
        # todo: 1. 解析 task
        # todo: 2. 发起 充值 rpc (处理 leaf old account)
        # todo: 3. rpc_result: ok, 更新 db 记录状态. error, dead queue.(rpc_重试机制)
        logger.info('Deposit_call_engine:{}'.format(payload))
        coin_name_str = CoinType.get_choice(payload.get('coin_type')).label
        engine_request_no = payload.get('engine_request_no')
        tx_amount = payload.get('tx_amount', 0)
        username = payload.get('user_id')
        engine_sn = payload.get('engine_sn')

        result = self.call_rpc_engine(engine_request_no, coin_name_str, tx_amount, username)

        if result.get('RC') == 0:
            self.update_db(engine_sn, response_code=EngineResponseCode.COMPLETED)
        else:
            error_code = result.get('RC', 99)
            self.update_db(engine_sn, error_code)
            logger.error('engine_rpc_fail Code:{}'.format(result.get('Reason', None)))

    @staticmethod
    def call_rpc_engine(request_id, coin_type, amount, username):
        engine_service = EngineService()
        # todo USDT
        if coin_type == 'USDT':
            result = engine_service.deposit_usdt(request_id=request_id,
                                                 amount=amount,
                                                 username=username,
                                                 coin_type='USD')
        else:
            result = engine_service.deposit(
                request_id=request_id,
                coin_type=coin_type,
                amount=amount,
                username=username
            )
        logger.info('engine rpc response:{}'.format(result))

        return result

    @staticmethod
    def update_db(engine_sn, response_code=None):
        deposit_service = CryptoDepositService()
        deposit_record = deposit_service.filter_unfinished_record(engine_sn=engine_sn)
        if not deposit_record:
            logger.error('crypto deposit.engine_rpc_consumer| Not find record in deposit record db|engine_sn:{}'.format(engine_sn))
            return
            # raise ObjectDoesNotExist
        if response_code == EngineResponseCode.COMPLETED:
            deposit_record.status = DepositStatus.COMPLETED
        else:
            deposit_record.status = DepositStatus.ENGINE_FAILED
        deposit_record.engine_code = response_code
        deposit_record.save()
