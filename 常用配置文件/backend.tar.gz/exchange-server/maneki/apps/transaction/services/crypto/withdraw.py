# -*- coding: utf-8 -*-
import datetime
import logging
import uuid
from decimal import Decimal
from django.conf import settings
from django.db import transaction
from django.utils import timezone

from maneki.apps.common.utils.validates_common import validate_timestamp_start, validate_timestamp_end, validate_limit, \
    validate_offset, validate_email, validate_user_id
from maneki.apps.engine.services.engine import EngineService
from maneki.apps.error_code import ErrorsCommon, Errors1
from maneki.apps.transaction.services.crypto.deposit import CryptoDepositService
from maneki.apps.transaction.services.crypto.withdraw_address import CryptoWithdrawAddressService
from maneki.apps.transaction.utils.verify_code import send_verify_email
from maneki.apps.user.services import UserService, User
from maneki.apps.transaction.models import CryptoWithdrawRecordLastThreeMonths, BlockchainTransaction, \
    CryptoDepositRecordLastThreeMonths, CryptoDepositAddress
from maneki.apps.transaction.services.crypto.tx import CryptoTransactionService
from maneki.apps.constants import WithdrawStatus, CoinType, CONFIRM_LIMIT, WITHDRAW_FEE_RATE, \
    WITHDRAW_MIN_LIMIT, WITHDRAW_MAX_LIMIT, DepositStatus, VerifyType, EngineResponseCode, DatetimeOrderBy, FreezeType
from maneki.taskapp.messagequeue import tasks
from maneki.apps.common.utils.dingbot import async_send_ding_msg
from maneki.apps.common.utils.redis.r import redis_sessions

logger = logging.getLogger(__name__)
DEPOSIT_WALLET_GROUPS = settings.RABBITMQ_CONFIG_GROUP["deposit"]["wallet"]
DEPOSIT_ENGINE_INBOX = settings.RABBITMQ_CONFIG_GROUP["deposit"]["engine_inbox"]


class CryptoWithdrawService(object):

    def __init__(self):
        self.model = CryptoWithdrawRecordLastThreeMonths
        self.tx_model = BlockchainTransaction
        self.deposit_model = CryptoDepositRecordLastThreeMonths
        self.deposit_address_model = CryptoDepositAddress
        #
        self.tx_service = CryptoTransactionService()
        self.engine = EngineService()
        self.user_service = UserService()
        #
        self.coin_type = CoinType
        #
        self.max_limit = WITHDRAW_MAX_LIMIT
        self.min_limit = WITHDRAW_MIN_LIMIT
        #
        self.fee_rate = WITHDRAW_FEE_RATE
        #
        self.status = WithdrawStatus
        self.confirm_limit = CONFIRM_LIMIT
        #
        self.address_service = CryptoWithdrawAddressService()
        self.deposit_service = CryptoDepositService()
        # Todo add to settings
        self.ding_token = 'c317f99f4ee8943e577e1f422dc6d08db84e0599a613cbc8e36ffa788977b91b'
        #
        self.redis_sessions = redis_sessions

    def create_withdraw_request(self, user_id, coin_type, tx_address, tx_amount, freeze_request_no=None,
                                freeze_status=FreezeType.UNFREEZE):
        """用户发起提现请求

        :param user_id:
        :param coin_type:
        :param tx_address:
        :param tx_amount:
        :param freeze_request_no:
        :param freeze_status:
        :return:
        """

        # 提现限额检查:
        min_check, max_check, all_check = self.validate_withdraw_limit(
            coin_type=coin_type,
            amount=tx_amount,
        )

        # 提现限额:
        if not settings.TEST_CRYPTO_WITHDRAW_DEBUG and not min_check:
            return False, 450, "withdraw amount must be greater than min limit."

        # 用户是否有此地址:
        if not self.address_exist(user_id, coin_type, tx_address):
            return False, 451, "user doesn't have this withdraw address."

        # todo: check_exist_pending_withdraw()
        is_exist = self.check_pending_withdraw(user_id=user_id, coin_type=coin_type)
        if is_exist:
            return False, 452, "pending withdraw record is exist, not allow new withdraw request."

        # tx fee:
        tx_fee = self.validate_tx_fee(coin_type)
        # if settings.TEST_CRYPTO_WITHDRAW_DEBUG:
        #     tx_fee = 0

        obj = self.create_record(
            user_id=user_id,
            coin_type=coin_type,
            tx_address=tx_address,
            tx_amount=tx_amount,
            tx_fee=tx_fee,
            freeze_request_no=freeze_request_no,
            freeze_status=freeze_status,

        )
        return True, 200, obj

    def check_pending_withdraw(self, user_id, coin_type):
        """检查是否存在未处理完的提现申请

        :param user_id:
        :param coin_type:
        :return:
        """
        r_count = self.model.objects.filter(
            user_id=user_id,
            # coin_type=coin_type,
            status__gt=WithdrawStatus.COMPLETED
        ).count()
        return bool(r_count)

    def address_exist(self, user_id, coin_type, address):
        return self.address_service.address_exist(user_id, coin_type, address)

    def is_inner_withdraw(self, record: CryptoWithdrawRecordLastThreeMonths):
        deposit_address_record = self.deposit_address_model.objects.filter(
            address=record.tx_address
        ).first()

        if not deposit_address_record:
            detail = 'this is not a inner address'
            logger.warning('this is not a inner address')
            return False, 452, detail

        if record.coin_type != deposit_address_record.coin_type:
            record.status = WithdrawStatus.VALIDATE_FAILED
            record.save()
            detail = f'inner address type not match withdraw: {record.coin_type}, deposit: {deposit_address_record.coin_type}'
            logger.warning(detail)
            return False, 4500, detail
        logger.warning("InnerWithdraw: target_address(deposit_address)={}".format(record.tx_address))
        return True, 200, ''

    def validate_tx_fee(self, coin_type: int):
        """根据币种, 获取手续费, 转成 decimal 类型

        :param coin_type:
        :return:
        """
        fee = self.fee_rate.get(coin_type)
        fee = Decimal(fee)
        print("tx_fee:", type(fee), fee)
        return fee

    @staticmethod
    def withdraw_engine_task(record: CryptoWithdrawRecordLastThreeMonths):
        """Engine RPC task

        :param record:
        :return:
        """
        user = User.objects.filter(user_id=record.user_id).first()
        result = {
            "request_no": record.engine_request_no.hex,
            "sn": record.engine_sn.hex,
            "coin_type": CoinType.get_choice(record.coin_type).label,
            "amount": str(record.tx_amount + record.tx_fee),
            "username": user.engine_account_id,
        }
        return result

    @staticmethod
    def withdraw_engine_task_with_fee(record: CryptoWithdrawRecordLastThreeMonths):
        """Engine RPC task

        :param record:
        :return:
        """
        user = User.objects.filter(user_id=record.user_id).first()
        result = {
            "request_no": record.engine_request_no.hex,
            "sn": record.engine_sn.hex,
            "coin_type": CoinType.get_choice(record.coin_type).label,
            "amount": str(record.tx_amount),
            "username": user.engine_account_id,
            "fee": str(record.tx_fee),
        }
        return result

    @staticmethod
    def withdraw_blockchain_proxy_task(record: CryptoWithdrawRecordLastThreeMonths):
        """打币节点 task

        :param record:
        :return:
        """
        task = {
            "coin_type": record.coin_type,
            "sn": record.engine_sn.hex,
            "target_address": record.tx_address,
            "amount": str(record.tx_amount),
        }
        return task

    def validate_manual_check_status(self, status):
        """客服允许录入的状态值

        :param status:
        :return:
        """
        allow_status = [
            self.status.REVIEW_FAILED,
            self.status.REVIEW_COMPLETED,
        ]
        return status in allow_status

    def validate_withdraw_limit(self, coin_type, amount):
        """提现限额校验

        :param coin_type: 币种
        :param amount: 提现金额
        :return: True/False
        """
        max_limit = self.max_limit.get(coin_type)
        min_limit = self.min_limit.get(coin_type)

        logger.info("coin_type={}, max={}, min={}, amount={}".format(coin_type, max_limit, min_limit, amount))
        if isinstance(amount, Decimal):
            max_limit = Decimal(str(max_limit))
            min_limit = Decimal(str(min_limit))

        return min_limit <= amount, amount <= max_limit, min_limit <= amount <= max_limit

    def update_record_status(self,
                             record: CryptoWithdrawRecordLastThreeMonths = None,
                             engine_sn: str = None,
                             status: bool = WithdrawStatus.UNDEFINED):
        """更新记录状态

        :param record: 记录
        :param engine_sn: 流水号
        :param status: 更新状态值
        :return:
        """
        if not any([record, engine_sn]):
            return None
        record = self.filter_record(engine_sn=engine_sn).first() if not record else record
        if not record:
            return None
        record.status = status
        return record.save()

    def user_verify_device_status(self, user: User):
        """2fa 设备状态

        :param user:
        :return:
        """
        device, is_exist, is_active = self.user_service.user_2fa_device_status(user)
        return device, is_exist, is_active

    def filter_record(self, engine_sn):
        """过滤唯一的提现请求记录

        :param engine_sn:
        :return:
        """
        return self.model.objects.filter(engine_sn=engine_sn).first()

    def create_record(self, user_id, coin_type: int, tx_amount, tx_address, tx_fee, freeze_request_no=None,
                      freeze_status=FreezeType.UNFREEZE):
        """创建用户提现申请

        :param user_id:
        :param coin_type:
        :param tx_amount:
        :param tx_address:
        :param tx_fee:
        :param freeze_request_no:
        :param freeze_status:
        :return:
        """
        return self.model.objects.create(
            user_id=user_id,
            coin_type=coin_type,
            tx_address=tx_address,
            tx_amount=tx_amount,
            tx_fee=tx_fee,
            status=WithdrawStatus.VERIFY_PENDING,  # 审核pending
            freeze_request_no=freeze_request_no,
            freeze_status=freeze_status,
        )

    def create_verify_process(self, user: User):
        """发送验证码

        :param user:
        :return:
        """
        # email:
        if user.email_verified:
            verify_code = self.user_service.cache_email_verify_code(user)
            logger.info("{} email verify code: {}".format(user.username, verify_code))
            send_verify_email(user.email, verify_code)

        # mobile:
        if user.mobile_verified:
            tasks.send_and_cache_sms_verify_code.delay(user.user_id_hex)

    def engine_response_update(self, engine_sn, engine_code, status):
        record = self.model.objects.filter(
            engine_sn=engine_sn
        ).exclude(
            engine_code=0
        ).first()
        logger.info('record:{}'.format(record.engine_sn))
        if not record:
            return None
        if record.engine_code == EngineResponseCode.COMPLETED or record.status == WithdrawStatus.COMPLETED \
                or record.status == WithdrawStatus.ENGINE_COMPLETED:
            return record
        record.engine_code = engine_code
        record.status = status
        record.save()
        return record

    def blockchain_proxy_response_update(self, tx_id, engine_sn, address, confirmations):
        record = self.model.objects.filter(
            engine_sn=engine_sn,
            tx_address=address,
        ).first()

        if not record:
            return None
        if not record.tx_id:
            record.tx_id = tx_id
        record.confirmations = confirmations
        if confirmations >= self.confirm_limit.get(record.coin_type):
            record.status = self.status.COMPLETED
        else:
            record.status = self.status.CHAIN_PENDING
        record.save()
        return record

    @transaction.atomic
    # TODO: 这个事务, 需要改成 with 局部控制写表部分
    def inner_withdraw(self, withdraw_record: CryptoWithdrawRecordLastThreeMonths):
        # todo 更新内部提现tx_id
        if not withdraw_record.tx_id:
            withdraw_record.tx_id = "inner-withdraw:sn:{}".format(withdraw_record.engine_sn)
        #########################################
        # deposit part:
        #########################################
        # deposit record:
        deposit_record = self.deposit_service.filter_record(engine_sn=withdraw_record.engine_sn)
        deposit_address_record = self.deposit_address_model.objects.filter(
            address=withdraw_record.tx_address
        ).first()
        if not deposit_record:
            deposit_record = self.deposit_service.create_record(
                user_id=deposit_address_record.user_id,
                engine_sn=withdraw_record.engine_sn,
            )

        self.deposit_service.update_inner_record(
            record=deposit_record,
            user_id=deposit_address_record.user_id,
            tx_address=withdraw_record.tx_address,
            coin_type=withdraw_record.coin_type,
            tx_amount=withdraw_record.tx_amount,
            tx_id="inner-deposit:sn:{}".format(withdraw_record.engine_sn)
        )

        #
        #########################################
        # withdraw RPC:
        #########################################
        # todo :engine withdraw with fee
        task = self.withdraw_engine_task_with_fee(withdraw_record)
        # todo USDT
        if task.get("coin_type") == 'USDT':
            eng_resp = self.engine.withdraw_usdt_with_fee(
                request_id=task.get("request_no"),
                coin_type='USD',
                amount=task.get("amount"),
                username=task.get("username"),
                fee=task.get("fee")
            )
        else:
            eng_resp = self.engine.withdraw_with_fee(
                request_id=task.get("request_no"),
                coin_type=task.get("coin_type"),
                amount=task.get("amount"),
                username=task.get("username"),
                fee=task.get("fee")
            )

        eng_resp_code = eng_resp.get("RC", -100)
        if eng_resp_code != 0:
            logger.error("Engine RPC Failed: Inner Withdraw Failed: {}".format(eng_resp))
            self.engine_response_update(
                engine_sn=withdraw_record.engine_sn,
                engine_code=eng_resp_code,
                status=self.status.ENGINE_FAILED,
            )
            return False
        else:
            withdraw_record.engine_code = eng_resp_code
            withdraw_record.status = self.status.ENGINE_COMPLETED
            withdraw_record.save()

        ###############################
        # deposit RPC:
        ###############################
        # engine rpc deposit:
        user = User.objects.filter(user_id=deposit_record.user_id).first()
        # todo USDT
        if task.get("coin_type") == 'USDT':
            eng_resp = self.engine.deposit_usdt(
                request_id=deposit_record.engine_request_no.hex,
                coin_type='USD',
                amount=str(withdraw_record.tx_amount),
                username=user.engine_account_id,
            )
        else:
            eng_resp = self.engine.deposit(
                request_id=deposit_record.engine_request_no.hex,
                coin_type=task.get("coin_type"),
                amount=str(withdraw_record.tx_amount),
                username=user.engine_account_id,
            )
        eng_resp_code = eng_resp.get("RC", 99)
        if eng_resp_code != 0:
            logger.error("Engine RPC Failed: Inner Deposit Failed: {}".format(eng_resp))
            self.deposit_service.update_record(record=deposit_record, status=DepositStatus.ENGINE_FAILED)
            return False

        ###############################
        # update record status:
        ###############################
        self.update_record_status(record=withdraw_record, status=WithdrawStatus.COMPLETED)
        self.deposit_service.update_record(
            record=deposit_record,
            status=DepositStatus.COMPLETED,
        )
        return True

    def delete_record(self, user_id, engine_sn):
        obj = self.model.objects.filter(
            user_id=user_id,
            engine_sn=engine_sn,
        ).first()

        if not obj:
            return False

        obj.soft_delete()
        return True

    def search_records(self, attrs: dict):
        """
        :param attrs:
                {"user_id": self.request.query_params.get('user_id', None),
                 "email": self.request.query_params.get('email', None),
                 "status": self.request.query_params.get('status', None),
                 "coin_type": self.request.query_params.get('coin_type', None),
                 "verify_type": self.request.query_params.get('verify_type', None),
                 "timestamp_start": self.request.query_params.get('timestamp_start', None),
                 "timestamp_end": self.request.query_params.get('timestamp_end', None),
                 "limit": self.request.query_params.get('limit', 10),
                 "offset": self.request.query_params.get('offset', 0)}
        :return:
        """
        qs = self.model.objects.filter(is_deleted=0)
        if attrs.get('user_id'):
            qs = qs.filter(user_id=attrs.get('user_id'))
        if attrs.get('email'):
            user_service = UserService()
            user = user_service.filter_record(email=attrs.get('email'))
            qs = qs.filter(user_id=user.user_id_hex)
        if attrs.get('status') is not None:
            if attrs.get('status') < -1:
                qs = qs.filter(status__lt=-1)
            else:
                qs = qs.filter(status=attrs.get('status'))
        if attrs.get('coin_type') is not None:
            qs = qs.filter(coin_type=attrs.get('coin_type'))
        if attrs.get('verify_type') is not None:
            qs = qs.filter(verify_type=attrs.get('verify_type'))
        if attrs.get('timestamp_start'):
            qs = qs.filter(updated_at__gte=attrs.get('timestamp_start'))
        if attrs.get('timestamp_end'):
            qs = qs.filter(updated_at__lte=attrs.get('timestamp_end'))
        order_by = int(attrs.get("order_by"))
        if order_by:
            if order_by == DatetimeOrderBy.REVERSE_ORDER_BY:
                qs = qs.order_by("-updated_at")
        count = qs.count()
        auto_count = qs.filter(verify_type=0).count()
        limit = attrs.get('limit')
        offset = attrs.get('offset')
        qs = qs[offset:limit + offset]
        return count, auto_count, qs

    def auto_cancel_order(self):
        # 超过10分钟未处理的提现请求, 交易撤销
        deadline = timezone.now() - datetime.timedelta(minutes=10)
        orders = self.model.objects.filter(status=1, is_deleted=0,
                                           updated_at__lte=deadline)
        # todo 资金解冻
        if settings.FREEZE_SWITCH:
            for order in orders:
                request_id = uuid.uuid4()
                user = User.objects.filter(user_id=order.user_id).first()
                is_ok = self.freeze_cash(
                             request_id=request_id.hex,
                             user=user,
                             coin_type=order.coin_type,
                             amount=order.tx_amount + order.tx_fee,
                             freeze_type=FreezeType.UNFREEZE,
                             )
                if is_ok:
                    order.freeze_request_no = request_id
                    order.freeze_status = FreezeType.UNFREEZE
                    order.status = WithdrawStatus.USER_REVOKE
                    order.save()

        counts = orders.update(status=WithdrawStatus.USER_REVOKE)
        return counts

    def notify_withdraw_quest(self, record: CryptoWithdrawRecordLastThreeMonths):
        """
        通知客服 有需要审核的提现请求
        :return:
        """
        message = {
            "coin_type": record.coin_type,
            "user_id": record.user_id_hex,
            "tx_amount": record.tx_amount_fmt
        }
        user = User.objects.filter(user_id=record.user_id).first()
        markdown_table = """
        用户ID:{}
        用户邮箱:{}
        提现币种:{}
        提现数量:{}
        """.format(record.user_id_hex, user.email, CoinType.get_choice(record.coin_type).label, record.tx_amount_fmt)
        async_send_ding_msg(markdown_table, self.ding_token, 'crypto_withdraw')
        return message

    def add_asscessor_info(self, user: User, record: CryptoWithdrawRecordLastThreeMonths):
        """
        客服审核通过后 添加客户管理员信息
        :param user:
        :param record:
        :return:
        """
        if not user or not record:
            logger.info(f'no accessor info or withdraw record')
            return False
        record.accessor = user.username
        record.verify_type = VerifyType.STAFF_ACCESS
        record.save()
        return True

    def record_count(self):
        total_number = self.model.objects.filter(is_deleted=0).count()
        auto_number = self.model.objects.filter(is_deleted=0, verify_type=VerifyType.AUTOMIC_ACCESS).count()
        return total_number, auto_number

    def validate_list(self, attrs: dict):
        """
        :param attrs:
                {"user_id": self.request.query_params.get('user_id', None),
                 "email": self.request.query_params.get('email', None),
                 "status": self.request.query_params.get('status', None),
                 "coin_type": self.request.query_params.get('coin_type', None),
                 "verify_type": self.request.query_params.get('verify_type', None),
                 "timestamp_start": self.request.query_params.get('timestamp_start', None),
                 "timestamp_end": self.request.query_params.get('timestamp_end', None),
                 "limit": self.request.query_params.get('limit', 10),
                 "offset": self.request.query_params.get('offset', 0)}
        :return:
        """
        attrs.update(code=200, detail="")
        # 起始时间
        timestamp_start = attrs.get('timestamp_start')
        if timestamp_start:
            is_ok, result = validate_timestamp_start(timestamp_start)
            if not is_ok:
                attrs.update(code=result[0], detail=result[1])
                return attrs
            attrs.update(timestamp_start=result)
        # 结束时间
        timestamp_end = attrs.get('timestamp_end')
        if timestamp_end:
            is_ok, result = validate_timestamp_end(timestamp_end)
            if not is_ok:
                attrs.update(code=result[0], detail=result[1])
                return attrs
            attrs.update(timestamp_end=result)
        # 状态
        status = attrs.get('status')
        if status is not None:
            logger.info(f'input status:{status}')
            is_ok, result = self.validate_status(status)
            if not is_ok:
                attrs.update(code=result[0], detail=result[1])
                return attrs
            attrs.update(status=result)
        # limit
        limit = attrs.get('limit', 10)
        is_ok, result = validate_limit(limit)
        if not is_ok:
            attrs.update(code=result[0], detail=result[1])
            return attrs
        attrs.update(limit=result)

        # offset
        offset = attrs.get('offset', 0)
        is_ok, result = validate_offset(offset)
        if not is_ok:
            attrs.update(code=result[0], detail=result[1])
            return attrs
        attrs.update(offset=result)

        # verify type
        verify_type = attrs.get('verify_type')
        if verify_type is not None:
            is_ok, result = self.validate_verify_type(verify_type)
            if not is_ok:
                attrs.update(code=result[0], detail=result[1])
                return attrs
            attrs.update(verify_type=result)

        # coin type
        coin_type = attrs.get('coin_type')
        logger.info(f'coin type:{coin_type}')
        if coin_type is not None:
            is_ok, result = self.validate_coin_type(coin_type)
            if not is_ok:
                attrs.update(code=result[0],
                             detail=result[1])
                return attrs
            attrs.update(coin_type=result)

        # user_id
        user_id = attrs.get('user_id')
        if user_id:
            is_ok, result = validate_user_id(user_id)
            if not is_ok:
                attrs.update(code=result[0],
                             detail=result[1])
                return attrs
            attrs.update(user_id=user_id)

        # email
        email = attrs.get('email')
        if email:
            is_ok, result = validate_email(email)
            if not is_ok:
                attrs.update(code=result[0], detail=result[1])
                return attrs
            attrs.update(email=result)

        # order_by
        order_by = attrs.get('order_by')
        if not str(order_by).isdigit() or not order_by:
            attrs.update(code='4510', detail="invalid statua or status needed !")
            return attrs
        is_ok = self.validate_order_by_status(order_by)
        if not is_ok:
            attrs.update(code="4511", detail="invalid order by status")
            return attrs
        attrs.update(order_by=order_by)
        return attrs

    @staticmethod
    def validate_status(status):
        if isinstance(status, int):
            return True, status
        if status and str(status).isdigit():
            return True, int(status)
        if status and (status == '-2' or status == '-1'):
            return True, int(status)
        return False, ErrorsCommon.status_error

    @staticmethod
    def validate_verify_type(verify_type):
        if isinstance(verify_type, int):
            return True, verify_type
        if verify_type and str(verify_type).isdigit():
            return True, int(verify_type)
        return False, Errors1.verify_type_error

    @staticmethod
    def validate_coin_type(coin_type):
        if isinstance(coin_type, int):
            return True, coin_type
        if coin_type and str(coin_type).isdigit():
            return True, int(coin_type)
        return False, Errors1.coin_type_error

    def update_verify_type(self, record: CryptoWithdrawRecordLastThreeMonths, verify_type: int):
        record.verify_type = verify_type
        record.save()
        return record

    @staticmethod
    def validate_order_by_status(order_by=None):
        """
        客服允许录入的状态值
        :param order_by:
        :return:
        """
        allowed_sort = [
            DatetimeOrderBy.POSITIVE_ORDER_BY,
            DatetimeOrderBy.REVERSE_ORDER_BY,
        ]
        return int(order_by) in allowed_sort

    def validate_withdraw_switch(self, access_switch, result: dict):
        """
        更新审核开关
        :param access_switch:
        :param result:
        :return:
        """
        if not str(access_switch):
            result.update(code=458, detail="withdraw access_switch needed !")

            return False, result

        if not str(access_switch).isdigit() or int(access_switch) not in [VerifyType.AUTOMIC_ACCESS, VerifyType.STAFF_ACCESS]:
            result.update(
                code=459,
                detail="invalid access_switch status"
            )
            return False, result
        return True, result

    def update_withdraw_switch(self, access_switch, result: dict):
        if int(access_switch) == VerifyType.AUTOMIC_ACCESS:
            self.redis_sessions["WithdrawSwitch"].set('WithdrawSwitch', VerifyType.AUTOMIC_ACCESS)
            result.update(data=access_switch)
            return True, result
        else:
            self.redis_sessions["WithdrawSwitch"].set("WithdrawSwitch", VerifyType.STAFF_ACCESS)
            result.update(data=access_switch)
            return True, result

    # 冻结or解冻用户资产
    def freeze_cash(self, request_id, user, coin_type: int, amount, freeze_type):
        # USDT提现冻结USD
        if CoinType.get_choice(coin_type).label == 'USDT':
            result = self.engine.freeze_cash(
                request_id=request_id,
                coin_type='USD',
                amount=amount,
                freeze_type=freeze_type,
                username=user.engine_account_id,
            )
        else:
            result = self.engine.freeze_cash(
                request_id=request_id,
                coin_type=CoinType.get_choice(coin_type).label,
                amount=amount,
                freeze_type=freeze_type,
                username=user.engine_account_id,
            )
        logger.info(f'freeze rpc response:{result}')
        if result.get('RC', -99) != 0:
            return False
        return True
