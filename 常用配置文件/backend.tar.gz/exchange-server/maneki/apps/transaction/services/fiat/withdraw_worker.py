# -*- coding: utf-8 -*-
import logging
from django.conf import settings
from django.db import transaction
from maneki.apps.common.utils.decorator.db import verify_db_connections
from maneki.apps.common.utils.mq.pika import BaseConsumer
from maneki.apps.common.utils.mq.pika import BaseProducer
from maneki.apps.transaction.services.fiat.withdraw_manager import FiatWithdrawManager

logger = logging.getLogger(__name__)
FIAT_WITHDRAW_ENGINE_INBOX = settings.RABBITMQ_CONFIG_GROUP["withdraw"]["fiat_engine_inbox"]


# 法币提现产生给引擎提币的数据
class FiatWithDrawEngineProducer(BaseProducer):
    MQ_CONFIG_GROUPS = FIAT_WITHDRAW_ENGINE_INBOX


# 法币提现处理引擎提币result--withdraw和backend数据库的数据
class FiatWithDrawEngineConsumer(BaseConsumer):
    MQ_CONFIG_GROUPS = FIAT_WITHDRAW_ENGINE_INBOX

    @verify_db_connections
    # @transaction.atomic()
    def do_task(self, payload):
        """

        :param payload:
                {
                    "request_id": "engine_request_no",
                    "coin_type": "USD",
                    "amount": "2",
                    "username": "user_id",
                    "fee": "0.006"
                }
        :return:
        """
        logger.info("queue task: {}".format(payload))
        fwm = FiatWithdrawManager()
        fwm.get_engine_response(payload)
