# -*- coding: utf-8 -*-
import datetime
import json
import logging
import uuid
from decimal import Decimal

from django.conf import settings
from django.utils import timezone

from maneki.apps.common.mixins.rest import ValidationError452
from maneki.apps.constants import FiatType, FIAT_WITHDRAW_MIN_LIMIT, FIAT_WITHDRAW_MAX_LIMIT, FreezeType
from maneki.apps.constants import FiatWithdrawFianceAllowStatus
from maneki.apps.constants import WithdrawStatus
from maneki.apps.engine.services import EngineService
from maneki.apps.transaction.models.fiat_currency import FiatCurrencyWithdrawRecordLastThreeMonths
from maneki.apps.user.models import User
from maneki.apps.user.services import UserService

logger = logging.getLogger(__name__)


class FiatWithdrawService(object):

    def __init__(self):
        self.model = FiatCurrencyWithdrawRecordLastThreeMonths
        #
        self.min_limit = FIAT_WITHDRAW_MIN_LIMIT
        self.max_limit = FIAT_WITHDRAW_MAX_LIMIT
        self.status = WithdrawStatus
        self.engine = EngineService()

    def filter_record(self, engine_sn, user_id=None, status=None):
        condition = {
            'engine_sn': engine_sn,
            'user_id': user_id,
            'status': status

        }
        condition = {k: v for k, v in condition.items() if v is not None}

        return self.model.objects.filter(**condition).first()

    def create_record(self, fiat_type, amount, bank_account, user_id, beneficiary_name, service_charge, status,
                      freeze_request_no=None, freeze_status=FreezeType.UNDEFINED):
        obj = self.model.objects.create(fiat_type=fiat_type, amount=amount,
                                        bank_account=bank_account,
                                        user_id=user_id,
                                        beneficiary_name=beneficiary_name,
                                        service_charge=service_charge,
                                        status=status,
                                        freeze_request_no=freeze_request_no,
                                        freeze_status=freeze_status)
        return obj

    def delete_record(self, user_id, engine_sn):
        obj = self.model.objects.filter(engine_sn=engine_sn, user_id=user_id).first()
        if not obj:
            return False
        obj.soft_delete()
        return True

    def list_record(self, user_id, status=None):
        query = self.model.objects.filter(user_id=user_id, is_deleted=False)
        if status:
            return query.filter(status=status).all()
        return query.all()

    def get_record_by_engine(self, user_id=None, engine_request_no=None, engine_sn=None):
        condition = dict(
            is_deleted=False)

        if user_id:
            condition.update(
                user_id=user_id
            )

        if engine_request_no:
            condition.update(
                engine_request_no=engine_request_no
            )

        if engine_sn:
            condition.update(
                engine_sn=engine_sn
            )

        return self.model.objects.filter(**condition).first()

    @staticmethod
    def gen_fiat_withdraw_inbox_data(withdraw_data: dict = None, user_id=None,
                                     record: FiatCurrencyWithdrawRecordLastThreeMonths = None):
        user = User.objects.filter(user_id=record.user_id).first()
        if record:
            result = {
                "request_id": record.engine_request_no.hex,
                "sn": record.engine_sn.hex,
                "coin_type": FiatType.get_choice(record.fiat_type).label,
                "amount": str(record.amount),
                "username": user.engine_account_id,
                "fee": str(record.service_charge)
            }
            return result

        if isinstance(withdraw_data, str):
            withdraw_data = json.loads(withdraw_data)

        # Todo: 计算提现手续费 引擎amount = 提现amount + 手续费

        result = {
            "request_id": str(withdraw_data.get('engine_request_no')),
            "coin_type": FiatType.get_choice(withdraw_data.get('fiat_type')).label,
            "amount": str(withdraw_data.get('amount')),
            "username": str(user_id),
            "fee": str(withdraw_data.get('service_charge'))
        }
        return result

    def validate_withdraw_limit(self, fiat_type, amount):
        """提现限额校验

        :param fiat_type: 币种
        :param amount: 提现金额
        :return: True/False
        """
        max_limit = self.max_limit.get(fiat_type)
        min_limit = self.min_limit.get(fiat_type)

        logger.info("coin_type={}, max={}, min={}, amount={}".format(fiat_type, max_limit, min_limit, amount))
        if isinstance(amount, Decimal):
            max_limit = Decimal(str(max_limit))
            min_limit = Decimal(str(min_limit))

        return min_limit <= amount, amount <= max_limit, min_limit <= amount <= max_limit

    def update_record_status(self, record: FiatCurrencyWithdrawRecordLastThreeMonths = None,
                             engine_sn: str = None,
                             status=WithdrawStatus.UNDEFINED):
        """更新表记录状态
        """
        if not any([record, engine_sn]):
            return None
        record = self.filter_record(engine_sn=engine_sn) if not record else record
        if not record:
            return None
        record.status = status
        return record.save()

    def validate_manual_check_status(self, status):
        """客服录入有效状态值检测

        :param status:
        :return:
        """
        allow_status = [
            self.status.REVIEW_FAILED,
            self.status.REVIEW_COMPLETED,
        ]
        return status in allow_status

    def update_out_money_sn(self, record: FiatCurrencyWithdrawRecordLastThreeMonths,
                            status: int, out_money_sn: str):
        """更新表记录状态

        :param record:
        :param engine_sn:
        :param status:
        :return:
        """
        if not any([record, status, out_money_sn]):
            return None
        record.out_money_bank_sn = out_money_sn
        if status == FiatWithdrawFianceAllowStatus.OUT_MONEY_COMPLETED:
            record.status = WithdrawStatus.COMPLETED
        else:
            record.status = status
        return record.save()

    def filter_timestamp(self):
        pass

    def filter_withdraw_out_money_sn(self, sn):
        sn = self.model.objects.filter(out_money_bank_sn=sn).first()
        return sn

    def check_pending_withdraw(self, user_id, fiat_type):
        """检查是否存在未处理完的提现申请

        :param user_id:
        :param fiat_type:
        :return:
        """
        r_count = self.model.objects.filter(
            user_id=user_id,
            fiat_type=fiat_type,
            # Todo
            status__gt=WithdrawStatus.COMPLETED
        ).count()
        return bool(r_count)

    def search_records(self, address=None, tx_id=None, user_id=None, email=None):
        qs = self.model.objects
        if address:
            qs = qs.filter(tx_address=address)
        if tx_id:
            qs = qs.filter(tx_id=tx_id)
        if user_id:
            qs = qs.filter(user_id=user_id)
        if email:
            user_service = UserService()
            user = user_service.filter_record(email=email)
            if user is None:
                raise ValidationError452(detail='this email did not registered.')
            qs = qs.filter(user_id=user.user_id_hex)
        return qs

    def auto_cancel_order(self):
        # 超过10分钟未处理的提现请求, 交易撤销
        deadline = timezone.now() - datetime.timedelta(minutes=10)

        orders = self.model.objects.filter(status=1, is_deleted=0,
                                           updated_at__lte=deadline)
        # todo 资金解冻
        if settings.FREEZE_SWITCH:
            for order in orders:
                request_id = uuid.uuid4()
                user = User.objects.filter(user_id=order.user_id).first()
                is_ok = self.freeze_cash(
                            request_id=request_id.hex,
                            user=user,
                            coin_type=order.fiat_type,
                            amount=order.amount + order.service_charge,
                            freeze_type=FreezeType.UNFREEZE,
                        )
                if is_ok:
                    order.freeze_request_no = request_id
                    order.freeze_status = FreezeType.UNFREEZE
                    order.status = WithdrawStatus.USER_REVOKE
                    order.save()
        counts = orders.update(status=WithdrawStatus.USER_REVOKE)
        return counts

    # 法币冻结or解冻用户资产
    def freeze_cash(self, request_id, user, coin_type: int, amount, freeze_type):
        # USD
        result = self.engine.freeze_cash(
            request_id=request_id,
            coin_type=FiatType.get_choice(coin_type).label,
            amount=amount,
            freeze_type=freeze_type,
            username=user.engine_account_id,
        )
        logger.info(f'freeze rpc response:{result}')
        if result.get('RC', -99) != 0:
            return False
        return True
