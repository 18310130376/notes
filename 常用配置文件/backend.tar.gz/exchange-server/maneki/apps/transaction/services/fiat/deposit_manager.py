# -*- coding: utf-8 -*-
import decimal
import logging
import uuid

from maneki.apps.engine.services.engine import EngineService
from maneki.apps.constants import EngineResponseCode, USD_DEPOSIT_FEE_BASE_RATE
from maneki.apps.transaction.services.fiat.deposit import FiatDepositService
from maneki.apps.transaction.utils.exceptions import FiatDepositRecordNotFound
from maneki.apps.constants import WithdrawStatus
from maneki.apps.user.services import UserService

logger = logging.getLogger(__name__)


class FiatDepositManager(object):

    def __init__(self):
        self.engine_rpc = EngineService()
        self.user_service = UserService()
        self.service = FiatDepositService()

    def get_engine_response(self, data: dict):
        """调rpc请求engine  状态

                :param data:
                        {
                            "request_id": "engine_request_no",
                            "coin_type": "USD",
                            "amount": "2",
                            "username": "user_id",
                        }

                :return:
        """
        request_id = data.get('request_id')
        coin_type = data.get('coin_type')
        amount = data.get('amount')
        username = data.get('username')
        engine_account_id = self.user_service.user_engine_account_id(user_id=username)
        username = (username if engine_account_id == 0 else engine_account_id)

        # rpc:
        # todo USD 收手续费
        if coin_type == 'USD' and data.get('source') != 'simplex':
            fee = decimal.Decimal(amount) * USD_DEPOSIT_FEE_BASE_RATE
            result = self.engine_rpc.deposit_with_fee(
                request_id=request_id,
                coin_type=coin_type,
                amount=decimal.Decimal(amount),
                username=username,
                fee=fee if fee > decimal.Decimal('10') else decimal.Decimal('10'),
            )
        else:
            result = self.engine_rpc.deposit(
                request_id=request_id,
                coin_type=coin_type,
                amount=amount,
                username=username,
            )
        logger.info('fiat deposit - engine response:{}'.format(result))

        # should not need this any more
        # fix old leaf account:
        # if result['RC'] == 2015:
        #     engine_account_id = self.user_service.user_engine_account_id(user_id=username)
        #     request_id = uuid.uuid4().hex # TODO request id变了，但是没写到DB，导致更新存取记录失败
        #     # rpc:
        #     if coin_type == 'USD':
        #         fee = decimal.Decimal(amount) * USD_DEPOSIT_FEE_BASE_RATE
        #         result = self.engine_rpc.deposit_with_fee(
        #             request_id=request_id,
        #             coin_type=coin_type,
        #             amount=decimal.Decimal(amount),
        #             username=engine_account_id,
        #             fee=fee,
        #         )
        #     else:
        #         result = self.engine_rpc.deposit(
        #             request_id=request_id,
        #             coin_type=coin_type,
        #             amount=amount,
        #             username=engine_account_id,
        #         )

        # ok:
        if result['RC'] == 0:
            self.update_db_record(data, response_code=EngineResponseCode.COMPLETED, eng_req_id=request_id)
        else:
            response_code = result.get('RC', 99)
            self.update_db_record(data, response_code, request_id)
            logger.error("engine_rpc_fail response:{}".format(result))

    def update_db_record(self, data: dict, response_code=None, eng_req_id=None):
        """

                :param data: = {
                    "request_id": "a52112f95ebe48cf9bb1d2b4ef0079e6",
                    "coin_type": "3",
                    "amount": "0.01000000000000000000",
                    "username": "27ddfc3d-08c7-4ca4-8c52-d91b6e19ee22"
                }
                :param response_code:
                :param eng_req_id:
                :return:
        """

        logger.info(data)
        record = self.service.get_record_by_engine(engine_request_no=eng_req_id)

        if not record:
            logger.info("Not found deposit_record: error")
            raise FiatDepositRecordNotFound

        if response_code == EngineResponseCode.COMPLETED:
            record.status = WithdrawStatus.COMPLETED
        else:
            record.status = WithdrawStatus.ENGINE_FAILED

        record.eng_errcode = response_code
        record.save()
