# -*- coding: utf-8 -*-
import logging
import uuid

from maneki.apps.engine.services.engine import EngineService
from maneki.apps.constants import EngineResponseCode
from maneki.apps.transaction.services.fiat.withdraw import FiatWithdrawService
from maneki.apps.transaction.utils.exceptions import FiatWithdrawRecordNotFound
from maneki.apps.constants import WithdrawStatus
from maneki.apps.user.services import UserService

logger = logging.getLogger(__name__)


class FiatWithdrawManager(object):

    def __init__(self):
        self.engine_rpc = EngineService()
        self.user_service = UserService()
        self.fws = FiatWithdrawService()

    def get_engine_response(self, data: dict):
        """调rpc请求engine  状态

                :param data:
                        {
                            "request_id": "engine_request_no",
                            "coin_type": "USD",
                            "amount": "2",
                            "username": "user_id",
                            "fee": "0.006"
                        }

                :return:
        """
        request_id = data.get('request_id')
        coin_type = data.get('coin_type')
        amount = data.get("amount")
        username = data.get("username")
        fee = data.get("fee")

        engine_account_id = self.user_service.user_engine_account_id(user_id=username)
        # rpc:
        result = self.engine_rpc.withdraw_with_fee(
            request_id=request_id,
            coin_type=coin_type,
            amount=amount,
            username=engine_account_id,
            fee=fee
        )
        logger.info('fiat withdraw - engine response:{}'.format(result))

        # fix old leaf account:
        if result['RC'] == 2015:
            engine_account_id = self.user_service.user_engine_account_id(user_id=username)
            request_id = uuid.uuid4().hex
            # rpc:
            result = self.engine_rpc.withdraw_with_fee(
                request_id=request_id,
                coin_type=coin_type,
                amount=amount,
                username=engine_account_id,
                fee=fee
            )

        # ok:
        if result['RC'] == 0:
            self.update_db_record(data, response_code=EngineResponseCode.COMPLETED, tid=result['TID'])
        else:
            response_code = result.get('RC', 99)
            self.update_db_record(data, response_code)
            logger.error(result.get('Reason', None))

    def update_db_record(self, data: dict, response_code=None, tid=None):
        """

                :param data: = {
                    "request_id": "a52112f95ebe48cf9bb1d2b4ef0079e6",
                    "coin_type": "3",
                    "amount": "0.01000000000000000000",
                    "username": "27ddfc3d-08c7-4ca4-8c52-d91b6e19ee22"
                }
                :param response_code:
                :param tid:
                :return:
        """

        logger.info(data)
        record = self.fws.get_record_by_engine(engine_sn=data.get('sn'))

        if not record:
            raise FiatWithdrawRecordNotFound
        if record.status == WithdrawStatus.ENGINE_COMPLETED:
            return

        if response_code == EngineResponseCode.COMPLETED:
            record.status = WithdrawStatus.ENGINE_COMPLETED
        else:
            record.status = WithdrawStatus.ENGINE_FAILED

        record.eng_errcode = response_code
        record.save()
