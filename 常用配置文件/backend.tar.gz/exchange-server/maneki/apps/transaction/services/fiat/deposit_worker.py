# -*- coding: utf-8 -*-
import logging
from django.conf import settings
from django.db import transaction
from maneki.apps.common.utils.decorator.db import verify_db_connections
from maneki.apps.common.utils.mq.pika import BaseConsumer
from maneki.apps.common.utils.mq.pika import BaseProducer
from maneki.apps.transaction.services.fiat.deposit_manager import FiatDepositManager

logger = logging.getLogger(__name__)
FIAT_DEPOSIT_ENGINE_INBOX = settings.RABBITMQ_CONFIG_GROUP["deposit"]["fiat_engine_inbox"]


# 法币充值
class FiatDepositEngineProducer(BaseProducer):
    MQ_CONFIG_GROUPS = FIAT_DEPOSIT_ENGINE_INBOX


# 法充值处理引擎提币result--withdraw和backend数据库的数据
class FiatDepositEngineConsumer(BaseConsumer):
    MQ_CONFIG_GROUPS = FIAT_DEPOSIT_ENGINE_INBOX

    @verify_db_connections
    # @transaction.atomic()
    def do_task(self, payload):
        """

        :param payload:
                {
                    "request_id": "engine_request_no",
                    "coin_type": "USD",
                    "amount": "2",
                    "username": "user_id",
                }
        :return:
        """
        logger.info("queue task: {}".format(payload))
        manage = FiatDepositManager()
        manage.get_engine_response(payload)
