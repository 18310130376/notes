# -*- coding: utf-8 -*-
import datetime
import logging
import uuid
from decimal import Decimal
from dateutil import parser

import requests

from config.settings.env import SIMPLEX_API_KEY, SIMPLEX_API
from maneki.apps.common.base import BaseService
from maneki.apps.common.mixins.rest import ValidationError452
from maneki.apps.common.utils import date
from maneki.apps.constants import FiatType, FIAT_WITHDRAW_MIN_LIMIT, FIAT_WITHDRAW_MAX_LIMIT, FiatDepositType
from maneki.apps.constants import FiatDepositStatus
from maneki.apps.transaction.models.fiat_currency import FiatCurrencyDepositRecordLastThreeMonths, \
    FiatCurrencyDepositRecord, SimplexEvent
from maneki.apps.common.utils.format_timestamp import format_timestamp
from maneki.apps.common.utils.decimal import format_amount
from maneki.apps.user.models import User
from maneki.apps.user.services import UserService
from django.core.cache import caches as DjangoCaches
from maneki.apps.common.utils.decorator.decorators import retry
from maneki.apps.user_kyc.libs.s3_storage_backend import PrivateMediaStorage
from maneki.apps.user_kyc.models import KYCIndividual

logger = logging.getLogger(__name__)


class FiatDepositService(object):

    def __init__(self):
        self.model = FiatCurrencyDepositRecordLastThreeMonths
        #
        self.max_limit = FIAT_WITHDRAW_MIN_LIMIT
        self.min_limit = FIAT_WITHDRAW_MAX_LIMIT
        self.status = FiatDepositStatus

    def filter_record(self, engine_sn, user_id=None):
        if not user_id:
            return self.model.objects.filter(engine_sn=engine_sn, is_deleted=False).first()
        return self.model.objects.filter(engine_sn=engine_sn, user_id=user_id, is_deleted=False).first()

    def update_record_status(self, record: FiatCurrencyDepositRecordLastThreeMonths = None,
                             engine_sn: str = None,
                             status=FiatDepositStatus.UNDEFINED):
        """更新表记录状态

        :param record:
        :param engine_sn:
        :param status:
        :return:
        """
        if not any([record, engine_sn]):
            return None
        record = self.filter_record(engine_sn=engine_sn) if not record else record
        if not record:
            return None
        record.status = status
        return record.save()

    def list_record(self, user_id, status=None):
        query = self.model.objects.filter(user_id=user_id, is_deleted=False)
        if status:
            return query.filter(status=status)
        return query

    @staticmethod
    def deposit_engine_task(record: FiatCurrencyDepositRecord):
        """Engine RPC task

        :param record:
        :return:
        """
        user = User.objects.filter(user_id=record.user_id).first()
        result = {
            "request_id": record.engine_request_no.hex,
            # "sn": record.engine_sn.hex,
            "coin_type": FiatType.get_choice(record.fiat_type).label,
            "amount": format_amount(record.amount),
            "username": user.engine_account_id,
        }
        return result

    def get_record_by_engine(self, engine_request_no):
        return self.model.objects.filter(engine_request_no=engine_request_no, is_deleted=False).first()

    @staticmethod
    def format_time_duration(timestamp_start, timestamp_end):
        if timestamp_start and timestamp_end:
            timestamp_start = date.unix_to_datetime(int(timestamp_start[0:10]), "%Y-%m-%d %H:%M:%S")
            timestamp_end = date.unix_to_datetime(int(timestamp_end[0:10]), "%Y-%m-%d %H:%M:%S")
        else:
            timestamp_start = date.utc_now_str(timedelta_day=30)
            timestamp_end = date.utc_now_str()

        return timestamp_start, timestamp_end

    def delete_record(self, user_id, engine_sn):
        obj = self.model.objects.filter(
            user_id=user_id,
            engine_sn=engine_sn
        ).first()

        if not obj:
            return False
        obj.soft_delete()
        return True

    def search_records(self, address=None, tx_id=None, user_id=None, email=None):
        qs = self.model.objects
        if address:
            qs = qs.filter(tx_address=address)
        if tx_id:
            qs = qs.filter(tx_id=tx_id)
        if user_id:
            qs = qs.filter(user_id=user_id)
        if email:
            user_service = UserService()
            user = user_service.filter_record(email=email)
            if user is None:
                raise ValidationError452(detail='this email did not registered.')
            qs = qs.filter(user_id=user.user_id_hex)
        return qs


class FiatCreditCardService(BaseService):
    """信用卡"""
    switch_flag = 1

    def __init__(self):
        super(FiatCreditCardService, self).__init__(
            model=FiatCurrencyDepositRecordLastThreeMonths,
            cache=DjangoCaches["user_info"]
        )

    @staticmethod
    def user_account_id(user_id):
        # 引擎用户ID
        return UserService().user_engine_account_id(user_id)

    def init_request(self, user_id, user_ip, ref_url, token, fiat_type, amount, fee):
        """
        用户首次请求充值
        """
        # 创建初始记录，paymentID为随机值，等待代理返回
        self.create_record(user_id, fiat_type, token, amount, fee)
        print("用户开始首次请求充值: {}".format(user_id))
        logger.info("user init request: {}".format(user_id))
        kyc_data = self.get_kyc_data(user_id, user_ip, token)
        kyc_data.update(transaction_details=self.transaction_details(token, ref_url))
        if SIMPLEX_API == 'https://sandbox.test-simplexcc.com/v2/': # means it's test
            self.switch_flag = 1 - self.switch_flag # switch between 0 and 1
            if self.switch_flag == 0:
                kyc_data['account_details']['signup_login']['timestamp'] = '2011-10-31T00:00:00Z' # check simplex doc to find out why
        logger.info("kyc_data: {}".format(kyc_data))
        result = requests.post(SIMPLEX_API + 'payments/initiate-request',
                               headers={"Authorization": SIMPLEX_API_KEY, "Content-Type": "application/json"},
                               json=kyc_data, timeout=3)
        logger.info("initiate-request response, content: {}, status code: {}".format(result.json(), result.status_code))
        if result.status_code == 200:
            result_data = result.json()
            if result_data['is_kyc_update_required']:
                re = self.upload_image(user_id, token)
                if re.get('code') == 500:
                    return None
            # 更新充值状态
            self.update_one(query_fields={"engine_request_no": token}, update_fields={
                "engine_sn": token,
                "status": FiatDepositStatus.SIMPLEX_PENDING,
            })
            result_data.update(version=2,
                               partner="btcc",
                               payment_id=kyc_data['transaction_details']['payment_details']['payment_id'],
                               user_id=kyc_data['account_details']['signup_login']['id'],
                               email=kyc_data['personal_details']['email'],
                               amount=kyc_data['transaction_details']['payment_details']['fiat_total_amount']['amount'],
                               currency=kyc_data['transaction_details']['payment_details']['fiat_total_amount']['currency'],
                               firstname=kyc_data['personal_details']['first_name'],
                               lastname=kyc_data['personal_details']['last_name'],
                               phone=kyc_data['personal_details']['phone'],
                               payment_flow_type=kyc_data['transaction_details']['payment_details']['payment_flow_type'],
                               return_url="http://www.btcc.com",
                               show_fee=True)
            return result_data
        else:
            self.update_one(query_fields={"engine_request_no": token}, update_fields={
                "status": FiatDepositStatus.SIMPLES_DECLINED,
            })
            logger.error("init request failed: user_id={}, engine_request_no={}, response={}".format(user_id, token, result.json()))
            return None

    def simplex_event_processing(self):
        url = SIMPLEX_API + 'events'
        logger.info("try to get simplex events: url={}".format(url))
        r = requests.get(url, headers={"Authorization": SIMPLEX_API_KEY, "Content-Type": "application/json"}, timeout=3)
        j = r.json()
        if len(j['events']) > 0:
            for event in j['events']:
                logger.info("processing event: {}".format(event))
                is_ok, payment = self.filter_one({"engine_sn": event['payment']['id']})
                if payment is not None:
                    logger.info("payment found: {}".format(payment))
                    if event['name'] == 'payment_request_submitted':
                        # no need to update payment status as the default simplex_status is pending
                        # just save the event and delete it from the queue
                        pass
                    elif event['name'] == 'payment_simplexcc_approved':
                        self.update_one(query_fields={"engine_sn": event['payment']['id']}, update_fields={
                            'status': FiatDepositStatus.SIMPLES_APPROVED
                        })
                        from maneki.apps.transaction.services.fiat.deposit_manager import FiatDepositManager
                        manage = FiatDepositManager()
                        manage.get_engine_response({
                            "request_id": payment.engine_request_no.hex,
                            "coin_type": "USD",
                            "amount": payment.amount,
                            "username": payment.user_id.hex,
                            "source": "simplex"
                        })
                    else:
                        self.update_one(query_fields={"engine_sn": event['payment']['id']}, update_fields={
                            'status': FiatDepositStatus.SIMPLES_DECLINED
                        })
                else:
                    logger.warning("payment not found for event: {}".format(event['payment']['id']))
                self._save_event(event)
                self._delete_event(event['event_id'])

    @staticmethod
    def _save_event(event):
        SimplexEvent.objects.create(
            event_id=event['event_id'],
            payment_id=event['payment']['id'],
            name=event['name'],
            status=event['payment']['status'],
            emit_time=parser.parse(event['timestamp']))

    @staticmethod
    def _delete_event(event_id):
        requests.delete(SIMPLEX_API + 'events/' + event_id,
                        headers={"Authorization": SIMPLEX_API_KEY, "Content-Type": "application/json"}, timeout=3)

    @staticmethod
    def is_mobile_verified(user_id):
        return User.objects.filter(user_id=user_id).first().mobile_verified

    def create_record(self, user_id, fiat_type, token, amount, fee):
        return self.create_one({
            "engine_request_no": token
        },
            {
                "user_id": user_id,
                "deposit_type": FiatDepositType.SIMPLEX,
                "status": FiatDepositStatus.SIMPLEX_PENDING,
                "fiat_type": fiat_type,
                "engine_request_no": token,
                "amount": amount,
                "simplex_fee": fee,
            })

    @staticmethod
    def get_timestamp():
        return datetime.datetime.now().strftime("%Y-%m-%d") + "T12:00:00Z"

    def get_kyc_data(self, user_id, user_ip, token):
        kyc_obj = KYCIndividual.objects.filter(user_id=user_id).first()
        account_id = self.user_account_id(user_id)
        identity_kyc_details = {
            "id_doc_type": 'passport', #kyc_obj.license_type,
            "first_name": kyc_obj.first_name,
            "last_name": kyc_obj.last_name,
            "document_id": kyc_obj.license_number,
            "phone": User.objects.filter(user_id=user_id).first().mobile.as_e164,
            # "verified_at": kyc_obj.updated_at.strftime("%Y-%m-%d"),
            "date_of_birth": kyc_obj.birth.strftime("%Y-%m-%d") + "T12:00:00Z",
        }
        personal_address = {
            "address_line_1": kyc_obj.local_address,
            "city": kyc_obj.local_city,
            "zip": kyc_obj.local_postcode,
            "country": kyc_obj.local_country,
            "state": "NY",
        }

        personnal_details = {
            "first_name": kyc_obj.first_name,
            "last_name": kyc_obj.last_name,
            "phone": User.objects.filter(user_id=user_id).first().mobile.as_e164,
            "email": User.objects.filter(user_id=user_id).first().email,
            "address": personal_address,
        }
        signup_login = {
            "ip": user_ip,
            "id": account_id,
            "uaid": str(token),
            "is_api_initiated": True,
            "http_accept_language": "en-US,en;q=0.9,lv;q=0.8",
            "timestamp": self.get_timestamp(),
            #'2011-10-31T00:00:00Z' use this for timestamp to test
            "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OSX10_12_5) AppleWebKit/537.36 (KHTML, likeGecko)Chrome/58.0.3029.110 Safari/537.36",
        }
        account_details = {
            "partner_end_user_id": account_id,
            # "last_kyc_verification_timestamp": kyc_obj.created_at.strftime("%Y-%m-%d") + "T12:00:00Z",
            "is_2fa_enabled": User.objects.filter(user_id=user_id).first().totp_device_verified,
            "signup_login": signup_login,
            "logins": [signup_login, ],
            "identity_kyc_details": identity_kyc_details
        }
        kyc_data = {
            "account_details": account_details,
            # "identity_kyc_details": identity_kyc_details,
            # "logins": [signup_login, ],
            "personal_details": personnal_details,
        }
        return kyc_data

    def transaction_details(self, token, ref_url):
        _, order_obj = self.filter_one({"engine_request_no": token})
        amount = order_obj.amount + order_obj.simplex_fee
        return {
            "payment_details": {
                "payment_id": str(token),
                "order_id": str(token),
                "payment_flow_type": "deposit",
                "original_http_ref_url": ref_url,
                "fiat_total_amount": {
                    "amount": float(amount.quantize(Decimal('1.00000'))),
                    "currency": FiatType.attributes.get(int(order_obj.fiat_type)),
                }
            }
        }

    @staticmethod
    @retry(times=3)
    def _do_put(api, data, user_id=None):
        logger.info("PUT request_url: {}".format(SIMPLEX_API + '/' + api))
        result = requests.put(SIMPLEX_API + '/' + api, headers={"Authorization": SIMPLEX_API_KEY}, files=data)
        if result.status_code != 200:
            logger.error("upload image to simplex [!]failed[!], status_code: {}, content: {}, user_id: {}"
                         .format(result.status_code, result.json(), user_id))
            raise Exception
        return result

    def upload_image(self, user_id, token):
        kyc_data = {k.split('.')[0]: (k, self.download_image(v)) for k, v in self._get_kyc_data(user_id).items()}
        # 老用户
        account_id = self.user_account_id(user_id)
        user_url = 'users/{}/kyc'.format(account_id)
        result = self._do_put(user_url, kyc_data, user_id)
        if not result:
            self.update_one(query_fields={"engine_request_no": token}, update_fields={
                "status": FiatDepositStatus.SIMPLES_DECLINED,
            })
            return {"code": 500, "detail": "upload image failed", "data": ""}
        logger.info("upload image to simplex, status_code: {}, content: {}, user_id: {}".format(result.status_code,
                                                                                                result.json(), user_id))
        return result.json()

    @staticmethod
    def _get_kyc_data(user_id):
        kyc_obj = KYCIndividual.objects.filter(user_id=user_id).first()
        kyc_data = {
            "identity_kyc_document_1.{}".format(kyc_obj.license_pic01.name.split('.')[1]): kyc_obj.license_pic01.name,
            "identity_kyc_document_2.{}".format(kyc_obj.license_pic03.name.split('.')[1]): kyc_obj.license_pic03.name,
            "address_kyc_document_1.{}".format(kyc_obj.address_cert.name.split('.')[1]): kyc_obj.address_cert.name,
        }
        if kyc_obj.license_type == 'paper':
            kyc_data.update({
                "identity_kyc_document_3.{}".format(
                    kyc_obj.license_pic02.name.split('.')[1]): kyc_obj.license_pic02.name
            })
        return kyc_data

    @staticmethod
    def download_image(file_name):
        result = requests.get(PrivateMediaStorage().url(file_name))
        return result.content
