# -*- coding:utf-8 -*-
import logging
import datetime
import uuid
from decimal import Decimal

from rest_framework import viewsets
from rest_framework import permissions
from rest_framework.response import Response
from django.db.models import Sum

from config.settings.env import SIMPLEX_FEE_RATE, SIMPLEX_FEE_MIN, SIMPLEX_DAILY_LIMIT, SIMPLEX_MONTHLY_LIMIT
from maneki.apps.transaction.services.fiat.deposit import FiatDepositService, FiatCreditCardService
from maneki.apps.transaction.views.filters.fiat_deposit import FiatDepositFilter
from maneki.apps.common.mixins.rest import BetterListModelMixin, BetterCreateModelMixin
from maneki.apps.transaction.models import FiatCurrencyDepositRecordLastThreeMonths
from maneki.apps.transaction.views.serializers import FiatCurrencyDepositRecordSerializer, \
    FiatCreditCardDepositSerializer
from maneki.apps.user_kyc.service import KYCIndividualBirthService
from maneki.apps.constants import FiatDepositStatus
from .throttles import TxRecordCommonThrottleDay, TxRecordCommonThrottleMinute
logger = logging.getLogger(__name__)


# 用户侧充值记录
class FiatCurrencyDepositRecordViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = FiatCurrencyDepositRecordSerializer
    filter_class = FiatDepositFilter
    throttle_classes = [TxRecordCommonThrottleDay, TxRecordCommonThrottleMinute]
    lookup_url_kwarg = "sn"
    #
    service = FiatDepositService()

    def get_queryset(self):
        return FiatCurrencyDepositRecordLastThreeMonths.objects.filter(
            user_id=self.request.user.user_id,
            is_deleted=False,
        ).order_by('-updated_at')

    def filter_queryset(self, queryset):
        """重写filter_queryset方法防止filter_class调用
        :param queryset:
        :return:
        """
        timestamp_start = self.request.query_params.get('timestamp_start')
        timestamp_end = self.request.query_params.get('timestamp_end')
        deposit_type = self.request.query_params.get('deposit_type')
        start_at, end_at = self.service.format_time_duration(timestamp_start, timestamp_end)

        qs = {"updated_at__gte": start_at,
              "updated_at__lte": end_at}

        if deposit_type:
            qs.update(
                deposit_type=int(deposit_type)
            )

        queryset = self.get_queryset().filter(**qs)
        return queryset

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        serializer_data = serializer.data
        if serializer_data:
            result.update(data=serializer.data)
        return result

    def list(self, request, *args, **kwargs):
        result = self.response_result
        timestamp_start = request.query_params.get('timestamp_start', None)
        timestamp_end = request.query_params.get('timestamp_end', None)

        if timestamp_start and not str(timestamp_start).isdigit():
            result.update(code=450,
                          detail='filter params invalid:[{}]'.format('timestamp_start'))
            return Response(result)

        if timestamp_end and not str(timestamp_end).isdigit():
            result.update(code=451,
                          detail='filter params invalid:[{}]'.format('timestamp_end'))
            return Response(result)
        return super(FiatCurrencyDepositRecordViewSet, self).list(request, *args, **kwargs)

    def do_destroy(self, request, *args, **kwargs):
        result = self.response_result
        user = request.user

        logger.info("request params: {}".format(request.__dict__))
        engine_sn = request.parser_context.get("kwargs").get("sn", None)
        if not engine_sn:
            result.update(
                code=451,
                detail="sn is required."
            )
            return result

        self.service.delete_record(engine_sn=engine_sn, user_id=user.user_id)
        return result


class FiatCreditCardInitViewSet(BetterCreateModelMixin, viewsets.GenericViewSet):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = FiatCreditCardDepositSerializer
    service = FiatCreditCardService()

    def do_create(self, request, serializer, *args, **kwargs):
        result = self.response_result
        user_ip = self.request.META.get('REMOTE_ADDR')
        user_id = self.request.user.user_id_hex
        user_birth = serializer.validated_data.get('birth')
        if not self.service.is_mobile_verified(user_id):
            result.update(code=454, detail='Please bind the mobile')
            return result

        default_birth = datetime.date(2037, 7, 7)
        kyc = KYCIndividualBirthService()
        is_level4, old_birth = kyc.get_birth(user_id)
        if not is_level4:
            result.update(code=451, detail='please pass kyc level4')
            return result
        # 输入的生日为默认值
        if user_birth == default_birth:
            result.update(code=452, detail='need user birthday')
            return result
        # 更新用户生日
        if old_birth != user_birth:
            if old_birth != default_birth:
                result.update(code=453, detail='wrong user birth')
                return result
            kyc.update_birth(user_id, user_birth)
        amount = serializer.validated_data.get('amount')
        now = datetime.datetime.now()
        today_start = datetime.datetime(now. year, now.month, now.day, 0, 0, 0, 0)
        daily_amount = FiatCurrencyDepositRecordLastThreeMonths.objects.filter(user_id=user_id,
                                                                               is_deleted=False,
                                                                               status__in=[FiatDepositStatus.COMPLETED, FiatDepositStatus.SIMPLEX_PENDING],
                                                                               updated_at__gte=today_start,
                                                                               updated_at__lt=now).exclude(simplex_fee=0).aggregate(Sum('amount'))
        if daily_amount and daily_amount['amount__sum']:
            daily_amount = daily_amount['amount__sum']
        else:
            daily_amount = 0
        if daily_amount + amount > SIMPLEX_DAILY_LIMIT:
            result.update(code=456, detail='daily deposit limit reached', left=SIMPLEX_DAILY_LIMIT - daily_amount)
            return result
        month_start = datetime.datetime(now.year, now.month, 1, 0, 0, 0, 0)
        monthly_amount = FiatCurrencyDepositRecordLastThreeMonths.objects.filter(user_id=user_id,
                                                                                 is_deleted=False,
                                                                                 status__in=[FiatDepositStatus.COMPLETED, FiatDepositStatus.SIMPLEX_PENDING],
                                                                                 updated_at__gte=month_start,
                                                                                 updated_at__lt=now).exclude(simplex_fee=0).aggregate(Sum('amount'))
        if monthly_amount and monthly_amount['amount__sum']:
            monthly_amount = monthly_amount['amount__sum']
        else:
            monthly_amount = 0
        if monthly_amount + amount > SIMPLEX_MONTHLY_LIMIT:
            result.update(code=457, detail='monthly deposit limit reached', left=SIMPLEX_MONTHLY_LIMIT - monthly_amount)
            return result
        # 生成token
        user_jwt_token = uuid.uuid4()
        # 用户url
        ref_url = self.request.META.get('HTTP_REFERER')
        # 计算费率
        fee = amount * Decimal(SIMPLEX_FEE_RATE)
        if fee < Decimal(SIMPLEX_FEE_MIN):
            fee = Decimal(SIMPLEX_FEE_MIN)
        # 向代理发送请求
        response_data = self.service.init_request(user_id, user_ip, ref_url, user_jwt_token,
                                                  serializer.validated_data.get('fiat_type'), amount, fee)
        if not response_data:
            result.update(code=500, detail="request failed")
        else:
            result.update(data=response_data)
        return result

    def create(self, request, *args, **kwargs):
        """用户请求信用卡充值

            request:

                {
                    "amount": 10,       //充值金额
                    "simplex_fee": 1,   //手续费
                    "fiat_type": 1,     //法币类型
                    "birth": 2018-07-07 //生日
                }

            response:

                {
                    "code": 201,
                    "detail": "ok",
                    "data": {
                                "version": "2",
                                "partner": "BTCC",
                                "payment_id": "696520f0-8f24-11e8-925c-e7aa6db15d5c",
                                "user_id": "992690",
                                "email": "737870378@qq.com",
                                "amount": 10010,
                                "currency": "USD",
                                "lastname": "HOMBO",
                                "phone": "+8615107174568",
                                "payment_flow_type": "deposit",
                                "return_url": "https://exchange-staging.btcc.com/account/deposit/usd/CreditCard",
                                "show_fee": True
                            }
                }

            response Code:

                Http Code | detail
                200       | ok
                451       | 用户kyc等级不是level4
                452       | 用户没有更新生日，输入的是默认值
                453       | 用户试图修改自己的生日
                454       | 用户没有绑定手机号
                455       | 用户低于充值限额
                456       | 用户高于充值限额
                500       | 请求simplex失败

        """
        return super(FiatCreditCardInitViewSet, self).create(request, *args, **kwargs)
