# -*- coding: utf-8 -*-
import logging
import uuid

import validators
from django.conf import settings
from rest_framework import permissions
from rest_framework import viewsets

from .filters import CryptoWithdrawCustomerVerifyFilter
from .filters import CryptoWithdrawFilter
from .throttles import TxRecordCommonThrottleDay
from .throttles import TxRecordCommonThrottleMinute
from maneki.apps.common.mixins.rest import BetterCreateModelMixin
from maneki.apps.common.mixins.rest import BetterListModelMixin
from maneki.apps.constants import WithdrawStatus, VerifyType, FreezeType
from maneki.apps.transaction.models import CryptoWithdrawRecordLastThreeMonths
from maneki.apps.transaction.services.crypto import CryptoWithdrawAddressService
from maneki.apps.transaction.services.crypto import CryptoWithdrawService
from maneki.apps.transaction.services.crypto import WithdrawRequestToEngineProducer
from maneki.apps.transaction.utils.date import format_time_duration
from maneki.apps.transaction.views.serializers.withdraw import CryptoWithdrawListSerializer
from maneki.apps.transaction.views.serializers.withdraw import CryptoWithdrawRequestSerializer
from maneki.apps.user.services import UserService
from maneki.apps.common.utils.redis.r import redis_sessions

logger = logging.getLogger(__name__)

# 提现：人工测试和自动测试开关
TEST_CRYPTO_WITHDRAW_DEBUG = redis_sessions["WithdrawSwitch"].get("WithdrawSwitch") if redis_sessions["WithdrawSwitch"].get("WithdrawSwitch") else 0


####################################################
#     数字代币(Crypto Currency) 交易: 提币
####################################################

class CryptoWithdrawRequestViewSet(BetterListModelMixin, BetterCreateModelMixin, viewsets.GenericViewSet):
    """数字货币 - POST: 提现请求 GET: 提现列表

    :note:
        1. 用户创建提现请求, 写表.
        2. 用户执行 2fa, email 验证,
        3. 验证通过, 更新表状态.


    """

    permission_classes = [permissions.IsAuthenticated]
    serializer_class = CryptoWithdrawRequestSerializer
    serializer_class_list = CryptoWithdrawListSerializer
    throttle_classes = [TxRecordCommonThrottleDay, TxRecordCommonThrottleMinute]
    filter_class = CryptoWithdrawFilter
    #
    lookup_url_kwarg = "engine_sn"
    #
    service = CryptoWithdrawService()

    def get_queryset(self):
        return CryptoWithdrawRecordLastThreeMonths.objects.filter(
            user_id=self.request.user.user_id,
            is_deleted=False,
        ).order_by("-updated_at")

    def filter_queryset(self, queryset):
        timestamp_start = self.request.query_params.get('timestamp_start', None)
        timestamp_end = self.request.query_params.get('timestamp_end', None)
        start_at, end_at = format_time_duration(timestamp_start, timestamp_end)
        queryset = self.get_queryset().filter(
            updated_at__gte=start_at,
            updated_at__lte=end_at,
        )
        queryset = super().filter_queryset(queryset)
        return queryset

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        # todo: qs maybe invalid
        result.update(
            data=serializer.data,
        )
        return result

    def do_create(self, request, serializer, instance, *args, **kwargs):
        result = self.response_result
        user = request.user

        logger.info("crypto withdraw: user={}".format(user.user_id_hex))

        coin_type = serializer.validated_data.get("coin_type")
        tx_address = serializer.validated_data.get("tx_address")
        tx_amount = serializer.validated_data.get("tx_amount")

        # TODO freeze account balance
        if settings.FREEZE_SWITCH:
            request_id = uuid.uuid4().hex
            fee = self.service.validate_tx_fee(coin_type=coin_type)
            is_freeze = self.service.freeze_cash(
                request_id=request_id,
                user=user,
                coin_type=coin_type,
                amount=tx_amount + fee,
                freeze_type=FreezeType.Freeze
            )
            if not is_freeze:
                result.update(code=451,
                              detail="assets freeze failed!")
                return result
            else:
                is_ok, code, detail = self.service.create_withdraw_request(
                    user_id=user.user_id,
                    coin_type=coin_type,
                    tx_address=tx_address,
                    tx_amount=tx_amount,
                    freeze_request_no=request_id,
                    freeze_status=FreezeType.Freeze,

                )
        else:

            is_ok, code, detail = self.service.create_withdraw_request(
                user_id=user.user_id,
                coin_type=coin_type,
                tx_address=tx_address,
                tx_amount=tx_amount,
            )

        if not is_ok:
            result.update(
                code=code,
                detail=detail
            )
            return result

        # TODO 用户校验选择: email+sms / email+2fa
        self.service.create_verify_process(user)

        result.update(
            data={
                "sn": detail.engine_sn,  # TODO: 用户登录, 可以在 user_profile 那里拿到 email/sms/2fa.
            },
        )
        return result

    def do_destroy(self, request, *args, **kwargs):
        result = self.response_result
        user = request.user
        # TODO: get from url_kwarg.
        engine_sn = self.request.query_params.get('engine_sn', None)
        if not engine_sn:
            result.update(
                code=451,
                detail="engine sn is required.",
            )
            return result

        self.service.delete_record(user_id=user.user_id, engine_sn=engine_sn)
        return result


class CryptoWithdrawRequestCustomerVerifyViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    """数字货币 - 提现请求审核 (用户操作)


    :note:
        1. 用户执行 2fa, email, sms 验证
        2. 验证通过, 更新表状态.
        3. task 丢 MQ,
        4. 引擎 RPC 调用.
        5. blockchain-proxy 打币出去

    """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = CryptoWithdrawRequestSerializer
    filter_class = CryptoWithdrawCustomerVerifyFilter
    throttle_classes = [TxRecordCommonThrottleDay, TxRecordCommonThrottleMinute]
    pagination_class = None
    #
    service = CryptoWithdrawService()
    address_service = CryptoWithdrawAddressService()
    producer = WithdrawRequestToEngineProducer()

    #
    def get_queryset(self):
        return CryptoWithdrawRecordLastThreeMonths.objects.filter(
            user_id=self.request.user.user_id,
            is_deleted=False,
        ).order_by("-updated_at")

    def filter_queryset(self, queryset):
        """修复 filter 问题, 必须写此方法

        :param queryset:
        :return:
        """
        return queryset

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        user = request.user

        sn = self.request.query_params.get('sn', None)
        email_code = self.request.query_params.get('email_code', None)
        #
        sms_code = self.request.query_params.get('sms_code', None)
        otp_code = self.request.query_params.get('otp_code', None)

        # 手机号 or 2fa 必须激活一个.
        if not any([user.mobile_verified, user.totp_device_verified]):
            result.update(
                code=450,
                detail="user should be activate a mobile phone or a 2fa device.",
            )
            return result

        # validate:
        if not all([sn, email_code]):
            result.update(
                code=451,
                detail="[sn, email_code] are required.",
            )
            return result

        if not any([sms_code, otp_code]):
            result.update(
                code=452,
                detail="sms_code or otp_code is required.",
                data={
                    "mobile_activated", user.mobile_verified,
                    "2fa_device_activated", user.totp_device_verified,
                },
            )
            return result
        #
        # ##########################################
        # validate uuid:
        #
        if not validators.uuid(sn):
            result.update(
                code=453,
                detail="sn is not uuid.",
            )
            return result

        record = self.service.filter_record(engine_sn=sn)
        if not record:
            result.update(
                code=454,
                detail="invalid sn.",
            )
            return result

        logger.info("withdraw request verify: user={}, params={},".format(request.user, self.request.query_params))

        # ##########################################
        # # ok:
        user_service = UserService()

        # email check:
        if not user_service.validate_email_verify_code(user, email_code):
            result.update(
                code=455,
                detail="invalid email verify code.",
            )
            return result

        # mobile check:
        is_sms_verified = user_service.validate_sms_verify_code(user, sms_code) if sms_code else False

        # otp check: device, is_exist, is_active
        otp_device, is_exist, is_active = user_service.user_2fa_device_status(user)
        otp_device = otp_device if is_active else None
        is_otp_verified = user_service.validate_otp_verify_code(otp_device, otp_code) if all([otp_device, otp_code]) else False

        #
        if not any([is_sms_verified, is_otp_verified]):
            result.update(
                code=456,
                detail="invalid [sms or otp(2fa)] verify code.",
            )
            return result

        # ##########################################
        # # ok: 提现限额检查
        min_check, max_check, all_check = self.service.validate_withdraw_limit(
            coin_type=record.coin_type,
            amount=record.tx_amount,
        )


        # if not max_check:
        if TEST_CRYPTO_WITHDRAW_DEBUG or not max_check:
            # 人工审核添加钉钉通知
            # 人工审核中
            self.service.update_verify_type(record=record, verify_type=VerifyType.STAFF_ACCESS)
            self.service.update_record_status(record=record, status=WithdrawStatus.REVIEW_PENDING)
            # TODO: 大额提现, cache for blockchain-proxy, 钱包余额预警
            #
            self.service.notify_withdraw_quest(record)
            result.update(
                code=202,
                detail="withdraw amount is greater than max limit, pending in manually review.",
            )
            return result

        ##########################################
        # 审核通过:
        # 更新记录状态
        self.service.update_record_status(record=record, status=WithdrawStatus.VERIFY_COMPLETED)
        logger.info('user withdraw verify finish:{}'.format(user.engine_account_id))
        ################################################
        # inner withdraw:
        ################################################
        logger.info("pre inner withdraw address: user={}, params={}".format(request.user, self.request.query_params))
        # if inner withdraw:
        is_ok, code, detail = self.service.is_inner_withdraw(record)
        # todo inner withdraw address type not match
        if code == 4500:
            result.update(code=code,
                          detail=detail)
            return result
        if is_ok:
            is_ok = self.service.inner_withdraw(withdraw_record=record)
            logger.info("inner withdraw: user={}, params={}".format(request.user, self.request.query_params))
            if not is_ok:
                logger.error("inner withdraw failed.")
                result.update(
                    code=457,
                    detail="withdraw failed, please contact us.",
                )
                return result

            logger.info("inner withdraw ok.")
            # ok:
            result.update(
                code=200,
                detail="ok",
            )
            return result
        logger.info("post inner withdraw address: user={}, params={}".format(request.user, self.request.query_params))

        ################################################
        # normal withdraw:
        ################################################
        # engine rpc + 打币
        # todo :withdraw engine with fee
        task = self.service.withdraw_engine_task_with_fee(record)
        self.producer.publish(task)

        result.update(
            code=200,
            detail="ok, withdraw pending...",
        )
        return result
