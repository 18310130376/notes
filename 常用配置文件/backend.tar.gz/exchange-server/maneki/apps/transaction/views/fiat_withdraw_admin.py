# -*- coding: utf-8 -*-
import logging
import uuid

from collections import OrderedDict

from django.conf import settings
from rest_framework import viewsets
from rest_framework import permissions
from django.db.models import Sum

from .throttles import TxRecordAdminThrottleDay
from maneki.apps.common.mixins.rest import BetterReadWriteViewSet, BetterListModelMixin
from maneki.apps.common.permissions.rest.permission_manage import StrictPermissionCheck
from maneki.apps.constants import WithdrawStatus, FreezeType

from maneki.apps.transaction.utils.date import format_time_duration
from maneki.apps.transaction.models import FiatCurrencyWithdrawRecordLastThreeMonths
from maneki.apps.transaction.services.fiat.withdraw import FiatWithdrawService
from maneki.apps.transaction.services.fiat.withdraw_worker import FiatWithDrawEngineProducer
from maneki.apps.transaction.views.filters.fiat_withdraw import FiatWithdrawAdminOutMoneyFilter
from maneki.apps.transaction.views.filters.fiat_withdraw import FiatWithdrawAdminVerifyFilter
from maneki.apps.transaction.views.filters.fiat_withdraw import FiatWithdrawRecordsAdminFilter

from maneki.apps.transaction.views.serializers.fiat_withdraw import FiatWithdrawAdminFianceReviewSerializer
from maneki.apps.transaction.views.serializers.fiat_withdraw import FiatWithdrawAdminListSerializer
from maneki.apps.transaction.views.serializers.fiat_withdraw import FiatWithdrawAdminReviewSerializer
from maneki.apps.transaction.views.serializers.fiat_withdraw import FiatCurrencyWithdrawRecordAdminListSerializer

from maneki.apps.user.models import User
logger = logging.getLogger(__name__)


class FiatWithdrawRequestAdminVerifyViewset(BetterReadWriteViewSet):
    """法币 -提现请求审核（客服管理员）GET:

    :note: 客服拉取待审核的提现请求列表，审核是否允许提现

    """
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]
    serializer_class_list = FiatWithdrawAdminListSerializer
    serializer_class = FiatWithdrawAdminReviewSerializer
    throttle_classes = [TxRecordAdminThrottleDay]
    filter_class = FiatWithdrawAdminVerifyFilter
    #
    service = FiatWithdrawService()
    producer = FiatWithDrawEngineProducer()

    def get_queryset(self):
        return FiatCurrencyWithdrawRecordLastThreeMonths.objects

    def do_list(self, request, serializer, *args, **kwargs):
        """拉取待审核记录
        """
        result = self.response_result
        result.update(data=serializer.data)
        return result

    def do_create(self, request, serializer, instance, *args, **kwargs):
        """修改记录状态
        """
        result = self.response_result

        engine_sn = serializer.validated_data.get("engine_sn")
        verify_status = serializer.validated_data.get("status")

        logger.info("admin verify - fiat withdraw request: {}".format(serializer.validated_data))

        # 校验无效状态
        if not self.service.validate_manual_check_status(verify_status):
            result.update(
                code=450,
                detail="invalid withdraw status.",
            )
            return result
        # 更新状态
        record = self.service.filter_record(engine_sn=engine_sn)
        if not record:
            result.update(
                code=451,
                detail="invalid withdraw sn.",
            )
            return result
        self.service.update_record_status(record=record, status=verify_status)

        if verify_status == WithdrawStatus.REVIEW_COMPLETED:
            msg = self.service.gen_fiat_withdraw_inbox_data(record=record)
            self.producer.publish(msg)
        else:
            # unfreeze balance
            if settings.FREEZE_SWITCH:
                request_id = uuid.uuid4()
                user = User.objects.filter(user_id=record.user_id).first()
                is_ok = self.service.freeze_cash(
                    request_id=request_id.hex,
                    user=user,
                    coin_type=record.fiat_type,
                    amount=record.amount + record.service_charge,
                    freeze_type=FreezeType.UNFREEZE,
                )
                if not is_ok:
                    result.update(
                        code=452,
                        detail='unfreeze failed!'
                    )
                    return result
                record.freeze_request_no = request_id
                record.freeze_status = FreezeType.UNFREEZE
                record.save()
        return result


class FiatWithdrawRequestAdminOutMoneyViewset(BetterReadWriteViewSet):
    """法币 -提现请求出款（财务）GET:

       :note:

       """
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]
    serializer_class_list = FiatWithdrawAdminListSerializer
    serializer_class = FiatWithdrawAdminFianceReviewSerializer
    filter_class = FiatWithdrawAdminOutMoneyFilter
    throttle_classes = [TxRecordAdminThrottleDay]
    #
    service = FiatWithdrawService()
    producer = FiatWithDrawEngineProducer()
    model = FiatCurrencyWithdrawRecordLastThreeMonths

    def get_queryset(self):
        return FiatCurrencyWithdrawRecordLastThreeMonths.objects

    def do_list(self, request, serializer, *args, **kwargs):
        """拉取待审核记录
        """
        result = self.response_result
        result.update(data=serializer.data)
        return result

    def do_create(self, request, serializer, instance, *args, **kwargs):
        """修改记录状态
        """
        result = self.response_result

        engine_sn = serializer.validated_data.get("engine_sn")
        verify_status = serializer.validated_data.get("status")
        out_money_sn = serializer.validated_data.get("out_money_bank_sn")

        # 更新状态
        record = self.service.filter_record(engine_sn=engine_sn, status=WithdrawStatus.ENGINE_COMPLETED)
        if not record:
            result.update(
                code=451,
                detail="ERROR TO FOUND RECORD",
            )
            return result

        if verify_status == WithdrawStatus.OUT_MONEY_FAILED:
            out_money_sn = ""

        if verify_status == WithdrawStatus.OUT_MONEY_COMPLETED:
            found = self.service.filter_withdraw_out_money_sn(out_money_sn)
            if found:
                result.update(
                    code=452,
                    detail="bank_sn exist",
                )
                return result

        self.service.update_out_money_sn(record, verify_status, out_money_sn)
        return result


# 法币提现对账:
class FiatCurrencyWithdrawRecordAdminViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    """ 法币提现
    """
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]
    filter_class = FiatWithdrawRecordsAdminFilter
    serializer_class_list = FiatCurrencyWithdrawRecordAdminListSerializer
    throttle_classes = [TxRecordAdminThrottleDay]

    def get_queryset(self):
        return FiatCurrencyWithdrawRecordLastThreeMonths.objects

    def filter_queryset(self, queryset=None):
        timestamp_start = self.request.query_params.get('timestamp_start')
        timestamp_end = self.request.query_params.get('timestamp_end')
        fiat_type = self.request.query_params.get('fiat_type', None)
        start_at, end_at = format_time_duration(timestamp_start, timestamp_end)
        user_email = self.request.query_params.get('email')
        out_money_bank_sn = self.request.query_params.get('out_money_bank_sn')
        condition = {
            'status': WithdrawStatus.COMPLETED
        }
        condition.update(
            updated_at__gte=start_at,
            updated_at__lt=end_at,
        )

        if fiat_type is not None:
            condition.update(
                fiat_type=fiat_type
            )

        if user_email:
            user_obj = User.objects.filter(email=user_email).first()
            if user_obj:
                condition.update(
                    user_id=user_obj.user_id,
                )

        if out_money_bank_sn:
            condition.update(
                out_money_bank_sn=out_money_bank_sn
            )

        condition = {k: v for k, v in condition.items() if v is not None}
        qs = self.get_queryset().filter(**condition)
        return qs

    def do_list(self, request, serializer, *args, **kwargs):
        """ 法币提现对账
        """
        result = self.response_result

        # 过滤 时间段, email, engine_sn 可以自定义错误码
        # 过滤起始时间
        timestamp_start = request.query_params.get('timestamp_start', None)
        timestamp_end = request.query_params.get('timestamp_end', None)

        if timestamp_start and not str(timestamp_start).isdigit():
            result.update(code=450, detail='filter params invalid:[{}]'.format('timestamp_start'))
            return result

        if timestamp_end and not str(timestamp_end).isdigit():
            result.update(code=451, detail='filter params invalid:[{}]'.format('timestamp_end'))
            return result

        data = {
            'service_charges': self.filter_queryset().aggregate(Sum('service_charge')).get('service_charge__sum', 0),
        }
        result.update(data=data)
        return result

    def do_pagination(self, page, request, *args, **kwargs):
        serializer = self._do_serializer(page, many=True, func_type="list")
        # hook for task:
        result = self.do_list(request, serializer, *args, **kwargs)
        if result.get("code") == 200:
            data = result.get('data', {})
            service_charges = data.get('service_charges', 0)
            result.update(
                data=OrderedDict([
                    ('count', self.paginator.count),
                    ('next', self.paginator.get_next_link()),
                    ('previous', self.paginator.get_previous_link()),
                    ('service_charges', service_charges),
                    ('results', serializer.data)
                ])
            )
        return result
