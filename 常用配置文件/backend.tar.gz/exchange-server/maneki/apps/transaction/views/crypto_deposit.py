# -*- coding:utf-8 -*-
import logging
from rest_framework import permissions
from rest_framework import viewsets

from maneki.apps.common.utils.format_timestamp import format_timestamp
from .filters import CryptoDepositFilter
from .throttles import TxRecordCommonThrottleDay, TxRecordCommonThrottleMinute
from maneki.apps.transaction.models import CryptoDepositRecordLastThreeMonths
from maneki.apps.transaction.views.serializers import CryptoCurrencyDepositSerializer, ValidationError450, \
    ValidationError451
from maneki.apps.common.mixins.rest.mixins import BetterListModelMixin
from maneki.apps.transaction.services.crypto.deposit import CryptoDepositService

logger = logging.getLogger(__name__)


####################################################
#     数字代币(Crypto Currency) 交易: 充值
####################################################


# 充值记录
class CryptoCurrencyDepositViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    """GET: 充值记录列表
                    Get User deposit record


                          :param
                            {
                                [url example transactions/crypto/deposit/?sdate=1521081678000&edate=1521081678000&]
                                no sdate  get 1 day record by default
                            }
                            status:
                            -1  - -3  # 失败
                            0<4        # pending
                            0         # 最终完成状态
                            CoinType define
                            UNDEFINED = ChoiceItem(-1, 'Undefined')
                            BTC = ChoiceItem(0, 'BTC')
                            ETC = ChoiceItem(1, 'ETC')
                            ETH = ChoiceItem(2, 'ETH')
                            BCH = ChoiceItem(3, 'BCH')
                            ICO = ChoiceItem(4, 'ICO')
                            REP = ChoiceItem(5, 'REP')


                            :return 200
                            {
                                "data": [
                                    {
                                        "updated_at": 2018-07-06 09:00:04"
                                        "coin_type": 0,
                                        "tx_amount": "msTX2A2UegcmqApb5Q1qavcpBhWG423xTL"
                                        "tx_fee": 0.02
                                        "tx_address":"msTX2A2UegcmqApb5Q1qavcpBhWG423xTL"
                                        "status": 0
                                    },....
                                ]
                            }


                             or 4xx 5xxfor failed
                """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = CryptoCurrencyDepositSerializer
    filter_class = CryptoDepositFilter
    throttle_classes = [TxRecordCommonThrottleDay, TxRecordCommonThrottleMinute]
    #
    service = CryptoDepositService()
    lookup_url_kwarg = "sn"

    def get_queryset(self):
        user = self.request.user
        return CryptoDepositRecordLastThreeMonths.objects.filter(
            user_id=user.user_id,
            is_deleted=False
        ).order_by("-updated_at")

    def filter_queryset(self, queryset):
        # 过滤 时间段, user_id, sn, status 可以自定义错误码
        # 过滤起始时间
        timestamp_start = self.request.query_params.get('timestamp_start', None)
        if timestamp_start and not str(timestamp_start).isdigit():
            raise ValidationError450(detail='filter params invalid:[{}]'.format('timestamp_start'))
        timestamp_start = format_timestamp(timestamp=timestamp_start)

        queryset = queryset.filter(updated_at__gte=timestamp_start)
        # 过滤结束时间
        timestamp_end = self.request.query_params.get('timestamp_end', None)
        if timestamp_end and not str(timestamp_end).isdigit():
            raise ValidationError451(detail='filter params invalid:[{}]'.format('timestamp_end'))
        timestamp_end = format_timestamp(timestamp_end, timedelta_day=0)
        queryset = queryset.filter(updated_at__lte=timestamp_end)
        queryset = super().filter_queryset(queryset)
        return queryset

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        # todo: qs maybe invalid
        result.update(
            data=serializer.data,
        )
        return result

    def do_destroy(self, request, *args, **kwargs):
        result = self.response_result
        engine_sn = self.request.query_params.get('engine_sn', None)

        if not engine_sn:
            result.update(
                code=451,
                detail="engine sn is required.",
            )
            return result

        # todo do delete
        return result
