# -*- coding:utf-8 -*-
import logging
import uuid

from rest_framework import permissions
from rest_framework import viewsets
from django.conf import settings
from maneki.apps.common.mixins.rest import ValidationError450, ValidationError451
from maneki.apps.common.utils.format_timestamp import format_timestamp
from maneki.apps.constants import WithdrawStatus, FreezeType
from maneki.apps.transaction.services.crypto import CryptoWithdrawService
from maneki.apps.transaction.services.fiat.withdraw import FiatWithdrawService
from maneki.apps.transaction.models import FiatCurrencyWithdrawRecordLastThreeMonths
from maneki.apps.transaction.views.serializers.fiat_withdraw import FiatWithdrawRequestSerializer
from maneki.apps.transaction.views.serializers.fiat_withdraw import FiatWithdrawRecordSerializer
from maneki.apps.common.mixins.rest.mixins import BetterCreateModelMixin
from maneki.apps.common.mixins.rest.mixins import BetterListModelMixin
from maneki.apps.transaction.services.fiat.withdraw_worker import FiatWithDrawEngineProducer
from maneki.apps.user.services import UserService
from .filters.fiat_withdraw import FiatWithdrawFilter, FiatWithdrawCustomerVerifyFilter
from .throttles import TxRecordCommonThrottleMinute, TxRecordCommonThrottleDay

logger = logging.getLogger(__name__)


####################################################
#     法币(Fiat Currency) 交易: 提现
####################################################


# fiat提现申请:
class FiatCurrencyWithdrawView(BetterCreateModelMixin, BetterListModelMixin, viewsets.GenericViewSet):
    """法币提现请求：GET: 记录列表 POST: 创建提现请求
    :param
    :return 200
    """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class_list = FiatWithdrawRecordSerializer
    serializer_class = FiatWithdrawRequestSerializer
    filter_class = FiatWithdrawFilter
    throttle_classes = [TxRecordCommonThrottleDay, TxRecordCommonThrottleMinute]

    lookup_url_kwarg = "engine_sn"
    #
    service = FiatWithdrawService()

    def get_queryset(self):
        return FiatCurrencyWithdrawRecordLastThreeMonths.objects

    def filter_queryset(self, queryset):
        queryset = queryset.filter(is_deleted=False).filter(user_id=self.request.user.user_id).order_by('-updated_at')
        # 过滤 时间段, user_id, sn, status 可以自定义错误码
        # 过滤起始时间
        timestamp_start = self.request.query_params.get('timestamp_start', None)
        if timestamp_start and not str(timestamp_start).isdigit():
            raise ValidationError450(detail='filter params invalid:[{}]'.format('timestamp_start'))
        timestamp_start = format_timestamp(timestamp=timestamp_start)

        queryset = queryset.filter(updated_at__gte=timestamp_start)
        # 过滤结束时间
        timestamp_end = self.request.query_params.get('timestamp_end', None)
        if timestamp_end and not str(timestamp_end).isdigit():
            raise ValidationError451(detail='filter params invalid:[{}]'.format('timestamp_end'))
        timestamp_end = format_timestamp(timestamp_end, timedelta_day=0)
        queryset = queryset.filter(updated_at__lte=timestamp_end)
        queryset = super().filter_queryset(queryset)
        return queryset

    def do_create(self, request, serializer, instance, *args, **kwargs):
        result = self.response_result
        # 用户校验邮箱，SMS和2fa二选一
        user = request.user
        # todo: check_exist_pending_withdraw()
        fiat_type = serializer.validated_data.get('fiat_type')
        is_exist = self.service.check_pending_withdraw(user_id=user.user_id, fiat_type=fiat_type)
        if is_exist:
            result.update(
                code=452,
                detail="pending withdraw record is exist, not allow new withdraw request."
            )
            return result
        # todo 冻结资金(包含fee)
        if settings.FREEZE_SWITCH:
            request_id = uuid.uuid4()
            is_freeze = self.service.freeze_cash(
                request_id=request_id.hex,
                user=user,
                coin_type=fiat_type,
                amount=serializer.validated_data.get('amount') + serializer.validated_data.get('service_charge'),
                freeze_type=FreezeType.Freeze
            )
            if not is_freeze:
                result.update(code=451,
                              detail="assets freeze failed!")
                return result
            reocrd = self.service.create_record(fiat_type=fiat_type,
                                                amount=serializer.validated_data.get('amount'),
                                                bank_account=serializer.validated_data.get('bank_account'),
                                                user_id=serializer.validated_data.get('user_id'),
                                                beneficiary_name=serializer.validated_data.get('beneficiary_name'),
                                                service_charge=serializer.validated_data.get('service_charge'),
                                                status=serializer.validated_data.get('status'),
                                                freeze_request_no=request_id,
                                                freeze_status=FreezeType.Freeze,
                                                )
        else:
            reocrd = self.service.create_record(fiat_type=fiat_type,
                                                amount=serializer.validated_data.get('amount'),
                                                bank_account=serializer.validated_data.get('bank_account'),
                                                user_id=serializer.validated_data.get('user_id'),
                                                beneficiary_name=serializer.validated_data.get('beneficiary_name'),
                                                service_charge=serializer.validated_data.get('service_charge'),
                                                status=serializer.validated_data.get('status')
                                                )
        service = CryptoWithdrawService()  # TODO
        service.create_verify_process(user)
        result.update(data={'sn': reocrd.engine_sn})
        return result

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        # todo: qs maybe invalid
        result.update(
            data=serializer.data,
        )
        return result

    def do_destroy(self, request, *args, **kwargs):
        result = self.response_result

        # Todo:
        engine_sn = self.request.query_params.get('engine_sn', None)
        if engine_sn:
            result.update(
                code=451,
                detail="engine sn is required.",
            )
            return result

        #
        is_ok = self.service.delete_record(engine_sn=engine_sn)
        if not is_ok:
            result.update(
                code=452,
                detail="invalid engine sn.",
            )
            return result
        return result


class FiatWithdrawRequestCustomerVerifyViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    """法币 - 提现请求审核 (用户操作)


    :note:
        1. 用户执行 2fa, email, sms 验证
        2. 验证通过, 更新表状态.
        3. task 丢 MQ,
        4. 引擎 RPC 调用.
        5. blockchain-proxy 打币出去

    """
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = FiatWithdrawRequestSerializer
    filter_class = FiatWithdrawCustomerVerifyFilter
    throttle_classes = [TxRecordCommonThrottleDay, TxRecordCommonThrottleMinute]
    pagination_class = None
    #
    service = FiatWithdrawService()
    producer = FiatWithDrawEngineProducer()

    def get_queryset(self):
        return FiatCurrencyWithdrawRecordLastThreeMonths.objects.filter(
            user_id=self.request.user.user_id,
            is_deleted=False,
        ).order_by("-updated_at")

    def filter_queryset(self, queryset):
        """修复 filter 问题, 必须写此方法

        :param queryset:
        :return:
        """
        return queryset

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        user = request.user

        sn = self.request.query_params.get('sn', None)
        email_code = self.request.query_params.get('email_code', None)
        #
        sms_code = self.request.query_params.get('sms_code', None)
        otp_code = self.request.query_params.get('otp_code', None)

        # 手机号 or 2fa 必须激活一个.
        if not any([user.mobile_verified, user.totp_device_verified]):
            result.update(
                code=450,
                detail="user should be activate a mobile phone or a 2fa device.",
            )
            return result

        # validate:
        if not all([sn, email_code]):
            result.update(
                code=451,
                detail="[sn, email_code] are required.",
            )
            return result

        if not any([sms_code, otp_code]):
            result.update(
                code=452,
                detail="sms_code or otp_code is required.",
                data={
                    "mobile_activated", user.mobile_verified,
                    "2fa_device_activated", user.totp_device_verified,
                }
            )
            return result

        ##########################################
        record = self.service.filter_record(engine_sn=sn)
        if not record:
            result.update(
                code=453,
                detail="invalid sn.",
            )
            return result

        ##########################################
        # ok:
        user_service = UserService()

        # email check:
        if not user_service.validate_email_verify_code(user, email_code):
            result.update(
                code=454,
                detail="invalid email verify code.",
            )
            return result

        # mobile check:
        is_sms_verified = user_service.validate_sms_verify_code(user, sms_code) if sms_code else False

        # otp check: device, is_exist, is_active
        otp_device, is_exist, is_active = user_service.user_2fa_device_status(user)
        otp_device = otp_device if is_active else None
        is_otp_verified = user_service.validate_otp_verify_code(otp_device, otp_code) if all([otp_device, otp_code]) else False

        #
        if not any([is_sms_verified, is_otp_verified]):
            result.update(
                code=455,
                detail="invalid [sms or otp(2fa)] verify code.",
            )
            return result

        ##########################################
        # ok: 提现限额检查Fiat
        min_check, max_check, all_check = self.service.validate_withdraw_limit(
            fiat_type=record.fiat_type,
            amount=record.amount,
        )

        if not max_check:
            # 人工审核中
            self.service.update_record_status(record=record, status=WithdrawStatus.REVIEW_PENDING)
            # TODO: 大额提现, 钱包余额预警
            #
            result.update(
                code=202,
                detail="withdraw amount is greater than max limit, pending in manually review.",
            )
            return result

        ##########################################
        # 审核通过:
        # 更新记录状态
        self.service.update_record_status(record=record, status=WithdrawStatus.VERIFY_COMPLETED)
        # engine rpc + 打币
        # 建立fiat 提现task 丢到mq中
        logger.info('user_id:{}'.format(self.request.user.user_id.hex))
        msg = self.service.gen_fiat_withdraw_inbox_data(
            serializer.data,
            user_id=self.request.user.user_id.hex,
            record=record,
        )
        self.producer.publish(msg)

        result.update(
            code=200,
            detail="ok, withdraw pending..."
        )
        return result
