# -*- coding:utf-8 -*-
from django.conf import settings
from rest_framework import exceptions
from rest_framework import mixins
from rest_framework import serializers
from rest_framework import status
from rest_framework import viewsets
from rest_framework.response import Response


class ExchangeSerializer(serializers.ModelSerializer):
    class Meta:
        model = "xxx_model"
        fields = (
            "exchange_name", "exchange_id",
        )


class ExchangeViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = "xxx_model"

    def retrieve(self, request, *args, **kwargs):
        return Response("hello exchange retrieve")

    def list(self, request, *args, **kwargs):
        return Response("hello exchange")


# 交易所-资金变动记录:
class ExchangeBalanceViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = "xxx_model"

    def retrieve(self, request, *args, **kwargs):
        return Response("retrieve: exchange balance")

    def list(self, request, *args, **kwargs):
        return Response("list: exchange balance")


# 交易历史: 买入/卖出
class ExchangeTradeHistoryViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = "xxx_model"

    def retrieve(self, request, *args, **kwargs):
        return Response("retrieve: exchange trade history")

    def list(self, request, *args, **kwargs):
        return Response("list: exchange trade history")
