# -*- coding:utf-8 -*-
from django.conf import settings
from rest_framework import exceptions
from rest_framework import mixins
from rest_framework import serializers
from rest_framework import status
from rest_framework import viewsets
from rest_framework.response import Response


class BotSerializer(serializers.ModelSerializer):
    class Meta:
        model = "xxx_model"
        fields = (
            "bot", "bot_id", "...",
        )


# API:
class BotViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = "xxx_model"

    def retrieve(self, request, *args, **kwargs):
        return Response("hello")

    def list(self, request, *args, **kwargs):
        return Response("hello")
