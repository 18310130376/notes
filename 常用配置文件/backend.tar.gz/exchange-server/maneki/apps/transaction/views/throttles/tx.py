from rest_framework.throttling import UserRateThrottle


class WithdrawAddressMinuteThrottle(UserRateThrottle):
    scope = 'minute_slow'


class WithdrawAddressHourThrottle(UserRateThrottle):
    scope = 'hour_normal'


class TxRecordCommonThrottleMinute(UserRateThrottle):
    scope = 'tx_record_common_minute'


class TxRecordCommonThrottleDay(UserRateThrottle):
    scope = 'tx_record_common_day'


class TxRecordAdminThrottleDay(UserRateThrottle):
    scope = 'tx_record_admin'
