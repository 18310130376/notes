# -*- coding: utf-8 -*-
from decimal import Decimal

from rest_framework import serializers

from maneki.apps.common.mixins.rest import ValidationError450
from maneki.apps.constants import FiatType, FiatServiceChargeMin
from maneki.apps.constants import WithdrawStatus, FiatWithdrawAllowStatus, FiatWithdrawFianceAllowStatus
from maneki.apps.transaction.models.fiat_currency import FiatCurrencyWithdrawRecordLastThreeMonths
from maneki.apps.assets.models.fiat_accounts import UserFiatAccount
from maneki.apps.assets.exceptions import UserFiatAccountNotFound
from maneki.apps.transaction.services.fiat.withdraw import FiatWithdrawService


class FiatWithdrawRecordSerializer(serializers.ModelSerializer):
    fiat_type = serializers.IntegerField()
    amount = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)
    bank_label = serializers.CharField(max_length=255)
    bank_code = serializers.CharField()
    bank_account = serializers.CharField(max_length=255)
    status = serializers.IntegerField(default=WithdrawStatus.UNDEFINED)
    engine_sn = serializers.UUIDField()
    engine_request_no = serializers.UUIDField()
    amount_fmt = serializers.CharField()

    class Meta:
        model = FiatCurrencyWithdrawRecordLastThreeMonths
        fields = ('fiat_type', 'amount', 'bank_label', 'bank_code', 'bank_account', 'status',
                  'updated_at', 'engine_sn', 'engine_request_no', 'verify_detail', 'amount_fmt',
                  'service_charge_fmt')


class FiatWithdrawRequestSerializer(serializers.ModelSerializer):
    fiat_type = serializers.ChoiceField(FiatType.choices, required=True)
    amount = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20, required=True)
    bank_account = serializers.CharField(max_length=255, required=True)

    def validate(self, attrs):
        """
        :param attrs:
                    {
                        "fiat_type": 1,
                        "amount": 100,
                        "bank_account": "",
                }
        :return:
        """
        # TODO：实时校验提现账户
        fiat_type = attrs.get('fiat_type')
        amount = attrs.get('amount')
        user = self.context['request'].user

        # Todo: 提现限额检测
        min_check, max_check, all_check = self.Meta.service.validate_withdraw_limit(
            fiat_type=fiat_type,
            amount=amount,
        )

        if not min_check:
            raise ValidationError450(detail="withdraw amount must be greater than min limit.")
        # 用户是否有该银行卡
        account = UserFiatAccount.objects.filter(
            user_id=user.user_id, bank_account=attrs['bank_account'],
            fiat_type=attrs['fiat_type'], is_deleted=False).first()
        if not account:
            raise UserFiatAccountNotFound
        attrs.update(user_id=user.user_id)
        attrs.update(beneficiary_name=account.beneficiary_name)
        # service_fee
        min_fee_limit, min_fee, beyond_rate = FiatServiceChargeMin.get(fiat_type)
        if amount > min_fee_limit:
            service_charge = amount * Decimal(beyond_rate)
        else:
            service_charge = min_fee
        attrs.update(service_charge=service_charge)
        # 用户审核状态
        attrs.update(status=WithdrawStatus.VERIFY_PENDING)
        # 校验用户资产（待完善）
        return attrs

    class Meta:
        model = FiatCurrencyWithdrawRecordLastThreeMonths
        fields = ('fiat_type', 'amount', 'bank_account')

        service = FiatWithdrawService()


# 提现人工审核 list:
class FiatWithdrawAdminListSerializer(serializers.ModelSerializer):
    uid = serializers.CharField(source="user_id_hex")
    amount = serializers.CharField(source="amount_fmt")
    fee = serializers.CharField(source="service_charge_fmt")
    #
    sn = serializers.CharField(source="engine_sn_id")
    order_no = serializers.CharField(source="engine_request_no_id")

    class Meta:
        model = FiatCurrencyWithdrawRecordLastThreeMonths
        # fields = "__all__"
        fields = [
            "uid",
            #
            "sn",
            "order_no",
            #
            'fiat_type',
            "amount",
            "fee",
            "total",
            #
            'bank_name', 'bank_swift_code', 'bank_account',
            'bank_address', 'beneficiary_address',
            'status',
            'updated_at',
            'verify_detail',
            'beneficiary_name',
            'via_bank_name',
            'via_bank_address',
            'via_bank_swift_code'
        ]


# 提现人工审核 create:
class FiatWithdrawAdminReviewSerializer(serializers.ModelSerializer):
    engine_sn = serializers.UUIDField()
    status = serializers.ChoiceField(FiatWithdrawAllowStatus.choices)

    class Meta:
        model = FiatCurrencyWithdrawRecordLastThreeMonths
        fields = (
            "engine_sn", "status",
        )


# 提现财务审核 create:
class FiatWithdrawAdminFianceReviewSerializer(serializers.ModelSerializer):
    engine_sn = serializers.UUIDField()
    status = serializers.ChoiceField(FiatWithdrawFianceAllowStatus.choices)
    out_money_bank_sn = serializers.CharField(required=False)

    class Meta:
        model = FiatCurrencyWithdrawRecordLastThreeMonths
        fields = (
            "engine_sn", "status", "out_money_bank_sn"
        )


####################################################
#     法币(Fiat Currency) 交易: 提现
####################################################
# 提现记录列表
class FiatCurrencyWithdrawRecordAdminListSerializer(serializers.ModelSerializer):
    class Meta:
        model = FiatCurrencyWithdrawRecordLastThreeMonths
        fields = ('fiat_type', 'user_email', 'updated_at',
                  'amount', 'service_charge', 'out_money_bank_sn')
