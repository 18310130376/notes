# -*- coding:utf-8 -*-
from rest_framework import serializers

from maneki.apps.common.mixins.rest import ValidationError451, ValidationError450
from maneki.apps.constants import CoinType
from maneki.apps.transaction.models.crypto_currency_address import CryptoDepositAddress
from maneki.apps.transaction.models.crypto_currency_address import CryptoWithdrawAddress
from maneki.apps.transaction.services.crypto import CryptoWithdrawAddressService
from maneki.apps.transaction.services.crypto.deposit_address import CryptoDepositAddressService
from maneki.apps.transaction.utils.exceptions import AddressDuplicated, AddressUsedByDeposit
from maneki.apps.transaction.utils.exceptions import AddressInvalidFormat
from maneki.apps.transaction.utils.validate import validate_address


# 充值地址:
class CoinDepositAddressSerializer(serializers.ModelSerializer):
    # coin_type = serializers.IntegerField()
    # address = serializers.CharField()

    class Meta:
        model = CryptoDepositAddress
        fields = ('coin_type', 'address',)


# 提现地址create:
class CoinWithdrawAddressCreateSerializer(serializers.ModelSerializer):
    coin_type = serializers.ChoiceField(CoinType.choices, required=True)
    address = serializers.CharField(required=True)
    label = serializers.CharField(required=True)

    class Meta:
        model = CryptoWithdrawAddress
        fields = (
            'coin_type', 'address',
            'label',
        )


# 提现地址list:
class CoinWithdrawAddressListSerializer(serializers.ModelSerializer):
    coin_type = serializers.ChoiceField(CoinType.choices)
    address = serializers.CharField()
    label = serializers.CharField()

    class Meta:
        model = CryptoWithdrawAddress
        fields = (
            'coin_type', 'address',
            'updated_at', 'id',
            'label',
        )


# 提现地址list:
class CoinWithdrawAddressDestroySerializer(serializers.ModelSerializer):
    coin_type = serializers.ChoiceField(CoinType.choices)
    address = serializers.CharField()

    class Meta:
        model = CryptoWithdrawAddress
        fields = (
            'coin_type', 'address',
        )
