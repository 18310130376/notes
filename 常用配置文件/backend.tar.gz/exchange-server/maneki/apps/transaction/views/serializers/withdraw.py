# -*- coding:utf-8 -*-
import logging
from rest_framework import serializers

from maneki.apps.constants import CoinType
from maneki.apps.constants import WithdrawAddressStatus
from maneki.apps.constants import CryptoWithdrawAllowStatus
from maneki.apps.transaction.models import CryptoWithdrawAddress
from maneki.apps.transaction.models import CryptoWithdrawRecordLastThreeMonths
from maneki.apps.transaction.utils.exceptions import WithdrawInvalidAddress

logger = logging.getLogger(__name__)


####################################################
#     数字代币(Crypto Currency) 交易: 提币
####################################################
# 提现:
class CryptoCurrencyWithdrawSerializer(serializers.ModelSerializer):
    coin_type = serializers.ChoiceField(CoinType.choices)
    tx_amount = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)
    tx_fee = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)
    tx_address = serializers.CharField(label=u'tx address', max_length=100)

    class Meta:
        model = CryptoWithdrawRecordLastThreeMonths
        fields = (
            "tx_address", "tx_amount", "tx_fee", "coin_type", "updated_at", "id",
        )


# 提现请求序列化:
class CryptoCurrencyWithdrawRequestSerializer(serializers.ModelSerializer):
    coin_type = serializers.ChoiceField(CoinType.choices, required=True)
    tx_amount = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20, required=True)
    tx_address = serializers.CharField(label=u'tx address', max_length=100, required=True)

    def validate(self, data):
        # TODO: merge this to util , may remove the,
        # TODO：发现提币地址不存在,应该实时校验和存储,不应返回错误,设置地址和请求withdraw应该可以在一个请求中完成

        user = self.context['request'].user
        # 提币地址是否存在
        exists = CryptoWithdrawAddress.objects.filter(
            user_id=user.user_id,
            coin_type=data['coin_type'],
            # address_type=0,
            status=WithdrawAddressStatus.NORMAL,
            address=data['tx_address'],
        )
        if not exists:
            raise WithdrawInvalidAddress

        # 用户账户中是否有这个币种的地址，#TODO:以及用户余额的校验
        # exists = CryptoDepositAddress.objects.filter(
        #     user_id=user.profile.user_id,
        #     coin_type=data['coin_type'],
        #     status=DepositAddressStatus.ASSIGNED,
        #     # address=data['tx_address'],
        # ).first()
        # if not exists:
        #     raise UserInvalidAddress
        # TODO:这里需要把初始化状态设置为用户审核
        # data['tx_address'] = exists.address

        return data

    class Meta:
        model = CryptoWithdrawRecordLastThreeMonths
        fields = (
            "tx_address", "tx_amount", "coin_type", "engine_sn", "updated_at", "status"
        )


# 提现请求序列化:
class CryptoWithdrawRequestSerializer(serializers.ModelSerializer):
    coin_type = serializers.ChoiceField(CoinType.choices, required=True)
    tx_amount = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20, required=True)
    tx_address = serializers.CharField(min_length=0, max_length=64, required=True)

    class Meta:
        model = CryptoWithdrawRecordLastThreeMonths
        fields = (
            "tx_address", "tx_amount", "coin_type",
        )


# withdraw list:
class CryptoWithdrawListSerializer(serializers.ModelSerializer):
    class Meta:
        model = CryptoWithdrawRecordLastThreeMonths
        # fields = "__all__"
        exclude = [
            "created_at", "deleted_at", "is_deleted",
            "engine_request_no", "engine_code",
        ]


# 提现人工审核 list:
class CryptoWithdrawAdminListSerializer(serializers.ModelSerializer):
    uid = serializers.CharField(source="user_id_hex")
    amount = serializers.CharField(source="tx_amount_fmt")
    fee = serializers.CharField(source="tx_fee_fmt")
    #
    sn = serializers.CharField(source="engine_sn_id")
    order_no = serializers.CharField(source="engine_request_no_id")
    accessor = serializers.CharField()
    verify_type = serializers.IntegerField()

    class Meta:
        model = CryptoWithdrawRecordLastThreeMonths
        # fields = "__all__"
        fields = [
            "uid",
            #
            "sn",
            "order_no",
            #
            "tx_id",
            "tx_address",
            #
            "tx_total",
            "amount",
            "fee",
            #
            "coin_type",
            "confirmations",
            "status",
            "updated_at",
            'verify_detail',
            'accessor',
            'verify_type',
            'user_email',
            'username',
        ]


# 提现人工审核 create:
class CryptoWithdrawAdminReviewSerializer(serializers.ModelSerializer):
    engine_sn = serializers.UUIDField()
    status = serializers.ChoiceField(CryptoWithdrawAllowStatus.choices)

    class Meta:
        model = CryptoWithdrawRecordLastThreeMonths
        fields = (
            "engine_sn", "status",
        )


class CryptoWithdrawAdminSwitchSerializer(serializers.ModelSerializer):
    access_switch = serializers.CharField()

    class Meta:
        model = CryptoWithdrawRecordLastThreeMonths
        fields = ("access_switch",)
