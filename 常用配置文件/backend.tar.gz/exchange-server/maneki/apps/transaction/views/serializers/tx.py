# -*- coding:utf-8 -*-
from rest_framework import serializers

from maneki.apps.constants import CoinType, FiatType, FiatDepositAllowStatus, WithdrawStatus, FiatDepositStatus
from maneki.apps.transaction.models import CryptoDepositRecordLastThreeMonths
from maneki.apps.transaction.models import FiatCurrencyDepositRecord, FiatCurrencyDepositRecordLastThreeMonths
from maneki.apps.transaction.models import FiatCurrencyWithdrawRecord


####################################################
#     数字代币(Crypto Currency) 交易: 充值
####################################################


# 充值:
class CryptoCurrencyDepositSerializer(serializers.ModelSerializer):
    coin_type = serializers.ChoiceField(CoinType.choices)
    tx_amount = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)
    tx_fee = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)
    tx_address = serializers.CharField(label=u'address', max_length=100)
    status = serializers.IntegerField(label=u'status', )
    updated_at = serializers.DateTimeField()
    confirmations = serializers.IntegerField()

    class Meta:
        model = CryptoDepositRecordLastThreeMonths
        fields = (
            "status",
            "tx_address",
            "tx_amount",
            "tx_fee",
            "coin_type",
            "updated_at",
            "confirmations",
            "engine_sn",
            "tx_id",

        )


# 充值--Engine-Inbox:
class CryptoCurrencyDepositEngineSerializer(serializers.ModelSerializer):
    coin_type = serializers.ChoiceField(CoinType.choices)
    tx_amount = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)
    tx_fee = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)
    tx_address = serializers.CharField(label=u'address', max_length=100)
    status = serializers.IntegerField(label=u'status', )
    updated_at = serializers.DateTimeField()

    class Meta:
        model = CryptoDepositRecordLastThreeMonths
        fields = (
            "status", "tx_id", "tx_sub_id", "tx_address", "tx_amount", "tx_fee", "coin_type", "updated_at", "user_id",
            "engine_sn", "engine_request_no",
        )


####################################################
#     法币(Fiat Currency) 交易: 充值
####################################################


# 充值:
class FiatCurrencyDepositSerializer(serializers.ModelSerializer):
    amount = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)
    deposit_code = serializers.CharField(max_length=10, required=True)
    fiat_type = serializers.ChoiceField(FiatType.choices, required=True)
    bank_account = serializers.CharField(max_length=20, required=True)
    bank_label = serializers.CharField(max_length=25)
    bank_sn = serializers.CharField(max_length=128)
    remitter = serializers.CharField(max_length=56)
    collection_date = serializers.CharField()

    class Meta:
        model = FiatCurrencyDepositRecord
        fields = (
            "bank_account", "bank_label", "deposit_code", "amount",  "fiat_type", "remitter", "bank_sn", "collection_date"
        )


class FiatCreditCardDepositSerializer(serializers.ModelSerializer):
    amount = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)
    # simplex_fee = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)
    fiat_type = serializers.ChoiceField(FiatType.choices, required=True)
    birth = serializers.DateField()

    class Meta:
        model = FiatCurrencyDepositRecord
        fields = (
            "amount", "fiat_type", "birth"
        )


# 充值review List:
class FiatCurrencyDepositListSerializer(serializers.ModelSerializer):
    engine_sn = serializers.UUIDField()
    amount = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)
    fiat_type = serializers.ChoiceField(FiatType.choices, required=True)
    bank_account = serializers.CharField(max_length=20, required=True)
    bank_label = serializers.CharField(max_length=25)
    bank_sn = serializers.CharField(max_length=128)
    remitter = serializers.CharField(max_length=56)
    status = serializers.IntegerField()
    collection_date = serializers.DateTimeField()
    deposit_code = serializers.CharField()
    created_at = serializers.DateTimeField()
    user_id = serializers.UUIDField()
    amount_fmt = serializers.CharField()

    class Meta:
        model = FiatCurrencyDepositRecordLastThreeMonths
        fields = ("engine_sn", "bank_account", "bank_label", "amount",  "fiat_type", "remitter",
                  "bank_sn", "status", "collection_date", "deposit_code", "created_at", "user_id", "amount_fmt")


# 充值review create:
class FiatCurrencyDepositConfirmSerializer(serializers.ModelSerializer):
    engine_sn = serializers.UUIDField()
    status = serializers.ChoiceField(FiatDepositAllowStatus.choices)

    class Meta:
        model = FiatCurrencyDepositRecordLastThreeMonths
        fields = ("engine_sn", "status")


# 提现:
class FiatCurrencyWithdrawSerializer(serializers.ModelSerializer):
    amount = serializers.DecimalField(min_value=0, max_digits=40, decimal_places=20)

    class Meta:
        model = FiatCurrencyWithdrawRecord
        fields = (
            "user_id", "amount"
        )


class FiatCurrencyDepositRecordSerializer(serializers.ModelSerializer):
    class Meta:
        model = FiatCurrencyDepositRecord
        fields = ('fiat_type', 'amount', 'bank_label', 'bank_code', 'bank_account', 'status',
                  'updated_at', 'engine_sn', 'engine_request_no', 'deposit_type', 'simplex_fee')


# 充值记录列表
class FiatCurrencyDepositRecordAdminSerializer(serializers.ModelSerializer):

    class Meta:
        model = FiatCurrencyDepositRecordLastThreeMonths
        fields = ('fiat_type', 'amount', 'user_email', 'updated_at',
                  'deposit_type', 'simplex_fee', 'bank_sn')
