# -*- coding: utf-8 -*-
import logging
from rest_framework import permissions
from rest_framework import viewsets

from .filters import CryptoDepositAddressFilter
from .throttles import TxRecordCommonThrottleMinute, TxRecordCommonThrottleDay
from maneki.apps.constants import ETH_GROUP
from maneki.apps.constants import CoinType
from maneki.apps.transaction.models.crypto_currency_address import CryptoDepositAddress
from maneki.apps.transaction.views.serializers.tx_address import CoinDepositAddressSerializer
from maneki.apps.common.mixins.rest.mixins import BetterListModelMixin
from maneki.apps.transaction.services.crypto.deposit_manager import CryptoDepositManager
from maneki.apps.transaction.services.crypto.deposit_address import CryptoDepositAddressService

logger = logging.getLogger(__name__)


# deposit address
class CryptoDepositAddressView(BetterListModelMixin, viewsets.GenericViewSet):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = CoinDepositAddressSerializer
    filter_class = CryptoDepositAddressFilter
    throttle_classes = [TxRecordCommonThrottleDay, TxRecordCommonThrottleMinute]
    pagination_class = None
    #
    service = CryptoDepositAddressService()

    def get_queryset(self):
        user = self.request.user
        return CryptoDepositAddress.objects.filter(
            user_id=user.user_id,
            is_deleted=False,
        ).order_by("-updated_at")

    def do_list(self, request, serializer, *args, **kwargs):
        """用户获取充值地址列表 DELETE: 删除地址

        :param request:

        :param serializer:

        :param args:

        :param kwargs:

        :return:
        """
        result = self.response_result

        coin_type = self.request.query_params.get('coin_type', None)
        if not coin_type:
            result.update(
                code=450,
                detail="coin_type needed!",
            )
            return result

        logger.info("tx crypto deposit address: coin_type={}".format(coin_type))

        if not str(coin_type).isdigit():
            result.update(
                code=451,
                detail="invalid param!",
            )
            return result

        coin_type = int(coin_type)
        dm = CryptoDepositManager()
        address = dm.distribute_address(user_id=self.request.user.user_id, coin_type=coin_type, )
        if not address:
            result.update(
                code=452,
                detail="address for this coin_type has run out or create failed!",
            )
            return result

        logger.info("tx deposit address: coin_type={}, address={}".format(coin_type, address))

        # 拉取地址列表
        das = CryptoDepositAddressService()
        if coin_type in ETH_GROUP:
            coin_type = CoinType.ETH
        coin_type, address = das.get_user_address(user_id=self.request.user.user_id, coin_type=coin_type)

        # TODO: 待清理?
        # 更新session
        request.session['address'] = serializer.data
        request.session.modified = True
        # TODO: end

        result.update(data={
            "coin_type": coin_type,
            "address": address
        })

        return result

    def do_destroy(self, request, *args, **kwargs):
        """

        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        result = self.response_result
        user = request.user
        address = self.request.query_params.get('address', '')
        if not address:
            result.update(
                code=451,
                detail="address is required."
            )

        is_ok = self.service.disable_record(user_id=user.user_id, address=address)
        if not is_ok:
            result.update(
                code=452,
                detail="invalid address."
            )
            return result

        return result
