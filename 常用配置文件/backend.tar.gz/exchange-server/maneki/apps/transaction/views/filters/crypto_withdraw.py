# -*- coding: utf-8 -*-
import django_filters

from maneki.apps.constants import WithdrawStatus, CoinType, DatetimeOrderBy
from maneki.apps.transaction.models import CryptoWithdrawRecordLastThreeMonths


class CryptoWithdrawFilter(django_filters.FilterSet):
    timestamp_start = django_filters.CharFilter(field_name="timestamp_start")
    timestamp_end = django_filters.CharFilter(field_name="timestamp_start")

    class Meta:
        model = CryptoWithdrawRecordLastThreeMonths
        fields = ["engine_sn"]


class CryptoWithdrawCustomerVerifyFilter(django_filters.FilterSet):
    """用户提现申请 - 状态校验

        1. email + sms 验证码
        2. email + 2fa 验证码

    fix:
        - filter 定义会在 filter_queryset() 执行过滤动作, 要不想执行, 就要覆写 filter_queryset()

    """
    sn = django_filters.UUIDFilter(field_name="engine_sn", required=True)
    # 必填
    email_code = django_filters.CharFilter(field_name="email_code", required=True)
    # 二选一
    sms_code = django_filters.CharFilter(field_name="sms_code", min_length=4, max_length=6)
    otp_code = django_filters.CharFilter(field_name="otp_code", min_length=6, max_length=6)

    class Meta:
        model = CryptoWithdrawRecordLastThreeMonths
        fields = []
        # strict = 'RAISE'   # WTF.
        # exclude = ["email_code"]


class CryptoWithdrawAdminVerifyFilter(django_filters.FilterSet):
    """客服人工审核: 用户提现申请

    fix:
        - filter 定义会在 filter_queryset() 执行过滤动作, 要不想执行, 就要覆写 filter_queryset()

    """
    user_id = django_filters.UUIDFilter(field_name="user_id")
    email = django_filters.CharFilter(field_name="email")
    status = django_filters.CharFilter(field_name="status", choices=WithdrawStatus.choices)
    coin_type = django_filters.CharFilter(field_name="coin_type", label="0: BTC, 1: BCH", choices=CoinType.choices)
    timestamp_start = django_filters.CharFilter(field_name="timestamp_start", )
    timestamp_end = django_filters.CharFilter(field_name="timestamp_end")
    verify_type = django_filters.CharFilter(field_name="verify_type")
    order_by = django_filters.CharFilter(field_name="order_by", choice=DatetimeOrderBy.choices)

    class Meta:
        model = CryptoWithdrawRecordLastThreeMonths
        fields = [
            "user_id", "email", "status", "coin_type",
            "timestamp_start", "timestamp_end",
            "verify_type", "order_by"
        ]

