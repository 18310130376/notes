# -*- coding: utf-8 -*-
import django_filters

from maneki.apps.constants import CoinType
from maneki.apps.transaction.models import CryptoDepositRecordLastThreeMonths


class CryptoDepositFilter(django_filters.FilterSet):
    timestamp_start = django_filters.CharFilter(field_name="timestamp_start")
    timestamp_end = django_filters.CharFilter(field_name="timestamp_end")

    class Meta:
        model = CryptoDepositRecordLastThreeMonths
        fields = ["engine_sn"]
