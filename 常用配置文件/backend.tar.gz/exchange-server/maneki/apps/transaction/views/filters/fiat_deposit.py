# -*- coding: utf-8 -*-
import django_filters
from maneki.apps.constants import FiatDepositStatus, FiatType
from maneki.apps.transaction.utils.date import format_time_duration
from maneki.apps.transaction.models import FiatCurrencyDepositRecordLastThreeMonths


class FiatDepositFilter(django_filters.FilterSet):
    timestamp_start = django_filters.CharFilter()
    timestamp_end = django_filters.CharFilter()

    class Meta:
        model = FiatCurrencyDepositRecordLastThreeMonths
        fields = ['timestamp_start', 'timestamp_end', "engine_sn", "deposit_type"]


class AdminFiatDepositFilter(django_filters.FilterSet):
    timestamp_start = django_filters.CharFilter()
    timestamp_end = django_filters.CharFilter()
    deposit_code = django_filters.CharFilter()
    bank_sn = django_filters.CharFilter()

    class Meta:
        model = FiatCurrencyDepositRecordLastThreeMonths
        fields = ['timestamp_start', 'timestamp_end', 'deposit_code', 'bank_sn']

    @property
    def qs(self):
        condition = dict()
        timestamp_start = self.data.get('timestamp_start', None)
        timestamp_end = self.data.get('timestamp_end', None)
        deposit_code = self.data.get('deposit_code', None)
        bank_sn = self.data.get('bank_sn', None)
        status = FiatDepositStatus.UN_REVIEW
        start_at, end_at = format_time_duration(timestamp_start, timestamp_end)
        condition.update(
            created_at__gt=start_at,
            created_at__lte=end_at,
            deposit_code=deposit_code,
            bank_sn=bank_sn,
            status=status
        )
        condition = {k: v for k, v in condition.items() if v is not None}

        return self.queryset.filter(**condition)


class FiatDepositDetailFilter(django_filters.FilterSet):

    class Meta:
        model = FiatCurrencyDepositRecordLastThreeMonths
        fields = ['engine_sn']


class FiatDepositRecordsAdminFilter(django_filters.FilterSet):
    timestamp_start = django_filters.CharFilter()
    timestamp_end = django_filters.CharFilter()
    email = django_filters.CharFilter()
    bank_sn = django_filters.CharFilter()
    fiat_type = django_filters.ChoiceFilter(field_name="fiat_type", label="0: CNY, 1: USD", choices=FiatType.choices)

    class Meta:
        model = FiatCurrencyDepositRecordLastThreeMonths
        fields = ['timestamp_start', 'timestamp_end', 'email', 'bank_sn', 'fiat_type']
