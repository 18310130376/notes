# -*- coding: utf-8 -*-
import django_filters
from maneki.apps.transaction.models.crypto_currency_address import CryptoWithdrawAddress, CryptoDepositAddress
from maneki.apps.constants import CoinType


class CryptoWithdrawAddressFilter(django_filters.FilterSet):
    coin_type = django_filters.ChoiceFilter(field_name="coin_type", label="0: BTC, 1: BCH", choices=CoinType.choices)

    class Meta:
        model = CryptoWithdrawAddress
        fields = ['coin_type']


class CryptoDepositAddressFilter(django_filters.FilterSet):
    coin_type = django_filters.ChoiceFilter(field_name="coin_type", label="0: BTC, 1: BCH", choices=CoinType.choices)

    class Meta:
        model = CryptoDepositAddress
        fields = ['coin_type']
