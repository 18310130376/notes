# -*- coding: utf-8 -*-
import validators
import django_filters

from maneki.apps.constants import WithdrawStatus, FiatType
from maneki.apps.transaction.models.fiat_currency import FiatCurrencyWithdrawRecordLastThreeMonths
from maneki.apps.common.utils.format_timestamp import format_timestamp
from maneki.apps.common.mixins.rest import ValidationError450, \
    ValidationError451, ValidationError452, ValidationError453, ValidationError454


class FiatWithdrawFilter(django_filters.FilterSet):
    timestamp_start = django_filters.CharFilter()
    timestamp_end = django_filters.CharFilter()

    class Meta:
        model = FiatCurrencyWithdrawRecordLastThreeMonths
        fields = ['timestamp_start', 'timestamp_end', 'engine_sn']


class FiatWithdrawRetrieveFilter(django_filters.FilterSet):
    class Meta:
        model = FiatCurrencyWithdrawRecordLastThreeMonths
        fields = ['engine_sn']


class FiatWithdrawCustomerVerifyFilter(django_filters.FilterSet):
    """用户提现申请 - 状态校验

        1. email + sms 验证码
        2. email + 2fa 验证码

    fix:
        - filter 定义会在 filter_queryset() 执行过滤动作, 要不想执行, 就要覆写 filter_queryset()

    """
    sn = django_filters.UUIDFilter(field_name="engine_sn")
    # 必填
    email_code = django_filters.CharFilter(field_name="email_code")
    # 二选一
    sms_code = django_filters.CharFilter(field_name="sms_code")
    otp_code = django_filters.CharFilter(field_name="otp_code")

    class Meta:
        model = FiatCurrencyWithdrawRecordLastThreeMonths
        fields = ["sms_code", "otp_code", "email_code", ]


class FiatWithdrawAdminVerifyFilter(django_filters.FilterSet):
    """客服人工审核: 用户提现申请

    fix:
        - filter 定义会在 filter_queryset() 执行过滤动作, 要不想执行, 就要覆写 filter_queryset()

    """
    timestamp_start = django_filters.CharFilter()
    timestamp_end = django_filters.CharFilter()
    user_id = django_filters.UUIDFilter(field_name="user_id")
    status = django_filters.ChoiceFilter(field_name="status", choices=WithdrawStatus.choices)
    fiat_type = django_filters.ChoiceFilter(field_name="fiat_type", label="0: CNY, 1: USD", choices=FiatType.choices)
    engine_sn = django_filters.UUIDFilter(field_name="engine_sn")

    class Meta:
        model = FiatCurrencyWithdrawRecordLastThreeMonths
        fields = [
            "user_id", "engine_sn",
            "timestamp_start", "timestamp_end",
            "status", "fiat_type",
        ]

    @property
    def qs(self):
        params = self.params_check()
        status = WithdrawStatus.REVIEW_PENDING
        condition = dict()

        condition.update(user_id=params['user_id'],
                         fiat_type=params['fiat_type'],
                         updated_at__gte=params['start_date'],
                         updated_at__lte=params['end_date'],
                         status=status,
                         engine_sn=params['engine_sn']
                         )
        condition = {k: v for k, v in condition.items() if v is not None}

        return self.queryset.filter(**condition)

    def params_check(self):
        user_id = self.data.get('user_id', None)
        timestamp_start = self.data.get('timestamp_start', None)
        timestamp_end = self.data.get('timestamp_end', None)
        fiat_type = self.data.get('fiat_type', None)
        engine_sn = self.data.get('engine_sn', None)

        if user_id and not validators.uuid(user_id):
            raise ValidationError450(detail='filter params invalid:[{}]'.format('user_id'))
        if timestamp_start and not str(timestamp_start).isdigit():
            raise ValidationError452(detail='filter params invalid:[{}]'.format('timestamp_end'))
        if timestamp_end and not str(timestamp_end).isdigit():
            raise ValidationError452(detail='filter params invalid:[{}]'.format('timestamp_end'))
        if fiat_type and not str(fiat_type).isdigit():
            raise ValidationError453(detail='filter params invalid:[{}]'.format('coin_type'))

        params = {
            'user_id': user_id,
            'start_date': format_timestamp(timestamp_start),
            'end_date': format_timestamp(timestamp_end, timedelta_day=0),
            'fiat_type': fiat_type,
            'engine_sn': engine_sn
        }

        return params


class FiatWithdrawAdminOutMoneyFilter(django_filters.FilterSet):
    """财务人工审核: 用户提现申请

    fix:
        - filter 定义会在 filter_queryset() 执行过滤动作, 要不想执行, 就要覆写 filter_queryset()

    """
    timestamp_start = django_filters.CharFilter()
    timestamp_end = django_filters.CharFilter()
    user_id = django_filters.UUIDFilter(field_name="user_id")
    fiat_type = django_filters.ChoiceFilter(field_name="fiat_type", label="0: CNY, 1: USD", choices=FiatType.choices)
    engine_sn = django_filters.UUIDFilter(field_name="engine_sn")

    class Meta:
        model = FiatCurrencyWithdrawRecordLastThreeMonths
        fields = [
            "user_id", "engine_sn",
            "timestamp_start", "timestamp_end",
            "status", "fiat_type",
        ]

    @property
    def qs(self):
        params = self.params_check()
        status = WithdrawStatus.ENGINE_COMPLETED
        condition = dict()

        condition.update(user_id=params['user_id'],
                         fiat_type=params['fiat_type'],
                         updated_at__gte=params['start_date'],
                         updated_at__lte=params['end_date'],
                         status=status,
                         engine_sn=params['engine_sn']
                         )
        condition = {k: v for k, v in condition.items() if v is not None}

        return self.queryset.filter(**condition)

    def params_check(self):
        user_id = self.data.get('user_id', None)
        timestamp_start = self.data.get('timestamp_start', None)
        timestamp_end = self.data.get('timestamp_end', None)
        fiat_type = self.data.get('fiat_type', None)
        engine_sn = self.data.get('engine_sn', None)

        if user_id and not validators.uuid(user_id):
            raise ValidationError450(detail='filter params invalid:[{}]'.format('user_id'))
        if timestamp_start and not str(timestamp_start).isdigit():
            raise ValidationError452(detail='filter params invalid:[{}]'.format('timestamp_end'))
        if timestamp_end and not str(timestamp_end).isdigit():
            raise ValidationError452(detail='filter params invalid:[{}]'.format('timestamp_end'))
        if fiat_type and not str(fiat_type).isdigit():
            raise ValidationError453(detail='filter params invalid:[{}]'.format('coin_type'))

        params = {
            'user_id': user_id,
            'start_date': format_timestamp(timestamp_start),
            'end_date': format_timestamp(timestamp_end, timedelta_day=0),
            'fiat_type': fiat_type,
            'engine_sn': engine_sn
        }

        return params


class FiatWithdrawRecordsAdminFilter(django_filters.FilterSet):
    timestamp_start = django_filters.CharFilter()
    timestamp_end = django_filters.CharFilter()
    email = django_filters.CharFilter()
    out_money_bank_sn = django_filters.CharFilter()
    fiat_type = django_filters.ChoiceFilter(field_name="fiat_type", label="0: CNY, 1: USD", choices=FiatType.choices)

    class Meta:
        model = FiatCurrencyWithdrawRecordLastThreeMonths
        fields = ['timestamp_start', 'timestamp_end', 'email', 'out_money_bank_sn', 'fiat_type']
