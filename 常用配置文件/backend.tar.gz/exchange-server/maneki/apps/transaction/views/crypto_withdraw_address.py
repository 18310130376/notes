# -*- coding:utf-8 -*-
import logging
from rest_framework import permissions

from .filters import CryptoWithdrawAddressFilter
from .throttles import WithdrawAddressMinuteThrottle, WithdrawAddressHourThrottle
from maneki.apps.constants import WithdrawAddressStatus
from maneki.apps.transaction.models.crypto_currency_address import CryptoWithdrawAddress
from maneki.apps.transaction.views.serializers.tx_address import CoinWithdrawAddressListSerializer, CoinWithdrawAddressCreateSerializer, CoinWithdrawAddressDestroySerializer
from maneki.apps.common.mixins.rest import BetterReadWriteDeleteViewSet
from maneki.apps.transaction.services.crypto import CryptoWithdrawAddressService
from maneki.apps.transaction.utils.validate import validate_address

logger = logging.getLogger(__name__)


# 提现地址:
class WithdrawAddressViewSet(BetterReadWriteDeleteViewSet):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = CoinWithdrawAddressCreateSerializer
    serializer_class_list = CoinWithdrawAddressListSerializer
    serializer_class_destroy = CoinWithdrawAddressDestroySerializer
    filter_class = CryptoWithdrawAddressFilter
    #
    throttle_classes = [WithdrawAddressMinuteThrottle, WithdrawAddressHourThrottle]
    pagination_class = None

    lookup_url_kwarg = "address"  # delete
    #
    create_save_required = False
    service = CryptoWithdrawAddressService()

    def get_queryset(self):
        return CryptoWithdrawAddress.objects.filter(
            user_id=self.request.user.user_id,
            is_deleted=False,
        ).order_by("-updated_at")

    def filter_queryset(self, queryset):
        return super().filter_queryset(queryset)

    def do_list(self, request, serializer, *args, **kwargs):
        result = self.response_result
        user = request.user
        coin_type = request.query_params.get("coin_type", None)

        if coin_type is None:
            result.update(
                code=451,
                detail="coin_type is required.",
            )
            return result

        # todo: validate coin type
        qs = self.get_queryset().filter(
            user_id=user.user_id,
            status=WithdrawAddressStatus.NORMAL,
            coin_type=int(coin_type),
            is_deleted=False
        )

        _serializer = self.serializer_class(qs, many=True)
        result.update(data=_serializer.data)
        return result

    def do_create(self, request, serializer, instance, *args, **kwargs):
        result = self.response_result
        user = request.user
        coin_type = serializer.validated_data.get("coin_type")
        address = serializer.validated_data.get("address")
        label = serializer.validated_data.get("label")

        logger.info("add withdraw address: user={}, addr={}".format(user, serializer.validated_data))
        #
        # 地址合法性
        #
        if not validate_address(coin_type=coin_type, address=address):
            result.update(
                code=451,
                detail="invalid address",
            )
            return result

        ##############################
        # 检查是不是用户的充值地址
        ##############################
        if self.service.check_user_deposit_address(address=address, user_id=user.user_id):
            result.update(
                code=452,
                detail="not allow add user own deposit address",
            )
            return result
        #
        # 检查是不是他人内部地址和类型是否匹配
        #
        is_exist, address_record, is_match = self.service.check_inner_address_type_match(coin_type=coin_type, address=address)
        if not is_match and is_exist:
            result.update(code=453,
                          detail='inner address type not match')
            return result

        ##############################
        # 添加 提现地址
        ##############################
        self.service.add_address(
            user_id=user.user_id,
            address=address,
            coin_type=coin_type,
            label=label,
        )
        return result

    def do_destroy(self, request, *args, **kwargs):
        result = self.response_result
        user = request.user

        logger.info("request params: {}".format(request.__dict__))
        address = request.parser_context.get("kwargs").get("address", None)

        # address = request.kwargs.get("address", None) or request.query_params.get("address", None)
        coin_type = request.data.get("coin_type", None) or request.query_params.get("coin_type", None)
        logger.info("disable withdraw address: user={}, coin_type={},address={}".format(user, coin_type, address))

        ret = self.service.disable_address(
            user_id=user.user_id,
            address=address,
            coin_type=coin_type,
        )

        result.update(
            code=ret.get("code"),
            detail=ret.get("detail"),

        )
        logger.info("disable result: {}".format(result))
        return result
