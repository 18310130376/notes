# -*- coding:utf-8 -*-
import logging

from rest_framework import viewsets
from rest_framework import permissions
from django.db import transaction

from maneki.apps.common.utils.date import unix_to_datetime

from maneki.apps.constants import FiatDepositStatus, FiatDepositAllowStatus, FiatDepositType
from maneki.apps.transaction.services.fiat.deposit import FiatDepositService
from maneki.apps.user.models import UserProfile, User
from maneki.apps.common.mixins.rest import BetterCreateModelMixin, BetterListModelMixin

from maneki.apps.transaction.utils.date import format_time_duration
from maneki.apps.transaction.models import FiatCurrencyDepositRecordLastThreeMonths
from maneki.apps.transaction.views.serializers import FiatCurrencyDepositSerializer
from maneki.apps.transaction.views.serializers import FiatCurrencyDepositConfirmSerializer
from maneki.apps.transaction.views.serializers import FiatCurrencyDepositListSerializer
from maneki.apps.transaction.views.serializers import FiatCurrencyDepositRecordAdminSerializer

from maneki.apps.transaction.views.filters import AdminFiatDepositFilter
from maneki.apps.transaction.views.filters import FiatDepositRecordsAdminFilter
from maneki.apps.transaction.services.fiat.deposit_worker import FiatDepositEngineProducer
from .throttles import TxRecordAdminThrottleDay
from maneki.apps.common.permissions.rest.permission_manage import StrictPermissionCheck

logger = logging.getLogger(__name__)


####################################################
#     法币(Fiat Currency) 交易: 充值
####################################################


# 充值录入:
class FiatCurrencyDepositAdminViewSet(BetterCreateModelMixin, viewsets.GenericViewSet):
    """法币充值录入
    """
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]
    serializer_class = FiatCurrencyDepositSerializer
    throttle_classes = [TxRecordAdminThrottleDay]
    pagination_class = None

    def get_queryset(self):
        return FiatCurrencyDepositRecordLastThreeMonths.objects

    def do_create(self, request, serializer, instance, *args, **kwargs):
        """ 充值录入
        """
        result = self.response_result
        deposit_code = serializer.validated_data.get('deposit_code')
        user = UserProfile.objects.filter(deposit_code=deposit_code).first()
        if not user:
            result.update(
                detail="deposit code not found",
                code=450
            )
            return result

        amount = serializer.validated_data.get('amount')
        fiat_type = serializer.validated_data.get('fiat_type')
        bank_account = serializer.validated_data.get('bank_account')
        bank_label = serializer.validated_data.get('bank_label')
        bank_sn = serializer.validated_data.get('bank_sn')
        remitter = serializer.validated_data.get('remitter')
        collection_date = serializer.validated_data.get('collection_date')
        if not str(collection_date).isdigit():
            result.update(
                detail="collection_date is not unix",
                code=451
            )
            return result

        collection_date = unix_to_datetime(collection_date, "%Y-%m-%d %H:%M:%S")

        record = FiatCurrencyDepositRecordLastThreeMonths.objects.filter(
            status=FiatDepositStatus.COMPLETED,
            bank_sn=bank_sn
        ).first()
        if record:
            result.update(
                code=452,
                detail="bank sn is exist",
            )
            return result
        FiatCurrencyDepositRecordLastThreeMonths.objects.create(
            bank_account=bank_account,
            bank_label=bank_label,
            amount=amount,
            fiat_type=fiat_type,
            user_id=user.user_id,
            status=FiatDepositStatus.UN_REVIEW,
            bank_sn=bank_sn,
            remitter=remitter,
            collection_date=collection_date,
            deposit_code=deposit_code
        )
        return result


# 充值审核
class FiatCurrencyDepositVerifyViewSet(BetterCreateModelMixin, BetterListModelMixin, viewsets.GenericViewSet):
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]
    serializer_class = FiatCurrencyDepositConfirmSerializer
    serializer_class_list = FiatCurrencyDepositListSerializer
    filter_class = AdminFiatDepositFilter
    throttle_classes = [TxRecordAdminThrottleDay]
    service = FiatDepositService()
    producer = FiatDepositEngineProducer()

    def get_queryset(self):
        return FiatCurrencyDepositRecordLastThreeMonths.objects

    # list all not review records
    def do_list(self, request, serializer, *args, **kwargs):
        """ 充值审核列表
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        result = self.response_result
        result.update(data=serializer.data)
        return result

    @transaction.atomic
    def do_create(self, request, serializer, instance, *args, **kwargs):
        """ 通过审核
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        result = self.response_result
        engine_sn = serializer.validated_data.get('engine_sn')
        status = serializer.validated_data.get('status')

        record = self.get_queryset().filter(
            engine_sn=engine_sn,
            status=FiatDepositStatus.UN_REVIEW
        ).first()
        if not record:
            result.update(
                detail='Not found un_review record',
                code=450
            )
            return result

        if status == FiatDepositAllowStatus.REJECT:
            record.status = status
            record.save()
            result.update(
                detail='reject record',
                code=202
            )
            return result

        record.status = FiatDepositStatus.ENGINE_PENDING
        record.save()
        # 异步调用引擎rpc. consumer取引擎执行状态更新结果
        task = self.service.deposit_engine_task(record)
        self.producer.publish(task)
        return result


# 法币充值对账:
class FiatCurrencyDepositRecordAdminViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    """ 法币充值
    """
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]
    filter_class = FiatDepositRecordsAdminFilter
    serializer_class_list = FiatCurrencyDepositRecordAdminSerializer
    throttle_classes = [TxRecordAdminThrottleDay]

    def get_queryset(self):
        return FiatCurrencyDepositRecordLastThreeMonths.objects

    def filter_queryset(self, queryset=None, deposit_type=FiatDepositType.BANK_TRANSFER):
        timestamp_start = self.request.query_params.get('timestamp_start')
        timestamp_end = self.request.query_params.get('timestamp_end')
        start_at, end_at = format_time_duration(timestamp_start, timestamp_end)
        fiat_type = self.request.query_params.get('fiat_type', None)
        user_email = self.request.query_params.get('email')
        bank_sn = self.request.query_params.get('bank_sn')
        condition = {
            'status': FiatDepositStatus.COMPLETED,
        }
        condition.update(
            updated_at__gte=start_at,
            updated_at__lt=end_at,
            deposit_type=deposit_type
        )
        if user_email:
            user_obj = User.objects.filter(email=user_email).first()
            if user_obj:
                condition.update(
                    user_id=user_obj.user_id,
                )

        if fiat_type is not None:
            condition.update(
                fiat_type=fiat_type
            )

        if bank_sn:
            condition.update(
                bank_sn=bank_sn
            )

        condition = {k: v for k, v in condition.items() if v is not None}
        qs = self.get_queryset().filter(**condition)
        return qs

    def do_list(self, request, serializer, *args, **kwargs):
        """ 法币币充值记录
        """
        result = self.response_result

        # 过滤 时间段, email, engine_sn 可以自定义错误码
        # 过滤起始时间

        timestamp_start = request.query_params.get('timestamp_start', None)
        timestamp_end = request.query_params.get('timestamp_end', None)

        if timestamp_start and not str(timestamp_start).isdigit():
            result.update(code=450, detail='filter params invalid:[{}]'.format('timestamp_start'))
            return result

        if timestamp_end and not str(timestamp_end).isdigit():
            result.update(code=451, detail='filter params invalid:[{}]'.format('timestamp_end'))
            return result

        data = serializer.data
        result.update(data=data)

        return result


class FiatCurrencyCreditCardDepositRecordAdminViewSet(FiatCurrencyDepositRecordAdminViewSet):

    def filter_queryset(self, queryset=None, deposit_type=FiatDepositType.SIMPLEX):
        super(FiatCurrencyCreditCardDepositRecordAdminViewSet, self).filter_queryset(queryset=None,
                                                                                     deposit_type=deposit_type)
