# -*- coding: utf-8 -*-
import logging
import uuid

from rest_framework import permissions, viewsets
from rest_framework.response import Response
from django.conf import settings

from maneki.apps.user.models import User
from .filters import CryptoWithdrawAdminVerifyFilter
from .throttles import TxRecordAdminThrottleDay
from maneki.apps.common.mixins.rest import BetterReadWriteViewSet, BetterListModelMixin
from maneki.apps.common.permissions.rest.permission_manage import StrictPermissionCheck
from maneki.apps.constants import WithdrawStatus, FreezeType
from maneki.apps.transaction.models import CryptoWithdrawRecordLastThreeMonths
from maneki.apps.transaction.services.crypto import CryptoWithdrawService
from maneki.apps.transaction.services.crypto import WithdrawRequestToEngineProducer
from maneki.apps.transaction.views.serializers.withdraw import CryptoWithdrawAdminListSerializer
from maneki.apps.transaction.views.serializers.withdraw import CryptoWithdrawAdminReviewSerializer, CryptoWithdrawAdminSwitchSerializer
from maneki.apps.common.utils.redis.r import redis_sessions

logger = logging.getLogger(__name__)


class CryptoWithdrawRequestAdminVerifyViewSet(BetterReadWriteViewSet):
    """数字货币 - 提现请求审核 (客服管理员操作)

    :note: 客服拉出所有待审核的提现请求的列表, 根据审核标准, 核准是否允许发起提现.

    """
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]
    serializer_class_list = CryptoWithdrawAdminListSerializer
    serializer_class = CryptoWithdrawAdminReviewSerializer
    filter_class = CryptoWithdrawAdminVerifyFilter
    throttle_classes = [TxRecordAdminThrottleDay]
    #
    service = CryptoWithdrawService()
    producer = WithdrawRequestToEngineProducer()

    def get_queryset(self):
        return CryptoWithdrawRecordLastThreeMonths.objects

    def list(self, request, *args, **kwargs):
        """admin数字货币提现记录
            order_by:{
            1: 正序；
            2：倒序；}
        :param request:
        :param args:
        :param kwargs:
        :return:
        """

        result = self.response_result
        params = {"user_id": self.request.query_params.get('user_id', None),
                  "email": self.request.query_params.get('email', None),
                  "status": self.request.query_params.get('status', None),
                  "coin_type": self.request.query_params.get('coin_type', None),
                  "verify_type": self.request.query_params.get('verify_type', None),
                  "timestamp_start": self.request.query_params.get('timestamp_start', None),
                  "timestamp_end": self.request.query_params.get('timestamp_end', None),
                  "limit": self.request.query_params.get('limit', 10),
                  "offset": self.request.query_params.get('offset', 0),
                  "order_by": self.request.query_params.get("order_by", 1)}
        attrs = self.service.validate_list(params)
        logger.info(f'attrs:{attrs}')
        code = attrs.get('code')
        detail = attrs.get('detail')
        if code != 200:
            result.update(code=code,
                          detail=detail)
            return Response(result)

        count, auto_count, qs = self.service.search_records(attrs)
        result.update(data={"count": count,
                            "auto_number": auto_count,
                            "access_number": count - auto_count,
                            "result": self.serializer_class_list(qs, many=True).data})
        return Response(result)

    def do_create(self, request, serializer, instance, *args, **kwargs):
        """修改记录状态

        :param request:
        :param serializer:
        :param instance:
        :param args:
        :param kwargs:
        :return:
        """
        result = self.response_result

        engine_sn = serializer.validated_data.get("engine_sn")
        verify_status = serializer.validated_data.get("status")

        # 无效状态值校验:
        if not self.service.validate_manual_check_status(verify_status):
            result.update(
                code=450,
                detail="invalid withdraw status.",
            )
            return result

        # 更新状态:
        # TODO: 状态为 completed, 执行 engine RPC, 扣款, 再 执行 blockchain-proxy 打币.
        record = self.service.filter_record(engine_sn=engine_sn)
        if not record:
            result.update(
                code=451,
                detail="invalid withdraw sn.",
            )
            return result

        self.service.update_record_status(record=record, status=verify_status)
        # publish task:
        if verify_status == WithdrawStatus.REVIEW_COMPLETED:
            # add asscessor info
            is_ok = self.service.add_asscessor_info(user=request.user, record=record)
            if not is_ok:
                result.update(code=4501,
                              detail='add accessor info failed!')
                return result
            ################################################
            # inner withdraw:
            ################################################
            # if inner withdraw:
            is_ok, code, detail = self.service.is_inner_withdraw(record)
            # todo inner withdraw address type not match
            if code == 4500:
                result.update(code=code,
                              detail=detail)
                return result
            if is_ok:
                is_ok = self.service.inner_withdraw(withdraw_record=record)
                logger.info("inner withdraw: user={}, params={}".format(request.user, self.request.query_params))
                if not is_ok:
                    logger.error("inner withdraw failed.")
                    result.update(
                        code=457,
                        detail="withdraw failed, please contact us.",
                    )
                    return result
                logger.info(
                    "inner withdraw completed: user={}, params={}".format(request.user, self.request.query_params))
                # ok:
                result.update(
                    code=200,
                    detail="withdraw completed.",
                )
                return result

            ################################################
            # normal withdraw:
            ################################################
            # engine prc + 打币
            # todo : withdraw engine with fee
            task = self.service.withdraw_engine_task_with_fee(record)
            self.producer.publish(task)
            #
            result.update(
                code=200,
                detail="ok, online withdraw pending...",
            )
        else:
            # unfreeze balance
            if settings.FREEZE_SWITCH:
                request_id = uuid.uuid4()
                user = User.objects.filter(user_id=record.user_id).first()
                is_ok = self.service.freeze_cash(
                            request_id=request_id.hex,
                            user=user,
                            coin_type=record.coin_type,
                            amount=record.tx_amount + record.tx_fee,
                            freeze_type=FreezeType.UNFREEZE,
                        )
                if not is_ok:
                    result.update(
                        code=452,
                        detail='unfreeze failed!'
                    )
                    return result
                record.freeze_request_no = request_id
                record.freeze_status = FreezeType.UNFREEZE
                record.save()

        return result


class CryptoWithdrawAdminCountViewSet(BetterListModelMixin, viewsets.GenericViewSet):
    """审核统计

    """
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]
    # queryset = CryptoWithdrawRecordLastThreeMonths.objects.first()
    serializer_class = CryptoWithdrawAdminReviewSerializer
    pagination_class = None

    service = CryptoWithdrawService()

    def list(self, request, *args, **kwargs):
        result = self.response_result
        total_number, auto_number = self.service.record_count()
        result.update(data={'total_number': total_number,
                            'auto_number': auto_number,
                            'access_number': total_number - auto_number})
        return Response(result)


class CryptoWithdrawAdminAccessSwitchViewSet(BetterReadWriteViewSet):
    """按钮切换用户和人工审核

    """
    permission_classes = [permissions.IsAuthenticated, StrictPermissionCheck]
    serializer_class = CryptoWithdrawAdminSwitchSerializer
    service = CryptoWithdrawService()

    def list(self, request, *args, **kwargs):
        """
        显示审核方式
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        result = self.response_result
        switch = redis_sessions["WithdrawSwitch"].get("WithdrawSwitch")
        if not switch:
            redis_sessions["WithdrawSwitch"].set("WithdrawSwitch", 1)
            switch = 1

        result.update(
            data={"switch": switch}
        )
        return Response(result)

    def create(self, request, *args, **kwargs):
        """
        改变审核方式
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        result = self.response_result
        access_switch = self.request.data.get("access_switch", None)
        is_ok, result = self.service.validate_withdraw_switch(access_switch, result)
        if not is_ok:
            return Response(result)
        result = self.service.update_withdraw_switch(access_switch, result)
        return Response(result)
