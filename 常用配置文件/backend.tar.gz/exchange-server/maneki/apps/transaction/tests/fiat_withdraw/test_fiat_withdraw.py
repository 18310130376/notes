# -*- coding: utf-8 -*-
import datetime
import logging
from django.test import TestCase
from faker import Faker

from maneki.apps.assets.services.user_fiat_account import UserFiatAccountService
from maneki.apps.transaction.services.fiat.withdraw import FiatWithdrawService
from maneki.apps.transaction.services.fiat.withdraw_worker import FiatWithDrawEngineConsumer
from maneki.apps.transaction.models.fiat_currency import FiatCurrencyWithdrawRecordLastThreeMonths
from maneki.apps.transaction.tests.crypto_deposit.test_deposit import mock_data

logger = logging.getLogger('test')


class TestDeposit(TestCase):

    def setUp(self):
        self.consumer = FiatWithDrawEngineConsumer()
        # 初始化用户
        self.user, self.token = mock_data()
        # 初始化银行卡信息
        self.bank_service = UserFiatAccountService()
        self.bank_service.get_or_create_account(user_id=self.user.user_id, fiat_type=1, bank_name="wqhe",
                                                bank_account="1878145212315465",
                                                beneficiary_name="nihi", account_type=-1,
                                                bank_swift_code="", bank_address="",
                                                beneficiary_address="", via_bank_name="",
                                                via_bank_address="", via_bank_swift_code="")
        # 初始化交易记录
        self.fake = Faker()

        self.req_id = self.fake.uuid4()
        self.model = FiatCurrencyWithdrawRecordLastThreeMonths
        self.model.objects.create(fiat_type=1, amount=10, bank_code='', bank_account='1878145212315465', status=1,
                                  user_id=self.user.user_id, engine_request_no=self.req_id)

    def test_fiat_withdraw_consumer(self):

        payload = {
                    "request_id": self.req_id,
                    "coin_type": "USD",
                    "amount": "0.01",
                    "username": self.user.user_id,
                }

        self.consumer.do_task(payload)

    def test_deposit_engine_consumer(self):
        payload = {
            "deposit": [{
                "status": 1,
                "tx_id": "2c0467239c2750717fe8fa91034c0682340a7ed2d3108c7758873179aedd6a44",
                "tx_sub_id": "",
                "tx_address": "mgNgPqUeVQ17uNGS6k6VfEiwpdVahd8yB8",
                "tx_amount": "650000000.00000000000000000000",
                "tx_fee": "0.00000000000000000000",
                "coin_type": 0,
                "updated_at": "2018-05-07T03:21:11.158185Z",
                "user_id": "84bfb451-e138-41b2-b53a-c77177719373",
                "engine_sn": "5ccfa436-8c26-477d-a1d6-649a6b07eddc",
                "engine_request_no": "88e26b72-2dd0-4a0e-9251-fb964db0c14d"
            }]
        }
        self.engine_consumer.do_task(payload)

    def test_deposit_address_view(self):
        pass

    def test_auto_cancel_withdraw_order(self):
        from maneki.apps.transaction.services.fiat.withdraw import FiatWithdrawService
        service = FiatWithdrawService()
        counts = service.auto_cancel_order()
        logger.info('Close Fiat Withdraw num {},{}'.format(counts, datetime.datetime.utcnow()))

    def test_create_account(self):
        obj = self.bank_service.create_account(user_id=self.user.user_id, fiat_type=1, bank_name="wqhe",
                                               bank_account="1878145212315465",
                                               beneficiary_name="nihi", account_type=-1,
                                               bank_swift_code="", bank_address="",
                                               beneficiary_address="", via_bank_name="",
                                               via_bank_address="", via_bank_swift_code="")
        logger.info('account:{}'.format(obj.bank_account))

    def test_create_fiat_withdraw_records(self):
        service = FiatWithdrawService()
        obj = service.create_record(fiat_type=1, amount=10, bank_account='1878145212315465',
                                    user_id=self.user.user_id, status=1, beneficiary_name='test',
                                    service_charge=1,)
        logger.info('record:{}'.format(obj.beneficiary_name))
