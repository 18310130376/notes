# @Author            :Helen
# @Product           :exchange-server
# @Description       :create engine user
import logging

import pytest
from django.conf import settings

from maneki.apps.common.utils.mq.pika import BaseConsumer
from maneki.apps.common.utils.mq.pika import BaseProducer
from maneki.apps.constants import CoinType
from maneki.apps.constants import DepositAddressStatus
from maneki.apps.transaction.models import BlockchainTransaction
from maneki.apps.transaction.models import CryptoDepositAddress
from maneki.apps.transaction.models import CryptoDepositRecordLastThreeMonths
from maneki.apps.transaction.utils.transdata import process_deposit
from maneki.apps.transaction.utils.transdata import process_deposit_data

logger = logging.getLogger(__name__)
CREATE_TEST_DEPOS = settings.RABBITMQ_CONFIG_GROUP["deposit"]["wallet"]
msg = {
    "sign": '5054dfc74f2177a5929541f488b87e85c15f0281',  # sha1   length 40
    "timestamp": "1400237485932",
    "nonce": "abcdefgh",
    "data": {
        "coin": "BTC",
        "coin_series": "btc",
        "coin_type": 0,
        "confirmations": 2,
        "confirmed": True,
        "tx_id": "12c1b805dc78b6e4384ff86bdc394f1adae803920727b1faec294875f745f230",
        "miner_fee": 3.00,
        "user_transactions": [
            {
                "tx_address_to": "mrUFtyiW3cJ55CwjQd4nEcr3Etx2Wyg7yP",
                "tx_amount": "0.1",
            },
            {
                "tx_address_to": "nrUFtyiW3cJ55CwjQd4nEcr3Etx2Wyg7yP",
                "tx_amount": "0.2",

            },
        ],
    },

}


def test_add_deposit_data():
    class TaskProducer(BaseProducer):

        def __init__(self):
            super().__init__(mq_conf_groups=CREATE_TEST_DEPOS)

    p = TaskProducer()
    msg = {
        "sign": '5054dfc74f2177a5929541f488b87e85c15f0281',  # sha1   length 40
        "timestamp": "1400237485932",
        "nonce": "abcdefgh",
        "data": {
            "coin": "BTC",
            "coin_series": "btc",
            "coin_type": 0,
            "confirmations": 5,
            "confirmed": True,
            "tx_id": "12c1b805dc78b6e4384ff86bdc394f1adae803920727b1faec294875f745f230",
            "miner_fee": 3.00,
            "user_transactions": [
                {
                    "tx_address_to": "mrUFtyiW3cJ55CwjQd4nEcr3Etx2Wyg7yP",
                    "tx_amount": "0.1",

                },
            ],
        },

    }
    p.publish(msg)


msg_start = {
    "sign": '5054dfc74f2177a5929541f488b87e85c15f0281',  # sha1   length 40
    "timestamp": "1400237485932",
    "nonce": "abcdefgh",
    "data": {
        "coin": "BTC",
        "coin_series": "btc",
        "coin_type": 0,
        "confirmations": 0,
        "confirmed": False,
        "tx_id": "12c1b805dc78b6e4384ff86bdc394f1adae803920727b1faec294875f745f230",
        "miner_fee": 3.00,
        "user_transactions": [
            {
                "uid": "2-1",
                "tx_address_to": "mrUFtyiW3cJ55CwjQd4nEcr3Etx2Wyg7yP",
                "tx_amount": "0.1",
            },
            {
                "uid": "2-2",
                "tx_address_to": "nrUFtyiW3cJ55CwjQd4nEcr3Etx2Wyg7yP",
                "tx_amount": "0.2",

            },
        ],
    },

}


msg_complete = {
    "sign": '5054dfc74f2177a5929541f488b87e85c15f0281',  # sha1   length 40
    "timestamp": "1400237485932",
    "nonce": "abcdefgh",
    "data": {
        "coin": "BTC",
        "coin_series": "btc",
        "coin_type": 0,
        "confirmations": 6,
        "confirmed": True,
        "tx_id": "12c1b805dc78b6e4384ff86bdc394f1adae803920727b1faec294875f745f230",
        "miner_fee": 3.00,
        "user_transactions": [
            {
                "uid": "2-1",
                "tx_address_to": "mrUFtyiW3cJ55CwjQd4nEcr3Etx2Wyg7yP",
                "tx_amount": "0.1",
            },
            {
                "uid": "2-2",
                "tx_address_to": "nrUFtyiW3cJ55CwjQd4nEcr3Etx2Wyg7yP",
                "tx_amount": "0.2",

            },
        ],
    },

}


@pytest.mark.django_db
def test_transdata():
    coin_addr = CryptoDepositAddress.objects.create(
        status=DepositAddressStatus.ASSIGNED, coin_type=CoinType.BTC,
        user_id=2, address='mrUFtyiW3cJ55CwjQd4nEcr3Etx2Wyg7yP', )
    coin_addr.save()
    coin_addr = CryptoDepositAddress.objects.create(
        status=DepositAddressStatus.ASSIGNED, coin_type=CoinType.BTC,
        user_id=3, address='nrUFtyiW3cJ55CwjQd4nEcr3Etx2Wyg7yP', )
    coin_addr.save()
    _status, data, depositObjs = process_deposit(msg_start)
    bObjs = BlockchainTransaction.objects.all()
    cObjs = CryptoDepositRecordLastThreeMonths.objects.all()
    print(list(bObjs))
    print(list(cObjs))
    print(list(depositObjs))
    assert _status == 1
    _status, data, depositObjs = process_deposit(msg_complete)
    bObjs = BlockchainTransaction.objects.all()
    cObjs = CryptoDepositRecordLastThreeMonths.objects.all()
    print(list(bObjs))
    print(list(cObjs))
    print(list(depositObjs))
    assert _status == 2
