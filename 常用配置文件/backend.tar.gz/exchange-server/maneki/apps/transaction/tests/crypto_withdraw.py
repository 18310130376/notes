import pytest

from maneki.apps.transaction.models.crypto_currency import CryptoWithdrawRecordLastThreeMonths
from maneki.apps.transaction.services.crypto import CryptoWithdrawService


def crypto_report_dingbot():
    record = CryptoWithdrawRecordLastThreeMonths.objects.first()
    service = CryptoWithdrawService()
    service.notify_withdraw_quest(record)


if __name__ == '__main__':
    crypto_report_dingbot()
