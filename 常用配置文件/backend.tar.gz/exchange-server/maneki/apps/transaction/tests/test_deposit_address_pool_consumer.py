# -*- coding: utf-8 -*-
import logging

from django.conf import settings
from django.test import TestCase
from maneki.apps.common.utils.mq.pika import BaseProducer
from maneki.apps.transaction.services.crypto_deposit_address_load_v2 import DepositAddressPoolConsumer

logger = logging.getLogger(__name__)

CREATE_TEST_DEPOSIT_ADDRESS_POOL = settings.RABBITMQ_CONFIG_GROUP["deposit_address"]["prepare"]


class TestDepositAddressPoolProducer(BaseProducer):
    # MQ_URL = "amqp://rabbit:rabbit@10.0.20.83:5672/exchange_server"
    MQ_CONFIG_GROUPS = CREATE_TEST_DEPOSIT_ADDRESS_POOL


class DepositAddressTest(TestCase):

    def test_deposit_address_pool_producer(self):
        data = {"coin_type": "BTC", "region": "stage", "address": ["miU4NTF1fo9PGSwhYtxiF65uKbbxiJCygP", "mjH5iEysq4FUqJp7Zwt6PHKEvcaDezJjnY", "mskUTc2q87Wrio62io4QLX8j8oPARPf4nR", "n4iAwPMj9Stf97iNHobKi3JAZTahXknEPU", "mrg9tUFHuARqFiRAvvoVp3pxVmEw6xPL7F", "muU5t47GSt1C7uZDBdC7P8H5U5SEPRwpnR", "miZJw16LTmREH2XGre84Meg6xWFzxG1cpm", "mkBLBPHp2Au1dXyqcqm4dL4eZKFEWPB4KX", "mmGrL3vzLJBpkM4jBpU1BkTxwuhqJbgWkP", "n248JTw7ejfJfgpmDUnyrwtubUPTKULKEo", "ms7DKTvfCfYXvTgmvGeq7De4ittWpKJcnJ", "mkgBkxFJooQ5YThvQPnKZagSxdX8MiD4kz", "mxgCct8Q4y4iiGbKBRhMqU7NPj4sLrWvES", "mm9hupBqo7cwut5xZpH6QWjVJHteWM1LDL", "mseibTmRQWpEiWzxCT5rpH16iFox7qTG13", "msZqFZt7e7BEkvMsL8nWDL9b2VtRhLNk1Q", "myZy3DWg37JyvPKy7jgaYnK25U7FGdaQft", "mtHvTwpzeL2nrJh7ewADW9DPY9xWB9ZoUb", "mgAyvt2mCNL92uc97xLmrD2ywtUemizEKk", "mrhVc3PfpQ2chFoHC6YY9rBMB5Rf1i3Uu1", "mySomFmyRtBoNPDZpMshty785qoR2rGBrG", "n3ypS2UqhmbYqEQHgMqbhjudfgJahUx3aM", "mgTbfcDJbyocE9bzV53pUxg4opzaqtTwG9", "n2PU7uzB8mgerM7NzDfz2fckKaP1hWHgnY", "mvw3HFHohniYhnuRY9RtnXhT4JizsCpP6h", "n3yaaW9g2bUDqureVoHWshUU7qJvQnttjx", "n4FsH3pRTkyegg7nKtJsQDf4PQwtmwsvzj", "n1eiGkbswAYaxPivMk8Lb7pGP5Sv2XUMbX", "mjaCzVcZg73iXpfbVNW3EQ3mTEZmHkxkaG", "mgMSAwPKq3AQcvEeU82xHFk6b1jNQZaGUU", "mzrBVLX3aqdG98GNX77tju5t9vPBA6rYfS", "moxeg2we8LXP7tKGknbUpjJW46quJtVUFb", "mk8YgAnh3mibnaYKpaw3VGLaDhQqqYvZBu", "muuYJgqncocmUTYVswTG6eo3jz9JdezTbY", "mhPC7idDtRzQpB825KcgojuKHrCGB2UrTV", "mzc9sN8e5nCYfjthyXmE6U82fhjFrULZLR", "n1aQLuvuH1jad7o3AHfd8wECZ8s87xYF6E", "mwnauXV3CCa9XzW6pKCaQGtPGCmGX3Cp5b", "mnXQeVSCuimAYPD1Z1EFdZHw8Yp2iE7pKh", "mncU6b9wJtDRL96Fj67DotHaQ2G4Y8R4Vh", "mkBJ7z978Fd12VgbNTZ2yjV1rcrxm2oWjU", "mw3waYQev1znyUZ2AmK6RgrsarT4UrLtJM", "msU7BUGz3yr2ATcnKW2SdxS7abAdKQo72L", "n42M8MGFi8eMq4Zbt7PnTgQpMmLHDz7Wy4", "muHGS9Kgcfh4tngo5DVorGayGmQv7DAnpm", "mrDBJPff3tW5ZYxXXF6XNnmHZCaFFwTc1j", "mntAtMFtjHPUEyLdbKxeQkPUbrVTZXidqJ", "mo32KCcm5KdDSvqXc8AMZEjth6GYYGqFtt", "mnTGa8BvcWDFomt4AzMjFFQumqvjjomRBD", "n2gCbU7S3mtd6yqnGXtemEjuwvS41faeRH", "mkKLN9H4AVVNamWWxrd5kSyPRD1kg3nAYs", "mgrh46usMfvHy83kWAzXuHgjpevuJyW1LM", "n4VZM5newr3cMHDhyzAD2BJCwAV8yuxtXQ", "mji8CBwML9chbYf3wpfRqvW4qiRP691FTS", "mi9QsooQ1najFCNsks9VZcFLaJw5EgVudN", "my7pm5v3xdJ4acmUYiSjygabwpySo4mTWY", "mwbjqsQDopnKKxLzLRPbRzeWWFWBZENi9N", "mywhfYEZgDrj3NiWAqbyzAJaXMgYPiRbET", "mwAzFefGuzU728is8imVbkyZiG8d1D9Ncb", "mjpiAS18AQmF1u3KCp7Q6CdUXkzesp712Z", "mgzEkC62Pg4t5JHPscTAKzHfjrPg7CbLbt", "mmRZqYwRaXT4kMjh3JxwUuYaaFRZ2WQ6PD", "moFhoSM1MbG9H54yDsaiGeWtUnZpfz3q5q", "mjtajjiapL2UabvRm9fLRqiJLvMSQtHZ1z", "mjLv8em8QjFHa19aWQxr27gGys7PK2Tcyy", "mhJHCiy7nb9ipviLaa1ug5CtWcDWehXAJw", "mywy1YmJ2KcektuVTRHchtSUBrUwHtUkoZ", "mgVVj9SbEQqMvJtSTfWW4gGNFfBvzBYLGk", "mm2TBcg75Ew58Y7E5GHj9DDKz4hCJZvXW9", "mx6jwxVcFC71KvkmPwFDvBaTBoZoRVjQ5x", "mjNxxBrxFgGdFax4Em1kerM6P2n87pMAUS", "moziQB24rVbeU8v3DaK6CiCyWPDH5hgFNL", "mrfy4DVXYn3HMqVAR2uuJGX3RCgQiKS2rb", "mhWaUUSuvh88p3ifowRCgEd4WGFizFBo6X", "mi3ogZh1BWYbe9Loih8s5whcAszYwmjonG", "mndY2umfsAgz4CbX9D1QgY9sjE7pGgkVrc", "n45bLCCA88gJaE4yX14jkwZLo7iBy76V3t", "mjmunDGxky7Hsa65Mut8EkxMrGyob5ebHw", "munBmRHZ1XXW6gjRs5WRpkykCquJqrXaNL", "mrHC5Hx1HoEJodzUswSwLoUahcK1Ffyapj", "mzwiRJ6YpRhK4Wmbb8CDMURNKK1xkBy1VU", "mk9GLZegLLACMQWkVWyD19en6nHX6GUBdS", "mhMB7UciTkCZv2kq7JAHzd66GCriaYdiJ1", "muPeWxKK9jN9xvenpsMhYg4YmYksGZaKDE", "mpBvH6NJ4FcEj9Xvqotxg2fzE7C5rSsXqa", "n48Do4Cdh4C9Jydqx5Br3qCsw8wSA6iZq9", "n2LDztd88tDHJHvNiL6JVuoyTxDoaRer2c", "mq17sZevp3iuDuzFyuAjykHsFuRL8PvxtV", "mxWCeXMqMNSQnpVrECvwcw18FXs5cfnj6R", "mvC9qxMtvne61tdrTJcR98b2STsXQJPS46", "mgRCU49roYu9AS7hWBgDZLNX2xDAAiKDTx", "mfcb1uCx1jmyvUK2yTATr5xMmpoj9uqyUT", "mhytD9wsHL7dRa5AZjZQL7BHibTdBmoqb1", "mfhKiyoC5UZv3MELyBpswoL6ALtLv6vCDv", "mrpj22W9xxaEAS2jNo34a4ArHZXug4TKrs", "mjQ4Ne3F3Ham6itmeMbcUTFWrHtT7SbTQS", "mtq6iaAkyviuqVRjBzCoy8zSBzV7EtnTrL", "mwtm8fSqoytMz7cSZ4JcfHBdtt7SotDvCn", "mq8fcgetQoxg4VBRqjSXoqavy7N2jXgNZ1", "muAuHQMbc2k6RKNqNNfbA78XC9A1ZWoU3p"]}
        p = TestDepositAddressPoolProducer()
        p.publish(data)


    def test_deposit_address_pool_consumer(self):
        c = DepositAddressPoolConsumer()
        c.consume()

