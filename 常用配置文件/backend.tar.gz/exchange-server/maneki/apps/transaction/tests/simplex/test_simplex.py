import uuid
from django.test import TestCase
from maneki.apps.transaction.services.fiat.deposit import FiatCreditCardService
from maneki.apps.transaction.models.fiat_currency import FiatCurrencyDepositRecordLastThreeMonths
from maneki.apps.user.models.user import User
from maneki.apps.user_kyc.models.kyc import KYCIndividual


class TestSimplex(TestCase):

    def setUp(self):
        FiatCurrencyDepositRecordLastThreeMonths.objects.create(
            user_id='5db28fb243724713a958865e87876d30',
            fiat_type=1,
            engine_sn='ecc47d60-a5f9-11e8-9681b-d950740adfb',
            engine_request_no='ecc47d60-a5f9-11e8-9681b-d950740adfb',
            engine_response_code=-99,
            status=5,
            amount=100,
            simplex_fee=10,
            deposit_type=1
        )
        User.objects.create(
            password='argon2$argon2i$v=19$m=512,t=2,p=2$a3M4RzJIQlZOSG9m$4veUa9ohnDrGIxT4O68lLg',
            is_superuser=1,
            username='user-82053188826',
            is_staff=0,
            user_id='5db28fb243724713a958865e87876d30',
            engine_token='6bc411f5622d7b8bfb6bef008c27742dc9ab14ae',
            email='miao.pi@btcc.com',
            mobile='+8613636393383',
            mobile_country_code='+86',
            email_verified=1,
            mobile_verified=1,
            status=0,
            is_active=1
        )
        KYCIndividual.objects.create(
            user_id='5db28fb243724713a958865e87876d30',
            license_country='CA',
            last_name='Shand',
            first_name='Colin',
            industry='Accounting',
            license_type='passport',
            license_number='S31791344910929',
            license_pic01='8c8f57ec4f5c40199715ab5346c734fc.png',
            license_pic03='f984f9d6d98a469ea732613bf6091bf8.png',
            address_cert='aab5f563e871457e84247db0d7757919.png',
            local_country='CA',
            local_city='Ottawa',
            local_region='OT',
            local_address='4387 Rainforest Drive, Ottawa, Ontario, k1v1l4, Canada',
            local_postcode='V1Y5E3',
            current_level=4,
            current_level_status='not_started',
            birth='1992-07-07'
        )

    def test_polling(self):
        FiatCreditCardService().simplex_event_processing()

    def test_initiate_request(self):
        FiatCreditCardService().init_request(
            '5db28fb243724713a958865e87876d30',
            '172.32.52.48',
            'https://www.google.com.hk/search?q=btcc&oq=btcc&aqs=chrome..69i57j69i60l5.2094j0j7&sourceid=chrome&ie=UTF-8',
            uuid.uuid4(),
            1,
            100,
            10
        )
