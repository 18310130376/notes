from django.test import TestCase
from maneki.apps.user_kyc.utils import is_cn_id_valid


class TestIdVerification(TestCase):

    def test_id_verification(self):
        self.assertTrue(is_cn_id_valid('43250119820205101X'))
        self.assertTrue(is_cn_id_valid('432501198903201527'))
        self.assertFalse(is_cn_id_valid('432501198202051011'))
        self.assertFalse(is_cn_id_valid('310920196401160087'))
        self.assertTrue(is_cn_id_valid('370920196401160087'))
        self.assertFalse(is_cn_id_valid(''))
        self.assertFalse(is_cn_id_valid('31920196401160087'))
        self.assertFalse(is_cn_id_valid('3109201964011600xx'))
        self.assertFalse(is_cn_id_valid('3109201***01160**7'))
