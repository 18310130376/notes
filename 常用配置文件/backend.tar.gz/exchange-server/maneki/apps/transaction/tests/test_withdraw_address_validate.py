# -*- coding: utf-8 -*-
from maneki.apps.transaction.utils.validate import validate_address
from maneki.apps.constants import CoinType
from django.test import TestCase
import logging

logger = logging.getLogger(__name__)


class TestWithdrawAddressValidated(TestCase):

    def setUp(self):
        self.btc_address = 'mtEXSUuSxhCb9Zu3YBhvgZphMgBGPXsDmW'
        self.btc_error_address = '1tEXSUuSxhCb9Zu3YBhvgZphMgBGPXsDmW'
        self.eth_address = '0xF8C368a95d03bFA73F02878c1Dad436Da1Bf6A58'
        self.eth_error_address = '0xF8C368a95d03bFA73F02878c1Dad436Da1Bf6A51'

    def test_validate_adress(self):
        # btc right
        try:
            validate_address(CoinType.BTC, self.btc_address)
            logger.info('1.btc address ok')
        except (ValueError, TypeError):
            logger.info('1.btc address error')
        # btc error
        try:
            validate_address(CoinType.BTC, self.btc_error_address)
            logger.info('2.btc address ok')
        except (ValueError, TypeError):
            logger.info('2.btc address error')
        # eth right
        try:
            validate_address(CoinType.ETH, self.eth_address)
            logger.info('3.eth address ok')
        except (ValueError, TypeError):
            logger.info('3.eth address error')

        # eth error
        try:
            validate_address(CoinType.ETH, self.eth_error_address)
            logger.info('4.eth address ok')
        except (ValueError, TypeError):
            logger.info('4.eth address error')

