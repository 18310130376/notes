# -*- coding: utf-8 -*-
import logging

from maneki.apps.user.models.user import User
from rest_framework.test import APIClient
from rest_framework.test import APITestCase

logger = logging.getLogger(__name__)


class TestDeposit(APITestCase):
    client = APIClient()
    login = APIClient().login(username='foo@bar.com', password='foobar123')
    user = User.objects.get(username='foo@bar.com')

    def test_deposit_list(self):
        is_login = self.login
        print(is_login)
        user = self.user
        self.client.force_authenticate(user=user)

        response_ok = self.client.get('/api/v1/transactions/fiat/deposit')
        data = {
            "code": 200,
            "detail": "ok",
            "data": []
        }
        self.assertEqual(
            response_ok.data,
            data,
        )



