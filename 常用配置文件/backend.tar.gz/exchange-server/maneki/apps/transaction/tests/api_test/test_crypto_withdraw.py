# -*- coding: utf-8 -*-
import logging

from maneki.apps.user.models.user import User
from rest_framework.test import APIClient
from rest_framework.test import APITestCase

logger = logging.getLogger(__name__)


class TestWithdraw(APITestCase):
    client = APIClient()
    login = APIClient().login(username='foo@bar.com', password='foobar123')
    user = User.objects.get(username='foo@bar.com')

    def test_withdraw_list(self):
        is_login = self.login
        print(is_login)
        user = self.user
        self.client.force_authenticate(user=user)

        response_ok = self.client.get('/api/v1/transactions/crypto/withdraw')
        data = {
            "code": 200,
            "detail": "ok",
            "data": []
        }
        self.assertEqual(
            response_ok.data,
            data,
        )

    def test_withdraw(self):
        is_login = self.login
        print(is_login)
        user = self.user
        self.client.force_authenticate(user=user)

        req_data = {
            "tx_address": "mqLghomWNtyT2eeKXLKXHGM8CVj3juv1u4",
            "tx_amount": 0.01,
            "coin_type": "0"
        }
        response_ok = self.client.post('/api/v1/transactions/crypto/withdraw', data=req_data)
        rep_data = {
            "code": 200,
            "detail": "ok",
            "data": {
                "sn": "45556e7d-a82f-4d3c-8def-0d632fb5f918"
            }
        }
        self.assertEqual(
            response_ok.data,
            rep_data,
        )
        

