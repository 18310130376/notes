# -*- coding: utf-8 -*-
import logging

from maneki.apps.user.models.user import User
from rest_framework.test import APIClient
from rest_framework.test import APITestCase

logger = logging.getLogger(__name__)


class TestDepositAddressView(APITestCase):
    client = APIClient()
    login = APIClient().login(username='foo@bar.com', password='foobar123')
    user = User.objects.get(username='foo@bar.com')


    def test_deposit_address_list_ok(self):
        is_login = self.login
        print(is_login)
        user = self.user
        self.client.force_authenticate(user=user)

        response_ok = self.client.get('/api/v1/transactions/crypto/deposit_address/?coin_type=0')
        data = {
                "data": [
                    {
                        "coin_type": 0,
                        "address": "mq4cbJKkeXfRvysubiW9K5zdp6pN4qzWia"
                    }
                ]
            }
        self.assertEqual(
            response_ok.data,
            data,
        )

    def test_deposit_address_list_450(self):
        is_login = self.login
        print(is_login)
        user = self.user
        self.client.force_authenticate(user=user)

        response_450 = self.client.get('/api/v1/transactions/crypto/deposit_address/?coin_type=')
        data = {
            "code": 450,
            "detail": "coin_type needed!",
            "data": {}
        }
        self.assertEqual(
            response_450.data,
            data,
        )

    def test_deposit_address_list_451(self):
        is_login = self.login
        print(is_login)
        user = self.user
        self.client.force_authenticate(user=user)

        response_451 = self.client.get('/api/v1/transactions/crypto/deposit_address/?coin_type=&&')
        data = {
            "code": 451,
            "detail": "invalid param!",
            "data": {}
        }
        self.assertEqual(
            response_451.data,
            data,
        )


class TestWithdrawAddressView(APITestCase):
    client = APIClient()
    login = APIClient().login(username='foo@bar.com', password='foobar123')
    user = User.objects.get(username='foo@bar.com')


    def test_withdraw_address_list_ok(self):
        is_login = self.login
        print(is_login)
        user = self.user
        self.client.force_authenticate(user=user)

        response_ok = self.client.get('/api/v1/transactions/crypto/withdraw_address/?coin_type=0')
        data = {
            "code": 200,
            "detail": "ok",
            "data": [
                {
                    "coin_type": 0,
                    "address": "mqLghomWNtyT2eeKXLKXHGM8CVj3juv1u4",
                    "label": "test"
                }
            ]
        }
        self.assertEqual(
            response_ok.data,
            data,
        )

    def test_withdraw_address_list_451(self):
        is_login = self.login
        print(is_login)
        user = self.user
        self.client.force_authenticate(user=user)

        response_451 = self.client.get('/api/v1/transactions/crypto/withdraw_address/?coin_type=')
        data = {
            "code": 451,
            "detail": "coin_type is required.",
            "data": {}
        }
        self.assertEqual(
            response_451.data,
            data
        )
