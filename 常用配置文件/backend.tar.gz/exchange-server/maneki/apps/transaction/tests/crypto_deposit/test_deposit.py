# -*- coding: utf-8 -*-
import uuid

from django.test import TestCase
import logging
from rest_framework.authtoken.models import Token

from maneki.apps.constants import TransactionType, WithdrawStatus
from maneki.apps.engine.services.engine import EngineService
from maneki.apps.transaction.services.crypto import WithdrawRequestToBlockchainProxyProducer, CryptoWithdrawService, \
    WithdrawResponseFromEngineConsumer
from maneki.apps.transaction.services.crypto.deposit_address import CryptoDepositAddressService
from maneki.apps.transaction.models.crypto_currency import CryptoDepositRecordLastThreeMonths
from maneki.apps.user.models import User
from maneki.apps.transaction.models.crypto_currency import BlockchainTransaction

logger = logging.getLogger('test_deposit')


def mock_data():
    data = {
        "id": "79",
        "password": "argon2$argon2i$v=19$m=512,t=2,p=2$d3R1eWNmd1g5QkYx$afZCqmRJ8TiMcdcYHTZuEQ",
        "last_login": "2018/05/04 08:19:18.502463",
        "is_superuser": "0",
        "username": "user-26440905071",
        "is_staff": "0",
        "date_joined": "2018/04/28 03:58:57.072315",
        "created_at": "2018/04/28 03:58:57.073913",
        "updated_at": "2018/04/28 06:47:40.272094",
        "is_deleted": "0",
        "deleted_at": "",
        "uid": "84bfb451e13841b2b53ac77177719373",
        "engine_token": "2846dce6ee4be097b217e0378f1e8f657dbe0065",
        "email": "test1@126.com",
        "mobile": "",
        "mobile_country_code": "",
        "verify_code": "00982727",
        "email_verified": "1",
        "mobile_verified": "0",
        "totp_device_verified": "0",
        "status": "0",
        "is_active": "1",
        "trade_password": ""
    }
    user = User.objects.create(
        email=data.get('email'), password='lj13043X', is_active=1,
        is_superuser=0, username=data.get('username'), is_staff=0,
        user_id=data.get('uid'),
        engine_token=data.get('engine_token'),
        verify_code=data.get('verify_code'), status=0
    )
    #token = Token.objects.create(key='b48b7719ee49228896b5d15d11226f6c4dfc18dd', user_id=user.id)
    token = None
    return user, token


class TestDeposit(TestCase):

    def setUp(self):
        data = {
            'status': 1,
            'tx_id': '2c0467239c2750717fe8fa91034c0682340a7ed2d3108c7758873179aedd6a44',
            'tx_sub_id': '',
            'tx_address': 'mgNgPqUeVQ17uNGS6k6VfEiwpdVahd8yB8',
            'tx_amount': '650000000.00000000000000000000',
            'tx_fee': '0.00000000000000000000',
            'coin_type': 0,
            'updated_at': '2018-05-10T02:08:21.283696Z',
            'user_id': '84bfb451-e138-41b2-b53a-c77177719373',
            'engine_sn': '5d5c41b9-0252-4edb-91ed-a3731f26b5fa',
            'engine_request_no': '402fc944-b314-4f25-b582-e31bd21804eb'}
        # 初始化充值地址信息
        self.address_service = CryptoDepositAddressService()
        self.address_service.create_record(
            user_id='84bfb451e13841b2b53ac77177719373',
            coin_type=0,
            tx_address='mksnCXgSR1JBUatpkWuTkuxPjSwF5q8Hpo')
        # 初始化用户
        self.user, self.token = mock_data()
        # 初始化交易记录
        self.tx_model = BlockchainTransaction
        self.tx_model.objects.create(
            tx_id=data['tx_id'],
            block_id='0000000000000278dbf61bdd9968819e7ba9af4aa8e7bc5c60734459edd3158c',
            coin_type=data['coin_type'],
            miner_fee=0,
            confirmations=0,
            status=1,
            tx_type=TransactionType.DEPOSIT)
        # 初始化提现记录
        self.model = CryptoDepositRecordLastThreeMonths

        self.model.objects.create(**data)

    def test_deposit_consumer(self):
        payload = {
            "coin_type": 3,
            "tx_id": "c6234f9764d57f83d4789e3b109b97cab782152274ac9f592c52154c6ebea0cd",
            "confirmations": 0,
            "status": 0,
            "update_time": "2018-05-18T03:25:55.000000+0000",
            "block_id": "0000000000350c2001d1f18c1e136a9a71ec68d8de1804c610dddf2b2ab367dc",
            "txs": [
                {"target_address": "mksnCXgSR1JBUatpkWuTkuxPjSwF5q8Hpo",
                 "coin_value": "13.0"}
            ],
            "nonce": "oH8WXcPc",
            "timestamp": 1526613955629,
            "sign": "9f5527dc7a4d00e0a476f03cd717af28b96467c9a4475002983c028d5d46f83e"}
        self.wallet_consumer.do_task(payload)

        payload2 = {"coin_type": 3,
                    "tx_id": "c6234f9764d57f83d4789e3b109b97cab782152274ac9f592c52154c6ebea0cd", "confirmations": 6, "status": 1,
                    "update_time": "2018-05-18T05:06:53.000000+0000",
                    "block_id": "0000000000350c2001d1f18c1e136a9a71ec68d8de1804c610dddf2b2ab367dc",
                    "txs": [
                        {
                            "target_address": "mksnCXgSR1JBUatpkWuTkuxPjSwF5q8Hpo",
                            "coin_value": "13.0",
                            "region": "stage_product", "index": 4}],
                    "nonce": "vJFVTSGm",
                    "timestamp": 1526620013946,
                    "sign": "5b64372c0266bac3e9c2cde6a140337302a57dc0041dd76b31df2935b9e412c7"}
        self.wallet_consumer.do_task(payload2)

    def test_deposit_engine_consumer(self):
        payload = {
            "deposit": [{
                "status": 1,
                "tx_id": "2c0467239c2750717fe8fa91034c0682340a7ed2d3108c7758873179aedd6a44",
                "tx_sub_id": "",
                "tx_address": "mgNgPqUeVQ17uNGS6k6VfEiwpdVahd8yB8",
                "tx_amount": "650000000.00000000000000000000",
                "tx_fee": "0.00000000000000000000",
                "coin_type": 0,
                "updated_at": "2018-05-07T03:21:11.158185Z",
                "user_id": "84bfb451-e138-41b2-b53a-c77177719373",
                "engine_sn": "5ccfa436-8c26-477d-a1d6-649a6b07eddc",
                "engine_request_no": "88e26b72-2dd0-4a0e-9251-fb964db0c14d"
            }]
        }
        self.engine_consumer.do_task(payload)

    def test_withdraw_rpc(self):
        payload = {"request_no": "0c2b71d9c1db4369a69b04cef61014c5",
                   "sn": "f7dc1da9e26142ffacdc84c19065c0b7",
                   "coin_type": "LTC",
                   "amount": "1.00100000000000000002",
                   "username": "5ebf4a57a99f4b48bc23e9daa000a3d3",
                   "nonce": "dpB5rIgm",
                   "timestamp": 1526641843181,
                   "sign": "d1d170a569f17d5a0c4bece7dd186f6391763e333fd1caf4d04e435c64cb03df"}

        # msg = {"MsgType": "WithdrawalRequest",
        #        "Currency": "BTC",
        #        "Amount": "0.01100000000000000002",
        #        "TargetAccount": "5a3c8cfd1e4f4285822577c04bcc5346",
        #        "CRID": "2d1cd000e1d049aa81d0f6e67dbeb53e",
        #        "Date": "20180510",
        #        "Account": "80bb23e4ccba7d9b17882ba8073d06d0",
        #        "Key": "141D80FA9161EBBECE6F4CB19331DCCF8175A2FA",
        #        "SIG": "d8960f2f1b98963d906ca4f639ce9e760e7d4736"}
        # service = EngineService()
        # result = service.withdraw(request_id=uuid.uuid4().hex,
        #                           coin_type="BTC",
        #                           amount="1.0010000000",
        #                           username='5a3c8cfd1e4f4285822577c04bcc5346',)
        # logger.info('rpc result: {}'.format(result))

        p = WithdrawRequestToBlockchainProxyProducer()
        service = CryptoWithdrawService()
        task = {
            "coin_type": 0,
            "sn": "4f401d8b7be14e4687bcd5d7ff70903e",
            "target_address": "2N6sSxpjdSNx9dHvbixs2FmFFZt1Pg69eBf",
            "amount": "1.00000000000000000000",
        }
        p.publish(task)

    def test_withdraw_inbox(self):
        payload = {
            "request_no": "9dd0e3a24da34eb78137fd23259dd9bd",
            "sn": "125823bc263b43c288a6296e802c7605",
            "coin_type": "BCH",
            "amount": "0.02010000000000000000",
            "username": "5ebf4a57a99f4b48bc23e9daa000a3d3",
            "nonce": "Xpfe3aRd",
            "timestamp": 1526627785745,
            "sign": "032781a8b92152bcd718bc1860a92733656c430c2b606db6215b1566168cf527"
        }
        consumer = WithdrawResponseFromEngineConsumer()
        consumer.do_task(payload=payload)

    def test_engine_response_update(self):
        WithdrawStatus.ENGINE_COMPLETED
