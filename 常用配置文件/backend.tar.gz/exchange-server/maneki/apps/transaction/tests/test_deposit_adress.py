# -*- coding: utf-8 -*-
import logging

from maneki.apps.user.models.user import User
from rest_framework.test import APIClient
from rest_framework.test import APITestCase
from rest_framework import status

logger = logging.getLogger(__name__)


class TestDepositAddressView(APITestCase):

    # def setUp(self):
    #     super(TestDepositAddressView, self).setUp()
    #     # create view
    #     self.view = CoinDepositAddressViewSetV2()
    #     # create fake request
    #     request = self.factory.get('/api/v1/transactions/crypto/deposit_address2?coin_type=0')
    #     # attach user to request
    #     request.user = self.user
    #     # attach request to view
    #     self.view.request = request

    def test_deposit_address_list(self):
        client = APIClient()
        is_login = client.login(username='1946218941@qq.com', password='lj13043X')
        print(is_login)
        # Include an appropriate `Authorization:` header on all requests.
        user = User.objects.get(username='1946218941@qq.com')
        client.force_authenticate(user=user)
        response = client.get('/api/v1/transactions/crypto/deposit_address2?coin_type=0')
        data = {
                "data": [
                    {
                        "coin_type": 0,
                        "address": "abc"
                    }
                ]
            }
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(
            response.data,
            data,
        )

