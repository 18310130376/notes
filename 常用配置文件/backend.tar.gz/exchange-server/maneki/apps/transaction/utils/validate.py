# -*- encoding:utf-8 -*-
import logging
from decimal import Decimal

from eth_utils import is_address
from eth_utils import is_checksum_address
from eth_utils import is_checksum_formatted_address
from eth_utils import is_dict
from eth_utils import is_list_like
from pycoin.key.validate import is_address_valid as validate_btc_address

from maneki.apps.constants import ETH_GROUP, BTC_GROUP

logger = logging.getLogger(__name__)

ETHER_PER_WEI = Decimal(int(1e18))


def validate_abi(abi):
    """
    Helper function for validating an ABI
    """
    if not is_list_like(abi):
        raise TypeError("'abi' is not a list")
    for e in abi:
        if not is_dict(e):
            raise TypeError("The elements of 'abi' are not all dictionaries")


def validate_eth_address(address):
    """
    Helper function for validating an address
    """
    if not is_address(address):
        raise TypeError("'address' is not an address")
    validate_address_checksum(address)


def validate_address_checksum(address):
    """
    Helper function for validating an address EIP55 checksum
    """
    if is_checksum_formatted_address(address):
        if not is_checksum_address(address):
            raise ValueError("'address' has an invalid EIP55 checksum")


def ether_to_wei(ether):
    if ether == 0:
        return Decimal(0)
    r = Decimal(ether) * ETHER_PER_WEI
    return r.normalize()


# Todo: xxx
def validate_address(coin_type, address):
    """校验 BTC / ETH 系列地址格式合法性

    :param coin_type:
    :param address:
    :return:
    """
    # TODO: 无法校验
    if coin_type in BTC_GROUP:
        return bool(validate_btc_address(address))

    if coin_type in ETH_GROUP:
        try:
            validate_eth_address(address)
        except Exception as e:
            logger.error("invalid address: {}, error: {}".format(address, e))
            return False
        return True

    logger.error("invalid address: {}".format(address))
    return False
