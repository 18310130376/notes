from maneki.taskapp.messagequeue.tasks import send_email


def send_verify_email(email, verify_code):
    """日常操作的验证码

    :param email:
    :param verify_code:
    :return:
    """
    email_template = "trade_verify"

    send_email.delay(
        user="",
        email=email,
        verify_code=verify_code,
        email_subject="Please Verify Your Operation",
        email_template=email_template,
    )
