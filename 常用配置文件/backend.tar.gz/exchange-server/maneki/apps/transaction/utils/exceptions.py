from rest_framework import status
from rest_framework.exceptions import APIException


class VerificationMissing(APIException):
    default_detail = 'Verifications missing.'


class InvalidWithdrawStatus(APIException):
    pass


class EngineRequestError(APIException):
    pass


class WithdrawLimitExceeded(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = 'Withdraw limit exceeded.'


class WithdrawReqTooMany(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = 'A withdraw request is in progress.'


class WithdrawInvalidAddress(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = "This address does not set."


class UserInvalidAddress(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = "This address does not belong to the user account."


class AddressInvalidFormat(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = "Invalid address format."


class AddressLimitExceeded(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = 'Withdraw address limit exceeded for this coin.'


class AddressDuplicated(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = 'This address exists.'


class AddressUsedByOthers(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = 'This address has been used by others!'


class AddressUsedByDeposit(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = 'This address has been used by deposit.'


class FiatWithdrawRecordNotFound(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = 'This record not found'


class FiatDepositRecordNotFound(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = 'This record not found'
