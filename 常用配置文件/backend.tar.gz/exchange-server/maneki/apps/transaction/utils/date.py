from maneki.apps.common.utils import date


def format_time_duration(timestamp_start, timestamp_end):
    if timestamp_start and timestamp_end:
        timestamp_start = date.unix_to_datetime(int(timestamp_start[0:10]), "%Y-%m-%d %H:%M:%S")
        timestamp_end = date.unix_to_datetime(int(timestamp_end[0:10]), "%Y-%m-%d %H:%M:%S")
    else:
        timestamp_start = date.utc_now_str(timedelta_day=30)
        timestamp_end = date.utc_now_str()

    return timestamp_start, timestamp_end
