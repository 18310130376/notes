# -*- coding: utf-8 -*-
import uuid
from django.db import models
from django.utils.translation import ugettext_lazy as _
from maneki.apps.constants import EngineResponseCode, WithdrawRequestVerifyReason, FiatDepositType, FiatDepositStatus, SimplexEventName
from maneki.apps.common.libs.models import BaseModel, UserSoftDeleteModel
from maneki.apps.constants import FiatType
from maneki.apps.constants import WithdrawStatus
from maneki.apps.constants import DepositStatus
from maneki.apps.constants import MODEL_PREFIX
from maneki.apps.constants import EngineResponseCode
from maneki.apps.common.utils.decimal import format_amount
from maneki.apps.assets.services.user_fiat_account import UserFiatAccountService

from maneki.apps.user.models import User
# 前缀:
PREFIX_DB_VERBOSE = "Transaction Record"
PREFIX_DB_TABLE = MODEL_PREFIX + "tx_record_"


####################################################
#     BASE MODEL
####################################################
class FiatTransactionBaseModel(UserSoftDeleteModel):
    fiat_type = models.IntegerField(verbose_name=_("Fiat Type"), default=FiatType.UNDEFINED, choices=FiatType.choices)
    amount = models.DecimalField(verbose_name=_("Fiat Amount"), default=0, max_digits=40, decimal_places=20)
    #
    bank_label = models.CharField(verbose_name=_("Bank Label"), default="", max_length=255)
    bank_code = models.CharField(verbose_name=_("Bank Code"), default="", max_length=255)
    bank_account = models.CharField(verbose_name=_("Bank Account"), default="", max_length=255)
    # engine:
    # TODO: 交易引擎ID设计
    engine_sn = models.UUIDField(verbose_name=_("Engine SN Number"), unique=True, default=uuid.uuid4,
                                 editable=False, )
    engine_request_no = models.UUIDField(verbose_name=_("Engine Request Number"), default=uuid.uuid4, max_length=255)
    engine_response_code = models.IntegerField(verbose_name=_("Engine Response Code"),
                                               default=EngineResponseCode.UNDEFINED,
                                               choices=EngineResponseCode.choices, )

    class Meta:
        abstract = True

    @property
    def amount_fmt(self):
        # return "{:.2f}".format(self.amount) Can not directly cut out. it Rounding the number
        return format_amount(self.amount)

    @property
    def engine_sn_id(self):
        return str(self.engine_sn.hex)

    @property
    def engine_request_no_id(self):
        return str(self.engine_request_no.hex)

    @property
    def user_email(self):
        obj = User.objects.filter(user_id=self.user_id).first()
        if obj:
            return obj.email

####################################################
#     法币(Fiat Currency) 交易: 充值
####################################################


# 最近3个月的法币充值记录:
class FiatCurrencyDepositRecordLastThreeMonths(FiatTransactionBaseModel):
    # 充值状态:
    status = models.IntegerField(verbose_name=_("Deposit Status"), default=FiatDepositStatus.UNDEFINED,
                                 choices=FiatDepositStatus.choices, )
    remitter = models.CharField(verbose_name=_("remitter name"), max_length=30, default='')
    bank_sn = models.CharField(verbose_name=_("Bank Serial Number"), max_length=128, default='')
    collection_date = models.DateTimeField(verbose_name=_("collection date"), default='1970-01-01')
    deposit_code = models.CharField(verbose_name=_("RN"), default='', max_length=128)
    simplex_fee = models.DecimalField(verbose_name=_("simplex_fee"), default=0, max_digits=40, decimal_places=20)
    deposit_type = models.IntegerField(help_text="充值方式：银行转账/信用卡", default=FiatDepositType.BANK_TRANSFER, choices=FiatDepositType.choices)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": Fiat Deposit Last 3 Months")
        db_table = PREFIX_DB_TABLE + "fiat_deposit_last_3months"


# 所有充值记录:
class FiatCurrencyDepositRecord(FiatTransactionBaseModel):
    # 充值状态:
    status = models.IntegerField(verbose_name=_("Deposit Status"), default=FiatDepositStatus.UNDEFINED,
                                 choices=FiatDepositStatus.choices, )
    remitter = models.CharField(verbose_name=_("remitter name"), max_length=30, default='')
    bank_sn = models.CharField(verbose_name=_("Bank Serial Number"), max_length=128, default='')
    collection_date = models.DateTimeField(verbose_name=_("收款日期"), default='1970-01-01')
    deposit_code = models.CharField(verbose_name=_("RN"), default='', max_length=128)
    simplex_fee = models.DecimalField(verbose_name=_("simplex_fee"), default=0, max_digits=40, decimal_places=20)
    deposit_type = models.IntegerField(help_text="充值方式：银行转账/信用卡", default=FiatDepositType.BANK_TRANSFER, choices=FiatDepositType.choices)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": Fiat Deposit")
        db_table = PREFIX_DB_TABLE + "fiat_deposit"


class SimplexEvent(BaseModel):
    event_id = models.CharField(max_length=40)
    payment_id = models.CharField(max_length=40)
    name = models.CharField(default=SimplexEventName.PENDING, choices=SimplexEventName.choices, max_length=30)
    status = models.CharField(max_length=64)
    emit_time = models.DateTimeField()

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": Simplex Event")
        db_table = PREFIX_DB_TABLE + "simplex_event"

####################################################
#     法币(FiatCurrency) 交易: 提现
####################################################

# 最近3个月的法币提现记录:
class FiatCurrencyWithdrawRecordLastThreeMonths(FiatTransactionBaseModel):
    # 提现状态:
    status = models.IntegerField(verbose_name=_("Withdraw Status"), default=WithdrawStatus.UNDEFINED,
                                 choices=WithdrawStatus.choices, )
    verify_detail = models.IntegerField(verbose_name=_("Admin Verify Status"),
                                        default=WithdrawRequestVerifyReason.UNDEFINED,
                                        choices=WithdrawRequestVerifyReason.choices, )
    out_money_bank_sn = models.CharField(verbose_name=_("out fo money bank sn"), default="", max_length=128)
    beneficiary_name = models.CharField(default="", max_length=255)
    # fee:
    service_charge = models.DecimalField(verbose_name=_("Fiat service charge 0.03%"), default=0, max_digits=40, decimal_places=20)
    # 资金冻结请求及状态
    freeze_request_no = models.UUIDField(verbose_name=_("freeze assets request no"), null=True, default=uuid.uuid4, max_length=32)
    freeze_status = models.IntegerField(verbose_name=_("freeze status"), default=-1, )

    extra_1 = models.CharField(default="", max_length=255)
    extra_2 = models.CharField(default="", max_length=255)
    extra_3 = models.CharField(default="", max_length=255)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": Fiat Withdraw Last 3 Months")
        db_table = PREFIX_DB_TABLE + "fiat_withdraw_last_3months"

    @property
    def service_charge_fmt(self):
        return format_amount(self.service_charge)

    @property
    def total(self):
        total = abs(self.amount) + abs(self.service_charge)
        return format_amount(total, scale=8)

    @property
    def bank_info(self):
        if not hasattr(self, '_bank_info'):
            service = UserFiatAccountService()
            self._bank_info = service.filter_record(user_id=self.user_id, fiat_type=self.fiat_type, bank_account=self.bank_account)
        return self._bank_info

    @property
    def via_bank_name(self):
        return self.bank_info.via_bank_name if self.bank_info else ''

    @property
    def via_bank_address(self):
        return self.bank_info.via_bank_address if self.bank_info else ''

    @property
    def via_bank_swift_code(self):
        return self.bank_info.via_bank_swift_code if self.bank_info else ''

    @property
    def bank_address(self):
        return self.bank_info.bank_address if self.bank_info else ''

    @property
    def bank_name(self):
        return self.bank_info.bank_name if self.bank_info else ''

    @property
    def bank_swift_code(self):
        return self.bank_info.bank_swift_code if self.bank_info else ''

    @property
    def beneficiary_address(self):
        return self.bank_info.beneficiary_address if self.bank_info else ''


# 所有提现记录:
class FiatCurrencyWithdrawRecord(FiatTransactionBaseModel):
    # 提现状态:
    status = models.IntegerField(verbose_name=_("Withdraw Status"), default=WithdrawStatus.UNDEFINED,
                                 choices=WithdrawStatus.choices, )
    verify_detail = models.IntegerField(verbose_name=_("Admin Verify Status"),
                                        default=WithdrawRequestVerifyReason.UNDEFINED,
                                        choices=WithdrawRequestVerifyReason.choices, )
    out_money_bank_sn = models.CharField(verbose_name=_("out fo money bank sn"), default="", max_length=128)
    beneficiary_name = models.CharField(default="", max_length=255)
    # fee:
    service_charge = models.DecimalField(verbose_name=_("Fiat service charge 0.03%"), default=0, max_digits=40, decimal_places=20)
    # 资金冻结请求及状态
    freeze_request_no = models.UUIDField(verbose_name=_("freeze assets request no"), null=True, default=uuid.uuid4, max_length=32)
    freeze_status = models.IntegerField(verbose_name=_("freeze status"), default=-1, )

    extra_1 = models.CharField(default="", max_length=255)
    extra_2 = models.CharField(default="", max_length=255)
    extra_3 = models.CharField(default="", max_length=255)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": Fiat Withdraw")
        db_table = PREFIX_DB_TABLE + "fiat_withdraw"

    @property
    def service_charge_fmt(self):
        return format_amount(self.service_charge)

    @property
    def total(self):
        total = abs(self.amount) + abs(self.service_charge)
        return format_amount(total, scale=8)

