# -*- coding: utf-8 -*-
from django.db import models
from django.utils.translation import ugettext_lazy as _

from maneki.apps.common.libs.models import UserSoftDeleteModel
from maneki.apps.constants import MODEL_PREFIX
from maneki.apps.constants import VerificationStatus
from maneki.apps.constants import VerificationType

# 前缀:
PREFIX_DB_VERBOSE = "Transaction Verification"
PREFIX_DB_TABLE = MODEL_PREFIX + "tx_"


# 交易审核:
class TransactionVerification(UserSoftDeleteModel):
    # 操作关联:
    record_id = models.CharField(verbose_name=_("Record ID"), default="", max_length=255)
    # 审核阶段:
    verify_stage = models.IntegerField(verbose_name=_("Verify Stage"), default=VerificationType.UNDEFINED, choices=VerificationType.choices)
    verify_label = models.CharField(verbose_name=_("Verify Label"), default="", max_length=255)
    #
    status = models.IntegerField(verbose_name=_("Status"), default=VerificationStatus.CREATED, choices=VerificationStatus.choices)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE)
        db_table = PREFIX_DB_TABLE + "verification"
