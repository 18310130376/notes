# -*- coding: utf-8 -*-
import uuid
from django.db import models
from django.utils.translation import ugettext_lazy as _

from maneki.apps.common.libs.models import UserSoftDeleteModel, SoftDeleteModel
from maneki.apps.constants import CoinType
from maneki.apps.constants import EngineResponseCode
from maneki.apps.constants import DepositStatus
from maneki.apps.constants import MODEL_PREFIX
from maneki.apps.constants import TransactionStatus
from maneki.apps.constants import TransactionType
from maneki.apps.constants import WithdrawStatus
from maneki.apps.constants import WithdrawRequestVerifyReason
from maneki.apps.common.utils.decimal import format_amount
from maneki.apps.user.models import User

# 前缀:


PREFIX_DB_VERBOSE = "Transaction Record"
PREFIX_DB_TABLE = MODEL_PREFIX + "tx_record_"


####################################################
#     数字代币(coin) 交易: 充值
####################################################


# 区块链tx记录:
class BlockchainTransaction(SoftDeleteModel):
    # TODO: inner_withdraw() tx_id 写入过, 会导致: 既是充值, 又是提现情况.(无法处理)

    # TODO: withdraw-tx-id: 拼接格式 [1:tx_id]
    tx_id = models.CharField(verbose_name=_("Block Transaction ID"), default="", max_length=255, unique=True)
    block_id = models.CharField(verbose_name=_("Block ID"), default="", max_length=255)
    coin_type = models.IntegerField(verbose_name=_("Coin Type"), default=CoinType.UNDEFINED, choices=CoinType.choices)
    miner_fee = models.DecimalField(verbose_name=_("Miner fee"), default=0, max_digits=40, decimal_places=20)  # 小数点后位数
    #
    confirmations = models.PositiveSmallIntegerField(verbose_name=_("Tx Confirmations"), default=0)
    status = models.IntegerField(verbose_name=_("Tx Status"), default=TransactionStatus.UNDEFINED, choices=TransactionStatus.choices, )
    # 交易类型: 充值/提现 todo: 一笔tx, 对不同用户, 可能既是充值, 又是提现
    tx_type = models.IntegerField(verbose_name=_("Tx Op Type"), default=TransactionType.UNDEFINED, choices=TransactionType.choices, )

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": Blockchain")
        db_table = PREFIX_DB_TABLE + "blockchain"


####################################################
#     BASE MODEL
####################################################
class TransactionBaseModel(UserSoftDeleteModel):
    coin_type = models.IntegerField(verbose_name=_("Coin Type"), default=CoinType.UNDEFINED, choices=CoinType.choices)
    #
    tx_id = models.CharField(verbose_name=_("Block Transaction ID"), default="", max_length=255)
    tx_address = models.CharField(verbose_name=_("Crypto Address"), default="", max_length=100)
    tx_amount = models.DecimalField(verbose_name=_("Tx Amount"), default=0, max_digits=40, decimal_places=20)
    tx_fee = models.DecimalField(verbose_name=_("Tx Total Fee"), default=0, max_digits=40, decimal_places=20)
    confirmations = models.PositiveSmallIntegerField(verbose_name=_("Tx Confirmations"), default=0)
    # engine:
    # TODO: 交易引擎ID设计
    engine_sn = models.UUIDField(verbose_name=_("Engine SN Number"), unique=True, default=uuid.uuid4, editable=False, )
    engine_request_no = models.UUIDField(verbose_name=_("Engine Request Number"), default=uuid.uuid4, max_length=255)
    engine_code = models.IntegerField(verbose_name=_("Engine Response Code"), default=EngineResponseCode.UNDEFINED, choices=EngineResponseCode.choices, )

    class Meta:
        abstract = True

    @property
    def engine_account_id(self):
        user = User.objects.filter(user_id=self.user_id_hex).first()
        return user.engine_account_id

    @property
    def engine_sn_id(self):
        return str(self.engine_sn.hex)

    @property
    def engine_request_no_id(self):
        return str(self.engine_request_no.hex)

    @property
    def tx_amount_fmt(self):
        return format_amount(self.tx_amount, scale=8)

    @property
    def tx_fee_fmt(self):
        return format_amount(self.tx_fee, scale=8)

    @property
    def tx_total(self):
        total = abs(self.tx_amount) + abs(self.tx_fee)
        return format_amount(total, scale=8)


#
# 最近3个月的充值记录:
#   - 查询速度优化
#   - 定时脚本: 定期清理此表超范围记录.(软删除, 很久之后, 再硬删除)
#
class CryptoDepositRecordLastThreeMonths(TransactionBaseModel):
    tx_sub_id = models.CharField(verbose_name=_("Block Sub Transaction ID"), default="", blank=False, max_length=30)
    # 充值状态:
    status = models.IntegerField(verbose_name=_("Deposit Status"), default=DepositStatus.UNDEFINED, choices=DepositStatus.choices, )

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": Crypto Deposit Last 3 Months")
        db_table = PREFIX_DB_TABLE + "crypto_deposit_last_3months"


# 充值记录全表:
class CryptoDepositRecord(TransactionBaseModel):
    tx_sub_id = models.CharField(verbose_name=_("Block Sub Transaction ID"), default="", blank=False, max_length=30)
    # 充值状态:
    status = models.IntegerField(verbose_name=_("Deposit Status"), default=DepositStatus.UNDEFINED, choices=DepositStatus.choices, )

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": Crypto Deposit(All)")
        db_table = PREFIX_DB_TABLE + "crypto_deposit"


####################################################
#     数字代币(coin) 交易: 提现
####################################################

#
# 最近3个月的提现记录:
#   - 查询速度优化
#   - 定时脚本: 定期清理此表超范围记录.(软删除, 很久之后, 再硬删除)
#
class CryptoWithdrawRecordLastThreeMonths(TransactionBaseModel):
    tx_sub_id = models.CharField(verbose_name=_("Block Sub Transaction ID"), default="", blank=False, max_length=30)
    to_address = models.CharField(verbose_name=_("Withdraw to Address"), default="", max_length=255)
    # 提现状态:
    status = models.IntegerField(verbose_name=_("Withdraw Status"), default=WithdrawStatus.UNDEFINED, choices=WithdrawStatus.choices, )
    verify_detail = models.IntegerField(verbose_name=_("Admin Verify Status"), default=WithdrawRequestVerifyReason.UNDEFINED, choices=WithdrawRequestVerifyReason.choices, )

    # 客服管理员信息
    accessor = models.CharField(verbose_name=_("Admin Crypto Withdraw Info"), default="", max_length=30)
    verify_type = models.IntegerField(verbose_name=_("Verify info"), default=0, )
    # 资金冻结请求及状态
    freeze_request_no = models.UUIDField(verbose_name=_("freeze assets request no"), null=True, default=uuid.uuid4, max_length=32)
    freeze_status = models.IntegerField(verbose_name=_("freeze status"), default=-1, )

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": Crypto Withdraw Last 3 Months")
        db_table = PREFIX_DB_TABLE + "crypto_withdraw_last_3months"

    @property
    def user(self):
        user = User.objects.filter(user_id=self.user_id).first()
        return user

    @property
    def user_email(self):

        return self.user.email if self.user else ""

    @property
    def username(self):
        return self.user.username if self.user else ""


class CryptoWithdrawRecord(TransactionBaseModel):
    tx_sub_id = models.CharField(verbose_name=_("Block Sub Transaction ID"), default="", blank=False, max_length=30)
    to_address = models.CharField(verbose_name=_("Withdraw to Address"), default="", max_length=255)

    # 提现状态:
    status = models.IntegerField(verbose_name=_("Withdraw Status"), default=WithdrawStatus.UNDEFINED,
                                 choices=WithdrawStatus.choices, )
    verify_detail = models.IntegerField(verbose_name=_("Admin Verify Status"),
                                        default=WithdrawRequestVerifyReason.UNDEFINED,
                                        choices=WithdrawRequestVerifyReason.choices, )
    # 客服管理员信息
    accessor = models.CharField(verbose_name=_("Admin Crypto Withdraw Info"), default="", max_length=30)
    verify_type = models.IntegerField(verbose_name=_("Verify info"), default=0, )
    # 资金冻结请求及状态
    freeze_request_no = models.UUIDField(verbose_name=_("freeze assets request no"), null=True, default=uuid.uuid4, max_length=32)
    freeze_status = models.IntegerField(verbose_name=_("freeze status"), default=-1, )

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + ": Crypto Withdraw(All)")
        db_table = PREFIX_DB_TABLE + "crypto_withdraw"
