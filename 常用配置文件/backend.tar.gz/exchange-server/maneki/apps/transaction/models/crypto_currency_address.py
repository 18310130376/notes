import uuid

from django.db import models
from django.utils.translation import ugettext_lazy as _

from maneki.apps.common.libs.models import UserSoftDeleteModel, SoftDeleteModel
from maneki.apps.constants import CoinSeries
from maneki.apps.constants import CoinType
from maneki.apps.constants import DepositAddressStatus
from maneki.apps.constants import MODEL_PREFIX
from maneki.apps.constants import WithdrawAddressStatus

# 前缀:
PREFIX_DB_VERBOSE = "Crypto Currency "
PREFIX_DB_TABLE = MODEL_PREFIX + "tx_crypto_currency_"


#################################################################################
#                          BASE MODEL
#################################################################################
# base model:
class AddressBaseModel(UserSoftDeleteModel):
    id = models.UUIDField(verbose_name=_("Address Id"), primary_key=True, default=uuid.uuid4, editable=False)
    address = models.CharField(verbose_name=_("Coin Address"), default="", max_length=255, unique=True)
    coin_type = models.IntegerField(verbose_name=_("Coin Type"), default=CoinType.UNDEFINED, choices=CoinType.choices)
    #
    label = models.CharField(verbose_name=_("Address Label / Notes"), default="", max_length=255)
    # 状态: 正常/禁用
    status = models.IntegerField(verbose_name=_("Address Status"), default=DepositAddressStatus.UNDEFINED, choices=DepositAddressStatus.choices)

    class Meta:
        abstract = True


##################################################################################
#                              充值
##################################################################################
# 充值地址池:
class CryptoDepositAddressPool(SoftDeleteModel):
    address = models.CharField(verbose_name=_("Coin Address"), default="", max_length=255, unique=True)
    coin_series = models.IntegerField(verbose_name=_("Coin Series"), default=CoinSeries.UNDEFINED, choices=CoinSeries.choices)  # BTC 系列, ETH 系列
    # 状态: 已使用, 未使用, 已禁止
    status = models.IntegerField(verbose_name=_("Address Status"), default=DepositAddressStatus.UNDEFINED, choices=DepositAddressStatus.choices)
    # 扫币搜索更快:
    address_region = models.CharField(verbose_name=_("Coin Address Region"), default="", max_length=255)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + "Deposit Address Pool")
        db_table = PREFIX_DB_TABLE + "deposit_address_pool"


# 充值地址:
class CryptoDepositAddress(AddressBaseModel):

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + "Deposit Address")
        db_table = PREFIX_DB_TABLE + "deposit_address"


#
# 用户充值地址历史:
#   - 当用户新生成充值地址, 就把旧的地址, 从 DepositAddress 移出, 写入到此表
#   - 保证 DepositAddress 单一用户单一币种, 地址唯一
#
class CryptoDepositAddressHistory(AddressBaseModel):
    # 地址使用历史顺序:(可选)
    version = models.IntegerField(verbose_name=_("Address Sort"), default=-1)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + "Deposit Address History")
        db_table = PREFIX_DB_TABLE + "deposit_address_history"


##################################################################################
#                              提现
##################################################################################

#
# 提现地址:
#   - 地址使用历史顺序: 在redis的session中实现.
#
class CryptoWithdrawAddress(AddressBaseModel):
    # 状态: 正常/禁用
    status = models.IntegerField(verbose_name=_("Address Status"), default=WithdrawAddressStatus.NORMAL, choices=WithdrawAddressStatus.choices)
    address = models.CharField(verbose_name=_("Coin Address"), default="", max_length=255)

    class Meta:
        verbose_name = _(PREFIX_DB_VERBOSE + "Withdraw Address")
        db_table = PREFIX_DB_TABLE + "withdraw_address"
