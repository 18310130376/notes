from django.apps import AppConfig


class TransactionConfig(AppConfig):
    name = 'maneki.apps.transaction'
    verbose_name = "Transaction"
