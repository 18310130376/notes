# -*- coding: utf-8 -*-
import datetime

from celery.schedules import crontab
from celery.task import periodic_task
from celery.utils.log import get_task_logger
from django.utils import timezone

from maneki.apps.constants import WithdrawStatus
from maneki.apps.transaction.models import FiatCurrencyWithdrawRecordLastThreeMonths, \
    CryptoWithdrawRecordLastThreeMonths
from maneki.apps.transaction.services.crypto import CryptoWithdrawService
from maneki.apps.transaction.services.fiat.withdraw import FiatWithdrawService

logger = get_task_logger(__name__)


def close_fiat_timeout_data(expired_deadline):
    # 提现超过一天用户未审核, 将状态改为用户审核失败
    expired_data = FiatCurrencyWithdrawRecordLastThreeMonths.objects.filter(
        is_deleted=False,
        status=WithdrawStatus.VERIFY_PENDING,
        updated_at__lte=expired_deadline,
    )
    if not expired_data:
        return 0
    for data in expired_data:
        data.status = WithdrawStatus.VERIFY_FAILED
        data.updated_at = timezone.now()
        data.save()
    return expired_data.count()


def close_crypto_timeout_data(expired_deadline):
    expired_data = CryptoWithdrawRecordLastThreeMonths.objects.filter(
        is_deleted=False,
        status=WithdrawStatus.VERIFY_PENDING,
        updated_at__lte=expired_deadline,
    )
    if not expired_data:
        return 0
    for data in expired_data:
        data.status = WithdrawStatus.VERIFY_FAILED
        data.updated_at = timezone.now()
        data.save()
    return expired_data.count()


@periodic_task(run_every=crontab(minute=0, hour='*/6'))
def run_close_process():
    expired_deadline = datetime.datetime.now() - datetime.timedelta(hours=24)

    close_fiat_num = close_fiat_timeout_data(expired_deadline)
    logger.info('Close un_verify Fiat Withdraw num {} at {}'.format(close_fiat_num, expired_deadline))

    close_crypto_num = close_crypto_timeout_data(expired_deadline)
    logger.info('Close un_verify Crypto Withdraw num {} at {}'.format(close_crypto_num, expired_deadline))


@periodic_task(run_every=crontab(minute='*/10'))
def auto_cancel_crypto_withdraw_process():
    service = CryptoWithdrawService()
    counts = service.auto_cancel_order()
    logger.info('Close Crypto Withdraw num {},{}'.format(counts, datetime.datetime.utcnow()))


@periodic_task(run_every=crontab(minute='*/10'))
def auto_cancel_fiat_withdraw_process():
    service = FiatWithdrawService()
    counts = service.auto_cancel_order()
    logger.info('Close Fiat Withdraw num {},{}'.format(counts, datetime.datetime.utcnow()))
