from __future__ import absolute_import
from __future__ import unicode_literals

import datetime
from celery.schedules import crontab
from celery.task import periodic_task
from celery.utils.log import get_task_logger

from maneki.apps.transaction.models.crypto_currency import CryptoDepositRecordLastThreeMonths, CryptoWithdrawRecordLastThreeMonths
from maneki.apps.transaction.models.fiat_currency import FiatCurrencyDepositRecordLastThreeMonths, FiatCurrencyWithdrawRecordLastThreeMonths

logger = get_task_logger(__name__)

def clear_crypto_deposit_expired_data(expired_deadline):
    expired_data = CryptoDepositRecordLastThreeMonths.objects.filter(
        is_deleted=False,
        updated_at__lte=expired_deadline,
    )
    if not expired_data:
        return 0
    for data in expired_data:
        data.soft_delete()
    return expired_data.count()

def clear_crypto_withdraw_expired_data(expired_deadline):
    expired_data = CryptoWithdrawRecordLastThreeMonths.objects.filter(
        is_deleted=False,
        updated_at__lte=expired_deadline,
    )
    if not expired_data:
        return 0
    for data in expired_data:
        data.soft_delete()
    return expired_data.count()

def clear_fiat_deposit_expired_data(expired_deadline):
    expired_data = FiatCurrencyDepositRecordLastThreeMonths.objects.filter(
        is_deleted=False,
        updated_at__lte=expired_deadline,
    )
    if not expired_data:
        return 0
    for data in expired_data:
        data.soft_delete()
    return expired_data.count()

def clear_fiat_withdraw_expired_data(expired_deadline):
    expired_data = FiatCurrencyWithdrawRecordLastThreeMonths.objects.filter(
        is_deleted=False,
        updated_at__lte=expired_deadline,
    )
    if not expired_data:
        return 0
    for data in expired_data:
        data.soft_delete()
    return expired_data.count()

@periodic_task(run_every=crontab(hour=15, minute=0))
def run_clear_process():
    expired_deadline = datetime.datetime.now() - datetime.timedelta(days=90)

    clear_crypto_deposit_num = clear_crypto_deposit_expired_data(expired_deadline)
    logger.info('Clear expired Crypto Deposit num {} at {}'.format(clear_crypto_deposit_num, expired_deadline))

    clear_crypto_withdraw_num = clear_crypto_withdraw_expired_data(expired_deadline)
    logger.info('Clear expired Crypto Withdraw num {} at {}'.format(clear_crypto_withdraw_num, expired_deadline))

    clear_fiat_deposit_num = clear_fiat_deposit_expired_data(expired_deadline)
    logger.info('Clear expired Fiat Deposit num {} at {}'.format(clear_fiat_deposit_num, expired_deadline))

    clear_fiat_withdraw_num = clear_fiat_withdraw_expired_data(expired_deadline)
    logger.info('Clear expired Fiat Withdraw num {} at {}'.format(clear_fiat_withdraw_num, expired_deadline))



