# -*- coding: utf-8 -*-
from django.contrib import admin

from maneki.apps.transaction.models import BlockchainTransaction
from maneki.apps.transaction.models import CryptoDepositRecord
from maneki.apps.transaction.models import CryptoDepositRecordLastThreeMonths
from maneki.apps.transaction.models import CryptoWithdrawRecordLastThreeMonths
from maneki.apps.transaction.models.crypto_currency_address import CryptoDepositAddress
from maneki.apps.transaction.models.crypto_currency_address import CryptoDepositAddressPool
from maneki.apps.transaction.models.crypto_currency_address import CryptoWithdrawAddress


class CryptoDepositAddressPoolAdmin(admin.ModelAdmin):
    # list page
    list_display = ('address', 'coin_series', 'status', 'created_at',)

    ordering = ('created_at',)
    search_fields = [
        '=address',
        '=coin_series',
        '=status',

    ]
    list_filter = ('status',)


class CryptoDepositAddressAdmin(admin.ModelAdmin):
    # list page
    list_display = ('address', 'user_id', 'status', 'coin_type', 'created_at',)

    ordering = ('created_at',)
    search_fields = [
        '=address',
        '=user_id',
        '=status',

    ]
    list_filter = ('status',)


class BlockchainTransactionAdmin(admin.ModelAdmin):
    # list page
    list_display = ('tx_id', 'miner_fee', 'coin_type', 'status', 'confirmations', 'created_at', 'tx_type')

    ordering = ('created_at',)
    search_fields = [
        '=address',
        '=coin_type',
        '=status',
        '=tx_id',
        '=confirmations',

    ]
    list_filter = ('status', 'coin_type')


class CryptoDepositRecordLastThreeMonthsAdmin(admin.ModelAdmin):
    # list page
    list_display = (
        'user_id', 'tx_sub_id', 'tx_fee', 'tx_address', 'coin_type', 'tx_amount',
        'status', 'engine_sn', 'created_at', 'engine_request_no', 'tx_id', 'engine_code',
    )

    ordering = ('created_at',)
    search_fields = [
        '=user_id',
        '=tx_sub_id',
        '=tx_fee',
        '=tx_id',
        '=engine_sn',

    ]
    list_filter = ('status', 'coin_type')


class CryptoDepositRecordAdmin(admin.ModelAdmin):
    # list page
    list_display = (
        'user_id', 'tx_sub_id', 'tx_fee', 'tx_address', 'coin_type', 'tx_amount',
        'status', 'engine_sn', 'created_at', 'engine_request_no', 'tx_id',
    )

    ordering = ('created_at',)
    search_fields = [
        '=user_id',
        '=tx_sub_id',
        '=tx_fee',
        '=tx_id',
        '=engine_sn',

    ]
    list_filter = ('status', 'coin_type')


class CryptoWithdrawAddressAdmin(admin.ModelAdmin):
    # list page
    list_display = ('address', 'user_id', 'status', 'coin_type', 'created_at',)

    ordering = ('created_at',)
    search_fields = [
        '=address',
        '=user_id',
        '=status',

    ]
    list_filter = ('status',)


class CryptoWithdrawRecordLastThreeMonthsAdmin(admin.ModelAdmin):
    # list page
    list_display = (
        'user_id', 'engine_request_no', 'status', 'tx_fee', 'tx_address', 'coin_type', 'tx_amount',
        'engine_sn', 'created_at', 'tx_id', 'engine_code',
    )

    ordering = ('created_at',)
    search_fields = [
        '=user_id',
        '=tx_sub_id',
        '=tx_fee',
        '=tx_id',
        '=engine_sn',

    ]
    list_filter = ('status', 'coin_type')


admin.site.register(CryptoDepositAddressPool, CryptoDepositAddressPoolAdmin)
admin.site.register(CryptoDepositAddress, CryptoDepositAddressAdmin)
admin.site.register(BlockchainTransaction, BlockchainTransactionAdmin)
admin.site.register(CryptoDepositRecordLastThreeMonths, CryptoDepositRecordLastThreeMonthsAdmin)
admin.site.register(CryptoDepositRecord, CryptoDepositRecordAdmin)
admin.site.register(CryptoWithdrawRecordLastThreeMonths, CryptoWithdrawRecordLastThreeMonthsAdmin)
admin.site.register(CryptoWithdrawAddress, CryptoWithdrawAddressAdmin)
