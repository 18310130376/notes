# -*- coding: utf-8 -*-
from maneki.apps.user_auth.utils.auth_access import AuthAccess

test_data = [{
    "x_auth_device": "dW5kZWZpbmVkQEBDaHJvbWUgNjdAQGJlMGU3ZDc4MjI2YWYxMTY5YzZjOTQ5ODlkYjY0YjZmQEB1bmRlZmluZWQ=",
    "access_key": "c9a194832b3b0a4677a817d54b07e1d517cea7c7cb590874f1e61c8528543524",
    "capture_id": "J2GbBpg_tezbQpnRWlfysYLdgesKwpxjx1pxTRcIrA41UEodnKreaPD26oGJwMX7C8YGdaybhxxpR2ZVVVyOKSPCWmDXByrz7xULoHwdgCDVBHcowCHalevLidOFKu9ajrg2CxiZKqRlD7DwzYe6KdZf1BHjMD2FITHnwZHD9ELubto1HDM98.2FoboZCDNEw2gP8gpyXltcmQCa9aakBLwjvLzJXfe2Bk46WsF5jIkJJAKfZRoDGKF_hKMHDlgV7oj1_4y2j.cEoCM6BxfaOe2jL16SqBiDv_du-LqNN92WtdF8z6i5D_7Dk0EFB5AhqiTaBHYBLzZYHlML.e8qTwJNnbtYQr9GNi2xoDQgiWCCIRgH.RH1oDy6yQS5F1iArNYGqrXnVunt4b1CuhN.BemRvWcVZ66kl_sHoOKOgC7_m5.iJdHwRmrzHLY_sWnx49_aWQR8b14CjWgzkrDONsCKHRH_mhvAczgXHbkiBuy2qARDxMCpn0_qLnz3"
},
    {
        "x_auth_device": "dW5kZWZpbmVkQEBDaHJvbWUgNjdAQGJlMGU3ZDc4MjI2YWYxMTY5YzZjOTQ5ODlkYjY0YjZmQEB1bmRlZmluZWQ=",
        "access_key": "08f48936f73c5053c78aa651b81a007a7d9d5bfaa152a5c2b521356bb17c1ade",
        "capture_id": "Wqu5YQ58eFtKU2Vw29OuXK2XwXIOF7BNvw9JiESjDQAu69OZRw-rLCBvm-ulyc_uzYpmQBC8EmuGHllMmxeLOsmiD--5H6JmE1ujNkDAYOqbZby1Ue5GT7IZg0eFiwNJILzIiRMY8WzSKJY2a6QZ4wsTADvwSF.CAdiNVGrAwMQRSNvYFx.dcLSuB2JZBDxyDtB.tP6oHXVw2vW6PcGyXgb88Kzu009c6eDoxZYEymgR1NubnXWdb-y5kbsfgLLcDlc0b-8w7CcM_ZKKj87lShqnCIgc0x9-jwVrBtJ.n04pGq6oNvyYqVy1NExwP-6xfP04JJMShXAa06vsRjEyrC8Onzkq0m68gHUsPPgcca6yjVxrzjh9Q51dSjJkMFd7X6pyhC_dVB5kockWKIki2BR5K7wbpe6WJF2jCnoxgzi6KBN_.KlaBGGdfNCW5K6j1dkGfeyI6Q5dlEpUXtHTieQ1xwNPsAYzulAmWl5fVPAO86.TAQ_UR7Sssep3"
    }
]


def test_auth():
    for i in test_data:
        result = AuthAccess().auth_access(**i)
        print(result)
