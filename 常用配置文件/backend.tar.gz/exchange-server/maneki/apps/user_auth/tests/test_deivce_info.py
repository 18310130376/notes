# -*- coding: utf-8 -*-
import base64
import logging
import uuid

from django.test import TestCase
from rest_framework.authtoken.models import Token

from maneki.apps.user.models import User
from maneki.apps.user.services import UserService

logger = logging.getLogger('test')


class TestDeviceToken(TestCase):

    def setUp(self):
        self.service = UserService()

        data = {
            "id": "79",
            "password": "argon2$argon2i$v=19$m=512,t=2,p=2$d3R1eWNmd1g5QkYx$afZCqmRJ8TiMcdcYHTZuEQ",
            "last_login": "2018/05/04 08:19:18.502463",
            "is_superuser": "0",
            "username": "user-26440905071",
            "is_staff": "0",
            "date_joined": "2018/04/28 03:58:57.072315",
            "created_at": "2018/04/28 03:58:57.073913",
            "updated_at": "2018/04/28 06:47:40.272094",
            "is_deleted": "0",
            "deleted_at": "",
            "user_id": "84bfb451e13841b2b53ac77177719373",
            "engine_token": "2846dce6ee4be097b217e0378f1e8f657dbe0065",
            "email": "test1@126.com",
            "mobile": "",
            "mobile_country_code": "",
            "verify_code": "00982727",
            "email_verified": "1",
            "mobile_verified": "0",
            "totp_device_verified": "0",
            "status": "0",
            "is_active": "1",
            "trade_password": ""
        }
        self.user = User.objects.create(
                email=data.get('email'), password='lj13043X', is_active=1,
                is_superuser=0, username=data.get('username'), is_staff=0,
                user_id=uuid.UUID(data.get('user_id')),
                engine_token=data.get('engine_token'),
                verify_code=data.get('verify_code'), status=0
            )
        # token = Token()
        # token.key = 'b48b7719ee49228896b5d15d11226f6c4dfc18dd'
        # token.save()
        # logger.info('token:{}'.format(token.key))
        # self.token = Token.objects.create(key='b48b7719ee49228896b5d15d11226f6c4dfc18dd', user_id=self.user.id)
        self.token = 'b48b7719ee49228896b5d15d11226f6c4dfc18dd'

    def test_get_device_info(self):
        device_str = 'pc' + '@@' + '2012' + '@@' + 'FFFFLLLL'
        # device_str = 'aW9zQEAxMS4yQEBGRkZGUFBQUA=='
        # base64编码
        device_b64str = base64.b64encode(device_str.encode()).decode()
        logger.info('device b64str:{},{}'.format(device_b64str, type(device_b64str)))
        device_info = self.service.get_device_info(device_b64str)
        logger.info('device info: {}'.format(device_info))
        # 缓存engine proxy info
        self.service.cache_for_engine_proxy_with_device(user=self.user, token=self.token,
                                                        device_b64str=device_b64str,
                                                        device_info=device_info)
        # 缓存user info
        self.service.cache_user_info_with_device(user=self.user, token=self.token,
                                                 device_b64str=device_b64str,
                                                 device_info=device_info)

    def test_create_user(self):
        # obj = self.service.create_user_email(email="test1@126.com",
        #                                      password="argon2$argon2i$v=19$m=512,t=2,p=2$d3R1eWNmd1g5QkYx$afZCqmRJ8TiMcdcYHTZuEQ",
        #                                      username="user-26440905072")
        # logger.info('user1 {}:'.format(obj.email))

        obj2 = self.service.create_user_mobile(mobile="+8617755619235",
                                               mobile_country_code="+86",
                                               password="argon2$argon2i$v=19$m=512,t=2,p=2$d3R1eWNmd1g5QkYx$afZCqmRJ8TiMcdcYHTZuEQ",
                                               username="user-26440905073"
                                               )
        logger.info('user2 {}:'.format(obj2.mobile))
