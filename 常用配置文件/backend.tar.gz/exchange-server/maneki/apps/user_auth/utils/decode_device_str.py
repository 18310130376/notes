# -*- coding: utf-8 -*-
import base64


def decode_device_str(device_b64str: str):
    """
    os@@version@@device_id 例如：aW9zQEAxMS4yQEBGRkZGUFBQUA==
    :return:

    """
    if not device_b64str:
        return None
    device_str = base64.b64decode(device_b64str).decode()
    device_str = device_str.rsplit('@@', 1)[0]
    return base64.b64encode(device_str.encode()).decode()


# if __name__ == '__main__':
#     decode_device_str('cGNAQDIwMTJAQEZGRkZMTExMQEAxMzc5ODIzNTA=')
