# -*- coding: utf-8 -*-
import hashlib
from base64 import b64decode


class AuthAccess(object):

    @staticmethod
    def _compute_hash(fingerprint, capture_id):
        if fingerprint and capture_id:
            payload = hashlib.sha256("{}{}".format(capture_id, fingerprint).encode())
            return payload.hexdigest()

    def auth_access(self, x_auth_device, access_key, capture_id):
        if not (x_auth_device and access_key and capture_id):
            return False, "need params"
        fingerprint = b64decode(x_auth_device).decode("utf-8").split("@@")
        if len(fingerprint) < 4:
            return False, "fingerprint error"
        fingerprint = fingerprint[2]
        compute_access = self._compute_hash(fingerprint, capture_id)
        return compute_access == access_key, "compare fail"
