from rest_framework import exceptions
from rest_framework.authentication import TokenAuthentication

from maneki.apps.common.utils.redis.r import redis_sessions, get_token_cache_key


class CacheTokenAuthentication(TokenAuthentication):

    # django framework call this.
    def authenticate_credentials(self, key):
        from maneki.apps.user.services import UserService  # TODO: 循环引用

        cache_key = get_token_cache_key(key)
        user_id = redis_sessions['TokenAuth'].get(cache_key)
        if not user_id:
            raise exceptions.AuthenticationFailed('Auth Reject. Not found token')

        service = UserService()
        user = service.filter_record(user_id=user_id)
        if not user:
            raise exceptions.AuthenticationFailed('Auth Reject. Not found user')
        return user, key
