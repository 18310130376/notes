# -*- coding: utf-8 -*-
from maneki.apps.transaction.services.fiat.withdraw_worker import FiatWithDrawEngineConsumer


def run(*args):
    """off-chain

    :param args:
    :return:
    """
    worker = FiatWithDrawEngineConsumer()
    worker.consume()
