# -*- coding: utf-8 -*-
from maneki.apps.user_members.services.user_member_activate import UserMemberCreateConsumer


def run(*args):
    """sync engine account

    :param args:
    :return:
    """
    worker = UserMemberCreateConsumer()
    worker.consume()
