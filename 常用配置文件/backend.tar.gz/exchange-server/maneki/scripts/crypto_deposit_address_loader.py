# -*- coding: utf-8 -*-
from maneki.apps.transaction.services.crypto.deposit_address_worker import CryptoDepositAddressLoader


def run(*args):
    """
    deposit address prepare mq consume worker
    :param args:
    :return:
    """

    worker = CryptoDepositAddressLoader()
    worker.consume()
