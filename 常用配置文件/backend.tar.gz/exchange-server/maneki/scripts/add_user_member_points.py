# -*- coding: utf-8 -*-
from maneki.apps.user_members.services.user_member_activate import UserMemberAddPointsConsumer


def run(*args):
    """sync engine account

    :param args:
    :return:
    """
    worker = UserMemberAddPointsConsumer()
    worker.consume()
