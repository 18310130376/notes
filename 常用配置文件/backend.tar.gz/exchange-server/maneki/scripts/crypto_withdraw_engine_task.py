from maneki.apps.transaction.services.crypto.withdraw_worker import WithdrawResponseFromEngineConsumer


def run(*args):
    """engine rpc task

    :param args:
    :return:
    """
    worker = WithdrawResponseFromEngineConsumer()
    worker.consume()
