# -*- coding: utf-8 -*-
from maneki.apps.transaction.services.crypto.deposit_engine_handler import DepositEngineRequestConsumer


def run(*args):
    """off-chain

    :param args:
    :return:
    """
    worker = DepositEngineRequestConsumer()
    worker.consume()
