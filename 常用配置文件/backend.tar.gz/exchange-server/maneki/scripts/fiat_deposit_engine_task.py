from maneki.apps.transaction.services.fiat.deposit_worker import FiatDepositEngineConsumer


def run(*args):
    """engine rpc task

    :param args:
    :return:
    """
    worker = FiatDepositEngineConsumer()
    worker.consume()
