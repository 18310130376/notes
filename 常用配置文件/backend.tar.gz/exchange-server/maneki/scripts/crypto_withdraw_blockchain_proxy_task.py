from maneki.apps.transaction.services.crypto.withdraw_worker import WithdrawResponseFromBlockchainProxyConsumer


def run(*args):
    """engine rpc task

    :param args:
    :return:
    """
    worker = WithdrawResponseFromBlockchainProxyConsumer()
    worker.consume()
