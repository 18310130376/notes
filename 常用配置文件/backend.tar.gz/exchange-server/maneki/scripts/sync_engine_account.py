# -*- coding: utf-8 -*-
from maneki.apps.user.services.account_sync import SyncEngineAccountConsumer


def run(*args):
    """sync engine account

    :param args:
    :return:
    """
    worker = SyncEngineAccountConsumer()
    worker.consume()
