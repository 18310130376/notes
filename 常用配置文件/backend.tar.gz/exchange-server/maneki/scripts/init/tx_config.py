# -*- coding: utf-8 -*-
from maneki.apps.user_settings.models.crypto_confirm_limit import CryptoConfirmLimit
from maneki.apps.user_settings.models.currency_type import CurrencyTypeConfig
from maneki.apps.user_settings.models.trade_fee import MarketTradeFeeRate, WithdrawFeeRate
from maneki.apps.user_settings.models.withdraw_limit import WithdrawLimit

from maneki.apps.constants import CoinType, FiatType, CurrencyType


def init_table():
    crypto_confirms = [
        CryptoConfirmLimit(coin_type=CoinType.BTC, min_confirm_num=6, ),
        CryptoConfirmLimit(coin_type=CoinType.ETC, min_confirm_num=6, ),
        CryptoConfirmLimit(coin_type=CoinType.ETH, min_confirm_num=12,),
        CryptoConfirmLimit(coin_type=CoinType.BCH, min_confirm_num=6, ),
        CryptoConfirmLimit(coin_type=CoinType.ICO, min_confirm_num=6, ),
        CryptoConfirmLimit(coin_type=CoinType.REP, min_confirm_num=6, ),
        CryptoConfirmLimit(coin_type=CoinType.LTC, min_confirm_num=6, ),
        CryptoConfirmLimit(coin_type=CoinType.DASH, min_confirm_num=6, ),
        CryptoConfirmLimit(coin_type=CoinType.MONA, min_confirm_num=6, ),
    ]
    for cc in crypto_confirms:
        cc.save()
    # CryptoConfirmLimit.objects.bulk_create(crypto_confirms)

    currency_types = [
        CurrencyTypeConfig(currency_type_value=CoinType.BTC, currency_type_name='BTC', currency_type=CurrencyType.COIN_TYPE),
        CurrencyTypeConfig(currency_type_value=CoinType.ETC, currency_type_name='ETC', currency_type=CurrencyType.COIN_TYPE),
        CurrencyTypeConfig(currency_type_value=CoinType.ETH, currency_type_name='ETH', currency_type=CurrencyType.COIN_TYPE),
        CurrencyTypeConfig(currency_type_value=CoinType.BCH, currency_type_name='BCH', currency_type=CurrencyType.COIN_TYPE),
        CurrencyTypeConfig(currency_type_value=CoinType.ICO, currency_type_name='ICO', currency_type=CurrencyType.COIN_TYPE),
        CurrencyTypeConfig(currency_type_value=CoinType.REP, currency_type_name='REP', currency_type=CurrencyType.COIN_TYPE),
        CurrencyTypeConfig(currency_type_value=CoinType.LTC, currency_type_name='LTC', currency_type=CurrencyType.COIN_TYPE),
        CurrencyTypeConfig(currency_type_value=CoinType.DASH, currency_type_name='DASH', currency_type=CurrencyType.COIN_TYPE),
        CurrencyTypeConfig(currency_type_value=CoinType.MONA, currency_type_name='MONA', currency_type=CurrencyType.COIN_TYPE),
        CurrencyTypeConfig(currency_type_value=FiatType.CNY, currency_type_name='CNY', currency_type=CurrencyType.FIAT_TYPE),
        CurrencyTypeConfig(currency_type_value=FiatType.USD, currency_type_name='USD', currency_type=CurrencyType.FIAT_TYPE),
        CurrencyTypeConfig(currency_type_value=FiatType.EU, currency_type_name='EU', currency_type=CurrencyType.FIAT_TYPE),
        CurrencyTypeConfig(currency_type_value=FiatType.HKD, currency_type_name='HKD', currency_type=CurrencyType.FIAT_TYPE),
        CurrencyTypeConfig(currency_type_value=FiatType.JPY, currency_type_name='JPY', currency_type=CurrencyType.FIAT_TYPE),
    ]
    for ct in currency_types:
        ct.save()
    # CurrencyTypeConfig.objects.bulk_create(currency_types)

    trade_fee_rates = [

    ]
    for tfr in trade_fee_rates:
        tfr.save()
    # MarketTradeFeeRate.objects.bulk_create(trade_fee_rates)

    withdraw_fee_rates = [
        WithdrawFeeRate(coin_type=CoinType.BTC, fee_rate="0.001"),
        WithdrawFeeRate(coin_type=CoinType.BCH, fee_rate="0.0001"),
        WithdrawFeeRate(coin_type=CoinType.ETH, fee_rate="0.01"),
        WithdrawFeeRate(coin_type=CoinType.ETC, fee_rate="0.01"),
        WithdrawFeeRate(coin_type=CoinType.LTC, fee_rate="0.001"),
        WithdrawFeeRate(coin_type=CoinType.DASH, fee_rate="0.002"),
        WithdrawFeeRate(coin_type=CoinType.MONA, fee_rate="0.001"),
    ]
    for wfr in withdraw_fee_rates:
        wfr.save()
    # WithdrawFeeRate.objects.bulk_create(withdraw_fee_rates)

    withdraw_limits = [
        WithdrawLimit(currency_type=CurrencyType.COIN_TYPE, currency_type_value=CoinType.BTC, min_amount_num="0.01", max_amount_num="0.5"),
        WithdrawLimit(currency_type=CurrencyType.COIN_TYPE, currency_type_value=CoinType.BCH, min_amount_num="0.01", max_amount_num="30"),
        WithdrawLimit(currency_type=CurrencyType.COIN_TYPE, currency_type_value=CoinType.ETH, min_amount_num="0.015", max_amount_num="5"),
        WithdrawLimit(currency_type=CurrencyType.COIN_TYPE, currency_type_value=CoinType.ETC, min_amount_num="0.5", max_amount_num="200"),
        WithdrawLimit(currency_type=CurrencyType.COIN_TYPE, currency_type_value=CoinType.LTC, min_amount_num="0.1", max_amount_num="30"),
        WithdrawLimit(currency_type=CurrencyType.COIN_TYPE, currency_type_value=CoinType.DASH, min_amount_num="0.02", max_amount_num="10"),
        WithdrawLimit(currency_type=CurrencyType.COIN_TYPE, currency_type_value=CoinType.MONA, min_amount_num="0.1", max_amount_num="1000"),
        WithdrawLimit(currency_type=CurrencyType.FIAT_TYPE, currency_type_value=FiatType.CNY, min_amount_num="0", max_amount_num="0"),
        WithdrawLimit(currency_type=CurrencyType.FIAT_TYPE, currency_type_value=FiatType.USD, min_amount_num="0", max_amount_num="0"),
        WithdrawLimit(currency_type=CurrencyType.FIAT_TYPE, currency_type_value=FiatType.EU, min_amount_num="0", max_amount_num="0"),
        WithdrawLimit(currency_type=CurrencyType.FIAT_TYPE, currency_type_value=FiatType.HKD, min_amount_num="0", max_amount_num="0"),
        WithdrawLimit(currency_type=CurrencyType.FIAT_TYPE, currency_type_value=FiatType.JPY, min_amount_num="0", max_amount_num="0"),
    ]
    for wl in withdraw_limits:
        wl.save()
    # WithdrawLimit.objects.bulk_create(withdraw_limits)


if __name__ == '__main__':
    init_table()
