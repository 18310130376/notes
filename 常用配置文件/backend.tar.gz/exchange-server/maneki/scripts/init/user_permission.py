from config.routers.v1.admin import api_admin
from maneki.apps.user_role.models.perms import Permission

prefix_url = '/api/v1/admin/'


def load_permission_to_db():
    urls = api_admin.registry
    for route_path, name, _ in urls:
        # url while auto slash
        route_path = prefix_url + route_path + '/'
        name = name.__name__
        Permission.objects.get_or_create(route_path=route_path,
                                         permission_code=1,
                                         permission_name=name + ":List")

        Permission.objects.get_or_create(route_path=route_path,
                                         permission_code=2,
                                         permission_name=name + ":Create")
