from maneki.apps.user.models import User
from maneki.apps.constants import UserAccountStatus
from django.contrib.auth.hashers import make_password
from django.conf import settings

SUPERUSER = settings.SUPERUSER
SUPERUSER_PASSWORD = settings.SUPERUSER_PASSWORD


def init_superuser():
    User.objects.create(
        username=SUPERUSER,
        email=SUPERUSER,
        password=make_password(SUPERUSER_PASSWORD),
        is_superuser=True,
        is_active=True,
        email_verified=True,
        status=UserAccountStatus.ENABLED
    )
