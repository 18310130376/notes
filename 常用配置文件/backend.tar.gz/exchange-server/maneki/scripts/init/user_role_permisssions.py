from maneki.apps.constants import ApiPermissionType
from maneki.apps.user_role.models.perms import RolePermission, Permission
from maneki.apps.user_role.models.role import RoleType
from maneki.scripts.init.resources.init_role_permission import frontend_map, KYC_FINANCE_LEADER, FINANCE_CUSTOM, FINANCE

"""
Run after init_role, init_permission
"""


def init_superuser_permission():
    role = RoleType.objects.filter(role_code=9991).first()
    if not role:
        print("No init role")
        return
    role_id = role.id

    permissions = Permission.objects.filter(is_deleted=False).all()

    for p in permissions:
        RolePermission.objects.get_or_create(
            permission_id=p.id,
            role_id=role_id
        )


def init_admin_role_permission(frontend_code, settings):
    """充提角色权限
    :return:
    """

    code = frontend_map.get(frontend_code)
    role = RoleType.objects.filter(role_code=code).first()
    for path, method, _ in settings:
        if method == 'GET':
            permission_code = ApiPermissionType.List
            permissions = Permission.objects.filter(is_deleted=False, route_path=path, permission_code=permission_code).all()
        else:
            permissions = Permission.objects.filter(is_deleted=False, route_path=path).all()

        for p in permissions:
            RolePermission.objects.get_or_create(
                permission_id=p.id,
                role_id=role.id
            )


def init_dw_role_permission():
    init_admin_role_permission('FINANCE_CUSTOM', FINANCE_CUSTOM)
    init_admin_role_permission('KYC_FINANCE_LEADER', KYC_FINANCE_LEADER)
    init_admin_role_permission('FINANCE', FINANCE)
