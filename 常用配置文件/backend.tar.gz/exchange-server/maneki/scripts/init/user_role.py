from maneki.apps.user_role.models import RoleType
from maneki.apps.user_role.models import RoleGroup

from maneki.scripts.init.resources.default_groups import DEFAULT_GROUPS
from maneki.scripts.init.resources.default_role_type import DEFAULT_ROLES


def init_role_type():
    for role in DEFAULT_ROLES:
        role = RoleType(
            role_code=role['role_code'],
            role_desc_cn=role['role_desc_cn'],
            role_desc_en=role['role_desc_cn'],
            group_code=role['group_code']
        )
        role.save()


def init_groups():
    for group in DEFAULT_GROUPS:
        group = RoleGroup(
            group_code=group['group_code'],
            group_desc_cn=group['group_desc_cn'],
            group_desc_en=group['group_desc_en'],
        )
        group.save()
