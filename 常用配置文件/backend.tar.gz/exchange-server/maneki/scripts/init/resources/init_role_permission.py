# KYC_CUSTOM = '40011'
# KYC_LEADER = '40010'
# FINANCE = '88801'
# FINANCE_CUSTOM = '40021'
# KYC_FINANCE_LEADER = '4001'
# ADMIN = '9991'
# map frontend
frontend_map = {
    'FINANCE_CUSTOM': 40021,
    'KYC_FINANCE_LEADER': 4001,
    'FINANCE': 88801
}

FINANCE_CUSTOM = [
    ("/api/v1/admin/audits/crypto/deposit/exceptions/", "GET", "数字货币充值记录"),
    ("/api/v1/admin/transactions/fiat/deposit/verify/", "POST", "法币充值申请审核"),
    ("/api/v1/admin/transactions/crypto/withdraw/verify/", "POST", "数字货币提现审核"),
    ("/api/v1/admin/transactions/fiat/withdraw/verify/", "POST", "法币提现申请审核"),

]
KYC_FINANCE_LEADER = [
    ("/api/v1/admin/audits/crypto/deposit/exceptions/", "GET", "数字货币充值记录"),
    ("/api/v1/admin/transactions/fiat/deposit/verify/", "POST", "法币充值申请审核"),
    ("/api/v1/admin/transactions/fiat/withdraw/verify/", "POST", "法币提现申请审核"),
    ("/api/v1/admin/transactions/fiat/withdraw/verify/", "POST", "法币提现申请审核"),
]

FINANCE = [
    ("/api/v1/admin/transactions/fiat/withdraw/finance/verify/", "POST", "法币提现申请出账"),
]
