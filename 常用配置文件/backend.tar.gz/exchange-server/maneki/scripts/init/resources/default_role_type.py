DEFAULT_ROLES = [
        {
            'role_code': '4001',
            'role_desc_cn': 'leader:查看所有信息、无操作权限',
            'role_desc_en': 'Custom Service Leader',
            'group_code': '400'
        },
        {
            'role_code': '40010',
            'role_desc_cn': '用户客服主管:KYC审核',
            'role_desc_en': 'KYC leader',
            'group_code': '400'
        },
        {
            'role_code': '40011',
            'role_desc_cn': '用户客服:用户信息处理',
            'role_desc_en': 'KYCer',
            'group_code': '400'
        },
        # {
        #     'role_code': '40020',
        #     'role_desc_cn': '风控 leader',
        #     'role_desc_en': 'Risk management leader',
        #     'group_code': '400'
        # },
        {
            'role_code': '40021',
            'role_desc_cn': '客服:充提信息审核处理',
            'role_desc_en': 'Risk management member',
            'group_code': '400'
        },
        # {
        #     'role_code': '8881',
        #     'role_desc_cn': '财务 leader',
        #     'role_desc_en': 'Finance leader',
        #     'group_code': '888'
        # },
        {
            'role_code': '88801',
            'role_desc_cn': '财务:充提信息录入 出账',
            'role_desc_en': 'Finance member',
            'group_code': '888'
        },
        {
            'role_code': '9991',
            'role_desc_cn': '超级管理员',
            'role_desc_en': 'System manage',
            'group_code': '999'
        }
    ]

