DEFAULT_GROUPS = [
            {
                'group_code': '400',
                'group_desc_cn': '客服部',
                'group_desc_en': 'CustomerService',
            },
            {
                'group_code': '666',
                'group_desc_cn': '交易部',
                'group_desc_en': 'Dealer',
            },
            {
                'group_code': '888',
                'group_desc_cn': '财务部',
                'group_desc_en': 'Finance',
            },
            {
                'group_code': '999',
                'group_desc_cn': '超级管理员',
                'group_desc_en': 'Administrator',
            },
        ]
