import json
import os
import uuid
import pytz
from django.utils.datetime_safe import datetime as datetime
from django_redis import get_redis_connection

from config.settings.base import ROOT_DIR
from maneki.apps.common.utils import generate_nonce_8bit_digits
from maneki.apps.constants import UserMigrationStatus, UserAccountStatus, TOTPDeviceStatus
from maneki.apps.user.models import TimeOTPDevice
from maneki.apps.user.models.user import User
from maneki.apps.user.models.user_profile import UserProfile
from maneki.apps.user_members.models.members import UserMembers
from maneki.apps.user_kyc.models import KYCIndividual


def deal_json(json_path):
    with open(str(os.path.join(str(ROOT_DIR), 'tmp/{}'.format(json_path))), 'rt', encoding="utf8") as f:
        dict_data = json.load(f)
    list_data = dict_data.get("RECORDS")
    return list_data


def save_to_redis(key, value: dict):
    con = get_redis_connection("default")
    con.hmset(key, value)


def get_from_redis(key, value: str):
    con = get_redis_connection("default")
    result = con.hget(key, value)
    if result:
        result = str(result, encoding='utf8')
    return result


def get_all_from_redis(key):
    con = get_redis_connection("default")
    result = con.hgetall(key)
    result = {k.decode(): v.decode() for k, v in result.items()}
    return result


def save_engine_user():
    data = deal_json('engine_users.json')
    data_dict = {i.get("account"): i.get("email") for i in data}
    save_to_redis('engine_users', data_dict)


def handle_user_v2():
    save_engine_user()
    data_2 = deal_json('user.json')

    result = []
    for row in data_2:
        old_id = row.get('user_id')
        account_id = row.get('account_key', '')
        tradepwd = row.get('tradepwd', '')
        otp_key = row.get('otpkey', '')
        email = get_from_redis('engine_users', old_id)
        if not email:
            continue
        user_name = row.get('username', '')
        tmp = {
            "email": email,
            "account_id": old_id,
            "username": user_name,
            "engine_token": account_id,
            "trade_password": tradepwd,
            "key": otp_key
        }
        result.append(tmp)
        print(old_id)
    return result


def _generate_deposit_bank_code():
    i = 0
    code_pool = set()
    while i < 400000:
        bank_code = generate_nonce_8bit_digits(8, 'ABCDEFGHIGKLMNPQRSTUVWXYZ123456789')
        i += 1
        code_pool.add(bank_code)
    print("deposit_bank_code_pool Done")
    return code_pool


def _batch_format_data(row, deposit_code, group1: list, group2: list, group3: list, group4: list):
    user_id = uuid.uuid4()
    old_id = row['account_id']
    # username = "user-{}".format(generate_username())
    #
    save_to_redis('user_id', {old_id: user_id})
    email = row.get('email')
    otp_key = row.get('key')
    email_ver = True
    otp_ver = False
    if not email:
        email = get_from_redis('engine_users', old_id)
        if not email:
            email = ''
            email_ver = False

    if otp_key:
        otp_ver = True
        group4.append(TimeOTPDevice(key=otp_key, user_id=user_id, status=TOTPDeviceStatus.ACTIVATED))

    group1.append(User(user_id=user_id, email=email, old_account_id=row['account_id'],
                       username=row['username'], is_active=True, old_account_status=UserMigrationStatus.PENDING,
                       status=UserAccountStatus.ENABLED, email_verified=email_ver,
                       trade_password=row.get('trade_password'),
                       engine_token=row.get('engine_token'), totp_device_verified=otp_ver))
    group2.append(UserProfile(user_id=user_id, deposit_code=deposit_code))
    group3.append(UserMembers(user_id=user_id, member_points=10000))


def _batch_insert_data(group1, group2, group3, group4):
    User.objects.bulk_create(group1)
    UserProfile.objects.bulk_create(group2)
    UserMembers.objects.bulk_create(group3)
    if group4:
        TimeOTPDevice.objects.bulk_create(group4)


def batch_insert_user(data, size=500):
    deposit_bank_code_pool = _generate_deposit_bank_code()
    i = 0
    j = 0
    group1 = []
    group2 = []
    group3 = []
    group4 = []
    while True:
        length = len(data)
        #
        if j == length:
            if group1:
                print(
                    "end insert length: group1={}, group2={}, group3={}, group4={}".format(len(group1), len(group2),
                                                                                           len(group3), len(group4)))
                _batch_insert_data(group1, group2, group3, group4)
            break
        #
        if i == size:
            print("insert length: group1={}, group2={}, group3={}, group4={}".format(len(group1), len(group2),
                                                                                     len(group3), len(group4)))
            _batch_insert_data(group1, group2, group3, group4)
            i = 0
            group1[:] = []
            group2[:] = []
            group3[:] = []
            group4[:] = []
            print("clear: group1={}, group2={}, group3={}, group4={}".format(group1, group2, group3, group4))
        #
        row = data[j]
        deposit_code = deposit_bank_code_pool.pop()
        print("count: index={}, no={}".format(j, i))
        # 500
        _batch_format_data(row, deposit_code, group1, group2, group3, group4)
        #
        i += 1
        j += 1


def _batch_insert_kyc(group):
    KYCIndividual.objects.bulk_create(group)


def _batch_format_kyc(row, group: list):
    group.append(KYCIndividual(**row))


def batch_insert_kyc(data, size=500):
    i = 0
    j = 0
    group = []
    while True:
        length = len(data)
        #
        if j == length:
            if group:
                print("end insert length: group={}".format(len(group)))
                _batch_insert_kyc(group)
            break

        if i == size:
            print("insert length: group={}".format(len(group)))
            _batch_insert_kyc(group)
            i = 0
            group[:] = []
            print("clear: group={}".format(len(group)))

        row = data[j]
        print("count: index={}, no={}".format(j, i))
        _batch_format_kyc(row, group)
        i += 1
        j += 1


def save_mobile_name():
    user_list = deal_json('userdata.json')
    country_list = deal_json('country.json')
    country_dict = {i.get('country_code'): '+' + i.get('dial_code') for i in country_list}
    for i in user_list:
        user_id = get_from_redis('user_id', i.get('user_id'))
        if not user_id:
            continue
        if i.get('phone_country') and i.get('phone') and i.get('phone_verified') == '1':
            print("保存用户名 " + i.get('user_id'))
            phone = i.get('phone')
            mobile_country_code = country_dict.get(i.get('phone_country'))
            # mobile, country_code = validate_mobile_phone_number(phone, mobile_country_code)
            mobile = mobile_country_code + phone
            print(mobile)
            print(mobile_country_code)
            User.objects.filter(user_id=user_id).update(
                mobile=mobile, mobile_country_code=mobile_country_code, mobile_verified=True
            )
        kyc_obj = KYCIndividual.objects.filter(user_id=user_id).first()
        if not kyc_obj:
            continue
        kyc_obj.first_name = i.get('name')
        kyc_obj.save()


def create_kyc():
    """
    {
            "user_id": "19417",
            "id_country": "HK",
            "intl_id_number": "K04517880",
            "intl_id_number_status": "3",
            "intl_id_type": "2",
            "id_expire_date": "1734019200",
            "birth_date": "108921600",
            "address": "No.7 G/F Sha Chau Lei Tsuen\nPing Ha Road,\nYuen Long",
            "country": "HK",
            "state": "HK",
            "city": "N.T.",
            "postal_code": "000000",
            "update_dateline": "1483593311"
        },
    :return:
    """
    list_data = deal_json('userdata_intl.json')
    id_type_dict = {
        0: 'paper',
        1: 'paper',
        2: 'passport',
        3: 'paper',
        4: 'paper',
        5: 'paper',
        6: 'driver_license',
        8: 'paper',
    }
    id_status_dict = {
        0: 1,
        1: 1,  # 未验证
        2: 1,  # 客服验证未通过
        3: 4  #
    }
    result = []
    for i in list_data:
        old_id = i.get('user_id')
        user_id = get_from_redis('user_id', old_id)
        if not user_id:
            # user_id = uuid.uuid4()
            print("none user_id: {}".format(user_id))
            continue
        temp = {
            "created_at": datetime.utcfromtimestamp(int(i.get('update_dateline')) + 0.000001).replace(tzinfo=pytz.utc),
            "user_id": user_id,
            "license_country": i.get('id_country'),
            "license_type1": id_type_dict.get(int(i.get('intl_id_type'))),
            "license_type": id_type_dict.get(int(i.get('intl_id_type'))),
            "license_number": i.get('intl_id_number'),
            "local_country": i.get('country'),
            "local_city": i.get("city"),
            "local_region": i.get("state"),
            "local_address": i.get('address'),
            "local_postcode": i.get('postal_code'),
            "current_level": id_status_dict.get(int(i.get('intl_id_number_status'))),
        }
        print("id:{}".format(old_id))
        result.append(temp)
    return result


def run():
    result = handle_user_v2()
    print("用户数据生成完毕")

    batch_insert_user(result)
    print("用户数据保存完毕")

    kyc_data = create_kyc()
    print("KYC数据生成完毕")

    batch_insert_kyc(kyc_data)
    print("KYC数据保存完毕")

    save_mobile_name()
