import json
import os

import redis
import MySQLdb


class BlobDataTestor:
    def __init__(self):
        self.conn = MySQLdb.connect(host='ds2.cfdsf45pttva.ap-northeast-1.rds.amazonaws.com', user='sean',
                                    passwd='@43$FJzGW&XNZqM', db='btcchina_mk')

    def __del__(self):
        try:
            self.conn.close()
        except Exception as e:
            print(e)

    def closedb(self):
        self.conn.close()

    def get_all_from_redis(self, payload):
        r = redis.Redis(host="127.0.0.1", port=6379)
        data = r.hgetall(payload)
        return data

    def save_image(self):
        user_data = self.get_all_from_redis('user_id')
        j = 0
        for k, v in user_data.items():
            user_id = str(k, encoding='utf8')
            user_uuid = str(v, encoding='utf8')
            cursor = self.conn.cursor()
            cursor.execute("SELECT * FROM userimage WHERE user_id={}".format(user_id))
            d = cursor.fetchall()
            if not d:
                continue
            for i in d:
                assert str(user_id) == str(i[0])
                f_format = i[4].split('/')[1]
                image = i[5]
                f = open("image/{}-{}.{}".format(user_uuid, d.index(i), f_format), "wb")
                f.write(image)
                f.close()
            print(j)
            j += 1
            cursor.close()

    @staticmethod
    def save_json(json_path, data):
        with open('{}'.format(json_path), 'w') as r:
            r.write(json.dumps(data))

    def get_image(self):
        user_data = self.get_all_from_redis('user_id')
        j = 0
        temp = {}
        for k, v in user_data.items():
            user_id = str(k, encoding='utf8')
            user_uuid = str(v, encoding='utf8')
            cursor = self.conn.cursor()
            cursor.execute("SELECT * FROM userimage WHERE user_id={}".format(user_id))
            d = cursor.fetchall()
            if not d:
                continue
            temp.update({user_id: []})
            for i in d:
                assert str(user_id) == str(i[0])
                image_name = "{}-{}".format(user_uuid, d.index(i))
                image_type = i[1]
                user_info = {"user_id": user_uuid,
                             "image_name": image_name,
                             "image_type": image_type}
                temp.get(user_id).append(user_info)
            print(j)
            j += 1
            # self.save_json(user_id, temp.get(user_id))
        self.save_json('image_data_type.json', temp)


if __name__ == "__main__":
    test = BlobDataTestor()
    test.get_image()
    test.closedb()
