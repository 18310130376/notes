# -*- coding: utf-8 -*-
import io
import json
import os
import sys
import uuid
from decimal import Decimal

import boto3
import pytz
from django.core.files.uploadedfile import InMemoryUploadedFile
from django.db.models import Sum
from django.utils import timezone
from django.utils.datetime_safe import datetime as datetime
from django_redis import get_redis_connection
import random
from config.routers.v1 import api_admin
from config.settings.base import ROOT_DIR
from maneki.apps.api_key.models import UserApiKey
from maneki.apps.assets.models import UserFiatAccount
from maneki.apps.audit.models import CryptoDailyClearingRecord, FiatDailyClearingRecord
from maneki.apps.common.utils import generate_nonce_8bit_digits
from maneki.apps.constants import UserMigrationStatus, UserAccountStatus, TOTPDeviceStatus, FiatType, CoinType
from maneki.apps.transaction.models import FiatCurrencyWithdrawRecordLastThreeMonths, \
    CryptoDepositRecordLastThreeMonths, CryptoWithdrawRecordLastThreeMonths
from maneki.apps.user.models import TimeOTPDevice
from maneki.apps.user.models.user import User
from maneki.apps.user.models.user_profile import UserProfile
from maneki.apps.user_kyc.libs.s3_storage_backend import PrivateMediaStorage
from maneki.apps.user_kyc.service import AuthImageUpload
from maneki.apps.user_kyc.utils import generate_file_name
from maneki.apps.user_members.models.members import UserMembers
from maneki.apps.user_kyc.models import KYCIndividual, UserExtraImage
from maneki.apps.user_role.models import Permission, RoleType, RolePermission
from maneki.scripts.init.user_permission import prefix_url


def deal_json(json_path):
    with open(str(os.path.join(str(ROOT_DIR), 'tmp/{}'.format(json_path))), 'rt', encoding="utf8") as f:
        dict_data = json.load(f)
    list_data = dict_data.get("RECORDS")
    return list_data


def open_json(json_path):
    with open(str(os.path.join(str(ROOT_DIR), 'tmp/{}'.format(json_path))), 'rt', encoding="utf8") as f:
        dict_data = json.load(f)
    return dict_data


def save_to_redis(key, value: dict):
    con = get_redis_connection("default")
    con.hmset(key, value)


def save_as_text(json_path, text):
    with open(str(os.path.join(str(ROOT_DIR), 'tmp/{}'.format(json_path))), 'a', encoding="utf8") as f:
        f.write(text + "\n")


def get_from_redis(key, value: str):
    con = get_redis_connection("default")
    result = con.hget(key, value)
    if result:
        result = str(result, encoding='utf8')
    return result


def get_all_from_redis(key):
    con = get_redis_connection("default")
    result = con.hgetall(key)
    result = {k.decode(): v.decode() for k, v in result.items()}
    return result


def save_engine_user():
    data = deal_json('engine_users.json')
    data_dict = {i.get("account"): i.get("email") for i in data}
    save_to_redis('engine_users', data_dict)


def handle_user_v2():
    save_engine_user()
    data_2 = deal_json('user.json')

    result = []
    for row in data_2:
        old_id = row.get('user_id')
        account_id = row.get('account_key', '')
        tradepwd = row.get('tradepwd', '')
        otp_key = row.get('otpkey', '')
        email = get_from_redis('engine_users', old_id)
        if not email:
            continue
        user_name = row.get('username', '')
        tmp = {
            "email": email,
            "account_id": old_id,
            "username": user_name,
            "engine_token": account_id,
            "trade_password": tradepwd,
            "key": otp_key
        }
        result.append(tmp)
        print(old_id)
    return result


def _generate_deposit_bank_code():
    i = 0
    code_pool = set()
    while i < 400000:
        bank_code = generate_nonce_8bit_digits(8, 'ABCDEFGHIGKLMNPQRSTUVWXYZ123456789')
        i += 1
        code_pool.add(bank_code)
    print("deposit_bank_code_pool Done")
    return code_pool


def _batch_format_data(row, deposit_code, group1: list, group2: list, group3: list, group4: list):
    user_id = uuid.uuid4()
    old_id = row['account_id']
    # username = "user-{}".format(generate_username())
    #
    save_to_redis('user_id', {old_id: user_id})
    email = row.get('email')
    otp_key = row.get('key')
    email_ver = True
    otp_ver = False
    if not email:
        email = get_from_redis('engine_users', old_id)
        if not email:
            email = ''
            email_ver = False

    if otp_key:
        otp_ver = True
        group4.append(TimeOTPDevice(key=otp_key, user_id=user_id, status=TOTPDeviceStatus.ACTIVATED))

    group1.append(User(user_id=user_id, email=email, old_account_id=row['account_id'],
                       username=row['username'], is_active=True, old_account_status=UserMigrationStatus.PENDING,
                       status=UserAccountStatus.ENABLED, email_verified=email_ver,
                       trade_password=row.get('trade_password'),
                       engine_token=row.get('engine_token'), totp_device_verified=otp_ver))
    group2.append(UserProfile(user_id=user_id, deposit_code=deposit_code))
    group3.append(UserMembers(user_id=user_id, member_points=10000))


def _batch_insert_data(group1, group2, group3, group4):
    User.objects.bulk_create(group1)
    UserProfile.objects.bulk_create(group2)
    UserMembers.objects.bulk_create(group3)
    if group4:
        TimeOTPDevice.objects.bulk_create(group4)


def batch_insert_user(data, size=500):
    deposit_bank_code_pool = _generate_deposit_bank_code()
    i = 0
    j = 0
    group1 = []
    group2 = []
    group3 = []
    group4 = []
    while True:
        length = len(data)
        #
        if j == length:
            if group1:
                print(
                    "end insert length: group1={}, group2={}, group3={}, group4={}".format(len(group1), len(group2),
                                                                                           len(group3), len(group4)))
                _batch_insert_data(group1, group2, group3, group4)
            break
        #
        if i == size:
            print("insert length: group1={}, group2={}, group3={}, group4={}".format(len(group1), len(group2),
                                                                                     len(group3), len(group4)))
            _batch_insert_data(group1, group2, group3, group4)
            i = 0
            group1[:] = []
            group2[:] = []
            group3[:] = []
            group4[:] = []
            print("clear: group1={}, group2={}, group3={}, group4={}".format(group1, group2, group3, group4))
        #
        row = data[j]
        deposit_code = deposit_bank_code_pool.pop()
        print("count: index={}, no={}".format(j, i))
        # 500
        _batch_format_data(row, deposit_code, group1, group2, group3, group4)
        #
        i += 1
        j += 1


def _batch_insert_kyc(group):
    KYCIndividual.objects.bulk_create(group)


def _batch_format_kyc(row, group: list):
    group.append(KYCIndividual(**row))


def batch_insert_kyc(data, size=500):
    i = 0
    j = 0
    group = []
    while True:
        length = len(data)
        #
        if j == length:
            if group:
                print("end insert length: group={}".format(len(group)))
                _batch_insert_kyc(group)
            break

        if i == size:
            print("insert length: group={}".format(len(group)))
            _batch_insert_kyc(group)
            i = 0
            group[:] = []
            print("clear: group={}".format(len(group)))

        row = data[j]
        print("count: index={}, no={}".format(j, i))
        _batch_format_kyc(row, group)
        i += 1
        j += 1


def save_mobile_name():
    user_list = deal_json('userdata.json')
    country_list = deal_json('country.json')
    country_dict = {i.get('country_code'): '+' + i.get('dial_code') for i in country_list}
    for i in user_list:
        user_id = get_from_redis('user_id', i.get('user_id'))
        if not user_id:
            continue
        if i.get('phone_country') and i.get('phone') and i.get('phone_verified') == '1':
            print("保存用户名 " + i.get('user_id'))
            phone = i.get('phone')
            mobile_country_code = country_dict.get(i.get('phone_country'))
            # mobile, country_code = validate_mobile_phone_number(phone, mobile_country_code)
            mobile = mobile_country_code + phone
            print(mobile)
            print(mobile_country_code)
            User.objects.filter(user_id=user_id).update(
                mobile=mobile, mobile_country_code=mobile_country_code, mobile_verified=True
            )
        kyc_obj = KYCIndividual.objects.filter(user_id=user_id).first()
        if not kyc_obj:
            continue
        kyc_obj.first_name = i.get('name')
        kyc_obj.save()


def create_kyc():
    """
    {
            "user_id": "19417",
            "id_country": "HK",
            "intl_id_number": "K04517880",
            "intl_id_number_status": "3",
            "intl_id_type": "2",
            "id_expire_date": "1734019200",
            "birth_date": "108921600",
            "address": "No.7 G/F Sha Chau Lei Tsuen\nPing Ha Road,\nYuen Long",
            "country": "HK",
            "state": "HK",
            "city": "N.T.",
            "postal_code": "000000",
            "update_dateline": "1483593311"
        },
    :return:
    """
    list_data = deal_json('userdata_intl.json')
    id_type_dict = {
        0: 'paper',
        1: 'paper',
        2: 'passport',
        3: 'paper',
        4: 'paper',
        5: 'paper',
        6: 'driver_license',
        8: 'paper',
    }
    id_status_dict = {
        0: 1,
        1: 1,  # 未验证
        2: 1,  # 客服验证未通过
        3: 4  #
    }
    result = []
    for i in list_data:
        old_id = i.get('user_id')
        user_id = get_from_redis('user_id', old_id)
        if not user_id:
            # user_id = uuid.uuid4()
            print("none user_id: {}".format(user_id))
            continue
        temp = {
            "created_at": datetime.utcfromtimestamp(int(i.get('update_dateline')) + 0.000001).replace(tzinfo=pytz.utc),
            "user_id": user_id,
            "license_country": i.get('id_country'),
            "license_type1": id_type_dict.get(int(i.get('intl_id_type'))),
            "license_type": id_type_dict.get(int(i.get('intl_id_type'))),
            "license_number": i.get('intl_id_number'),
            "local_country": i.get('country'),
            "local_city": i.get("city"),
            "local_region": i.get("state"),
            "local_address": i.get('address'),
            "local_postcode": i.get('postal_code'),
            "current_level": id_status_dict.get(int(i.get('intl_id_number_status'))),
        }
        print("id:{}".format(old_id))
        result.append(temp)
    return result


def bank_account():
    """
    "bank_account_intl_id": "1",
    "user_id": "569610",
    "receving_bank_swift_code": "KCBLRWRWCUS",
    "receving_bank_name": "china ICBC",
    "receving_bank_address": "shanghai xuhui icbc",
    "beneficiary_name": "Mr. vincent",
    "beneficiary_account": "6212261001031611392",
    "beneficiary_address": "china shanghai xuhui load",
    "intermediary_bank_swift_code": "",
    "intermediary_bank_name": "",
    "intermediary_bank_address": "",
    "dateline": "1463299884",
    "update_dateline": "1463299884",
    "status": "-1",
    "vcode_id": "",
    "prod_type": "prousd"
    :return:
    """
    data = deal_json('bank_account_intl.json')
    # result = []
    for i in data:
        old_id = i.get('user_id')
        user_id = get_from_redis('user_id', old_id)
        if not user_id:
            with open(str(os.path.join(str(ROOT_DIR), 'tmp/{}'.format('error_user.log'))), 'at') as f:
                f.write("有银行卡记录的用户，被后端删除的用户：{} \n".format(old_id))
            continue
        tmp = {
            "user_id": user_id,
            "fiat_type": FiatType.USD,
            # "account_type": i.get(''),
            # "bank_id": i.get(''),
            "bank_swift_code": i.get('receving_bank_swift_code', ''),
            "bank_name": i.get('receving_bank_name', ''),
            "bank_address": i.get('receving_bank_address', ''),
            "beneficiary_name": i.get('beneficiary_name', ''),
            "bank_account": i.get('beneficiary_account', ''),
            "beneficiary_address": i.get('beneficiary_address', ''),
            # "via_bank_id": i.get(''),
            "via_bank_name": i.get('intermediary_bank_name', ''),
            "via_bank_address": i.get('intermediary_bank_address', ''),
            "via_bank_swift_code": i.get('intermediary_bank_swift_code', ''),
        }
        print(old_id)
        UserFiatAccount.objects.create(**tmp)


def save_pwd():
    # email_data = get_all_from_redis('engine_users')
    # email_id = {v: get_from_redis('user_id', k) for k, v in email_data.items()}
    # save_to_redis('email_id', email_id)
    data = deal_json('email_token.json')
    j = 0
    for i in data:
        email = i.get('email')
        user_id = get_from_redis('email_id', email)
        if not user_id:
            continue
        if user_id == 'None':
            with open(str(os.path.join(str(ROOT_DIR), 'tmp/{}'.format('error_user.log'))), 'at') as f:
                f.write(email + '\n')
            continue
        print(j)
        # print(user_id)
        # print(email)
        j += 1
        User.objects.filter(user_id=user_id).update(password=i.get('password'))


def check_user():
    data = deal_json('engine_users.json')
    j = 0
    for i in data:
        # user_obj = User.objects.filter()
        old_id = i.get('account')
        user_id = get_from_redis('user_id', old_id)
        if not user_id:
            with open(str(os.path.join(str(ROOT_DIR), 'tmp/{}'.format('error_user.log'))), 'at') as f:
                f.write("在引擎中存在，被后端删除的用户：{} \n".format(old_id))
            continue
        if user_id == 'None':
            with open(str(os.path.join(str(ROOT_DIR), 'tmp/{}'.format('error_user.log'))), 'at') as f:
                f.write("在引擎中存在，被后端删除的用户：{} \n".format(old_id))
        print(j)
        j += 1


def api_user():
    data = deal_json('apiauth.json')
    for i in data:
        pass


def load_permission_to_db():
    urls = api_admin.registry
    for route_path, name, _ in urls:
        # url while auto slash
        route_path = prefix_url + route_path + '/'
        name = name.__name__
        Permission.objects.get_or_create(route_path=route_path,
                                         permission_code=1,
                                         permission_name=name + ":List")

        Permission.objects.get_or_create(route_path=route_path,
                                         permission_code=2,
                                         permission_name=name + ":Create")


def init_superuser_permission():
    role = RoleType.objects.filter(role_code=9991).first()
    if not role:
        print("No init role")
        return
    role_id = role.id

    permissions = Permission.objects.filter(is_deleted=False).all()

    for p in permissions:
        RolePermission.objects.get_or_create(
            permission_id=p.id,
            role_id=role_id
        )


def user_image():
    """
    "user_id": "33143",
    "type": "id",
    "width": "600",
    "height": "338",
    "mime": "image/jpeg",
    "img": "/9j
    :return:
    """
    data = deal_json('user_image.json')
    j = 0
    for i in data:
        old_id = i.get('user_id')
        user_id = get_from_redis('user_id', old_id)
        type = i.get('mime').split('/')[1]
        with open(str(os.path.join(str(ROOT_DIR),
                                   'tmp/image/{}@{}.{}'.format(user_id, random.randint(0, 9), type))), 'w') as f:
            f.write(i.get('img'))
        print(j)
        j += 1


def get_user_id():
    user_data = User.objects.all()
    j = 0
    for i in user_data:
        user_id = i.user_id
        data_obj = KYCIndividual.objects.filter(user_id=user_id)
        if data_obj:
            save_to_redis('user_id', {i.old_account_id: user_id.hex})
            print(j)
            j += 1


def save_json(json_path, data):
    with open(str(os.path.join(str(ROOT_DIR), 'tmp/{}'.format(json_path))), 'w') as r:
        r.write(json.dumps(data))


def update_to_s3():
    root_path = str(os.path.join(str(ROOT_DIR), 'maneki/scripts/migrations/image/'))
    data = os.listdir(root_path)
    dict_data = {}
    for i in data:
        # os.rename(os.path.join(path,file),os.path.join(path,new_name))
        f_type = i.split('.')[1]
        if f_type in ('jpeg', 'JPEG'):
            f_type = 'jpg'
        user_id = i.split('.')[0]
        new_file_name = str(uuid.uuid4().hex) + "." + f_type
        os.rename(os.path.join(root_path, i), os.path.join(root_path, new_file_name))
        redis_dict = {user_id: new_file_name}
        save_to_redis('image', redis_dict)
        dict_data.update(redis_dict)
        print(i)
    save_json('user_image2.json', dict_data)


def save_to_mysql():
    """
    'id' => ['身份证前面', '身份证前面上传'],
    'id_back'  => ['身份证后面', '身份证后面上传'],
    'holdid'   => ['手持身份证', '手持身份证上传'],
    'passport' => ['护照', '护照上传'],
    'address'  => ['地址证明文件', '地址证明文件上传'],
    'holdPassport' => ['手持护照', '手持护照上传'],
    'id'                        => '身份照正面',
    'id_back'                   => '身份照背面',
    'holdid'                    => '手持身份证',
    'passport'                  => '护照正面',
    'passport_back'             => '护照背面',
    'hold_passport'             => '手持护照',
    'taiwan'                    => '台湾证件照',
    'taiwan_back'               => '台湾证件照背面',
    'hongkong'                  => '香港证件照',
    'hongkong_back'             => '香港证件照背面',
    'other'                     => '其他证件照',
    'other_back'                => '其他证件照背面',
    'driver_license'            => '驾照',
    'address'                   => '地址证明文件',
    'trans'                     => '其他1',
    'transname'                 => '其他2',
    'auctioncomplain1'          => '其他3',
    'auctioncomplain2'          => '其他4',
    'auctioncomplain3'          => '其他5',
    'business_registration'     => '营业执照',
    'articles_of_association'   => '公司章程',
    'ownership_structure_chart' => '股权结构',
    'authorization_document'    => '企业授权书',
    :return:
    """
    # data = get_all_from_redis('')
    data = open_json('image_data_type.json')
    type_dict = {
        "id": "license_pic01",
        "id_back": "license_pic02",
        "holdid": "license_pic03",
        "passport": "license_pic01",
        "passport_back": "license_pic02",
        "hold_passport": "license_pic03",
        "taiwan": "license_pic01",
        "taiwan_back": "license_pic02",
        "hongkong": "license_pic01",
        "hongkong_back": "license_pic02",
        "driver_license": "license_pic01",
        "address": "address_cert",
        "other": "license_pic01",
        "other_back": "license_pic02",
        "trans": "license_pic01",
        "transname": "license_pic02",
        # "auctioncomplain1": "license_pic01",
        # "auctioncomplain2": "license_pic02",
        # "auctioncomplain3": "license_pic03",
    }
    final_list = []
    for k, v in data.items():
        old_id = k
        print(old_id)
        # temp_dict = {"user_id": '', "extra_1": {}}
        temp_dict = {'user_id': ''}
        for i in v:
            user_id = i.get('user_id')
            image_name = i.get('image_name')
            new_image_name = get_from_redis('image', image_name)
            image_type = i.get('image_type')
            final_type = type_dict.get(image_type)
            # temp_dict.get('extra_1').update({image_type: new_image_name})
            if not final_type:
                print(user_id)
                with open(str(os.path.join(str(ROOT_DIR), 'tmp/{}'.format('enterprise_user.log'))), 'at',
                          encoding='utf8') as f:
                    f.write("企业用户，old_id: {}, user_id: {} \n".format(old_id, user_id))
                continue
            temp_dict.update({"user_id": user_id, final_type: new_image_name, })
        re = temp_dict.get('license_pic02')
        if re:
            temp_dict.update(license_type='paper')
        else:
            temp_dict.update(license_pic02='', license_type='passport')
        final_list.append(temp_dict)
    save_json('mysql_json2.json', final_list)


def save_extra_image():
    pass


def save_to_aws():
    data = open_json('mysql_json2.json')
    for i in data:
        user_id = i.get('user_id')
        print(data.index(i))
        del i['user_id']
        KYCIndividual.objects.filter(user_id=user_id).update(**i)

    # with open(str(os.path.join(str(ROOT_DIR), 'maneki/apps/user_kyc/libs/KYC L2 agreement_20180608.docx')), 'rb') as file:
    #
    #     print(file)
    #     file_name = generate_file_name(file.name)
    #     file_temp = InMemoryUploadedFile(file,
    #                                      'docx_file',  # important to specify field name here
    #                                      file_name,
    #                                      'docx',
    #                                      sys.getsizeof(file),
    #                                      None)
    #     f = PrivateMediaStorage()
    #     print(file_name)
    #     f.save(file_name, file_temp)
    # s3 = boto3.resource('s3')
    # data = open('test.jpg', 'rb')
    # s3.Bucket('my-bucket').put_object(Key='test.jpg', Body=data)


def save_api_key():
    data = deal_json('maneki_user_api_key.json')
    j = 0
    for i in data:
        UserApiKey.objects.create(**i)
        print(j)
        j += 1


def change_otp(user_email):
    user_id = User.objects.filter(email=user_email).first().user_id
    User.objects.filter(email=user_email).update(totp_device_verified=False)
    TimeOTPDevice.objects.filter(user_id=user_id).update(status=-1, confirmed=0)


def get_user_extra_image():
    data = open_json('mysql_json.json')
    j = 0
    t = 0
    for i in data:
        extra_data = i.get('extra_1')
        user_id = i.get('user_id')
        if len(extra_data) > 4:
            KYCIndividual.objects.filter(user_id=user_id).update(extra_1=False)
            UserExtraImage.objects.create(user_id=user_id, value=extra_data)
            print("过长的图片列表：" + str(t) + " # " + str(len(extra_data)))
            t += 1
        else:
            pass
            KYCIndividual.objects.filter(user_id=user_id).update(extra_1=extra_data)
        print(j)
        j += 1


def get_user_bank_info():
    import json
    from django.core.serializers.json import DjangoJSONEncoder
    a = FiatCurrencyWithdrawRecordLastThreeMonths.objects.filter(user_id='c1fecce61a3a47f6a4b20a98f0fd7e9e')
    result = []
    for i in a:
        user_id = i.user_id

        b = UserFiatAccount.objects.filter(user_id=user_id, bank_account=i.bank_account)
        # i_data = i.values_list()
        b_data = b.values('fiat_type', 'bank_swift_code', 'bank_name', 'bank_address',
                          'beneficiary_name', 'bank_account', 'beneficiary_address', 'via_bank_name',
                          'via_bank_address', 'via_bank_swift_code', 'id')

        result.append({"bank_info": list(b_data),
                       "amount": i.amount,
                       "service_charge": i.service_charge,
                       "user_id": i.user_id,
                       "email": User.objects.filter(user_id=user_id).first().email})
        # b_data_list = [en for en in b_data]
        # result.append(dict(b_data_list))
    c = json.dumps(result, cls=DjangoJSONEncoder)
    print(c)


def _generate_deposit_bank_code2():
    i = 0
    code_pool = set()
    while i < 400:
        bank_code = generate_nonce_8bit_digits(8, 'ABCDEFGHIGKLMNPQRSTUVWXYZ123456789')
        i += 1
        code_pool.add(bank_code)
    print("deposit_bank_code_pool Done")
    return code_pool


def save_lost_old_user():
    """
    """
    user_list = [
        {
            "old_id": 478618,
            "email": "33.sb@163.com",
            "engine_token": "7142d144-0f22-4ccd-a639-bbe2c356e397",
            "tradepwd": "b46be128767ab292d21fefa36646b27eb90af648",
            "otp_key": ""
        },
        {
            "old_id": 478725,
            "email": "39597767@qq.com",
            "engine_token": "dd09262e-25cc-4eee-b09e-e5f0e11467f8",
            "tradepwd": "260e28892580597da5b7bc20908275b476e87b51",
            "otp_key": ""
        },
        {
            "old_id": 636958,
            "email": "chi264@gmail.com",
            "engine_token": "04546525-ee41-410d-ba6b-7a86e1004f87",
            "tradepwd": "375b7c36216b173cf5b1f5af4199899ed3a32b8d",
            "otp_key": ""
        },
        {
            "old_id": 989563,
            "email": "obbassl1@gmail.com",
            "engine_token": "9fe2bbf2-405f-45b7-8ff8-68617ef0aa36",
            "tradepwd": "",
            "otp_key": ""
        },
        {
            "old_id": 993315,
            "email": "tsumu.k.4525@gmail.com",
            "engine_token": "1653d35e-f155-4ac4-a4a5-ccd3717bc428",
            "tradepwd": "e03a6b53227737b3aa492f945bc997a460db8bc0",
            "otp_key": "VIXB4TNNNXKAKYHQ"
        },
        {
            "old_id": 993343,
            "email": "shizheqin@163.com",
            "engine_token": "8421e8ad-ecfc-4b32-a60b-094f1b2ca0f1",
            "tradepwd": "5cc25cb6e824436e391fa7c2855103830ee4aa2c",
            "otp_key": ""
        },
        {
            "old_id": 993345,
            "email": "sophisteta@gmail.com",
            "engine_token": "31b5dd8c-4968-42b7-8405-a8aa8d0117d7",
            "tradepwd": "",
            "otp_key": ""
        },
        {
            "old_id": 993349,
            "email": "jimmykixx@gmail.com",
            "engine_token": "5a074c23-4991-4aab-bfd3-2fa851c80b06",
            "tradepwd": "667b629cc4f5cff9f49984e73cb24d1f9be680e4",
            "otp_key": ""
        },
        {
            "old_id": 993351,
            "email": "626779147@qq.com",
            "engine_token": "d9813630-c054-4a73-9855-0dbada3cac4c",
            "tradepwd": "",
            "otp_key": ""
        },
        {
            "old_id": 993354,
            "email": "kamheaven888@gmail.com",
            "engine_token": "7f492322-86d5-4d27-8989-a16601b196f6",
            "tradepwd": "",
            "otp_key": ""
        },
        {
            "old_id": 993355,
            "email": "2979610179@qq.com",
            "engine_token": "acc9c2c2-12d5-44a2-827d-33364981215a",
            "tradepwd": "",
            "otp_key": ""
        },
        {
            "old_id": 993361,
            "email": "qqqqchan999@gmail.com",
            "engine_token": "1dbcf985-cd82-4403-aa9c-824ae3a4016a",
            "tradepwd": "2c21ae0839dcadd2b33bdf3e9268343558efcdd8",
            "otp_key": ""
        },
        {
            "old_id": 993365,
            "email": "552763011@qq.com",
            "engine_token": "0c6c59bf-2561-4fba-98b8-284f2ad3a7c7",
            "tradepwd": "5e13f0e59d89f500de599bb6de09727de6dfd6f0",
            "otp_key": ""
        },
        {
            "old_id": 993370,
            "email": "naoki19800705@yahoo.co.jp",
            "engine_token": "7be4a5b9-5d8b-47ee-9b4d-b927229c7f89",
            "tradepwd": "61b232f4c4c893847ba5c1a31ea001282fa5faa3",
            "otp_key": "FSETCGSCNVVQF4GC"
        },
        {
            "old_id": 993371,
            "email": "admailmk@gmail.com",
            "engine_token": "2f849594-2415-401e-b352-226b41ed9a70",
            "tradepwd": "",
            "otp_key": ""
        },
        {
            "old_id": 993372,
            "email": "morisawa0903hisashi@yahoo.co.jp",
            "engine_token": "39d816fb-fa59-449a-88d8-bfe1dd1c889a",
            "tradepwd": "439cb4ffb51b51a7b924d195e60078fca56866b6",
            "otp_key": "4KHG22TGNF3GYI33"
        },
        {
            "old_id": 993374,
            "email": "rahmansyaharief18@gmail.com",
            "engine_token": "4b2caee0-ec0d-40d9-a5cd-f4d5293c1419",
            "tradepwd": "",
            "otp_key": ""
        },
        {
            "old_id": 993378,
            "email": "moffee1026@yahoo.co.jp",
            "engine_token": "4a3e6c22-1de7-4d38-b3d3-7adb02d5afdf",
            "tradepwd": "",
            "otp_key": ""
        },
        {
            "old_id": 993379,
            "email": "arthurstatg2a@gmail.com",
            "engine_token": "944955d9-26ec-4619-b2f4-624ea54ecd1c",
            "tradepwd": "",
            "otp_key": ""
        },
        {
            "old_id": 993380,
            "email": "qnvvvvvv@abv.bg",
            "engine_token": "fcfe20b2-f0e3-47ad-a72c-32b7863a8571",
            "tradepwd": "",
            "otp_key": ""
        },
        {
            "old_id": 993381,
            "email": "rdelimasilva@gmail.com",
            "engine_token": "776bfc37-8970-4384-8d24-cd0eea5644fd",
            "tradepwd": "8371aec022f01e5b10f7b3dccf3dc07fbe0f3aa3",
            "otp_key": ""
        },
        {
            "old_id": 993387,
            "email": "sedattuzun123@gmail.com",
            "engine_token": "966c8b37-c924-4f18-8822-501002c67c82",
            "tradepwd": "",
            "otp_key": ""
        },
        {
            "old_id": 993388,
            "email": "roorooshuu@gmail.com",
            "engine_token": "5bcbf689-9c1b-4eba-a36d-74d116b56746",
            "tradepwd": "",
            "otp_key": ""
        },
        {
            "old_id": 993391,
            "email": "gas_newman@yahoo.com",
            "engine_token": "696f6ffc-7a29-4abe-9e7b-a82d29374275",
            "tradepwd": "e07acf4315be47d08d88a52b735aa29ff7236f9f",
            "otp_key": ""
        },
        {
            "old_id": 993393,
            "email": "37178863@qq.com",
            "engine_token": "2b287132-e5b4-4336-affb-718535d0dc94",
            "tradepwd": "",
            "otp_key": ""
        },
        {
            "old_id": 993395,
            "email": "diephuynh.olm@gmail.com",
            "engine_token": "88f1f4a8-5c61-4f83-afc9-5e567462b2a1",
            "tradepwd": "",
            "otp_key": ""
        },
        {
            "old_id": 993396,
            "email": "munibux1991@gmail.com",
            "engine_token": "326c04bf-728d-4e0b-86d5-f06906e71c30",
            "tradepwd": "",
            "otp_key": ""
        }
    ]
    # code_pool = _generate_deposit_bank_code2()
    j = 0
    for i in user_list:
        old_id = i.get('old_id')
        email = i.get('email')
        user_obj = User.objects.filter(email=email).first()
        # deposit_code = code_pool.pop()
        print(old_id)
        if user_obj:
            user_id = user_obj.user_id
            if not user_obj.old_account_id:
                user_obj.old_account_id = old_id
                user_obj.old_account_status = 0
            if i.get('otp_key'):
                user_obj.engine_token = i.get('engine_token')
                user_obj.totp_device_verified = True
                user_obj.save()
                TimeOTPDevice.objects.create(key=i.get('otp_key'), user_id=user_id, status=1, )
            j += 1
            print(j)
            # if not UserProfile.objects.filter(user_id=user_id).first():
            #     UserProfile.objects.create(user_id=user_id, deposit_code=deposit_code)
            # if not UserMembers.objects.filter(user_id=user_id).first():
            #     UserMembers.objects.create(user_id=user_id, member_points=10000)
        #     continue
        # User.objects.create(user_id=user_id, email=email, old_account_id=old_id, is_active=True, old_account_status=0,
        #                     status=UserAccountStatus.ENABLED, email_verified=True, engine_token=i.get('engine_token'),
        #                     trade_password=i.get('tradepwd', ''), username=email)
        # UserProfile.objects.create(user_id=user_id, deposit_code=deposit_code)
        # UserMembers.objects.create(user_id=user_id, member_points=10000)
        # print(j)
        # j += 1


def reject_reason():
    with open(str(os.path.join(str(ROOT_DIR), 'tmp/{}'.format('20180606.txt'))), 'at', encoding='utf8') as f:
        temp = f.readlines()
        print(temp)


def _save_crypto_fee(coin_type, day):
    record_obj = CryptoWithdrawRecordLastThreeMonths.objects.filter(updated_at__gte="2018-6-{} 8:00".format(day - 1),
                                                                    updated_at__lt="2018-6-{} 8:00".format(day),
                                                                    coin_type=coin_type)
    complete_fee = record_obj.filter(status=0).aggregate(Sum('tx_fee')).get('tx_fee__sum')
    if not complete_fee:
        complete_fee = 0
    complete_count = record_obj.filter(status=0).count()
    pending_fee = record_obj.filter(status__gt=0).aggregate(Sum('tx_fee')).get('tx_fee__sum', 0)
    if not pending_fee:
        pending_fee = 0
    pending_count = record_obj.filter(status__gt=0).count()
    print(
        "complete_fee: {}, complete_count: {}, pending_fee: {}, pending_count: {}".format(complete_fee, complete_count,
                                                                                          pending_fee, pending_count))
    temp_obj = CryptoDailyClearingRecord.objects.create(coin_type=coin_type, pending_fee_total=pending_fee,
                                                        pending_tx_count=pending_count,
                                                        completed_fee_total=complete_fee,
                                                        completed_tx_count=complete_count, )
    CryptoDailyClearingRecord.objects.filter(id=temp_obj.id).update(
        day_at=datetime.strptime("2018-06-{}".format(day), "%Y-%m-%d"))


def _save_fiat_fee(fiat_type, day):
    record_obj = FiatCurrencyWithdrawRecordLastThreeMonths.objects.filter(
        updated_at__gte="2018-6-{} 8:00".format(day - 1),
        updated_at__lt="2018-6-{} 8:00".format(day),
        fiat_type=fiat_type)
    complete_fee = record_obj.filter(status=0).aggregate(Sum('service_charge')).get('service_charge__sum', 0)
    if not complete_fee:
        complete_fee = 0
    complete_count = record_obj.filter(status=0).count()
    pending_fee = record_obj.filter(status__gt=0).aggregate(Sum('service_charge')).get('service_charge__sum', 0)
    if not pending_fee:
        pending_fee = 0
    pending_count = record_obj.filter(status__gt=0).count()
    print(
        "complete_fee: {}, complete_count: {}, pending_fee: {}, pending_count: {}".format(complete_fee, complete_count,
                                                                                          pending_fee, pending_count))
    obj_temp = FiatDailyClearingRecord.objects.create(fiat_type=fiat_type, pending_fee_total=pending_fee,
                                                      pending_tx_count=pending_count,
                                                      completed_fee_total=complete_fee,
                                                      completed_tx_count=complete_count, )

    FiatDailyClearingRecord.objects.filter(id=obj_temp.id).update(
        day_at=datetime.strptime("2018-06-{}".format(day), "%Y-%m-%d"))


def _save_fee(day):
    for i in CoinType.values:
        if i < 0:
            continue
        _save_crypto_fee(i, day)
    for i in FiatType.values:
        if i < 0:
            continue
        _save_fiat_fee(i, day)


def get_fee():
    day = int(timezone.now().strftime('%d'))
    for i in range(2, day + 1):
        _save_fee(i)


def random_crypto_record():
    i = 0
    user_id = get_all_from_redis('user_id')
    user_id = [v for k, v in user_id.items()]
    while i < 40:
        CryptoDepositRecordLastThreeMonths.objects.create(
            coin_type=random.randint(0, 5),
            tx_id=uuid.uuid4().hex,
            tx_address=generate_nonce_8bit_digits(8, 'ABCDEFGHIGKLMNPQRSTUVWXYZ123456789'),
            tx_amount=Decimal("{}.{}".format(random.randint(0, 10), random.randint(0, 999))),
            tx_fee=Decimal("{}.{}".format(random.randint(0, 10), random.randint(0, 999))),
            confirmations=1,
            engine_sn=uuid.uuid4(),
            engine_request_no=uuid.uuid4(),
            engine_code=0,
            tx_sub_id="KLTC448L",
            status=0,
            user_id=user_id.pop(),
            updated_at="2018-06-{} 04:00:00.000001".format(random.randint(1, 28))
        )
        CryptoWithdrawRecordLastThreeMonths.objects.create(
            coin_type=random.randint(0, 5),
            tx_id=uuid.uuid4().hex,
            tx_address=generate_nonce_8bit_digits(8, 'ABCDEFGHIGKLMNPQRSTUVWXYZ123456789'),
            tx_amount=Decimal("{}.{}".format(random.randint(0, 10), random.randint(0, 999))),
            tx_fee=Decimal("{}.{}".format(random.randint(0, 10), random.randint(0, 999))),
            confirmations=1,
            engine_sn=uuid.uuid4(),
            engine_request_no=uuid.uuid4(),
            engine_code=0,
            tx_sub_id="KLTC448L",
            status=0,
            to_address=generate_nonce_8bit_digits(8, 'ABCDEFGHIGKLMNPQRSTUVWXYZ123456789'),
            user_id=user_id.pop(),
            updated_at="2018-06-{} 04:00:00.000001".format(random.randint(1, 28))
        )
        i += 1


def get_permission():
    pass


def run():
    pass
    # result = handle_user_v2()
    # print("用户数据生成完毕")
    #
    # batch_insert_user(result)
    # print("用户数据保存完毕")
    #
    # kyc_data = create_kyc()
    # print("KYC数据生成完毕")
    #
    # batch_insert_kyc(kyc_data)
    # print("KYC数据保存完毕")
    #
    # bank_account()
    # print("用户银行卡信息")
    #
    # save_mobile_name()
