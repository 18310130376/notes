# -*- coding: utf-8 -*-
from maneki.apps.transaction.services.crypto.deposit_block_analyzer import DepositReportBlockAnalyzer


def run(*args):
    """off-chain

    :param args:
    :return:
    """
    worker = DepositReportBlockAnalyzer()
    worker.consume()
