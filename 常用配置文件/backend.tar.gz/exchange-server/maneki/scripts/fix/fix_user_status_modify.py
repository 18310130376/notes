# -*- coding: utf-8 -*-
import os
import logging
import json
from maneki.apps.engine.services import EngineService
from maneki.apps.user.models import User

logger = logging.getLogger(__name__)


def run(*args):
    path = os.path.dirname(os.path.abspath(__file__))
    if os.path.exists(path + "/enginelost.json"):
        with open(path + "/enginelost.json", 'r') as load_f:
            load_user_list = json.load(load_f)
            logger.info("user info list:{}".format(load_user_list))

        # 修改条数
        modify_num = 0

        for user_info in load_user_list:
            """user_info:{
                    "user_id": "",
                    "engine_token": "",
                    "email": "",
                }
            """
            row = User.objects.filter(user_id=user_info.get("user_id")).update(status=0)
            modify_num = modify_num + row

        # 总条数
        print('total number:{}'.format(len(load_user_list)))
        logger.info('total number:{}'.format(len(load_user_list)))
        # 修改数
        print('modify numer:{}'.format(modify_num))
        logger.info('modify numer:{}'.format(modify_num))

