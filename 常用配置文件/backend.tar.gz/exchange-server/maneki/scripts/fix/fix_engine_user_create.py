# -*- coding: utf-8 -*-
import os
import logging
import json
from datetime import datetime

from maneki.apps.constants import UserActivityPoint, UserMembersPointsSource
from maneki.apps.engine.services import EngineService
from maneki.apps.user.models import User
from maneki.apps.user_members.models import UserMembers
from maneki.apps.user_members.services.user_member_activate import UserMemberCreateProducer

logger = logging.getLogger(__name__)


def run(*args):

    service = EngineService()
    path = os.path.dirname(os.path.abspath(__file__))
    if os.path.exists(path + "/enginelost.json"):
        with open(path + "/enginelost.json", 'r') as load_f:
            load_user_list = json.load(load_f)

        # 同步条数
        sync_num = 0
        unsync_num = 0
        modify_num1 = 0
        modify_num2 = 0
        member_num = 0

        for user_info in load_user_list:
            """user_info:{
                    "user_id": "",
                    "engine_token": "",
                    "email": "",
                }
            """

            logger.info("user info:{}".format(user_info))

            response = service.create_account(user_id=user_info.get("user_id"),
                                              email=user_info.get("email"),
                                              token=user_info.get("engine_token"))

            logger.info('engine create user account response:{}'.format(response))

            if response.get('RC') == 3:
                sync_num = sync_num + 1
                row = User.objects.filter(user_id=user_info.get("user_id")).update(status=0)
                modify_num1 = modify_num1 + row
            elif response.get('RC') == 0:
                unsync_num = unsync_num + 1
                row = User.objects.filter(user_id=user_info.get("user_id")).update(status=0)
                modify_num2 = modify_num2 + row

            # 判断用户积分账号是否存在
            usermember = UserMembers.objects.filter(user_id=user_info.get("user_id"))
            if usermember:
                continue

            # 创建用户积分账号
            user = User.objects.filter(user_id=user_info.get("user_id")).first()
            if user.old_account_id:
                point = 10000
            else:
                point = 1000
            result = {
                "user_id": user.user_id_hex,
                "point": point,  # TODO: need refactor.
                "point_source": UserMembersPointsSource.USERACTIVATE,
                "remark": "user activate at {}".format(datetime.now())
            }
            p = UserMemberCreateProducer()
            p.publish(result)
            member_num = member_num + 1
        # 总条数
        print('total number:{}'.format(len(load_user_list)))
        logger.info('total number:{}'.format(len(load_user_list)))
        # 同步数
        print('sync num:{}, unsync num:{}'.format(sync_num, unsync_num))
        logger.info('sync num:{}, unsync num:{}'.format(sync_num, unsync_num))

        # 已存在修改
        print('modify numer1:{}'.format(modify_num1))
        logger.info('modify numer1:{}'.format(modify_num1))
        # 创建修改数
        print('modify numer2:{}'.format(modify_num2))
        logger.info('modify numer2:{}'.format(modify_num2))
        # 创建积分账号数量
        logger.info('积分账号创建 member num:{}'.format(member_num))

