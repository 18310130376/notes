import json
import logging

from django.conf import settings

from maneki.apps.common.utils.sign import generate_sign_sha256
from maneki.apps.transaction.models import CryptoDepositRecordLastThreeMonths
from maneki.apps.transaction.services.crypto.deposit_engine_handler import DepositEngineRequestProducer

logger = logging.getLogger(__name__)


def construct_msg(user_id, coin_type, deposit_address, tx_id, engine_sn=None):
    condition = dict()
    condition.update(
        user_id=user_id,
        coin_type=coin_type,
        tx_address=deposit_address,
        tx_id=tx_id,
        is_deleted=False
    )
    if engine_sn:
        condition.update(engine_sn=engine_sn)
    record = CryptoDepositRecordLastThreeMonths.objects.filter(**condition).exclude(
        status=0,
        engine_code=0
    )

    if len(record) > 1:
        logger.info("found record > 1 please provide engine_sn")
        return
    sql = record.query
    logger.info(sql)
    r = record.first()
    msg = {
        'tx_amount': r.tx_amount_fmt,
        'engine_sn': r.engine_sn_id,
        'engine_request_no': r.engine_request_no_id,
        'user_id': r.engine_account_id,
        'coin_type': r.coin_type

    }
    return msg


def send_msg_to_q(msg):
    producer = DepositEngineRequestProducer()
    producer.publish(msg)
