/*
 Navicat Premium Data Transfer

 Source Server         : dev
 Source Server Type    : MySQL
 Source Server Version : 50721
 Source Host           : 10.0.20.83
 Source Database       : test_maneki

 Target Server Type    : MySQL
 Target Server Version : 50721
 File Encoding         : utf-8

 Date: 07/27/2018 13:58:48 PM
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;


-- ----------------------------
-- `maneki_tx_record_crypto_withdraw_last_3months`
-- ----------------------------
ALTER TABLE maneki_tx_record_crypto_withdraw_last_3months
	ADD accessor varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '';

ALTER TABLE maneki_tx_record_crypto_withdraw_last_3months
	ADD verify_type int(11) NOT NULL DEFAULT 0;

-- ----------------------------
-- `maneki_tx_record_crypto_withdraw`
-- ----------------------------
ALTER TABLE maneki_tx_record_crypto_withdraw
	ADD accessor varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '';

ALTER TABLE maneki_tx_record_crypto_withdraw
	ADD to_address varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '';

ALTER TABLE maneki_tx_record_crypto_withdraw
	ADD verify_type int(11) NOT NULL DEFAULT 0;
