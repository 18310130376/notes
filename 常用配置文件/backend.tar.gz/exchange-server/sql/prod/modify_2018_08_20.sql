/*
 Navicat Premium Data Transfer

 Source Server         : dev
 Source Server Type    : MySQL
 Source Server Version : 50721
 Source Host           : 10.0.20.83
 Source Database       : test_maneki

 Target Server Type    : MySQL
 Target Server Version : 50721
 File Encoding         : utf-8

 Date: 07/27/2018 13:58:48 PM
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;


-- ----------------------------
-- `maneki_user_api_key`
-- ----------------------------
ALTER TABLE maneki_user_api_key
	ADD white_list varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '';
