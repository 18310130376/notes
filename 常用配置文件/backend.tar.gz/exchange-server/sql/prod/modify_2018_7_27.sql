/*
 Navicat Premium Data Transfer

 Source Server         : dev
 Source Server Type    : MySQL
 Source Server Version : 50721
 Source Host           : 10.0.20.83
 Source Database       : test_maneki

 Target Server Type    : MySQL
 Target Server Version : 50721
 File Encoding         : utf-8

 Date: 07/27/2018 13:58:48 PM
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
--  Table structure for `maneki_agent_daily_count`
-- ----------------------------
DROP TABLE IF EXISTS `maneki_agent_daily_count`;
CREATE TABLE `maneki_agent_daily_count` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL ,
  `node` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supernode` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `root_id` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_tx_fee` decimal(20,10) NOT NULL,
  `tx_fee_type` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_tx_fee_usd` decimal(20,10) NOT NULL,
  `exchange_rate` decimal(10,2) NOT NULL,
  `data_date` date NOT NULL,
  `count_datetime` datetime(6) NOT NULL,
  `extra_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `extra_2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `extra_3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `maneki_agent_daily_count_user_id_adc73c32` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ----------------------------
--  Table structure for `maneki_agent_trade_count`
-- ----------------------------
DROP TABLE IF EXISTS `maneki_agent_trade_count`;
CREATE TABLE `maneki_agent_trade_count` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `account` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `duration` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fee` decimal(20,10) NOT NULL,
  `rate` decimal(10,2) DEFAULT NULL,
  `count_date` date DEFAULT NULL,
  `extra_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `extra_2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `extra_3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;


-- ----------------------------
--  Table structure for `maneki_user_rebate_rate`
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_rebate_rate`;
CREATE TABLE `maneki_user_rebate_rate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `rate_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` int(11) NOT NULL,
  `extra_1` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_2` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_3` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rate_type` (`rate_type`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
--  Records of `maneki_user_rebate_rate`
-- ----------------------------
BEGIN;
INSERT INTO `maneki_user_rebate_rate` VALUES ('1', '2018-07-16 00:00:00.000000', '2018-07-16 00:00:00.000000', '0', null, 'share', '10', '', '', ''), ('2', '2018-07-16 00:00:00.000000', '2018-07-16 00:00:00.000000', '0', null, 'direct', '30', '', '', ''), ('3', '2018-07-16 00:00:00.000000', '2018-07-16 00:00:00.000000', '0', null, 'indirect', '10', '', '', ''), ('4', '2018-07-16 00:00:00.000000', '2018-07-16 00:00:00.000000', '0', null, 'super', '10', '', '', ''), ('5', '2018-07-16 00:00:00.000000', '2018-07-16 00:00:00.000000', '0', null, 'normal', '10', '', '', '');
COMMIT;

-- ----------------------------
-- `maneki_user_distributor`
-- ----------------------------
ALTER TABLE maneki_user_distributor
	CHANGE inviter_id parent_id varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '';
ALTER TABLE maneki_user_distributor
	CHANGE invitee_list root_id varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '';
ALTER TABLE maneki_user_distributor
	CHANGE extra_2 node_id varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '';
ALTER TABLE maneki_user_distributor
	CHANGE extra_3 super_node_id varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '';


SET FOREIGN_KEY_CHECKS = 1;
