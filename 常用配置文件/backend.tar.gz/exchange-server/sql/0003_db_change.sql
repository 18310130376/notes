
-- api_key: 255
ALTER TABLE maneki_user_api_key MODIFY secret_key VARCHAR(255);
