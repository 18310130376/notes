/*
 Navicat Premium Data Transfer

 Source Server         : 10.0.20.83
 Source Server Type    : MySQL
 Source Server Version : 50721
 Source Host           : 10.0.20.83:13306
 Source Schema         : maneki

 Target Server Type    : MySQL
 Target Server Version : 50721
 File Encoding         : 65001

 Date: 10/06/2018 17:06:11
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;


-- ----------------------------
-- Table structure for maneki_user
-- user table must be first.
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user`;
CREATE TABLE `maneki_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(254) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_country_code` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `verify_code` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified` tinyint(1) NOT NULL,
  `mobile_verified` tinyint(1) NOT NULL,
  `totp_device_verified` tinyint(1) NOT NULL,
  `trade_password` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `old_account_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_account_status` int(11) NOT NULL,
  `extra_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `maneki_user_email_7448ee35` (`email`),
  KEY `maneki_user_mobile_e2d84771` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ----------------------------
-- Table structure for auth_group
-- ----------------------------
DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for auth_group_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for auth_permission
-- ----------------------------
DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for django_admin_log
-- ----------------------------
DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext COLLATE utf8mb4_unicode_ci,
  `object_repr` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_maneki_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_maneki_user_id` FOREIGN KEY (`user_id`) REFERENCES `maneki_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for django_content_type
-- ----------------------------
DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for django_migrations
-- ----------------------------
DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for django_session
-- ----------------------------
DROP TABLE IF EXISTS `django_session`;
CREATE TABLE `django_session` (
  `session_key` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for django_site
-- ----------------------------
DROP TABLE IF EXISTS `django_site`;
CREATE TABLE `django_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_site_domain_a2e37b91_uniq` (`domain`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_config_crypto_confirm_limit
-- ----------------------------
DROP TABLE IF EXISTS `maneki_config_crypto_confirm_limit`;
CREATE TABLE `maneki_config_crypto_confirm_limit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `coin_type` int(11) NOT NULL,
  `min_confirm_num` smallint(5) unsigned NOT NULL,
  `max_confirm_num` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_config_crypto_withdraw_fee_rate
-- ----------------------------
DROP TABLE IF EXISTS `maneki_config_crypto_withdraw_fee_rate`;
CREATE TABLE `maneki_config_crypto_withdraw_fee_rate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `coin_type` int(11) NOT NULL,
  `fee_rate` decimal(40,20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_config_crypto_withdraw_limit
-- ----------------------------
DROP TABLE IF EXISTS `maneki_config_crypto_withdraw_limit`;
CREATE TABLE `maneki_config_crypto_withdraw_limit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `currency_type` int(11) NOT NULL,
  `currency_type_value` int(11) NOT NULL,
  `min_amount_num` decimal(40,20) NOT NULL,
  `max_amount_num` decimal(40,20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_config_currency_type
-- ----------------------------
DROP TABLE IF EXISTS `maneki_config_currency_type`;
CREATE TABLE `maneki_config_currency_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `currency_type_value` int(11) NOT NULL,
  `currency_type_name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency_type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_config_market_trade_fee_rate
-- ----------------------------
DROP TABLE IF EXISTS `maneki_config_market_trade_fee_rate`;
CREATE TABLE `maneki_config_market_trade_fee_rate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `level` int(11) NOT NULL,
  `fee_type` int(11) NOT NULL,
  `fee_rate` decimal(40,20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_tx_crypto_currency_deposit_address
-- ----------------------------
DROP TABLE IF EXISTS `maneki_tx_crypto_currency_deposit_address`;
CREATE TABLE `maneki_tx_crypto_currency_deposit_address` (
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coin_type` int(11) NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `address` (`address`),
  KEY `maneki_tx_crypto_currency_deposit_address_user_id_7aeb87cb` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_tx_crypto_currency_deposit_address_history
-- ----------------------------
DROP TABLE IF EXISTS `maneki_tx_crypto_currency_deposit_address_history`;
CREATE TABLE `maneki_tx_crypto_currency_deposit_address_history` (
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coin_type` int(11) NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `version` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `address` (`address`),
  KEY `maneki_tx_crypto_currency_d_user_id_7d0b8def` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_tx_crypto_currency_deposit_address_pool
-- ----------------------------
DROP TABLE IF EXISTS `maneki_tx_crypto_currency_deposit_address_pool`;
CREATE TABLE `maneki_tx_crypto_currency_deposit_address_pool` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coin_series` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `address_region` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `address` (`address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_tx_crypto_currency_withdraw_address
-- ----------------------------
DROP TABLE IF EXISTS `maneki_tx_crypto_currency_withdraw_address`;
CREATE TABLE `maneki_tx_crypto_currency_withdraw_address` (
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coin_type` int(11) NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `maneki_tx_crypto_currency_withdraw_address_user_id_a404fc5d` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_tx_record_blockchain
-- ----------------------------
DROP TABLE IF EXISTS `maneki_tx_record_blockchain`;
CREATE TABLE `maneki_tx_record_blockchain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `tx_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `block_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coin_type` int(11) NOT NULL,
  `miner_fee` decimal(40,20) NOT NULL,
  `confirmations` smallint(5) unsigned NOT NULL,
  `status` int(11) NOT NULL,
  `tx_type` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tx_id` (`tx_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_tx_record_crypto_deposit
-- ----------------------------
DROP TABLE IF EXISTS `maneki_tx_record_crypto_deposit`;
CREATE TABLE `maneki_tx_record_crypto_deposit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coin_type` int(11) NOT NULL,
  `tx_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tx_address` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tx_amount` decimal(40,20) NOT NULL,
  `tx_fee` decimal(40,20) NOT NULL,
  `confirmations` smallint(5) unsigned NOT NULL,
  `engine_sn` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_request_no` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_code` int(11) NOT NULL,
  `tx_sub_id` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `engine_sn` (`engine_sn`),
  KEY `maneki_tx_record_crypto_deposit_user_id_c83e7eb5` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_tx_record_crypto_deposit_last_3months
-- ----------------------------
DROP TABLE IF EXISTS `maneki_tx_record_crypto_deposit_last_3months`;
CREATE TABLE `maneki_tx_record_crypto_deposit_last_3months` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coin_type` int(11) NOT NULL,
  `tx_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tx_address` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tx_amount` decimal(40,20) NOT NULL,
  `tx_fee` decimal(40,20) NOT NULL,
  `confirmations` smallint(5) unsigned NOT NULL,
  `engine_sn` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_request_no` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_code` int(11) NOT NULL,
  `tx_sub_id` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `engine_sn` (`engine_sn`),
  KEY `maneki_tx_record_crypto_deposit_last_3months_user_id_ed3bf656` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_tx_record_crypto_withdraw
-- ----------------------------
DROP TABLE IF EXISTS `maneki_tx_record_crypto_withdraw`;
CREATE TABLE `maneki_tx_record_crypto_withdraw` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coin_type` int(11) NOT NULL,
  `tx_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tx_address` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tx_amount` decimal(40,20) NOT NULL,
  `tx_fee` decimal(40,20) NOT NULL,
  `confirmations` smallint(5) unsigned NOT NULL,
  `engine_sn` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_request_no` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_code` int(11) NOT NULL,
  `tx_sub_id` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `engine_sn` (`engine_sn`),
  KEY `maneki_tx_record_crypto_withdraw_user_id_a38efa02` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_tx_record_crypto_withdraw_last_3months
-- ----------------------------
DROP TABLE IF EXISTS `maneki_tx_record_crypto_withdraw_last_3months`;
CREATE TABLE `maneki_tx_record_crypto_withdraw_last_3months` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coin_type` int(11) NOT NULL,
  `tx_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tx_address` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tx_amount` decimal(40,20) NOT NULL,
  `tx_fee` decimal(40,20) NOT NULL,
  `confirmations` smallint(5) unsigned NOT NULL,
  `engine_sn` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_request_no` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_code` int(11) NOT NULL,
  `tx_sub_id` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `to_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `verify_detail` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `engine_sn` (`engine_sn`),
  KEY `maneki_tx_record_crypto_withdraw_last_3months_user_id_49133c25` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_tx_record_fiat_deposit
-- ----------------------------
DROP TABLE IF EXISTS `maneki_tx_record_fiat_deposit`;
CREATE TABLE `maneki_tx_record_fiat_deposit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fiat_type` int(11) NOT NULL,
  `amount` decimal(40,20) NOT NULL,
  `bank_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_account` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_sn` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_request_no` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_response_code` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `remitter` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_sn` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `collection_date` datetime(6) NOT NULL,
  `deposit_code` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `engine_sn` (`engine_sn`),
  KEY `maneki_tx_record_fiat_deposit_user_id_1a862417` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_tx_record_fiat_deposit_last_3months
-- ----------------------------
DROP TABLE IF EXISTS `maneki_tx_record_fiat_deposit_last_3months`;
CREATE TABLE `maneki_tx_record_fiat_deposit_last_3months` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fiat_type` int(11) NOT NULL,
  `amount` decimal(40,20) NOT NULL,
  `bank_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_account` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_sn` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_request_no` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_response_code` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `remitter` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_sn` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `collection_date` datetime(6) NOT NULL,
  `deposit_code` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `engine_sn` (`engine_sn`),
  KEY `maneki_tx_record_fiat_deposit_last_3months_user_id_01cc865c` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_tx_record_fiat_withdraw
-- ----------------------------
DROP TABLE IF EXISTS `maneki_tx_record_fiat_withdraw`;
CREATE TABLE `maneki_tx_record_fiat_withdraw` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fiat_type` int(11) NOT NULL,
  `amount` decimal(40,20) NOT NULL,
  `bank_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_account` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_sn` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_request_no` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_response_code` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `verify_detail` int(11) NOT NULL,
  `out_money_bank_sn` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `beneficiary_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `service_charge` decimal(40,20) NOT NULL,
  `extra_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `engine_sn` (`engine_sn`),
  KEY `maneki_tx_record_fiat_withdraw_user_id_b7e125a8` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_tx_record_fiat_withdraw_last_3months
-- ----------------------------
DROP TABLE IF EXISTS `maneki_tx_record_fiat_withdraw_last_3months`;
CREATE TABLE `maneki_tx_record_fiat_withdraw_last_3months` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fiat_type` int(11) NOT NULL,
  `amount` decimal(40,20) NOT NULL,
  `bank_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_account` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_sn` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_request_no` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `engine_response_code` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `verify_detail` int(11) NOT NULL,
  `out_money_bank_sn` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `beneficiary_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `service_charge` decimal(40,20) NOT NULL,
  `extra_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `engine_sn` (`engine_sn`),
  KEY `maneki_tx_record_fiat_withdraw_last_3months_user_id_1b279dae` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_tx_verification
-- ----------------------------
DROP TABLE IF EXISTS `maneki_tx_verification`;
CREATE TABLE `maneki_tx_verification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `record_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `verify_stage` int(11) NOT NULL,
  `verify_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `maneki_tx_verification_user_id_313d58b4` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ----------------------------
-- Table structure for maneki_user_2fa_totp
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_2fa_totp`;
CREATE TABLE `maneki_user_2fa_totp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `step` smallint(5) unsigned NOT NULL,
  `t0` bigint(20) NOT NULL,
  `digits` smallint(5) unsigned NOT NULL,
  `tolerance` smallint(5) unsigned NOT NULL,
  `drift` smallint(6) NOT NULL,
  `last_t` bigint(20) NOT NULL,
  `status` int(11) NOT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirmed` tinyint(1) NOT NULL,
  `extra_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_api_key
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_api_key`;
CREATE TABLE `maneki_user_api_key` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `public_key_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `public_key` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret_key` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `permission` int(11) NOT NULL,
  `version` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `public_key_hash` (`public_key_hash`),
  UNIQUE KEY `public_key` (`public_key`),
  UNIQUE KEY `secret_key` (`secret_key`),
  KEY `maneki_user_api_key_user_id_5a34ce5a` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_api_key_internal
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_api_key_internal`;
CREATE TABLE `maneki_user_api_key_internal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `internal_key` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `internal_key` (`internal_key`),
  KEY `maneki_user_api_key_internal_user_id_26826099` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_assets_crypto
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_assets_crypto`;
CREATE TABLE `maneki_user_assets_crypto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coin_type` int(11) NOT NULL,
  `balance` decimal(40,20) NOT NULL,
  `frozen_balance` decimal(40,20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `maneki_user_assets_crypto_user_id_b1573ee6` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_assets_fiat_balance
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_assets_fiat_balance`;
CREATE TABLE `maneki_user_assets_fiat_balance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fiat_type` int(11) NOT NULL,
  `balance` decimal(40,20) NOT NULL,
  `frozen_balance` decimal(40,20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `maneki_user_assets_fiat_balance_user_id_cd07caa4` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_assets_fiat_bank_account
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_assets_fiat_bank_account`;
CREATE TABLE `maneki_user_assets_fiat_bank_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fiat_type` int(11) NOT NULL,
  `account_type` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `bank_swift_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `beneficiary_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_account` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `beneficiary_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `via_bank_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `via_bank_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `via_bank_swift_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `maneki_user_assets_fiat_bank_account_user_id_9521f950` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_distributor
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_distributor`;
CREATE TABLE `maneki_user_distributor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` smallint(6) NOT NULL,
  `inviter_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invitee_list` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invite_code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invite_code` (`invite_code`),
  KEY `maneki_user_distributor_user_id_c28f94e1` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_groups
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_groups`;
CREATE TABLE `maneki_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `maneki_user_groups_user_id_group_id_55c3f879_uniq` (`user_id`,`group_id`),
  KEY `maneki_user_groups_group_id_17bc5d19_fk_auth_group_id` (`group_id`),
  CONSTRAINT `maneki_user_groups_group_id_17bc5d19_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `maneki_user_groups_user_id_37d7e2a6_fk_maneki_user_id` FOREIGN KEY (`user_id`) REFERENCES `maneki_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_history_login
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_history_login`;
CREATE TABLE `maneki_user_history_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` char(39) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `maneki_user_history_login_user_id_eaf9c856` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_history_security_change
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_history_security_change`;
CREATE TABLE `maneki_user_history_security_change` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` int(11) NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `maneki_user_history_security_change_user_id_0f6e5936` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_kyc_comment
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_kyc_comment`;
CREATE TABLE `maneki_user_kyc_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `key` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_kyc_enterprise
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_kyc_enterprise`;
CREATE TABLE `maneki_user_kyc_enterprise` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `register_num` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_num` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `local_country` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `local_city` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `local_region` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `local_address` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `local_postcode` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_sign` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_num` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `set_up_date` date NOT NULL,
  `register_country` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_license` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `org_cert` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auth_cert` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `license_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middle_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `license_number` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `license_pic01` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `license_pic02` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `license_pic03` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `current_level` int(11) NOT NULL,
  `current_step` int(11) NOT NULL,
  `current_level_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `change_list` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `industry` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reject_reason` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_kyc_individual
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_kyc_individual`;
CREATE TABLE `maneki_user_kyc_individual` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `license_country` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `license_type1` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middle_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `industry` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_sign2` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_sign3` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `license_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `license_number` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `license_pic01` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `license_pic02` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `license_pic03` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_cert` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `local_country` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `local_city` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `local_region` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `local_address` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `local_postcode` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `current_level` int(11) NOT NULL,
  `current_level_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `change_list` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `application_status` int(11) NOT NULL,
  `extra_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reject_reason` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_kyc_log
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_kyc_log`;
CREATE TABLE `maneki_user_kyc_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `client_id` char(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `csr_id` char(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `application_status` int(11) NOT NULL,
  `key` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_members_points
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_members_points`;
CREATE TABLE `maneki_user_members_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `member_points` int(11) NOT NULL,
  `member_levels` int(11) NOT NULL,
  `extra_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `maneki_user_members_points_user_id_93433a36` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_members_points_logs
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_members_points_logs`;
CREATE TABLE `maneki_user_members_points_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` int(10) unsigned NOT NULL,
  `points_source` int(10) unsigned NOT NULL,
  `remark` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `maneki_user_members_points_logs_user_id_82675c5f` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_profile
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_profile`;
CREATE TABLE `maneki_user_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nickname` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `level` int(11) NOT NULL,
  `labels` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deposit_code` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trade_discount` double NOT NULL,
  `withdraw_discount` double NOT NULL,
  `is_double_check` tinyint(1) NOT NULL,
  `kyc_type` tinyint(1) NOT NULL,
  `extra_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `deposit_code` (`deposit_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_register_code
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_register_code`;
CREATE TABLE `maneki_user_register_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `user_id` char(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `publisher` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_role_group_permission
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_role_group_permission`;
CREATE TABLE `maneki_user_role_group_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `permission_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_role_permission
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_role_permission`;
CREATE TABLE `maneki_user_role_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `route_path` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permission_name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permission_code` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_role_role_group
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_role_role_group`;
CREATE TABLE `maneki_user_role_role_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `group_code` int(11) NOT NULL,
  `group_desc_cn` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_desc_en` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_code` (`group_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_role_role_permission
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_role_role_permission`;
CREATE TABLE `maneki_user_role_role_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `permission_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_role_role_type
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_role_role_type`;
CREATE TABLE `maneki_user_role_role_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime(6) DEFAULT NULL,
  `role_code` int(11) NOT NULL,
  `role_desc_cn` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_desc_en` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_code` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_code` (`role_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for maneki_user_user_permissions
-- ----------------------------
DROP TABLE IF EXISTS `maneki_user_user_permissions`;
CREATE TABLE `maneki_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `maneki_user_user_permissions_user_id_permission_id_ca683014_uniq` (`user_id`,`permission_id`),
  KEY `maneki_user_user_per_permission_id_37af47dc_fk_auth_perm` (`permission_id`),
  CONSTRAINT `maneki_user_user_per_permission_id_37af47dc_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `maneki_user_user_permissions_user_id_80a7190b_fk_maneki_user_id` FOREIGN KEY (`user_id`) REFERENCES `maneki_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
