
# ./schemalex -version

# diff to a file:
./schemalex -o=db_result.sql  db_old.sql db_new.sql







