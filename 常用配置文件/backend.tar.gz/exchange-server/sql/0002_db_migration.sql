
-- 65532
SELECT count(1) from maneki_user;
-- 65532
SELECT count(1) from maneki_user_profile;
-- 65532
SELECT count(1) from maneki_user_members_points;
-- 8019
SELECT count(1) from maneki_user_kyc_individual;
-- 7049
SELECT count(1) from maneki_user_2fa_totp;

SELECT count(1) from maneki_user_assets_fiat_bank_account;

