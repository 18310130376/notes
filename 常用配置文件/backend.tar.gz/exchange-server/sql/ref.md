


## ref:

- https://github.com/hhstore/blog/issues/43


## tools:

- https://github.com/schemalex/schemalex/releases
- 下载, 命令行工具.
- 有bug, 部分sql 语法不支持.

## IDE diff db:

- diff 可以自动生成 migration script.


## migrations:

- user 表 依赖 django.auth.model 表
- 先 migrate user 部分, django 框架缺陷, 必须先初始化 user model.




## db migration:



```

# load data:
mysql -h hostname -u user database < path/to/test.sql


# ipython:

python manage.py shell_plus

# ipython cli:

from django.db import connection

c = connection.cursor()


sql = "CREATE DATABASE /*!32312 IF NOT EXISTS*/ `maneki_prod` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;"


c.execute(sql)


#
mycli -h prd-backend-cluster.cluster-cs8toxpyqcko.ap-northeast-1.rds.amazonaws.com -u Backend_superdb


use maneki_prod;


mysql Backend_superdb@prd-backend-cluster.cluster-cs8toxpyqcko.ap-northeast-1.rds.amazonaws.com:maneki_prod> SELECT count(1) from maneki_user;
+------------+
|   count(1) |
|------------|
|      65765 |
+------------+
1 row in set
Time: 0.016s



# f2: auto completed!


quit


```


