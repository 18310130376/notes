# 交易所项目结构

```
exchange-server
├── CONTRIBUTORS.txt
├── LICENSE
├── Makefile
├── README.md
├── compose
│   └── production
│       ├── caddy
│       │   ├── Caddyfile.admin.conf
│       │   ├── Caddyfile.api.conf
│       │   ├── Caddyfile1
│       │   ├── Dockerfile
│       │   └── Dockerfile.admin
│       ├── django
│       │   ├── Dockerfile
│       │   ├── entrypoint2.sh
│       │   └── gunicorn.sh
│       ├── postgres
│       │   ├── Dockerfile
│       │   ├── backup.sh
│       │   ├── list-backups.sh
│       │   └── restore.sh
├── compose-local.yml
├── compose-prod-api-00-proxy-lb.yml
├── compose-prod-api-01-auth.yml
├── compose-prod-api-02-tx.yml
├── compose-prod-api-03-settings.yml
├── compose-prod-api-04-etc.yml
├── compose-prod-api-admin.yml
├── compose-prod-base.yml
├── compose-prod-worker-01-beat.yml
├── compose-prod-worker-02-task.yml
├── compose-prod-worker-03-mq-engine.yml
├── compose-prod-worker-04-mq-tx.yml
├── compose-prod-worker-05-mq-etc.yml
├── compose-prod-worker-06-mq-engine-proxy.yml
├── config
│   ├── routers
│   │   ├── v1
│   │   │   ├── admin.py
│   │   │   ├── assets.py
│   │   │   ├── auth.py
│   │   │   ├── engines.py
│   │   │   ├── marketing.py
│   │   │   ├── settings.py
│   │   │   └── transactions.py
│   │   └── v2
│   │       ├── mutation.py
│   │       └── query.py
│   ├── settings
│   │   ├── base
│   │   │   ├── basic.py
│   │   │   ├── core.py
│   │   │   ├── core_apps.py
│   │   │   ├── core_rest.py
│   │   │   └── custom.py
│   │   ├── env.py
│   │   ├── local.py
│   │   ├── production.py
│   │   └── test.py
│   ├── urls.py
│   └── wsgi.py
├── debug.log
├── deploy
│   ├── compose
│   │   └── production
│   │       ├── caddy
│   │       │   ├── Caddyfile.admin.conf
│   │       │   ├── Caddyfile.api.conf
│   │       │   ├── Caddyfile1
│   │       │   ├── Dockerfile
│   │       │   └── Dockerfile.admin
│   │       ├── django
│   │       │   ├── Dockerfile
│   │       │   ├── entrypoint2.sh
│   │       │   └── gunicorn.sh
│   │       ├── postgres
│   │       │   ├── Dockerfile
│   │       │   ├── backup.sh
│   │       │   ├── list-backups.sh
│   │       │   └── restore.sh
│   ├── compose-local.yml
│   ├── compose-prod-api-admin.yml
│   ├── compose-prod-api.yml
│   ├── compose-prod-base.yml
│   ├── compose-prod-worker.yml
│   └── kubernetes
├── docs
│   ├── Makefile
│   ├── conf.py
│   ├── deploy.rst
│   ├── docker_ec2.rst
│   ├── index.rst
│   ├── install.rst
│   ├── make.bat
│   ├── pycharm
│   └── sdk
│       ├── __init__.py
│       ├── requirements.txt
│       ├── sdk.py
│       └── sdk_usage.py
├── engine_proxy
│   ├── celery_app.py
│   ├── config.py
│   ├── constants.py
│   ├── merge_env.py
│   ├── models
│   │   ├── engine_model.py
│   │   └── maneki_model.py
│   ├── rpc
│   │   ├── client
│   │   │   └── external
│   │   │       └── engine_proxy_client.py
│   │   └── external_engine
│   │       ├── config.py
│   │       ├── db_services
│   │       │   └── engine_proxy.py
│   │       ├── rpc_services
│   │       │   ├── build.sh
│   │       │   ├── engine_proxy_message.proto
│   │       │   ├── engine_proxy_service.proto
│   │       │   ├── gen_py
│   │       │   │   ├── engine_proxy_message_pb2.py
│   │       │   │   ├── engine_proxy_message_pb2_grpc.py
│   │       │   │   ├── engine_proxy_service_pb2.py
│   │       │   │   └── engine_proxy_service_pb2_grpc.py
│   │       │   ├── service.py
│   │       │   └── t_engine_service.py
│   │       └── run.py
│   ├── schemas
│   │   └── engine_proxy_schemas.py
│   ├── tasks
│   │   ├── clear_daily_tx_fee.py
│   │   └── fetch_exchange_rate.py
│   ├── test
│   │   ├── __init__.py
│   │   ├── model_test.py
│   │   ├── t_client.py
│   │   └── test_sqlarchemy.py
│   └── utils
│       ├── dao.py
│       ├── date.py
│       ├── db.py
│       ├── format_data.py
│       ├── redis_client.py
│       └── wrapper.py
├── gulpfile.js
├── manage.py
├── maneki
│   ├── apps
│   │   ├── alarm
│   │   │   ├── admin.py
│   │   │   ├── apps.py
│   │   │   ├── migrations
│   │   │   ├── models.py
│   │   │   ├── services
│   │   │   │   ├── base.py
│   │   │   │   ├── crypto.py
│   │   │   │   ├── fiat.py
│   │   │   │   └── transaction.py
│   │   │   ├── tasks
│   │   │   │   ├── dingnotify.py
│   │   │   │   └── transaction.py
│   │   │   ├── tests
│   │   │   │   ├── __init__.py
│   │   │   │   ├── test_bot.py
│   │   │   │   └── test_transaction.py
│   │   │   └── views.py
│   │   ├── api_key
│   │   │   ├── admin.py
│   │   │   ├── apps.py
│   │   │   ├── authentication.py
│   │   │   ├── constants.py
│   │   │   ├── migrations
│   │   │   ├── models
│   │   │   │   └── api_key.py
│   │   │   ├── services
│   │   │   │   └── api_key.py
│   │   │   ├── tests
│   │   │   │   ├── __init__.py
│   │   │   │   └── test_views.py
│   │   │   ├── utils
│   │   │   │   └── __init__.py
│   │   │   └── views
│   │   │       ├── api_key.py
│   │   │       ├── filters.py
│   │   │       ├── old_leaf.py
│   │   │       └── serializers.py
│   │   ├── assets
│   │   │   ├── admin.py
│   │   │   ├── apps.py
│   │   │   ├── exceptions.py
│   │   │   ├── migrations
│   │   │   ├── models
│   │   │   │   ├── crypto_assets.py
│   │   │   │   ├── fiat_accounts.py
│   │   │   │   ├── fiat_assets.py
│   │   │   │   └── fiat_banks.py
│   │   │   ├── serializers.py
│   │   │   ├── services
│   │   │   │   ├── engine_proxy_service.py
│   │   │   │   ├── save_ex_rate.py
│   │   │   │   └── user_fiat_account.py
│   │   │   ├── tasks
│   │   │   │   ├── exchange_rate
│   │   │   │   └── exchange_rate.py
│   │   │   ├── tests
│   │   │   │   ├── __init__.py
│   │   │   │   └── test_user_fiat_account.py
│   │   │   ├── tests.py
│   │   │   ├── utils.py
│   │   │   ├── views
│   │   │   │   ├── exchange_rate.py
│   │   │   │   ├── filters
│   │   │   │   │   ├── user_crypt_account.py
│   │   │   │   │   └── user_fiat_account.py
│   │   │   │   ├── serializers
│   │   │   │   │   └── user_fiat_account.py
│   │   │   │   ├── user_assets.py
│   │   │   │   ├── user_assets_admin.py
│   │   │   │   ├── user_fiat_account.py
│   │   │   │   └── user_trades_admin.py
│   │   │   └── views.py
│   │   ├── assets_transfer
│   │   │   ├── __init__.py
│   │   │   ├── admin.py
│   │   │   ├── apps.py
│   │   │   ├── migrations
│   │   │   │   └── __init__.py
│   │   │   ├── models.py
│   │   │   ├── tests.py
│   │   │   └── views.py
│   │   ├── audit
│   │   │   ├── admin.py
│   │   │   ├── apps.py
│   │   │   ├── migrations
│   │   │   ├── models
│   │   │   │   ├── clearing_crypto.py
│   │   │   │   ├── clearing_fiat.py
│   │   │   │   └── exception_record_update_log.py
│   │   │   ├── services
│   │   │   │   ├── __init__.py
│   │   │   │   ├── clearing_crypto.py
│   │   │   │   ├── clearing_fiat.py
│   │   │   │   ├── crypto_wallet.py
│   │   │   │   └── fiat_account.py
│   │   │   ├── tasks
│   │   │   │   ├── clearing_crypto.py
│   │   │   │   └── clearing_fiat.py
│   │   │   ├── tests
│   │   │   │   └── __init__.py
│   │   │   ├── utils
│   │   │   │   └── data.py
│   │   │   └── views
│   │   │       ├── crypto_exception_record.py
│   │   │       ├── crypto_wallet.py
│   │   │       ├── fiat_account.py
│   │   │       ├── fiat_exception_record.py
│   │   │       ├── filters
│   │   │       │   ├── crypto_deposit_exception_filter.py
│   │   │       │   ├── crypto_withdraw_exception_filter.py
│   │   │       │   ├── fiat_deposit_exception_filter.py
│   │   │       │   ├── fiat_withdraw_exception_filter.py
│   │   │       │   └── records_search_filter.py
│   │   │       ├── records_search_admin.py
│   │   │       ├── serializers
│   │   │       │   ├── crypto_deposit_exception_serializer.py
│   │   │       │   ├── crypto_withdraw_exception_serializer.py
│   │   │       │   ├── fiat_deposit_exception_serializer.py
│   │   │       │   └── fiat_withdraw_exception_serializer.py
│   │   │       └── throttles
│   │   │           └── audit.py
│   │   ├── common
│   │   │   ├── base
│   │   │   │   └── services.py
│   │   │   ├── libs
│   │   │   │   ├── fields.py
│   │   │   │   └── models.py
│   │   │   ├── middleware
│   │   │   │   ├── csrf.py
│   │   │   │   └── db_log.py
│   │   │   ├── mixins
│   │   │   │   └── rest
│   │   │   │       ├── exceptions.py
│   │   │   │       ├── mixins.py
│   │   │   │       └── viewsets.py
│   │   │   ├── permissions
│   │   │   │   └── rest
│   │   │   │       └── permission_manage.py
│   │   │   ├── tests
│   │   │   │   ├── __init__.py
│   │   │   │   ├── test.html
│   │   │   │   ├── test_compare_tool.py
│   │   │   │   ├── test_config_manager.py
│   │   │   │   ├── test_crypto.py
│   │   │   │   ├── test_db.py
│   │   │   │   ├── test_email.py
│   │   │   │   ├── test_get_user_info_cache.py
│   │   │   │   ├── test_mq.py
│   │   │   │   ├── test_redis.py
│   │   │   │   ├── test_sign.py
│   │   │   │   └── test_sms.py
│   │   │   └── utils
│   │   │       ├── cache.py
│   │   │       ├── compare.py
│   │   │       ├── config_manager.py
│   │   │       ├── crypto.py
│   │   │       ├── date.py
│   │   │       ├── db.py
│   │   │       ├── decimal.py
│   │   │       ├── decorator
│   │   │       │   ├── db.py
│   │   │       │   ├── decorators.py
│   │   │       │   └── testutil.py
│   │   │       ├── dict.py
│   │   │       ├── dingbot.py
│   │   │       ├── email
│   │   │       │   ├── mail_gun.py
│   │   │       │   ├── mailgun.py
│   │   │       │   ├── send_pool.py
│   │   │       │   ├── sendcloud.py
│   │   │       │   ├── smtp2go.py
│   │   │       │   ├── template.py
│   │   │       │   └── test_send_pool.py
│   │   │       ├── format_timestamp.py
│   │   │       ├── geetest
│   │   │       │   ├── geetest.py
│   │   │       │   └── test_api.py
│   │   │       ├── http
│   │   │       │   ├── request.py
│   │   │       │   └── status.py
│   │   │       ├── mq
│   │   │       │   └── pika.py
│   │   │       ├── necaptcha
│   │   │       │   └── necaptcha.py
│   │   │       ├── random.py
│   │   │       ├── redis
│   │   │       │   ├── r.py
│   │   │       │   ├── redis.py
│   │   │       │   ├── redis_key.py
│   │   │       │   └── test_reids.py
│   │   │       ├── sign.py
│   │   │       ├── slack.py
│   │   │       ├── sms
│   │   │       │   ├── aliyun.py
│   │   │       │   ├── netease.py
│   │   │       │   ├── nexmo_sms.py
│   │   │       │   ├── send_pool.py
│   │   │       │   ├── test_send_sms.py
│   │   │       │   └── twilio_client.py
│   │   │       ├── telegrambot.py
│   │   │       ├── test.py
│   │   │       ├── timestamp.py
│   │   │       ├── validate
│   │   │       │   ├── crypto_currency
│   │   │       │   │   ├── __init__.py
│   │   │       │   │   ├── btc.py
│   │   │       │   │   └── eth.py
│   │   │       │   └── params_validators.py
│   │   │       └── validates_common.py
│   │   ├── constants.py
│   │   ├── engine
│   │   │   ├── apps.py
│   │   │   ├── constants.py
│   │   │   ├── serializers.py
│   │   │   ├── services
│   │   │   │   ├── base.py
│   │   │   │   ├── engine.py
│   │   │   │   └── manager.py
│   │   │   ├── tests
│   │   │   │   ├── __init__.py
│   │   │   │   ├── test_engine.py
│   │   │   │   └── test_engine2.py
│   │   │   ├── utils.py
│   │   │   └── views
│   │   │       ├── __init__.py
│   │   │       ├── trade.py
│   │   │       └── tx.py
│   │   ├── error_code.py
│   │   ├── market
│   │   │   ├── __init__.py
│   │   │   ├── constants.py
│   │   │   ├── migrations
│   │   │   ├── services
│   │   │   │   ├── __init__.py
│   │   │   │   ├── server.py
│   │   │   │   └── wsservice
│   │   │   │       ├── __init__.py
│   │   │   │       ├── handler
│   │   │   │       │   ├── __init__.py
│   │   │   │       │   └── transport.py
│   │   │   │       ├── server.py
│   │   │   │       └── utils
│   │   │   │           └── __init__.py
│   │   │   ├── tests
│   │   │   │   ├── __init__.py
│   │   │   │   └── tests.py
│   │   │   └── utils
│   │   │       ├── __init__.py
│   │   │       └── utils.py
│   │   ├── market_agents
│   │   │   ├── admin.py
│   │   │   ├── apps.py
│   │   │   ├── migrations
│   │   │   ├── models
│   │   │   │   ├── daily_count.py
│   │   │   │   └── rebate_rates.py
│   │   │   ├── services
│   │   │   │   ├── daily_count.py
│   │   │   │   └── rebate_rates.py
│   │   │   ├── tasks
│   │   │   │   └── user_points_rebate.py
│   │   │   ├── tests
│   │   │   │   └── __init__.py
│   │   │   └── views
│   │   │       ├── rebate_rates.py
│   │   │       └── serializers
│   │   │           └── rebate_rates.py
│   │   ├── monitor
│   │   │   ├── __init__.py
│   │   │   ├── services.py
│   │   │   └── tasks.py
│   │   ├── transaction
│   │   │   ├── admin.py
│   │   │   ├── apps.py
│   │   │   ├── migrations
│   │   │   ├── models
│   │   │   │   ├── crypto_currency.py
│   │   │   │   ├── crypto_currency_address.py
│   │   │   │   ├── fiat_currency.py
│   │   │   │   └── verification.py
│   │   │   ├── services
│   │   │   │   ├── crypto
│   │   │   │   │   ├── deposit.py
│   │   │   │   │   ├── deposit_address.py
│   │   │   │   │   ├── deposit_address_worker.py
│   │   │   │   │   ├── deposit_block_analyzer.py
│   │   │   │   │   ├── deposit_engine_handler.py
│   │   │   │   │   ├── deposit_manager.py
│   │   │   │   │   ├── tx.py
│   │   │   │   │   ├── withdraw.py
│   │   │   │   │   ├── withdraw_address.py
│   │   │   │   │   └── withdraw_worker.py
│   │   │   │   └── fiat
│   │   │   │       ├── deposit.py
│   │   │   │       ├── deposit_manager.py
│   │   │   │       ├── deposit_worker.py
│   │   │   │       ├── withdraw.py
│   │   │   │       ├── withdraw_manager.py
│   │   │   │       └── withdraw_worker.py
│   │   │   ├── tasks
│   │   │   │   ├── clear_expired_data.py
│   │   │   │   ├── close_timeout.py
│   │   │   │   └── get_simplex_result.py
│   │   │   ├── tests
│   │   │   │   ├── __init__.py
│   │   │   │   ├── api_test
│   │   │   │   │   ├── __init__.py
│   │   │   │   │   ├── test_address.py
│   │   │   │   │   ├── test_crypto_deposit.py
│   │   │   │   │   ├── test_crypto_withdraw.py
│   │   │   │   │   ├── test_fiat_deposit.py
│   │   │   │   │   └── test_fiat_withdraw.py
│   │   │   │   ├── crypto_deposit
│   │   │   │   │   ├── __init__.py
│   │   │   │   │   └── test_deposit.py
│   │   │   │   ├── crypto_withdraw.py
│   │   │   │   ├── fiat_withdraw
│   │   │   │   │   ├── __init__.py
│   │   │   │   │   └── test_fiat_withdraw.py
│   │   │   │   ├── test_deposit_address_pool_consumer.py
│   │   │   │   ├── test_deposit_adress.py
│   │   │   │   ├── test_withdraw_address_validate.py
│   │   │   │   └── tests.py
│   │   │   ├── utils
│   │   │   │   ├── date.py
│   │   │   │   ├── exceptions.py
│   │   │   │   ├── mixin.py
│   │   │   │   ├── validate.py
│   │   │   │   └── verify_code.py
│   │   │   └── views
│   │   │       ├── bot.py
│   │   │       ├── crypto_deposit.py
│   │   │       ├── crypto_deposit_address.py
│   │   │       ├── crypto_withdraw.py
│   │   │       ├── crypto_withdraw_address.py
│   │   │       ├── crypto_withdraw_admin.py
│   │   │       ├── exchange.py
│   │   │       ├── fiat_deposit.py
│   │   │       ├── fiat_deposit_admin.py
│   │   │       ├── fiat_withdraw.py
│   │   │       ├── fiat_withdraw_admin.py
│   │   │       ├── filters
│   │   │       │   ├── crypto_address.py
│   │   │       │   ├── crypto_deposit.py
│   │   │       │   ├── crypto_withdraw.py
│   │   │       │   ├── fiat_deposit.py
│   │   │       │   └── fiat_withdraw.py
│   │   │       ├── serializers
│   │   │       │   ├── fiat_withdraw.py
│   │   │       │   ├── tx.py
│   │   │       │   ├── tx_address.py
│   │   │       │   └── withdraw.py
│   │   │       └── throttles
│   │   │           └── tx.py
│   │   ├── user
│   │   │   ├── adapters.py
│   │   │   ├── admin.py
│   │   │   ├── apps.py
│   │   │   ├── migrations
│   │   │   ├── models
│   │   │   │   ├── otp.py
│   │   │   │   ├── user.py
│   │   │   │   ├── user_history.py
│   │   │   │   └── user_profile.py
│   │   │   ├── schemas
│   │   │   │   ├── user.py
│   │   │   │   └── user_profile.py
│   │   │   ├── services
│   │   │   │   ├── account_sync.py
│   │   │   │   ├── otp.py
│   │   │   │   ├── user.py
│   │   │   │   └── user_profile.py
│   │   │   ├── tasks
│   │   │   │   └── user_info_cache.py
│   │   │   ├── tests
│   │   │   │   ├── __init__.py
│   │   │   │   ├── factories.py
│   │   │   │   ├── test_2fa.py
│   │   │   │   ├── test_admin.py
│   │   │   │   ├── test_models.py
│   │   │   │   ├── test_mq.py
│   │   │   │   ├── test_urls.py
│   │   │   │   ├── test_utils.py
│   │   │   │   └── test_views.py
│   │   │   ├── urls.py
│   │   │   ├── utils
│   │   │   │   ├── black_list.py
│   │   │   │   ├── check_field.py
│   │   │   │   ├── filters.py
│   │   │   │   ├── mobile.py
│   │   │   │   └── user.py
│   │   │   └── views
│   │   │       │   └── user_filter.py
│   │   │       ├── search_user.py
│   │   │       ├── serializers
│   │   │       │   └── user_profile.py
│   │   │       ├── user.py
│   │   │       └── user_profile.py
│   │   ├── user_auth
│   │   │   ├── admin.py
│   │   │   ├── apps.py
│   │   │   ├── migrations
│   │   │   ├── models
│   │   │   │   └── register_code.py
│   │   │   ├── services
│   │   │   │   ├── auth.py
│   │   │   │   └── register_code.py
│   │   │   ├── tests
│   │   │   │   ├── __init__.py
│   │   │   │   ├── test_auth_access.py
│   │   │   │   └── test_deivce_info.py
│   │   │   ├── utils
│   │   │   │   ├── auth_access.py
│   │   │   │   ├── authtoken.py
│   │   │   │   └── decode_device_str.py
│   │   │   └── views
│   │   │       ├── anti_robot.py
│   │   │       ├── change.py
│   │   │       ├── exceptions
│   │   │       │   ├── __init__.py
│   │   │       │   └── auth.py
│   │   │       ├── filters
│   │   │       │   └── auth.py
│   │   │       ├── login.py
│   │   │       ├── login_with_geetest.py
│   │   │       ├── logout.py
│   │   │       ├── mixins
│   │   │       │   └── auth.py
│   │   │       ├── otp.py
│   │   │       ├── register.py
│   │   │       ├── serializers
│   │   │       │   ├── auth.py
│   │   │       │   ├── login.py
│   │   │       │   ├── register.py
│   │   │       │   ├── token.py
│   │   │       │   └── verify.py
│   │   │       ├── throttles
│   │   │       │   │   └── auth.cpython-36.pyc
│   │   │       │   └── auth.py
│   │   │       ├── token.py
│   │   │       └── verify.py
│   │   ├── user_kyc
│   │   │   ├── admin.py
│   │   │   ├── apps.py
│   │   │   ├── exceptions.py
│   │   │   ├── libs
│   │   │   │   ├── db
│   │   │   │   │   ├── choices.py
│   │   │   │   │   └── fields.py
│   │   │   │   ├── exceptions.py
│   │   │   │   └── s3_storage_backend.py
│   │   │   ├── migrations
│   │   │   ├── models
│   │   │   │   └── kyc.py
│   │   │   ├── service.py
│   │   │   ├── tests
│   │   │   │   ├── __init__.py
│   │   │   │   ├── test_enterprise.py
│   │   │   │   ├── test_individual.py
│   │   │   │   └── tests.py
│   │   │   ├── utils.py
│   │   │   └── views
│   │   │       ├── filters.py
│   │   │       ├── kyc.py
│   │   │       └── serializers
│   │   │           └── profile.py
│   │   ├── user_members
│   │   │   ├── admin.py
│   │   │   ├── apps.py
│   │   │   ├── migrations
│   │   │   ├── models
│   │   │   │   ├── distributor.py
│   │   │   │   └── members.py
│   │   │   ├── services
│   │   │   │   ├── distributor.py
│   │   │   │   ├── members.py
│   │   │   │   └── user_member_activate.py
│   │   │   ├── tests
│   │   │   │   ├── __init__.py
│   │   │   │   └── test_members.py
│   │   │   └── views
│   │   │       ├── activity.py
│   │   │       ├── distributor.py
│   │   │       ├── filters
│   │   │       │   └── distributor.py
│   │   │       ├── invitee_trade_rebate.py
│   │   │       ├── members.py
│   │   │       ├── serializers
│   │   │       │   ├── distributor.py
│   │   │       │   └── members.py
│   │   │       └── throttles
│   │   │           └── members.py
│   │   ├── user_role
│   │   │   ├── admin.py
│   │   │   ├── apps.py
│   │   │   ├── migrations
│   │   │   ├── models
│   │   │   │   ├── perms.py
│   │   │   │   └── role.py
│   │   │   ├── services
│   │   │   │   └── role.py
│   │   │   ├── tests
│   │   │   │   ├── __init__.py
│   │   │   │   └── test_cache_permission.py
│   │   │   ├── utils
│   │   │   │   └── cache.py
│   │   │   └── views
│   │   │       ├── filters
│   │   │       │   └── role_permission.py
│   │   │       ├── permission_management.py
│   │   │       ├── role_management.py
│   │   │       └── serializers
│   │   │           ├── permission.py
│   │   │           └── role.py
│   │   ├── user_security
│   │   │   ├── __init__.py
│   │   │   ├── admin.py
│   │   │   ├── apps.py
│   │   │   ├── migrations
│   │   │   ├── models
│   │   │   ├── services
│   │   │   ├── tests
│   │   │   └── views.py
│   │   └── user_settings
│   │       ├── admin.py
│   │       ├── apps.py
│   │       ├── migrations
│   │       ├── models
│   │       │   ├── crypto_confirm_limit.py
│   │       │   ├── currency_type.py
│   │       │   ├── trade_fee.py
│   │       │   └── withdraw_limit.py
│   │       ├── models.py
│   │       ├── services
│   │       │   └── settings_manager.py
│   │       ├── tasks
│   │       │   └── announcement.py
│   │       ├── tests
│   │       │   └── __init__.py
│   │       └── views
│   │           ├── filters
│   │           │   └── mobile.py
│   │           ├── mobile.py
│   │           ├── serializers
│   │           │   ├── mobile.py
│   │           │   ├── settings_manager.py
│   │           │   └── user_profile.py
│   │           ├── settings_manager.py
│   │           ├── throttles
│   │           │   └── user_settings.py
│   │           ├── user_announcement.py
│   │           └── user_profile.py
│   ├── contrib
│   │   └── sites
│   ├── locale
│   │   ├── japan
│   │   └── korea
│   ├── scripts
│   │   ├── add_user_member_points.py
│   │   ├── crypto_deposit_address_loader.py
│   │   ├── crypto_deposit_blockchain_proxy_task.py
│   │   ├── crypto_deposit_engine_task.py
│   │   ├── crypto_withdraw_blockchain_proxy_task.py
│   │   ├── crypto_withdraw_engine_task.py
│   │   ├── fiat_deposit_engine_task.py
│   │   ├── fiat_withdraw_engine_task.py
│   │   ├── fix
│   │   │   ├── __init__.py
│   │   │   ├── enginelost.json
│   │   │   ├── fix_engine_user_create.py
│   │   │   └── fix_user_status_modify.py
│   │   ├── init
│   │   │   ├── resources
│   │   │   │   ├── __init__.py
│   │   │   │   ├── default_groups.py
│   │   │   │   ├── default_role_type.py
│   │   │   │   └── init_role_permission.py
│   │   │   ├── superuser.py
│   │   │   ├── tx_config.py
│   │   │   ├── user_permission.py
│   │   │   ├── user_role.py
│   │   │   └── user_role_permisssions.py
│   │   ├── migrations
│   │   │   ├── __init__.py
│   │   │   ├── user_image.py
│   │   │   ├── user_kyc.py
│   │   │   ├── user_profile.py
│   │   │   └── user_settings.py
│   │   ├── retry_crypto_deposit.py
│   │   ├── sync_engine_account.py
│   │   └── sync_user_member_infos.py
│   ├── static
│   │   ├── css
│   │   │   └── project.css
│   │   ├── fonts
│   │   ├── geetest_demo.html
│   │   ├── images
│   │   │   └── favicon.ico
│   │   ├── js
│   │   │   └── project.js
│   │   └── sass
│   │       ├── custom_bootstrap_vars.scss
│   │       └── project.scss
│   ├── taskapp
│   │   ├── apps.py
│   │   ├── celery.py
│   │   └── messagequeue
│   │       ├── base.py
│   │       ├── exceptions.py
│   │       └── tasks.py
│   └── templates
│       ├── 403_csrf.html
│       ├── 404.html
│       ├── 500.html
│       ├── account
│       │   ├── account_inactive.html
│       │   ├── base.html
│       │   ├── email.html
│       │   ├── email_confirm.html
│       │   ├── login.html
│       │   ├── logout.html
│       │   ├── password_change.html
│       │   ├── password_reset.html
│       │   ├── password_reset_done.html
│       │   ├── password_reset_from_key.html
│       │   ├── password_reset_from_key_done.html
│       │   ├── password_set.html
│       │   ├── reg_confirm_email.html
│       │   ├── signup.html
│       │   ├── signup_closed.html
│       │   ├── verification_sent.html
│       │   └── verified_email_required.html
│       ├── base.html
│       ├── bootstrap4
│       │   ├── field.html
│       │   └── layout
│       │       └── field_errors_block.html
│       └── users
│           ├── user_detail.html
│           ├── user_form.html
│           └── user_list.html
├── maneki-neko.png
├── package.json
├── pytest.ini
├── reference.md
├── requirements
│   ├── base.txt
│   ├── local.txt
│   ├── production.txt
│   └── test.txt
├── requirements.txt
├── setup.cfg
├── sql
│   ├── 0000_db_create.sql
│   ├── 0001_db_init_structure.sql
│   ├── 0002_db_migration.sql
│   ├── 0003_db_change.sql
│   ├── diff_tmp
│   │   ├── auto_diff.sh
│   │   ├── db_new.sql
│   │   ├── db_old.sql
│   │   └── db_result.sql
│   ├── prod
│   │   ├── modify_2018_08_16.sql
│   │   ├── modify_2018_08_20.sql
│   │   ├── modify_2018_7_27.sql
│   │   ├── modify_2018_8_1.sql
│   │   ├── modify_2018_8_21.sql
│   │   └── prod_maneki_2018_05_25.sql
│   └── ref.md
└── utility
    ├── install_os_dependencies.sh
    ├── install_python_dependencies.sh
    ├── requirements-jessie.apt
    ├── requirements-trusty.apt
    └── requirements-xenial.apt

366 directories, 1259 files

```

# 环境搭建
## 1.Python环境
```
# python3.6 + django==1.11.10
```
## 2.安装依赖

```
# 建议Python虚拟环境中安装
pip install -r requirements/production.txt
pip install -r requirements/local.txt
```
注意：mysqlclient安装，参考：https://pypi.org/project/mysqlclient/

#项目docker部署

```bash
# 本地环境:先stop再build最后start

# build
make local.build
# or
docker-compose -f compose-local.yml build

# stop
make local.down
# or
docker-compose -f compose-local.yml down --remove-orphans

# start
make local.up
# or
docker-compose -f compose-local.yml up -d
docker-compose -f compose-local.yml ps
docker-compose -f compose-local.yml logs --follow

# ps
docker-compose -f compose-local.yml ps

# log
make local.log
# or
docker-compose -f compose-local.yml logs --follow

```
_______________

```bash
# 生产环境
# admin：对应makefile中的docker-compose操作
make prod.admin CMD='down --remove-orphans'		# stop
make prod.admin CMD='build' 					# build
make prod.admin CMD='up -d'						# up

# api： 对应makefile中的docker-compose操作
make prod.api.all CMD="down --remove-orphans" 	# stop
make prod.api.all CMD='build' 					# build
make prod.api.all CMD='up -d'					# up

# beat,woker: 对应makefile中的docker-compose操作
make prod.worker.all CMD="down --remove-orphans"
make prod.worker.all CMD="build"
make prod.worker.all CMD="up -d"
# 注意所有机器上同一个beat只能起一个，否则定时任务会执行两次
```
***注意：上述所有命令均在makefile中或docker-cpmose.yml文件中均有说明***

# 项目调试工具

```bash
# 本运行api服务，需配置.env文件
python manage.py runserver_plus

# 数据迁移，需配置.env文件
python manage.py makemigrations
python manage.py migrate

# 本地运行celery,需指定Celery示例所在文件
celery beat -l info --app=maneki.taskapp
celery worker -l info --app=maneki.taskapp

# 运行指定celery分发Queue任务,Queue路由配置查看：maneki/taskapp/celery.py
celery worker -l info --app=maneki.taskapp -Q sms

# shell模式,shell会自动加载环境变量
python manage.py shell_plus
```

# 项目初始化

```bash
# 1.数据库初始化:
# sql初始化，exchange-server/sql文件夹下包含初始化sql文件
# 每次数据库结构变化，需要添加新的sql文件并标明改动日期，上线前执行
```

```bash
# 权限初始化
# 1.角色初始化：/maneki/scripts/init/user_role.py，容器中运行
python manage.py shell_plus
from maneki.scripts.init.user_role import init_role_type,init_groups
init_role_type()
init_groups()

# 2.用户权限初始化，shell环境下
from maneki.scripts.init.user_permission import load_permission_to_db
load_permission_to_db()

# 3.角色-权限初始化吗，shell环境下
from maneki.scripts.init.user_role_permissions import init_dw_role_permission
init_dw_role_permission()

```
***如果有新角色加入，需添加配置，并重新运行1，2，3步骤；如果有新的admin接口加入，添加配置，需重新运行2，3步骤，配置内容maneki/scripts/init/resources目录下***

# 线上错误手动处理
## 1.引擎账号创建问题：
```bash
# shell环境下单个创建
user = User.objects.filter(user_id='858e14c8e41c459f907708a59f08df00').first()
from maneki.apps.engine.services.engine import EngineService
service = EngineService()
service.create_account(email=user.email, user_id=user.user_id_hex, token=user.engine_token)

# shell环境下批量创建：
# 1.将导出的excel文件通过脚本转换为json文件，参考maneki/scripts/fix/enginelost.json
# 2.将json文件内容复制到线上任意机器maneki/scripts/fix目录下的enginelost.json中
# 3.重新build启动容器，进入任意容器进入shell环境，执行
from maneki.scripts.fix.fix_engine_user_create import run
run()
```
## 2.注册积分问题：

```bash
# 创建积分变动日志
UserMembersPointsLogs.objects.create(user_id='a0f6045f377849b4b9bd0aa5c6521be3',value=1000,points_source=101, remark='user activate at 2018-08-12 11:25:30.730829')

# 修改用户积分值
record = UserMembers.objects.filter(user_id='a0f6045f377849b4b9bd0aa5c6521be3').first()
record.member_points
3000
record.member_points=4000
record.save()

```
## 3.线上充值问题

```bash
# 查看记录状态，并确定引擎是否到账
record=CryptoDepositRecordLastThreeMonths.objects.filter(engine_sn='64f58df448cc420488b7e5980a497025').first()
record.status
2
# 充值，注意币种尤其是USDT和USD有个字的充值方法
from maneki.apps.engine.services.engine import EngineService
service = EngineService()
import uuid
request_id=uuid.uuid4().hex
service.deposit(request_id=request_id,amount='0.10952568',coin_type='BTC',username='b2814333cca742e7ba38d2a78306871e')
# 充值成功：
record.engine_request_no=request_id
record.status=0
record.save()
```
## 4.线上提现问题
***提现分法币和数字货币，注意USDT和USD之间的区别，USDT有自己的独有的充提RPC，查看异常记录注意记录状态，引擎是否扣款，链上是否打币，接上冻结后需要查看冻结状态。***

```bash
# 查找用户，engine_account_id为非uuid形式的为老用户
user = User.objects.filter(email='marketmaking.btcc@gmail.com').first()
user.engine_account_id
'988196'
# 查找记录
record=CryptoWithdrawRecordLastThreeMonths.objects.filter(user_id='1ce13436998747348ee9569ece8308f4').first()
from maneki.apps.engine.services.engine import EngineService
import uuid
service = EngineService()
request_id = uuid.uuid4().hex
# 调用RPC
service.withdraw_with_fee(request_id=request_id,coin_type='LTC',amount=record.tx_amount_fmt,fee=record.tx_fee_fmt,username=user.engine_account_id)
# 提现成功：
record.engine_request_no=request_id
record.status=0
record.save()
```
## 5.交易返佣积分问题，整天未统计情况
***先查看表maneki_agent_daily_count和maneki_agent_trade_count是否已经统计引擎交易手续费，如果没有需要执行下面步骤1和2，如果已经统计需要查看积分变动日志表points_source为108的是否有当时日期的记录，如果有说明已返佣，没有需执行步骤2。***

```bash
# 先查看统计表中当天引擎的的交易是否有统计（每天北京时间9点，UTC时间1点统计）
# 1.python shell 环境下运行
# 统计引擎交易产生的手续费
from engine_proxy.tasks.clear_daily_tx_fee import DailyTxFeeClearService
service = DailyTxFeeClearService(time_duration_start='开始统计时间', time_duration_end='统计结束时间')
service.process()
# 2.返佣（北京时间12点，UTC时间4点开始返佣，返前一天交易产生的积分）
from maneki.apps.market_agents.tasks.user_points_rebate import user_points_rebate_dalily
user_points_rebate_dalily()

```
