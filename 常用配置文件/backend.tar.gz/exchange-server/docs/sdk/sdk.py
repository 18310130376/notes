# -*- coding: utf-8 -*-
import logging
import hashlib
import hmac
import time
import secrets
from collections import OrderedDict
from urllib import parse as url_parse

logger = logging.getLogger(__name__)

"""
===============================================================
           BTCC exchange API_KEY 签名规则
===============================================================

说明:
    - 本SDK, 基于 Python 3.6+ 版本, 只依赖标准库.
    - 签名方式: API_KEY(public_key, secret_key) 
    - 签名算法: sha256
    - 签名字段: { nonce, timestamp, public_key } 
    - 请求字段: 
        - payload = { nonce, timestamp, public_key } + { API request_params(数据字段) } + { signature( 根据签名字段 + 数据字段计算出 ) }
    - signature 计算规则: 
        - payload = { nonce, timestamp, public_key } + { API 数据字段 }
        - 把 payload 的 k-v 值, 按key的字母顺序排序, 并拼接
        - 基于 sha256 + secret_key 计算生成 signature 值, 并补充到 payload 字典中
    - 验签规则:
        - 根据 payload 字典数据, 服务端重新算出 signature 值, 与API用户 payload 传入 signature 值比对.


"""


# 生成签名:
def generate_sign_sha256(payload: dict, secret_key: str):
    return _generate_signature(payload, secret_key, hashlib.sha256)


# 生成签名:
def _generate_signature(payload: dict, secret_key: str, sign_type: str):
    """ 生成签名

    :param payload: 待签名数据, type=dict
    :param secret_key: 私钥
    :param sign_type: 签名类型: [hashlib.sha512, hashlib.sha256]
    :return:
    """
    enc_payload = format_payload(payload)

    signed = hmac.new(
        bytes(secret_key, encoding='utf8'),
        bytes(enc_payload, encoding='utf8'),
        sign_type,
    ).hexdigest()
    return signed


# 格式化字段:
def format_payload(payload: dict, sign_field_name: str = "signature"):
    """格式化 k-v 参数对

    :param payload:
    :param sign_field_name: filter sign field
    :return:
    """
    payload = OrderedDict(payload)
    # fix: remove duplicate sign field
    if payload.get(sign_field_name):
        payload.pop(sign_field_name)

    logger.warning("sorted payload={}".format(payload))
    return url_parse.urlencode(payload)


def generate_timestamp_13bit():
    """ 13 位整数的毫秒时间戳
        - python 默认是10位, java默认是13位(毫秒级)
        - Unix 时间戳根据精度的不同，有 10 位（秒级），13 位（毫秒级），16 位（微妙级）和 19 位（纳秒级）
    :return:
    """
    ts = int(round(time.time() * 1000))
    # ts = time.time() * 1000
    # int(datetime.now().timestamp()) * 1000
    return ts


def generate_nonce_8bit(length=6):
    """生成随机字符串, 防止重放攻击

    secrets 包:
    - 只存在 python3.6+ 中,
    - 低版本, 可以移植该lib方法实现代码, 很简短

    :param length: =6, 返回长度为 8
    :return: ['1AieFdS1', 't1YCflcD']
    """
    return secrets.token_urlsafe(length)
