import requests

from docs.sdk.sdk import *

"""
====================
test run response:
====================

# HTTP GET:
sorted payload=OrderedDict([('nonce', 'dNiiOSMG'), ('timestamp', 1530503698419), ('public_key', 'tjAEJLfyMDz6dudUiDXg4TA9iU5yh-b4wnOWQFUX4QZcd4zJ_m9M7vLPP7aJCz2O')])
HTTP GET(raw): {'nonce': 'dNiiOSMG', 'timestamp': 1530503698419, 'public_key': 'tjAEJLfyMDz6dudUiDXg4TA9iU5yh-b4wnOWQFUX4QZcd4zJ_m9M7vLPP7aJCz2O'}
HTTP GET(with sign): {'nonce': 'dNiiOSMG', 'timestamp': 1530503698419, 'public_key': 'tjAEJLfyMDz6dudUiDXg4TA9iU5yh-b4wnOWQFUX4QZcd4zJ_m9M7vLPP7aJCz2O', 'signature': '975015282f832945fd7ffcd2b77fe0b4383876ac9e1f992396be951877a63d95'}
HTTP GET Response:  200 {'code': 200, 'detail': 'ok', 'data': [{'public_key': 'tjAEJLfyMDz6dudUiDXg4TA9iU5yh-b4wnOWQFUX4QZcd4zJ_m9M7vLPP7aJCz2O', 'secret_key': 'GKaPg-HOBJOtrHz6FbO-gT0tsTYQzrIWOH4vNkFCAuSbn90WUlZIzMnvE0RS3dJV', 'label': '他', 'permission': 1}]}

# HTTP POST:
sorted payload=OrderedDict([('label', 'test1'), ('permission', '1'), ('nonce', 'dNiiOSMG'), ('timestamp', 1530503698419), ('public_key', 'tjAEJLfyMDz6dudUiDXg4TA9iU5yh-b4wnOWQFUX4QZcd4zJ_m9M7vLPP7aJCz2O')])
HTTP POST(raw): {'label': 'test1', 'permission': '1', 'nonce': 'dNiiOSMG', 'timestamp': 1530503698419, 'public_key': 'tjAEJLfyMDz6dudUiDXg4TA9iU5yh-b4wnOWQFUX4QZcd4zJ_m9M7vLPP7aJCz2O'}
HTTP POST(with sign): {'label': 'test1', 'permission': '1', 'nonce': 'dNiiOSMG', 'timestamp': 1530503698419, 'public_key': 'tjAEJLfyMDz6dudUiDXg4TA9iU5yh-b4wnOWQFUX4QZcd4zJ_m9M7vLPP7aJCz2O', 'signature': '1a513149498cc3bfc80b9c1218f0d5763d643819fb00554551c3fd65af67618e'}
HTTP POST Response:  201 {'code': 200, 'detail': 'ok', 'data': {'public_key': 'KgBCDO9BRxPxfY68pTLPaD1nVzbjcmEXcmxCAKmu-QcCnZuCAx3WS_C3SDgmX8uw', 'secret_key': 'aGo5wMYRRnIFSoWFToGHlqWVYL_nRmxfNRf0O4plpUFbdSSRYKV7BcCKxXcqePQe', 'label': 'test1', 'user_id': '27839c8fec414a7d9a5e44c9cd25d090'}}


"""


def sdk_usage():
    url = "http://127.0.0.1:8000/api/v1/settings/api_key/"

    public_key = "tjAEJLfyMDz6dudUiDXg4TA9iU5yh-b4wnOWQFUX4QZcd4zJ_m9M7vLPP7aJCz2O"
    secret_key = "GKaPg-HOBJOtrHz6FbO-gT0tsTYQzrIWOH4vNkFCAuSbn90WUlZIzMnvE0RS3dJV"

    sign_params = {
        "nonce": generate_nonce_8bit(),
        "timestamp": generate_timestamp_13bit(),
        "public_key": public_key,
    }
    #########################################
    # HTTP-GET:
    #########################################
    get_params = {}
    get_params.update(sign_params)
    print("HTTP GET(raw):", get_params)
    get_params["signature"] = generate_sign_sha256(get_params, secret_key)
    print("HTTP GET(with sign):", get_params)
    #
    r = requests.get(url, params=get_params)
    print("HTTP GET Response: ", r.status_code, r.json())

    #########################################
    # HTTP-POST:
    #########################################
    post_params = {
        "label": "test1",
        "permission": "1"
    }
    post_params.update(sign_params)
    print("HTTP POST(raw):", post_params)
    post_params["signature"] = generate_sign_sha256(post_params, secret_key)
    print("HTTP POST(with sign):", post_params)
    #
    r = requests.post(url, data=post_params)
    print("HTTP POST Response: ", r.status_code, r.json())


if __name__ == '__main__':
    sdk_usage()
