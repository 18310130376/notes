
# reference:

## 加密货币:

### BTC:

- [bitcoin](https://en.wikipedia.org/wiki/Bitcoin)
- [比特币](https://zh.wikipedia.org/wiki/%E6%AF%94%E7%89%B9%E5%B8%81)
- 基本概念:
    - [Blockchain](https://bitcoin.org/en/developer-guide#block-chain)
    - [Transactions](https://bitcoin.org/en/developer-guide#transactions)
    - [Wallets](https://bitcoin.org/en/developer-guide#wallets)
    - [Mining](https://bitcoin.org/en/developer-guide#mining)
    - 合约[Contracts](https://bitcoin.org/en/developer-guide#contracts)
    - [Payment Processing](https://bitcoin.org/en/developer-guide#payment-processing)

### ETH:

- 官方项目[go-ethereum](https://github.com/ethereum/go-ethereum)
- 官方文档[ETH docs](http://ethdocs.org/en/latest/index.html)
- [Ethereum Virtual Machine](http://ethdocs.org/en/latest/introduction/what-is-ethereum.html#ethereum-virtual-machine)
- [ETH clients](http://ethdocs.org/en/latest/ethereum-clients/index.html)
- https://github.com/ethereum/pyethereum
- [Connecting to Ethereum Clients](http://ethdocs.org/en/latest/connecting-to-clients/index.html)
- [ETH 合约](http://ethdocs.org/en/latest/contracts-and-transactions/index.html)
- SDK:
    - [web3.js](https://github.com/ethereum/web3.js)
    - [web3.py](https://github.com/ethereum/web3.py)
- 针对ETH的开发都是基于 web3 项目.


## API:

## 测试链:

## 区块链浏览器:
